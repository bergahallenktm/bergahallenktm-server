# BergaHallen KTM Server — Standalone Quick Install

This is a **public standalone distribution** of BergaHallen KTM Server for users who want to run the Server/Webapp without the separate BergaHallen Installer/Manager.

> Runtime basis: frozen Server/Webapp `1.0.0-dev.5 / r2`.  
> Distribution wrapper: `github-standalone.2`.  
> This package does not change the canonical frozen project artifact.

## Fast install

Supported target:

- Ubuntu Server **24.04 LTS**
- **amd64 / x86_64**
- physical server or full VM
- a normal LAN IPv4 address
- Internet access during installation for Ubuntu/Docker packages and the Node base image

Unpack the release and run:

```bash
cd BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install
sudo ./install.sh
```

The script will:

1. install Docker Engine/Compose and required host tools if necessary;
2. select the host's normal LAN IPv4 address;
3. build the Server image from the included source;
4. create a new schema-21 database and stable server identity;
5. create a **per-installation local CA** and an HTTPS leaf certificate with the LAN IP as `iPAddress` SAN;
6. generate TLS State v2 and Pairing & Trust v2 data;
7. generate strong Server/session/admin credentials;
8. start the service on **HTTPS TCP/443**;
9. verify the Server health through the generated CA;
10. print the admin credentials and an Android pairing QR in the terminal.

Normal address after installation:

```text
https://<SERVER-LAN-IP>/
```

No `.local`, mDNS or custom DNS is required.

## Useful commands

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm pairing
sudo bergahallen-ktm logs
sudo bergahallen-ktm restart
sudo bergahallen-ktm ca-path
sudo bergahallen-ktm rebind-ip
```

If DHCP gives the server a new LAN address, run:

```bash
sudo bergahallen-ktm rebind-ip
```

This reissues only the leaf certificate and keeps the same local CA, so Android can retain the same pinned CA identity.

## Browser trust

The Server uses a private installation CA. Browsers will trust the HTTPS address only after that CA is installed in the client operating system/browser trust store.

Find the exported CA with:

```bash
sudo bergahallen-ktm ca-path
```

Do not bypass browser certificate warnings as the normal workflow.

## Android pairing

Run:

```bash
sudo bergahallen-ktm pairing
```

The command prints:

- canonical HTTPS LAN-IP endpoint;
- stable instance UID;
- CA SPKI SHA-256 fingerprint;
- credential-free Pairing Contract v2 JSON;
- a scannable terminal QR when `qrencode` supports the terminal.

No password or session token is included in the QR.

## Initial credentials

The installer creates a random admin password and prints it once. It is also stored temporarily in:

```text
/etc/bergahallen-ktm/FIRST-LOGIN.txt
```

This file is root-readable only (`0600`). Store the password safely and remove the file when you no longer need it.

## Data and security locations

```text
Application files:     /opt/bergahallen-ktm-server
Configuration/secrets: /etc/bergahallen-ktm
TLS identity:          /etc/bergahallen-ktm/tls
Exported CA:           /etc/bergahallen-ktm/export/bergahallen-ktm-ca.crt
Database:              Docker volume bergahallen-ktm-data
Privacy journal:       Docker volume bergahallen-ktm-privacy-journal
Privacy key:           Docker volume bergahallen-ktm-privacy-key
```

The CA private key is never mounted into the Server container. The Server receives only the CA certificate, leaf certificate, leaf private key and TLS state.

## Uninstall

Preserve database and TLS identity:

```bash
sudo bergahallen-ktm uninstall
```

Permanent purge, including data and TLS identity:

```bash
sudo bergahallen-ktm uninstall --purge-data
```

The purge option is destructive and cannot be undone unless you have your own backup.

## Important limitations

- This standalone distribution is intended for **fresh installs**.
- It is not an in-place upgrade mechanism for an Installer/Manager-managed installation.
- It does not expose the Server to the public Internet and does not configure router port forwarding.
- The underlying Suite runtime is still a development-line build (`1.0.0-dev.5`), so the GitHub release should be marked **Pre-release**.

For source architecture, API, privacy, backup and contract details, see `docs/`.

### Fresh-install safety after uninstall

A normal uninstall intentionally preserves persistent volumes and `/etc/bergahallen-ktm`. Because this distribution is fresh-install only, `install.sh` will refuse to overwrite those preserved assets. Use `--purge-data` only when you intentionally want a completely clean reinstall, or manage/backup the preserved data manually first.


## Uninstall and reinstall

`sudo bergahallen-ktm uninstall` removes the application files but intentionally preserves the database, privacy state, local CA and server identity. In **Standalone Quick Install 2** and newer, unpack the release again and run `sudo ./install.sh`; the preserved standalone state is detected automatically and restored with the same database, CA and `instance_uid`.

For a destructive clean removal use `sudo bergahallen-ktm uninstall --purge-data`. That deletes the Docker data volumes and local TLS identity so the next installation is completely fresh.
