#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=standalone/lib.sh
source "$SOURCE_DIR/standalone/lib.sh"

LAN_IP="${BERGAHALLEN_IP:-}"
TZ_VALUE="${BERGAHALLEN_TZ:-Europe/Stockholm}"
ADMIN_USER="${BERGAHALLEN_ADMIN_USER:-admin}"
REINSTALL=0

usage() {
  cat <<'EOF_USAGE'
Usage: sudo ./install.sh [--ip 192.168.1.50] [--timezone Europe/Stockholm]

Install BergaHallen KTM Server standalone.
A previous standalone uninstall that preserved data is detected automatically and
reinstalled with the same database, local CA, secrets and instance identity.
This installer does NOT modify an Installer/Manager-managed installation.
EOF_USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --ip) LAN_IP="${2:-}"; shift 2 ;;
    --timezone) TZ_VALUE="${2:-}"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

require_root

[[ -r /etc/os-release ]] || die "Cannot identify operating system."
# shellcheck disable=SC1091
source /etc/os-release
[[ "${ID:-}" == "ubuntu" ]] || die "Supported target: Ubuntu Server 24.04 LTS. Detected: ${PRETTY_NAME:-unknown}."
[[ "${VERSION_ID:-}" == "24.04" ]] || die "Supported target: Ubuntu Server 24.04 LTS. Detected: ${PRETTY_NAME:-unknown}."
[[ "$(dpkg --print-architecture)" == "amd64" ]] || die "This release supports amd64/x86_64 only."

# A normal standalone uninstall intentionally preserves /etc identity and Docker
# volumes. standalone.2 recognises that state and treats install.sh as a safe
# reinstall instead of rejecting the preserved installation.
if [[ -d "$APP_DIR" ]]; then
  die "An active BergaHallen KTM application directory already exists at $APP_DIR. Use the installed management command instead of overwriting it."
fi
if [[ -s "$INSTALL_STATE" && -d "$ETC_DIR" ]]; then
  if grep -Eq '"distribution"[[:space:]]*:[[:space:]]*"github_public_standalone"' "$INSTALL_STATE"; then
    REINSTALL=1
  else
    die "Existing BergaHallen KTM configuration is not a recognised standalone installation. Refusing to overwrite it."
  fi
elif [[ -e "$INSTALL_STATE" || -d "$ETC_DIR" ]]; then
  die "Existing BergaHallen KTM configuration is incomplete or not recognised. Refusing to overwrite it."
fi

info "Installing required host packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y ca-certificates curl openssl qrencode jq iproute2 docker.io
if apt-cache show docker-compose-v2 >/dev/null 2>&1; then
  apt-get install -y docker-compose-v2
elif apt-cache show docker-compose-plugin >/dev/null 2>&1; then
  apt-get install -y docker-compose-plugin
else
  die "Docker Compose v2 package is not available from the configured APT repositories."
fi
systemctl enable --now docker

docker info >/dev/null 2>&1 || die "Docker daemon is not reachable."
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is not available."

if docker ps -a --format '{{.Names}}' | grep -qx 'bergahallen-ktm'; then
  die "Docker container 'bergahallen-ktm' already exists; refusing to overwrite another installation."
fi

VOLUMES=(bergahallen-ktm-data bergahallen-ktm-privacy-journal bergahallen-ktm-privacy-key)
if (( REINSTALL )); then
  for volume in "${VOLUMES[@]}"; do
    docker volume inspect "$volume" >/dev/null 2>&1 || die "Preserved standalone state was found, but Docker volume '$volume' is missing. Refusing an unsafe partial reinstall."
  done
else
  for volume in "${VOLUMES[@]}"; do
    if docker volume inspect "$volume" >/dev/null 2>&1; then
      die "Docker volume '$volume' already exists without a recognised preserved standalone state. Refusing to reuse unknown data."
    fi
  done
fi

if ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq '(^|:)443$'; then
  die "TCP port 443 is already in use on this host."
fi

if (( REINSTALL )); then
  info "Detected a previous standalone uninstall with preserved data; entering safe reinstall mode."
  [[ -s "$ENV_FILE" ]] || die "Preserved server.env is missing."
  [[ -s "$TLS_DIR/ca.key" && -s "$TLS_DIR/ca.crt" && -s "$TLS_DIR/server.key" && -s "$TLS_DIR/server.crt" && -s "$TLS_DIR/tls-state.json" ]] || die "Preserved TLS identity is incomplete."
  STORED_UID="$(jq -r '.instance_uid // empty' "$INSTALL_STATE")"
  TLS_UID="$(jq -r '.instance_uid // empty' "$TLS_DIR/tls-state.json")"
  [[ "$STORED_UID" =~ ^[0-9a-fA-F-]{36}$ ]] || die "Preserved install state has an invalid instance UID."
  [[ "$STORED_UID" == "$TLS_UID" ]] || die "Preserved install state and TLS identity disagree."
  INSTANCE_UID="$STORED_UID"
  if [[ -z "$LAN_IP" ]]; then
    STORED_IP="$(jq -r '.selected_ip // empty' "$INSTALL_STATE")"
    if [[ -n "$STORED_IP" ]] && validate_ipv4 "$STORED_IP" && [[ -n "$(detect_interface_for_ip "$STORED_IP")" ]]; then
      LAN_IP="$STORED_IP"
    else
      LAN_IP="$(detect_default_ip || true)"
    fi
  fi
else
  if [[ -z "$LAN_IP" ]]; then
    LAN_IP="$(detect_default_ip || true)"
  fi
fi

[[ -n "$LAN_IP" ]] || die "Could not auto-detect a LAN IPv4 address. Re-run with --ip ADDRESS."
validate_ipv4 "$LAN_IP" || die "Invalid LAN IPv4 address: $LAN_IP"
IFACE="$(detect_interface_for_ip "$LAN_IP")"
[[ -n "$IFACE" ]] || die "The selected IP $LAN_IP is not assigned to a global host interface."

info "Selected LAN endpoint: https://$LAN_IP/ ($IFACE)"

install -d -m 0755 "$APP_DIR"
install -d -m 0755 "$ETC_DIR" "$EXPORT_DIR"
install -d -m 0700 "$TLS_DIR"

# Copy this release tree into /opt. Runtime secrets stay under /etc.
tar -C "$SOURCE_DIR" \
  --exclude='./.git' --exclude='./.env' --exclude='./*.db*' \
  -cf - . | tar -C "$APP_DIR" -xf -

if (( REINSTALL )); then
  info "Reusing preserved database, local CA, secrets and instance identity..."
  sed -i -E "s#^BERGAHALLEN_PREFERRED_URL=.*#BERGAHALLEN_PREFERRED_URL=https://$LAN_IP#" "$ENV_FILE"
else
  SESSION_SECRET="$(openssl rand -hex 32)"
  ADMIN_PASSWORD="$(openssl rand -hex 16)"
  cat > "$ENV_FILE" <<EOF_ENV
SESSION_SECRET=$SESSION_SECRET
ADMIN_USERNAME=$ADMIN_USER
ADMIN_PASSWORD=$ADMIN_PASSWORD
TZ=$TZ_VALUE
BERGAHALLEN_PREFERRED_URL=https://$LAN_IP
BERGAHALLEN_LAN_URL=
EOF_ENV
  chmod 0600 "$ENV_FILE"
fi

info "Building the Server image..."
cd "$APP_DIR"
docker compose --env-file "$ENV_FILE" -f docker-compose.yml -f docker-compose.standalone.yml build --pull

if (( REINSTALL )); then
  DB_UID="$(docker run --rm \
    -e NODE_ENV=development \
    -e BERGAHALLEN_TLS_MODE=disabled \
    -v bergahallen-ktm-data:/app/data \
    "$IMAGE_NAME" \
    node -e "const db=require('./server/db'); console.log('INSTANCE_UID='+db.instanceUid); db.close();" \
    | sed -n 's/^INSTANCE_UID=//p' | tail -n1)"
  [[ "$DB_UID" == "$INSTANCE_UID" ]] || die "Preserved database identity does not match the preserved standalone/TLS identity."

  CURRENT_IP="$(jq -r '.selected_ip // empty' "$TLS_DIR/tls-state.json")"
  CURRENT_IFACE="$(jq -r '.selected_interface // empty' "$TLS_DIR/tls-state.json")"
  if [[ "$CURRENT_IP" != "$LAN_IP" || "$CURRENT_IFACE" != "$IFACE" ]]; then
    info "LAN address changed since uninstall; reissuing leaf certificate under the same local CA..."
    OLD_FP="$(jq -r '.tls_ca_spki_sha256' "$TLS_DIR/tls-state.json")"
    issue_leaf_for_ip "$INSTANCE_UID" "$LAN_IP" "$IFACE"
    NEW_FP="$(jq -r '.tls_ca_spki_sha256' "$TLS_DIR/tls-state.json")"
    [[ "$OLD_FP" == "$NEW_FP" ]] || die "CA identity changed unexpectedly during reinstall."
  fi
  write_pairing

  TMP_STATE="$INSTALL_STATE.tmp"
  jq \
    --arg packaging_revision "github-standalone.2" \
    --arg ip "$LAN_IP" \
    --arg iface "$IFACE" \
    '.packaging_revision=$packaging_revision | .selected_ip=$ip | .selected_interface=$iface | .reinstalled_at=(now|todateiso8601)' \
    "$INSTALL_STATE" > "$TMP_STATE"
  chmod 0644 "$TMP_STATE"
  mv -f "$TMP_STATE" "$INSTALL_STATE"
else
  docker volume create bergahallen-ktm-data >/dev/null
  docker volume create bergahallen-ktm-privacy-journal >/dev/null
  docker volume create bergahallen-ktm-privacy-key >/dev/null

  info "Initializing a fresh schema-21 database and stable instance identity..."
  INIT_OUT="$(docker run --rm \
    -e NODE_ENV=development \
    -e BERGAHALLEN_TLS_MODE=disabled \
    -v bergahallen-ktm-data:/app/data \
    "$IMAGE_NAME" \
    node -e "const db=require('./server/db'); console.log('INSTANCE_UID='+db.instanceUid); db.close();")"
  INSTANCE_UID="$(sed -n 's/^INSTANCE_UID=//p' <<< "$INIT_OUT" | tail -n1)"
  [[ "$INSTANCE_UID" =~ ^[0-9a-fA-F-]{36}$ ]] || die "Could not initialize a valid instance UID."

  info "Creating per-installation local CA and HTTPS certificate..."
  openssl ecparam -name prime256v1 -genkey -noout -out "$TLS_DIR/ca.key"
  chmod 0600 "$TLS_DIR/ca.key"
  openssl req -x509 -new -sha256 \
    -key "$TLS_DIR/ca.key" \
    -days 3650 \
    -subj "/CN=BergaHallen KTM Local CA ${INSTANCE_UID:0:8}" \
    -addext "basicConstraints=critical,CA:TRUE" \
    -addext "keyUsage=critical,keyCertSign,cRLSign" \
    -addext "subjectKeyIdentifier=hash" \
    -out "$TLS_DIR/ca.crt"
  chmod 0644 "$TLS_DIR/ca.crt"
  issue_leaf_for_ip "$INSTANCE_UID" "$LAN_IP" "$IFACE"
  write_pairing

  jq -n \
    --arg packaging_revision "github-standalone.2" \
    --arg runtime_suite "1.0.0-dev.5" \
    --arg instance_uid "$INSTANCE_UID" \
    --arg ip "$LAN_IP" \
    --arg iface "$IFACE" \
    '{schema_version:1,distribution:"github_public_standalone",packaging_revision:$packaging_revision,runtime_suite_version:$runtime_suite,instance_uid:$instance_uid,selected_ip:$ip,selected_interface:$iface,installed_at:(now|todateiso8601)}' \
    > "$INSTALL_STATE"
  chmod 0644 "$INSTALL_STATE"
fi

info "Starting BergaHallen KTM Server..."
compose up -d

for _ in $(seq 1 60); do
  if healthcheck >/tmp/bergahallen-ktm-health.json 2>/dev/null; then
    break
  fi
  sleep 2
done
healthcheck >/tmp/bergahallen-ktm-health.json || {
  compose logs --tail=120 >&2 || true
  die "Server did not become healthy."
}

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
  ufw allow 443/tcp >/dev/null
  info "UFW: allowed TCP/443."
fi

install -m 0755 "$APP_DIR/standalone/bergahallen-ktm" /usr/local/bin/bergahallen-ktm

if (( ! REINSTALL )); then
  cat > "$ETC_DIR/FIRST-LOGIN.txt" <<EOF_LOGIN
BergaHallen KTM Server standalone installation

Server URL: https://$LAN_IP/
Admin username: $ADMIN_USER
Admin password: $ADMIN_PASSWORD

Android pairing:
  sudo bergahallen-ktm pairing

Browser CA certificate:
  $EXPORT_DIR/bergahallen-ktm-ca.crt

Keep this file private. Delete it after you have stored the password safely.
EOF_LOGIN
  chmod 0600 "$ETC_DIR/FIRST-LOGIN.txt"
fi

printf '\n============================================================\n'
if (( REINSTALL )); then
  printf 'BergaHallen KTM Server reinstalled successfully.\n'
  printf 'Existing database, CA and instance identity were preserved.\n'
else
  printf 'BergaHallen KTM Server installed successfully.\n'
fi
printf 'Server:   https://%s/\n' "$LAN_IP"
if (( ! REINSTALL )); then
  printf 'Admin:    %s\n' "$ADMIN_USER"
  printf 'Password: %s\n' "$ADMIN_PASSWORD"
  printf 'Details:  %s\n' "$ETC_DIR/FIRST-LOGIN.txt"
fi
printf '============================================================\n\n'
show_pairing
printf '\nUseful commands:\n'
printf '  sudo bergahallen-ktm status\n'
printf '  sudo bergahallen-ktm pairing\n'
printf '  sudo bergahallen-ktm logs\n'
printf '  sudo bergahallen-ktm rebind-ip\n'
printf '  sudo bergahallen-ktm uninstall\n\n'
