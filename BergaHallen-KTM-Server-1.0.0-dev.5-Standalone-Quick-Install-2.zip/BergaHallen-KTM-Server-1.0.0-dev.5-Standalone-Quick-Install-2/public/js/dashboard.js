import { fetchPlayers, fetchAllDecks, fetchStatsV2, fetchMatchHistoryPage, fetchMatchHistory, fetchActiveMatches } from './api.js';
import { t, formatDateTime, formatDurationSeconds } from './i18n.js';
import { matchFormatLabel, matchPlayModeLabel } from './matchFormatUi.js';

export let players = [];
export let allDecks = [];
export let activeMatches = [];

let analyticsFilters = {};
let historyPageOffset = 0;
const historyPageSize = 25;
let analyticsControlsBound = false;
let lastStatsV2 = null;
let lastHistoryPage = null;

let participantLimits = { min: 2, max: 6, recommended: 4 };
let deckSelectionMode = 'required';

export function getMatchPlayMode() {
  return document.getElementById('matchPlayMode')?.value || 'ffa';
}

export function getMatchTeamMode() {
  return ['teams','two_headed_giant','emperor','archenemy','archenemy_commander'].includes(getMatchPlayMode()) ? 'teams' : 'ffa';
}

export function setMatchDeckSelectionMode(mode = 'required') {
  deckSelectionMode = mode === 'optional' || mode === 'not_applicable' ? mode : 'required';
  refreshParticipantDropdowns();
}

export function getMatchDeckSelectionMode() {
  return deckSelectionMode;
}

function currentLimitedFormatKey() {
  return document.getElementById('matchLimitedFormat')?.value || '';
}

function specialTeamPreset(mode, rowCount) {
  const limited = currentLimitedFormatKey();
  if (limited === 'team_draft') return [1,1,1,2,2,2];
  if (limited === 'team_sealed') return Array.from({length:rowCount}, (_,i) => i < Math.ceil(rowCount / 2) ? 1 : 2);
  if (mode === 'two_headed_giant') return [1,1,2,2];
  if (mode === 'emperor') return [1,1,1,2,2,2];
  if (mode === 'archenemy' || mode === 'archenemy_commander') return Array.from({length:rowCount}, (_,i) => i === 0 ? 1 : 2);
  return null;
}

function roleForRow(mode, index, teamNumber) {
  if (mode === 'emperor') {
    const teamIndexes = [...document.querySelectorAll('.participant-row')]
      .map((row,i) => ({i, team:Number(row.querySelector('.team-select')?.value || 0)}))
      .filter(x => x.team === Number(teamNumber)).map(x => x.i);
    const pos = teamIndexes.indexOf(index);
    return pos === 1 ? 'emperor' : 'general';
  }
  if (mode === 'archenemy' || mode === 'archenemy_commander') return Number(teamNumber) === 1 ? 'archenemy' : 'hero';
  if (mode === 'two_headed_giant') return 'head';
  return null;
}


function participantRowsAreEmpty() {
  return [...document.querySelectorAll('.participant-row')].every(row =>
    !Number(row.querySelector('.player-select')?.value || 0) &&
    !Number(row.querySelector('.deck-select')?.value || 0)
  );
}

export function setMatchBuilderParticipantLimits({ min = 2, max = 6, recommended = 2 } = {}, { adjustEmpty = true } = {}) {
  participantLimits = {
    min: Math.max(2, Math.min(8, Number(min) || 2)),
    max: Math.max(2, Math.min(8, Number(max) || 8)),
    recommended: Math.max(2, Math.min(8, Number(recommended) || 2))
  };
  if (participantLimits.min > participantLimits.max) participantLimits.min = participantLimits.max;
  participantLimits.recommended = Math.max(participantLimits.min, Math.min(participantLimits.max, participantLimits.recommended));
  if (adjustEmpty && participantRowsAreEmpty()) setParticipantRowCount(participantLimits.recommended, { onlyIfEmpty: true });
}

export function setParticipantRowCount(target, { onlyIfEmpty = true } = {}) {
  const container = document.getElementById('participantsContainer');
  if (!container) return;
  if (onlyIfEmpty && !participantRowsAreEmpty()) return;
  const desired = Math.max(participantLimits.min, Math.min(participantLimits.max, Number(target) || participantLimits.recommended));
  while (container.querySelectorAll('.participant-row').length < desired) addParticipantRow();
  while (container.querySelectorAll('.participant-row').length > desired) {
    container.lastElementChild?.remove();
  }
  refreshParticipantDropdowns();
}

function teamOptions(selectedTeam = 1) {
  return Array.from({ length: 8 }, (_, i) => i + 1)
    .map(team => `<option value="${team}" ${team === Number(selectedTeam) ? 'selected' : ''}>${t('team.team', { number: team })}</option>`)
    .join('');
}

function suggestedTeamNumber() {
  const counts = new Map([[1, 0], [2, 0]]);
  document.querySelectorAll('.team-select').forEach(select => {
    const n = Number(select.value || 1);
    counts.set(n, (counts.get(n) || 0) + 1);
  });
  const candidates = [...counts.entries()].sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  return candidates[0]?.[0] || 1;
}

export function updateTeamBuilderUI() {
  const teamMode = getMatchTeamMode();
  const panel = document.getElementById('teamBuilderPanel');
  if (panel) panel.classList.toggle('hidden', teamMode !== 'teams');

  document.querySelectorAll('.team-select-wrap').forEach(el => el.classList.toggle('hidden', teamMode !== 'teams'));
  document.querySelectorAll('.participant-row').forEach(row => row.classList.toggle('team-mode-row', teamMode === 'teams'));

  const selectedRows = [...document.querySelectorAll('.participant-row')]
    .filter(row => Number(row.querySelector('.player-select')?.value || 0));
  const counts = new Map();
  selectedRows.forEach(row => {
    const team = Number(row.querySelector('.team-select')?.value || 1);
    counts.set(team, (counts.get(team) || 0) + 1);
  });

  const ordered = [...counts.entries()].sort((a, b) => a[0] - b[0]);
  const summary = document.getElementById('teamSummary');
  const shape = document.getElementById('teamMatchShape');
  if (summary) {
    summary.innerHTML = ordered.length
      ? ordered.map(([team, count]) => `<span class="team-summary-chip">${t('team.summary', { team, number: team, count })}</span>`).join('')
      : `<span class="text-gray-500">${t('team.summary_empty')}</span>`;
  }
  if (shape) {
    shape.textContent = ordered.length >= 2 ? ordered.map(([, count]) => count).join('v') : t('team.choose_two');
    const validShape = ordered.length >= 2 && ordered.length < selectedRows.length;
    shape.classList.toggle('text-green-400', validShape);
    shape.classList.toggle('text-amber-400', !validShape);
  }
}

export function setMatchTeamMode() {
  const mode = getMatchPlayMode();
  const rows = [...document.querySelectorAll('.participant-row')];
  const preset = specialTeamPreset(mode, rows.length);

  if (getMatchTeamMode() === 'teams') {
    rows.forEach((row, index) => {
      const select = row.querySelector('.team-select');
      if (!select) return;
      if (preset) {
        select.value = String(preset[index] || preset[preset.length - 1] || 1);
        select.disabled = true;
        select.dataset.specialPreset = '1';
      } else {
        select.disabled = false;
        delete select.dataset.specialPreset;
        if (!select.dataset.userChanged) select.value = String((index % 2) + 1);
      }
    });
  } else {
    rows.forEach(row => {
      const select = row.querySelector('.team-select');
      if (select) { select.disabled = false; delete select.dataset.specialPreset; }
    });
  }

  rows.forEach((row,index) => {
    const hint = row.querySelector('.role-hint');
    if (!hint) return;
    const team = Number(row.querySelector('.team-select')?.value || index + 1);
    const role = roleForRow(mode,index,team);
    hint.textContent = role ? t(`role.${role}`) : '';
    hint.classList.toggle('hidden', !role);
  });
  updateTeamBuilderUI();
}

export function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatHistoryTime(value) {
  if (!value) return '';
  const raw = String(value);
  const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T') + 'Z';
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return '';
  return formatDateTime(date.toISOString(), {
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}

function getBusyPlayerIds() {
  return new Set(activeMatches.flatMap(match => (match.players || []).map(p => Number(p.player_id))));
}

function getBusyDeckIds() {
  return new Set(activeMatches.flatMap(match => (match.players || []).map(p => Number(p.deck_id))));
}

function getSelectedValues(selectorClass, exceptSelect = null) {
  return new Set(
    [...document.querySelectorAll(selectorClass)]
      .filter(select => select !== exceptSelect && select.value)
      .map(select => Number(select.value))
  );
}

function buildPlayerOptions(currentSelect) {
  const currentValue = Number(currentSelect?.value || 0);
  const busy = getBusyPlayerIds();
  const selectedElsewhere = getSelectedValues('.player-select', currentSelect);

  return players
    .filter(player => {
      const id = Number(player.id);
      return !busy.has(id) && (id === currentValue || !selectedElsewhere.has(id));
    })
    .map(player => `<option value="${player.id}">${escapeHtml(player.name)}</option>`)
    .join('');
}

function buildDeckOptions(currentSelect) {
  const currentValue = Number(currentSelect?.value || 0);
  const busy = getBusyDeckIds();
  const selectedElsewhere = getSelectedValues('.deck-select', currentSelect);

  return allDecks
    .filter(deck => {
      const id = Number(deck.id);
      return !busy.has(id) && (id === currentValue || !selectedElsewhere.has(id));
    })
    .map(deck => `<option value="${deck.id}">${escapeHtml(deck.name)} (${escapeHtml(deck.owner_name)})</option>`)
    .join('');
}

export function refreshParticipantDropdowns() {
  document.querySelectorAll('.player-select').forEach(select => {
    const previous = select.value;
    select.innerHTML = `${`<option value="">${t('validation.choose_player')}</option>`}${buildPlayerOptions(select)}`;
    if (previous && [...select.options].some(o => o.value === previous)) select.value = previous;
  });

  document.querySelectorAll('.deck-select').forEach(select => {
    const previous = select.value;
    const placeholder = deckSelectionMode === 'required' ? t('validation.choose_deck') : t('validation.choose_deck_optional');
    select.innerHTML = `${`<option value="">${placeholder}</option>`}${buildDeckOptions(select)}`;
    select.dataset.selectionMode = deckSelectionMode;
    if (previous && [...select.options].some(o => o.value === previous)) select.value = previous;
  });
  updateTeamBuilderUI();
}

export async function refreshMatchAvailability() {
  activeMatches = await fetchActiveMatches();
  refreshParticipantDropdowns();
  return activeMatches;
}

function selectedValue(id) {
  return document.getElementById(id)?.value || '';
}

function collectAnalyticsFilters() {
  return {
    from: selectedValue('statsFilterFrom'),
    to: selectedValue('statsFilterTo'),
    player_uid: selectedValue('statsFilterPlayer'),
    deck_uid: selectedValue('statsFilterDeck'),
    match_profile: selectedValue('statsFilterProfile'),
    play_mode: selectedValue('statsFilterPlayMode'),
    limited_format: selectedValue('statsFilterLimited'),
    modifier: selectedValue('statsFilterModifier')
  };
}

function option(value, label, selected = '') {
  return `<option value="${escapeHtml(value)}" ${String(value) === String(selected) ? 'selected' : ''}>${escapeHtml(label)}</option>`;
}

function populateAnalyticsFilters(stats) {
  const current = collectAnalyticsFilters();
  const setOptions = (id, rows, valueKey, labelFn, emptyLabel) => {
    const el = document.getElementById(id);
    if (!el) return;
    const old = current[id === 'statsFilterPlayer' ? 'player_uid' : id === 'statsFilterDeck' ? 'deck_uid' : id === 'statsFilterProfile' ? 'match_profile' : id === 'statsFilterPlayMode' ? 'play_mode' : id === 'statsFilterLimited' ? 'limited_format' : 'modifier'] || '';
    el.innerHTML = option('', emptyLabel, old) + rows.map(row => option(row[valueKey], labelFn(row), old)).join('');
  };

  setOptions('statsFilterPlayer', players.filter(p => !p.is_admin), 'entity_uid', p => p.name, t('stats2.all_players'));
  setOptions('statsFilterDeck', allDecks, 'entity_uid', d => `${d.name}${d.owner_name ? ` · ${d.owner_name}` : ''}`, t('stats2.all_decks'));
  setOptions('statsFilterProfile', stats?.matchProfileStats || [], 'match_profile', row => t(`matchProfile.${row.match_profile}`, {}, row.match_profile), t('stats2.all_profiles'));
  setOptions('statsFilterPlayMode', stats?.playModeStats || [], 'play_mode', row => matchPlayModeLabel({ play_mode: row.play_mode, team_mode: row.team_mode }), t('stats2.all_play_modes'));
  setOptions('statsFilterLimited', stats?.limitedFormatStats || [], 'limited_format', row => t(`limitedFormat.${row.limited_format}`, {}, row.limited_format), t('stats2.all_limited'));
  setOptions('statsFilterModifier', stats?.modifierStats || [], 'modifier', row => t(`modifier.${row.modifier}`, {}, row.modifier), t('stats2.all_modifiers'));
}

function renderHistoryPage(page) {
  lastHistoryPage = page;
  renderMatches(Array.isArray(page?.items) ? page.items : []);
  const info = document.getElementById('historyPageInfo');
  const prev = document.getElementById('historyPrevBtn');
  const next = document.getElementById('historyNextBtn');
  const total = Number(page?.total || 0);
  const offset = Number(page?.offset || 0);
  const count = Array.isArray(page?.items) ? page.items.length : 0;
  if (info) info.textContent = total ? t('stats2.history_range', { from: offset + 1, to: offset + count, total }) : t('stats2.history_empty');
  if (prev) prev.disabled = offset <= 0;
  if (next) next.disabled = !page?.has_more;
}

export async function refreshAnalytics({ resetPage = false } = {}) {
  if (resetPage) historyPageOffset = 0;
  analyticsFilters = collectAnalyticsFilters();
  const [stats, history] = await Promise.all([
    fetchStatsV2(analyticsFilters),
    fetchMatchHistoryPage(analyticsFilters, { limit: historyPageSize, offset: historyPageOffset })
  ]);
  lastStatsV2 = stats;
  if (stats) renderStats(stats);
  if (history) renderHistoryPage(history);
}

function bindAnalyticsControls() {
  if (analyticsControlsBound) return;
  analyticsControlsBound = true;
  document.getElementById('statsFilterApplyBtn')?.addEventListener('click', () => refreshAnalytics({ resetPage: true }).catch(console.error));
  document.getElementById('statsFilterResetBtn')?.addEventListener('click', () => {
    ['statsFilterFrom','statsFilterTo','statsFilterPlayer','statsFilterDeck','statsFilterProfile','statsFilterPlayMode','statsFilterLimited','statsFilterModifier'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    analyticsFilters = {};
    refreshAnalytics({ resetPage: true }).catch(console.error);
  });
  document.getElementById('historyPrevBtn')?.addEventListener('click', () => {
    historyPageOffset = Math.max(0, historyPageOffset - historyPageSize);
    refreshAnalytics().catch(console.error);
  });
  document.getElementById('historyNextBtn')?.addEventListener('click', () => {
    if (!lastHistoryPage?.has_more) return;
    historyPageOffset += historyPageSize;
    refreshAnalytics().catch(console.error);
  });
}

export async function loadDashboardData() {
  try {
    const [pData, dData, sData, mData, activeData] = await Promise.all([
      fetchPlayers(), fetchAllDecks(), fetchStatsV2(), fetchMatchHistoryPage({}, { limit: historyPageSize, offset: 0 }), fetchActiveMatches()
    ]);
    players = pData;
    allDecks = dData;
    activeMatches = Array.isArray(activeData) ? activeData : [];
    lastStatsV2 = sData;
    historyPageOffset = 0;
    analyticsFilters = {};
    renderMatchForm();
    populateAnalyticsFilters(sData);
    bindAnalyticsControls();
    if (sData) renderStats(sData);
    if (mData) renderHistoryPage(mData);
  } catch (e) {
    console.error('Dashboard Load Error:', e);
  }
}

export function renderMatchForm() {
  const container = document.getElementById('participantsContainer');
  if (!container) return;
  container.innerHTML = '';
  for (let i = 0; i < participantLimits.recommended; i++) addParticipantRow();
  setMatchTeamMode();
}

export function addParticipantRow() {
  const container = document.getElementById('participantsContainer');
  if (!container) return;
  if (container.querySelectorAll('.participant-row').length >= participantLimits.max) {
    alert(t('validation.max_players_dynamic', { count: participantLimits.max }));
    return;
  }

  const defaultTeam = suggestedTeamNumber();
  const div = document.createElement('div');
  div.className = 'participant-row grid grid-cols-2 sm:grid-cols-4 gap-2 bg-gray-800 p-2 rounded-lg border border-gray-700/70';
  div.innerHTML = `
    <select aria-label="${escapeHtml(t('validation.choose_player'))}" class="player-select p-2 rounded bg-gray-700 border border-gray-600 text-sm min-w-0">
      <option value="">${t('validation.choose_player')}</option>
    </select>
    <select aria-label="${escapeHtml(deckSelectionMode === 'required' ? t('validation.choose_deck') : t('validation.choose_deck_optional'))}" class="deck-select p-2 rounded bg-gray-700 border border-gray-600 text-sm min-w-0">
      <option value="">${deckSelectionMode === 'required' ? t('validation.choose_deck') : t('validation.choose_deck_optional')}</option>
    </select>
    <div class="team-select-wrap ${getMatchTeamMode() === 'teams' ? '' : 'hidden'}">
      <select aria-label="${escapeHtml(t('a11y.team_select'))}" class="team-select w-full p-2 rounded bg-gray-900 border border-amber-500/40 text-sm font-bold text-amber-300">
        ${teamOptions(defaultTeam)}
      </select>
    </div>
    <button type="button" class="remove-participant-btn bg-gray-900 hover:bg-red-950 border border-gray-700 hover:border-red-700 text-gray-400 hover:text-red-300 rounded px-3 py-2 text-sm font-bold transition-all" title="${t('validation.remove_player_title')}" aria-label="${t('validation.remove_row')}">${t('validation.remove_player')}</button>
    <div class="role-hint hidden col-span-2 sm:col-span-4 text-xs font-bold text-amber-300"></div>
    <div class="col-span-2 sm:col-span-4 text-xs text-red-400 validation-error hidden"></div>
  `;

  // Deck-listan filtreras medvetet INTE på ägare. Familjemedlemmar får låna
  // varandras kortlekar. Vi filtrerar bara bort kortlekar som redan används
  // i en aktiv match eller som redan valts i en annan rad i matchbyggaren.
  container.appendChild(div);

  div.querySelector('.player-select').addEventListener('change', () => {
    refreshParticipantDropdowns();
    updateTeamBuilderUI();
  });
  div.querySelector('.deck-select').addEventListener('change', refreshParticipantDropdowns);
  div.querySelector('.team-select').addEventListener('change', (event) => {
    if (!event.currentTarget.dataset.specialPreset) event.currentTarget.dataset.userChanged = '1';
    setMatchTeamMode();
  });
  div.querySelector('.remove-participant-btn').addEventListener('click', () => {
    const rows = container.querySelectorAll('.participant-row');
    if (rows.length <= participantLimits.min) {
      alert(t('validation.min_rows_dynamic', { count: participantLimits.min }));
      return;
    }
    div.remove();
    refreshParticipantDropdowns();
  });
  refreshParticipantDropdowns();
  setMatchTeamMode();
}

export function renderStats(s) {
  if (!s || !s.playerStats) return;

  const summaryOutput = document.getElementById('statsSummaryOutput');
  if (summaryOutput) {
    const sum = s.summary || {};
    const cards = [
      ['🎮', t('stats2.summary_matches'), Number(sum.total_matches || 0)],
      ['👤', t('stats2.summary_players'), Number(sum.distinct_players || 0)],
      ['🃏', t('stats2.summary_decks'), Number(sum.distinct_decks || 0)],
      ['⏱️', t('stats2.summary_avg'), sum.avg_seconds == null ? '—' : formatDurationSeconds(sum.avg_seconds)]
    ];
    summaryOutput.innerHTML = cards.map(([icon,label,value]) => `
      <div class="bg-gray-950/70 border border-gray-700 rounded-lg p-3">
        <div class="text-[11px] uppercase tracking-wide text-gray-500">${icon} ${escapeHtml(label)}</div>
        <div class="text-xl font-black text-amber-300 mt-1">${escapeHtml(value)}</div>
      </div>
    `).join('');
  }

  document.getElementById('playerStatsOutput').innerHTML = s.playerStats.map(p => `
    <div class="bg-gray-800 p-3 rounded-lg border border-gray-700 space-y-1 hover:border-amber-500/50 transition-all">
      <div class="flex justify-between items-center">
        <span class="font-bold text-amber-400">${escapeHtml(p.name)}${p.deleted ? ` <span class="text-[10px] text-red-300">(${t('common.deleted')})</span>` : p.archived ? ` <span class="text-[10px] text-gray-400">(${t('common.archived')})</span>` : ''}</span>
        <div class="flex items-center gap-2">
          <div class="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
            <div class="h-full bg-gradient-to-r from-amber-600 to-amber-400 rounded-full" style="width: ${p.win_rate}%"></div>
          </div>
          <span class="text-xs font-bold text-amber-400">${p.win_rate}%</span>
        </div>
      </div>
      <div class="flex justify-between text-xs text-gray-300">
        <span>${t('stats.matches', { count: p.total_games })}</span>
        <span>🏆 ${p.wins} | 💀 ${p.losses}</span>
      </div>
      <div class="text-xs text-gray-400">
        ${t('stats.best_deck')} <span class="text-amber-300 font-medium">${p.best_deck_name
          ? escapeHtml(t('stats.best_deck_value', {
              name: p.best_deck_name,
              deleted: p.best_deck_deleted ? t('stats.deleted_suffix') : '',
              rate: p.best_deck_win_rate ?? 0
            }))
          : t('stats.no_games')}</span>
      </div>
    </div>
  `).join('');

  document.getElementById('deckStatsOutput').innerHTML = s.deckStats.map(d => `
    <div class="bg-gray-800 p-3 rounded-lg border border-gray-700 space-y-1 hover:border-amber-500/50 transition-all">
      <div class="flex justify-between items-center">
        <div>
          <span class="font-bold text-amber-400">${escapeHtml(d.deck_name)}</span>
          <span class="text-xs text-gray-400">(${escapeHtml(d.owner_name)})${d.deleted ? ` · ${t('common.deleted')}` : d.archived ? ` · ${t('common.archived')}` : ''}</span>
        </div>
        <div class="flex items-center gap-2">
          <div class="w-12 h-2 bg-gray-700 rounded-full overflow-hidden">
            <div class="h-full bg-gradient-to-r from-green-600 to-green-400 rounded-full" style="width: ${d.win_rate}%"></div>
          </div>
          <span class="text-xs font-bold text-green-400">${d.win_rate}%</span>
        </div>
      </div>
      <div class="flex justify-between text-xs text-gray-300">
        <span>${t('stats.games_wins', { games: d.total_games, wins: d.wins })}</span>
        <span>⏱️ ${formatDurationSeconds(d.avg_seconds)}</span>
      </div>
    </div>
  `).join('');

  document.getElementById('matchupsOutput').innerHTML = s.matchups && s.matchups.length ? s.matchups.map(m => `
    <div class="bg-gray-800 p-2.5 rounded border border-gray-700 flex justify-between items-center hover:border-amber-500/50 transition-all">
      <span class="font-semibold text-gray-200 text-sm">${escapeHtml(m.deck1)}${m.deck1_deleted ? ` <span class="text-[10px] text-red-300">(${t('common.deleted')})</span>` : ''} <span class="text-xs text-gray-500">${t('common.vs')}</span> ${escapeHtml(m.deck2)}${m.deck2_deleted ? ` <span class="text-[10px] text-red-300">(${t('common.deleted')})</span>` : ''}</span>
      <span class="text-xs font-bold text-amber-400 bg-gray-900 px-2 py-1 rounded">${t('stats.matchup_count', { count: m.total })} (${m.deck1_wins}-${m.deck2_wins}${m.neither_won ? ` · ${t('stats.no_winner', { count: m.neither_won })}` : ''})</span>
    </div>
  `).join('') : `<div class="text-xs text-gray-500">${t('stats.no_matchups')}</div>`;

  const playModeOutput = document.getElementById('playModeStatsOutput');
  if (playModeOutput) {
    const modeStats = Array.isArray(s.playModeStats) ? s.playModeStats : [];
    playModeOutput.innerHTML = modeStats.length ? modeStats.map(mode => `
      <div class="bg-gray-800 p-3 rounded-lg border border-gray-700 flex items-center justify-between gap-3 hover:border-amber-500/50 transition-all">
        <div class="min-w-0">
          <div class="font-bold text-amber-400 truncate">${escapeHtml(matchPlayModeLabel({ play_mode: mode.play_mode, team_mode: mode.team_mode }))}</div>
          <div class="text-xs text-gray-400">${escapeHtml(t('stats.play_mode_share', { share: mode.share_percent }))}</div>
        </div>
        <span class="text-xs font-bold text-amber-300 bg-gray-900 px-2 py-1 rounded whitespace-nowrap">${escapeHtml(t('stats.play_mode_count', { count: mode.total_matches }))}</span>
      </div>
    `).join('') : `<div class="text-xs text-gray-500">${t('stats.no_play_modes')}</div>`;
  }

  const limitedOutput = document.getElementById('limitedFormatStatsOutput');
  if (limitedOutput) {
    const rows = Array.isArray(s.limitedFormatStats) ? s.limitedFormatStats : [];
    limitedOutput.innerHTML = rows.length ? rows.map(row => `
      <div class="bg-gray-800 p-2.5 rounded border border-gray-700 flex justify-between items-center gap-2">
        <span class="font-semibold text-amber-300">${escapeHtml(t(`limitedFormat.${row.limited_format}`, {}, row.limited_format))}</span>
        <span class="text-xs text-gray-300">${escapeHtml(t('stats.format_count_share', { count: row.total_matches, share: row.share_percent }))}</span>
      </div>
    `).join('') : `<div class="text-xs text-gray-500">${t('stats.no_limited_formats')}</div>`;
  }

  const modifierOutput = document.getElementById('modifierStatsOutput');
  if (modifierOutput) {
    const rows = Array.isArray(s.modifierStats) ? s.modifierStats : [];
    modifierOutput.innerHTML = rows.length ? rows.map(row => `
      <div class="bg-gray-800 p-2.5 rounded border border-gray-700 flex justify-between items-center gap-2">
        <span class="font-semibold text-amber-300">🌀 ${escapeHtml(t(`modifier.${row.modifier}`, {}, row.modifier))}</span>
        <span class="text-xs text-gray-300">${escapeHtml(t('stats.format_count_share', { count: row.total_matches, share: row.share_percent }))}</span>
      </div>
    `).join('') : `<div class="text-xs text-gray-500">${t('stats.no_modifiers')}</div>`;
  }

  const dayNightOutput = document.getElementById('dayNightStatsOutput');
  if (dayNightOutput) {
    const dn = s.dayNightStats || {};
    const most = dn.most_switches_match;
    const cards = [
      ['🔁', t('stats.day_night_switches'), Number(dn.switches || 0)],
      ['☀️→🌙', t('stats.day_to_night'), Number(dn.day_to_night || 0)],
      ['🌙→☀️', t('stats.night_to_day'), Number(dn.night_to_day || 0)],
      ['🎮', t('stats.day_night_matches'), Number(dn.matches_with_day_night || 0)],
      ['✨', t('stats.day_night_establishments'), Number(dn.establishments || 0)],
      ['📊', t('stats.day_night_average'), Number(dn.avg_switches_per_tracked_match || 0)],
      ['☀️', t('stats.final_day'), Number(dn.final_day_matches || 0)],
      ['🌙', t('stats.final_night'), Number(dn.final_night_matches || 0)]
    ];
    dayNightOutput.innerHTML = cards.map(([icon,label,value]) => `
      <div class="bg-gray-800 p-3 rounded-lg border border-gray-700">
        <div class="text-[11px] uppercase tracking-wide text-gray-500">${icon} ${escapeHtml(label)}</div>
        <div class="text-xl font-black text-amber-300 mt-1">${escapeHtml(value)}</div>
      </div>
    `).join('') + (most && Number(most.switches || 0) > 0 ? `
      <div class="col-span-2 md:col-span-4 bg-gray-950/70 p-3 rounded-lg border border-indigo-500/30 text-xs text-gray-300">
        ${escapeHtml(t('stats.day_night_most', {
          id: most.match_id,
          count: most.switches,
          table: most.table_name ? ` · ${most.table_name}` : ''
        }))}
      </div>
    ` : '');
  }

  const playerDeckOutput = document.getElementById('playerDeckStatsOutput');
  if (playerDeckOutput) {
    const rows = Array.isArray(s.playerDeckStats) ? s.playerDeckStats : [];
    playerDeckOutput.innerHTML = rows.length ? rows.map(row => `
      <div class="bg-gray-800 p-3 rounded-lg border border-gray-700 space-y-1">
        <div class="font-bold text-amber-300">${escapeHtml(row.player_name)} <span class="text-gray-500">+</span> ${escapeHtml(row.deck_name)}</div>
        <div class="text-[11px] text-gray-500">${escapeHtml(row.deck_owner_name || '')}</div>
        <div class="flex justify-between text-xs text-gray-300"><span>${escapeHtml(t('stats.matches', { count: row.total_games }))}</span><span>🏆 ${row.wins} · ${row.win_rate}%</span></div>
      </div>
    `).join('') : `<div class="text-xs text-gray-500">${t('stats2.no_player_decks')}</div>`;
  }

  const formatOutput = document.getElementById('formatStatsOutput');
  if (formatOutput) {
    const profiles = Array.isArray(s.matchProfileStats) ? s.matchProfileStats : [];
    const decks = Array.isArray(s.deckFormatStats) ? s.deckFormatStats : [];
    const rows = [
      ...profiles.map(row => ({ icon:'🧭', label:t(`matchProfile.${row.match_profile}`, {}, row.match_profile), count:row.total_matches, share:row.share_percent })),
      ...decks.map(row => ({ icon:'🃏', label:t(`deckFormat.${row.deck_format}`, {}, row.deck_format), count:row.total_matches, share:row.share_percent }))
    ];
    formatOutput.innerHTML = rows.length ? rows.map(row => `
      <div class="bg-gray-800 p-2.5 rounded border border-gray-700 flex justify-between items-center gap-2">
        <span class="font-semibold text-gray-200">${row.icon} ${escapeHtml(row.label)}</span>
        <span class="text-xs text-gray-400">${escapeHtml(t('stats.format_count_share', { count:row.count, share:row.share }))}</span>
      </div>
    `).join('') : `<div class="text-xs text-gray-500">${t('stats2.no_formats')}</div>`;
  }

  const trendOutput = document.getElementById('trendStatsOutput');
  if (trendOutput) {
    const rows = Array.isArray(s.trendStats) ? s.trendStats : [];
    const max = Math.max(1, ...rows.map(row => Number(row.total_matches || 0)));
    trendOutput.innerHTML = rows.length ? rows.map(row => `
      <div class="space-y-1">
        <div class="flex justify-between text-xs"><span class="font-semibold text-gray-300">${escapeHtml(row.period)}</span><span class="text-amber-300">${escapeHtml(t('stats2.trend_matches', { count:row.total_matches }))}</span></div>
        <div class="h-2 bg-gray-800 rounded overflow-hidden"><div class="h-full bg-amber-500/70 rounded" style="width:${Math.max(3, Math.round(Number(row.total_matches || 0)/max*100))}%"></div></div>
      </div>
    `).join('') : `<div class="text-xs text-gray-500">${t('stats2.no_trends')}</div>`;
  }
}

export function renderMatches(m) {
  if (!m || !Array.isArray(m)) return;
  
  document.getElementById('matchHistoryOutput').innerHTML = m.map((match, index) => {
    const winner = match.players.find(p => p.is_winner);
    return `
      <div class="bg-gray-800 p-3 rounded border border-gray-700 space-y-2 hover:border-amber-500/50 transition-all">
        <div class="flex justify-between items-center">
          <div>
            <span class="font-bold text-amber-400">${escapeHtml(matchFormatLabel(match))}</span>
            <span class="ml-2 play-mode-badge" title="${escapeHtml(t('history.play_mode', { mode: matchPlayModeLabel(match) }))}">🎮 ${escapeHtml(matchPlayModeLabel(match))}</span>
            ${match.limited_format ? `<span class="ml-2 play-mode-badge">📦 ${escapeHtml(t(`limitedFormat.${match.limited_format}`, {}, match.limited_format))}</span>` : ''}
            ${(match.modifiers || []).map(mod => `<span class="ml-2 play-mode-badge">🌀 ${escapeHtml(t(`modifier.${mod}`, {}, mod))}</span>`).join('')}
            ${match.day_night_state === 'day' ? `<span class="ml-2 play-mode-badge">☀️ ${escapeHtml(t('dayNight.day'))}</span>` : match.day_night_state === 'night' ? `<span class="ml-2 play-mode-badge">🌙 ${escapeHtml(t('dayNight.night'))}</span>` : ''}
            ${match.team_mode === 'teams' ? `<span class="ml-2 team-badge">🤝 ${match.teams?.map(team => team.player_count).join('v') || t('team.match')}</span>` : ''}
            <span class="ml-2 text-xs text-gray-400">${t('history.round', { number: match.current_round })}</span>
            <span class="ml-2 text-xs font-semibold bg-gray-700 px-2 py-0.5 rounded-full text-amber-300">⏱️ ${formatDurationSeconds(match.duration_seconds)}</span>
          </div>
          <button type="button" data-match-id="${match.id}" class="toggle-history-btn text-xs text-amber-400 underline hover:text-amber-300 transition-all">${t('history.show_details')}</button>
        </div>
        <div class="text-sm text-gray-300 space-y-1">
          ${match.players.map(p => `
            <div class="flex justify-between items-center ${p.is_winner ? 'bg-amber-500/10 border-l-2 border-amber-400 pl-2 rounded' : ''}">
              <span>${p.is_winner ? '🏆 ' : ''}${escapeHtml(p.player_name)} (${escapeHtml(p.deck_name || t('limited.no_registered_deck'))})${match.team_mode === 'teams' ? ` <span class="team-badge ml-1">${t('history.team', { number: p.team_number })}</span>` : ''}${p.role_key ? ` <span class="special-role-badge ml-1">${escapeHtml(t(`role.${p.role_key}`, {}, p.role_key))}</span>` : ''}</span>
              <span class="text-xs text-gray-400 ${p.is_winner ? 'text-amber-400 font-bold' : ''}">${t('common.life_value', { count: p.current_life })}</span>
            </div>
          `).join('')}
        </div>
        <div id="history-logs-${match.id}" class="hidden mt-2 p-2 bg-gray-900 rounded text-xs space-y-2 border border-gray-700 font-mono max-h-60 overflow-y-auto"></div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.toggle-history-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const matchId = e.target.getAttribute('data-match-id');
      toggleLifeHistory(matchId);
    });
  });
}

export async function toggleLifeHistory(matchId) {
  const logDiv = document.getElementById(`history-logs-${matchId}`);
  if (!logDiv.classList.contains('hidden')) {
    logDiv.classList.add('hidden');
    return;
  }

  const history = await fetchMatchHistory(matchId);
  const rounds = Array.isArray(history?.rounds) ? history.rounds : [];
  if (rounds.length === 0) {
    logDiv.innerHTML = `<span class="text-gray-500">${t('history.no_events')}</span>`;
    logDiv.classList.remove('hidden');
    return;
  }

  const eventLabel = (e) => {
    if (e.event_type === 'LIFE_CHANGE') return t('history.life', { name: e.player_name, from: e.prev_value, to: e.new_value, change: `${e.change_value > 0 ? '+' : ''}${e.change_value}` });
    if (e.event_type === 'POISON_CHANGE') return t('history.poison', { name: e.player_name, from: e.prev_value, to: e.new_value });
    if (e.event_type === 'TAX_CHANGE') return t('history.tax', { name: e.player_name, from: e.prev_value, to: e.new_value });
    if (e.event_type === 'CMDR_DMG') return t('history.cmdr', { source: e.related_player_name || 'Commander', name: e.player_name, from: e.prev_value, to: e.new_value });
    if (e.event_type === 'CONCEDE') return t('history.concede', { name: e.player_name });
    if (e.event_type === 'DAY_NIGHT_CHANGE') {
      if (Number(e.prev_value) === 0) return t('history.day_night_established', { state: Number(e.new_value) === 1 ? t('dayNight.day') : t('dayNight.night') });
      if (Number(e.prev_value) === 1 && Number(e.new_value) === 2) return t('history.day_to_night');
      if (Number(e.prev_value) === 2 && Number(e.new_value) === 1) return t('history.night_to_day');
      return t('history.day_night_changed');
    }
    if (e.event_type === 'NEXT_TURN') return t('history.next_turn');
    if (e.event_type === 'PAUSE_TIMER') return t('history.pause');
    if (e.event_type === 'RESUME_TIMER') return t('history.resume');
    if (e.event_type === 'REORDER_SEATS') return t('history.reorder');
    if (e.event_type === 'UNDO') return t('history.undo');
    if (e.event_type === 'ABORT') return t('history.abort');
    return e.player_name ? `${e.player_name}: ${e.event_type}` : e.event_type;
  };

  let html = '';
  for (const round of rounds) {
    html += `
      <div class="border-b border-gray-800 pb-3 mb-3 last:border-0">
        <div class="flex justify-between items-center text-amber-400 font-bold border-b border-gray-800/80 pb-1 mb-2">
          <span>🔄 ${t('history.round', { number: round.round_number })}</span>
          <span class="text-[11px] text-amber-300/80">⏱️ ${formatDurationSeconds(round.duration_seconds)}</span>
        </div>
        <div class="space-y-1 mb-2">
          ${(round.turns || []).map(turn => `
            <div class="flex justify-between gap-2 text-[11px] bg-gray-800/50 rounded px-2 py-1">
              <span class="text-gray-400">${formatHistoryTime(turn.started_at_utc || turn.started_at)}</span>
              <span class="font-semibold text-gray-200 flex-1">${escapeHtml(turn.player_name)}</span>
              <span class="text-amber-300">${t('history.turn', { duration: turn.duration_seconds != null ? formatDurationSeconds(turn.duration_seconds) : t('history.ongoing') })}</span>
            </div>
          `).join('')}
        </div>
        <div class="space-y-0.5">
          ${(round.events || []).map(e => `
            <div class="flex gap-2 text-[11px] py-0.5 px-1 text-gray-300">
              <span class="text-gray-500 font-sans">${formatHistoryTime(e.created_at_utc || e.created_at)}</span>
              <span>${escapeHtml(eventLabel(e))}</span>
            </div>
          `).join('') || `<div class="text-[11px] text-gray-600 px-1">${t('history.no_round_events')}</div>`}
        </div>
      </div>
    `;
  }

  logDiv.innerHTML = html;
  logDiv.classList.remove('hidden');
}