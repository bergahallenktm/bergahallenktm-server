import { players, refreshMatchAvailability, getMatchTeamMode, getMatchDeckSelectionMode, updateTeamBuilderUI } from './dashboard.js';
import { escapeHtml } from './dashboard.js';
import { postStartMatch, postCheckMatchAvailability } from './api.js';
import { t, apiErrorMessage } from './i18n.js';

export let diceSessionParticipants = [];
export let diceRollResults = {};
export let selectedStartingPlayerId = null;

export function triggerHaptic() {
  if ('vibrate' in navigator) {
    try { navigator.vibrate(15); } catch (e) {}
  }
}

export async function initiateDiceRollPhase() {
  // Hämta färsk beläggning precis innan D20-steget. Om någon annan har hunnit
  // starta en match tas den spelaren/decken bort ur dropdown-listan direkt.
  try {
    await refreshMatchAvailability();
  } catch (err) {
    console.error('Kunde inte uppdatera matchbeläggning:', err);
  }

  const rows = document.querySelectorAll('.participant-row');
  const teamMode = getMatchTeamMode();
  const deckSelectionMode = getMatchDeckSelectionMode();
  diceSessionParticipants = [];
  diceRollResults = {};

  const seenPlayers = new Set();
  const seenDecks = new Set();

  for (const [idx, r] of [...rows].entries()) {
    const pId = Number(r.querySelector('.player-select').value || 0);
    const dId = Number(r.querySelector('.deck-select').value || 0);
    const teamNumber = teamMode === 'teams' ? Number(r.querySelector('.team-select')?.value || 0) : idx + 1;
    const errorEl = r.querySelector('.validation-error');
    errorEl.classList.add('hidden');
    errorEl.textContent = '';

    // Tomma extra rader ignoreras. I Limited kan deck vara valfri, men
    // en vald deck utan spelare är alltid ogiltig.
    if (!pId && !dId) continue;
    if (!pId || (deckSelectionMode === 'required' && !dId)) {
      errorEl.textContent = deckSelectionMode === 'required' ? t('validation.choose_player_deck') : t('validation.choose_player');
      errorEl.classList.remove('hidden');
      alert(t('validation.row_choose', { row: idx + 1 }));
      return;
    }
    if (seenPlayers.has(pId)) {
      alert(t('validation.duplicate_player'));
      return;
    }
    if (dId && seenDecks.has(dId)) {
      alert(t('validation.duplicate_deck'));
      return;
    }
    seenPlayers.add(pId);
    if (dId) seenDecks.add(dId);

    const playerObj = players.find(p => p.id === pId);
    diceSessionParticipants.push({
      player_id: pId,
      deck_id: dId || null,
      team_number: teamNumber,
      player_name: playerObj ? playerObj.name : t('dice.player_fallback', { number: idx + 1 })
    });
  }

  if (diceSessionParticipants.length < 2) {
    alert(t('validation.min_players'));
    return;
  }

  if (teamMode === 'teams') {
    const teams = new Set(diceSessionParticipants.map(p => Number(p.team_number)));
    if (teams.size < 2) {
      alert(t('validation.team_two'));
      updateTeamBuilderUI();
      return;
    }
    if (teams.size >= diceSessionParticipants.length) {
      alert(t('validation.team_shared'));
      updateTeamBuilderUI();
      return;
    }
  }

  // Servern gör samma kontroll igen här, innan någon tärning rullas. Det
  // skyddar mot att en annan webbläsare startat en match precis efter refresh.
  const match_type = document.getElementById('matchType').value;
  const match_profile = document.getElementById('matchProfile').value;
  const deck_format = document.getElementById('matchDeckFormat').value;
  const play_mode = document.getElementById('matchPlayMode').value;
  const limited_format = document.getElementById('matchLimitedFormat')?.value || null;
  const modifiers = document.getElementById('modifierPlanechase')?.checked ? ['planechase'] : [];
  const starting_life = Number(document.getElementById('startingLife').value);
  const availabilityResponse = await postCheckMatchAvailability({
    match_type,
    match_profile,
    deck_format,
    play_mode,
    limited_format,
    modifiers,
    team_mode: teamMode,
    starting_life,
    participants: diceSessionParticipants.map(p => ({
      player_id: p.player_id,
      deck_id: p.deck_id,
      team_number: p.team_number
    }))
  });

  if (!availabilityResponse.ok) {
    const data = await availabilityResponse.json().catch(() => ({}));
    alert(`❌ ${apiErrorMessage(data, 'dice.availability_failed').replace(/^❌\s*/, '')}`);
    await refreshMatchAvailability().catch(() => {});
    return;
  }

  if (play_mode === 'kingdoms') {
    selectedStartingPlayerId = null;
    renderHiddenRoleStartModal();
  } else if (play_mode === 'archenemy' || play_mode === 'archenemy_commander') {
    const counts = new Map();
    diceSessionParticipants.forEach(p => counts.set(Number(p.team_number), (counts.get(Number(p.team_number)) || 0) + 1));
    const archenemyTeam = [...counts.entries()].find(([, count]) => count === 1)?.[0];
    const archenemy = diceSessionParticipants.find(p => Number(p.team_number) === Number(archenemyTeam));
    selectedStartingPlayerId = archenemy?.player_id || diceSessionParticipants[0]?.player_id || null;
    renderForcedStartModal(archenemy);
  } else {
    renderDiceRollModal();
  }
  const diceModal = document.getElementById('diceModal');
  diceModal.classList.remove('hidden');
  requestAnimationFrame(() => diceModal.querySelector('button:not([disabled])')?.focus());
}

function renderHiddenRoleStartModal() {
  const listEl = document.getElementById('diceRollList');
  const confirm = document.getElementById('confirmStartMatchBtn');
  const announcement = document.getElementById('diceWinnerAnnouncement');
  listEl.innerHTML = `<div class="bg-gray-800 p-4 rounded-xl border border-purple-500/40 text-left">
    <div class="text-xs uppercase tracking-wider text-purple-300">${escapeHtml(t('dice.hidden_role_setup'))}</div>
    <div class="text-lg font-black text-amber-300 mt-1">${escapeHtml(t('playMode.kingdoms'))}</div>
    <div class="text-sm text-gray-300 mt-2">${escapeHtml(t('dice.kingdoms_starts'))}</div>
  </div>`;
  announcement.classList.add('hidden');
  confirm.disabled = false;
  confirm.className = 'flex-1 bg-green-600 hover:bg-green-500 font-bold py-3 rounded-xl transition-all';
}

function renderForcedStartModal(archenemy) {
  const listEl = document.getElementById('diceRollList');
  const confirm = document.getElementById('confirmStartMatchBtn');
  const announcement = document.getElementById('diceWinnerAnnouncement');
  listEl.innerHTML = `<div class="bg-gray-800 p-4 rounded-xl border border-amber-500/40 text-left">
    <div class="text-xs uppercase tracking-wider text-gray-400">${escapeHtml(t('role.archenemy'))}</div>
    <div class="text-xl font-black text-amber-300 mt-1">${escapeHtml(archenemy?.player_name || '')}</div>
    <div class="text-sm text-gray-300 mt-2">${escapeHtml(t('dice.archenemy_starts'))}</div>
  </div>`;
  announcement.classList.add('hidden');
  confirm.disabled = false;
  confirm.className = 'flex-1 bg-green-600 hover:bg-green-500 font-bold py-3 rounded-xl transition-all';
}

export function renderDiceRollModal() {
  const listEl = document.getElementById('diceRollList');
  document.getElementById('confirmStartMatchBtn').disabled = true;
  document.getElementById('diceWinnerAnnouncement').classList.add('hidden');

  listEl.innerHTML = diceSessionParticipants.map(p => {
    const roll = diceRollResults[p.player_id];
    return `
      <div class="flex justify-between items-center bg-gray-800 p-3 rounded-xl border border-gray-700 hover:border-amber-500/50 transition-all">
        <span class="font-bold text-gray-200 text-lg flex items-center gap-2">${escapeHtml(p.player_name)}${getMatchTeamMode() === 'teams' ? `<span class="team-badge">${t('team.team', { number: p.team_number })}</span>` : ''}</span>
        <div class="flex items-center gap-3">
          <span id="dice-result-${p.player_id}" class="text-2xl font-black font-mono text-amber-400 min-w-[3rem] text-right">
            ${roll !== undefined ? `🎲 ${roll}` : '--'}
          </span>
          <button type="button" data-player-id="${p.player_id}" class="roll-d20-btn bg-amber-600 hover:bg-amber-500 font-bold px-6 py-3 rounded-lg text-sm active:scale-95 transition-all touch-manipulation">
            ${t('dice.roll')}
          </button>
        </div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.roll-d20-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pId = Number(e.target.getAttribute('data-player-id'));
      rollD20ForPlayer(pId);
    });
  });
}

export function rollD20ForPlayer(playerId) {
  triggerHaptic();
  const resEl = document.getElementById(`dice-result-${playerId}`);
  let counter = 0;
  
  const animInterval = setInterval(() => {
    resEl.innerText = `🎲 ${Math.floor(Math.random() * 20) + 1}`;
    counter++;
    if (counter > 8) {
      clearInterval(animInterval);
      const finalRoll = Math.floor(Math.random() * 20) + 1;
      diceRollResults[playerId] = finalRoll;
      resEl.innerText = `🎲 ${finalRoll}`;
      resEl.classList.add('animate-bounce');
      setTimeout(() => resEl.classList.remove('animate-bounce'), 500);
      checkDiceWinner();
    }
  }, 50);
}

export function checkDiceWinner() {
  const rolledCount = Object.keys(diceRollResults).length;
  if (rolledCount < diceSessionParticipants.length) return;

  let maxRoll = -1;
  let winners = [];

  diceSessionParticipants.forEach(p => {
    const r = diceRollResults[p.player_id];
    if (r > maxRoll) {
      maxRoll = r;
      winners = [p];
    } else if (r === maxRoll) {
      winners.push(p);
    }
  });

  const announcement = document.getElementById('diceWinnerAnnouncement');
  announcement.classList.remove('hidden');

  if (winners.length === 1) {
    const winner = winners[0];
    selectedStartingPlayerId = winner.player_id;
    announcement.innerHTML = t('dice.winner', { name: `<span class="text-amber-400 font-bold">${escapeHtml(winner.player_name)}</span>`, roll: maxRoll });
    announcement.className = 'p-4 bg-green-500/20 border border-green-500/40 rounded-xl text-green-300 font-bold text-lg';
    document.getElementById('confirmStartMatchBtn').disabled = false;
    document.getElementById('confirmStartMatchBtn').className = 'flex-1 bg-green-600 hover:bg-green-500 font-bold py-3 rounded-xl transition-all';
  } else {
    announcement.innerHTML = t('dice.tie', { roll: maxRoll, names: winners.map(w => `<span class="text-amber-400 font-bold">${escapeHtml(w.player_name)}</span>`).join(', ') });
    announcement.className = 'p-4 bg-amber-500/20 border border-amber-500/40 rounded-xl text-amber-300 font-bold text-lg';
  }
}

export function closeDiceModal() {
  document.getElementById('diceModal').classList.add('hidden');
  document.getElementById('startDicePhaseBtn')?.focus();
}

function storeHiddenRoleRevealTokens(data) {
  const matchId = Number(data?.matchId || data?.match?.id || 0);
  const tokens = data?.hidden_role_setup?.reveal_tokens;
  if (!matchId || !Array.isArray(tokens) || typeof sessionStorage === 'undefined') return;
  for (const item of tokens) {
    const playerId = Number(item?.player_id || 0);
    const token = String(item?.reveal_token || '');
    if (!playerId || !token) continue;
    try { sessionStorage.setItem(`ktm:hidden-role:${matchId}:${playerId}`, token); } catch (_) {}
  }
}

let startMatchInFlight = false;

export async function confirmAndStartMatchWithWinner(onSuccessCallback) {
  if (startMatchInFlight) return; // Förhindrar dubbla klick som startar två matcher i rad
  startMatchInFlight = true;
  closeDiceModal();

  try {
    const match_type = document.getElementById('matchType').value;
    const match_profile = document.getElementById('matchProfile').value;
    const deck_format = document.getElementById('matchDeckFormat').value;
    const play_mode = document.getElementById('matchPlayMode').value;
    const limited_format = document.getElementById('matchLimitedFormat')?.value || null;
    const modifiers = document.getElementById('modifierPlanechase')?.checked ? ['planechase'] : [];
    const starting_life = document.getElementById('startingLife').value;
    const timer_minutes = document.getElementById('timerMinutes').value;
    const team_mode = getMatchTeamMode();

    const res = await postStartMatch({
      match_type,
      match_profile,
      deck_format,
      play_mode,
      limited_format,
      modifiers,
      team_mode,
      starting_life: Number(starting_life),
      participants: diceSessionParticipants.map(p => ({
        player_id: p.player_id,
        deck_id: p.deck_id,
        team_number: p.team_number
      })),
      timer_minutes: Number(timer_minutes),
      starting_player_id: selectedStartingPlayerId
    });

    if (res.ok) {
      const data = await res.json();
      storeHiddenRoleRevealTokens(data);
      onSuccessCallback(data);
    } else {
      const data = await res.json().catch(() => ({}));
      alert(`❌ ${apiErrorMessage(data, 'dice.start_failed').replace(/^❌\s*/, '')}`);
    }
  } finally {
    startMatchInFlight = false;
  }
}