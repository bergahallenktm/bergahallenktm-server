export function createLiveMatchTimerController({
  getActiveMatch,
  setActiveMatch,
  refreshActiveMatch,
  fetchTimer,
  pauseTimer,
  resumeTimer,
  haptic,
  translate,
  errorMessage,
  documentRef = () => globalThis.document,
  navigatorRef = () => globalThis.navigator,
  alertFn = (...args) => globalThis.alert?.(...args),
  now = () => Date.now(),
  setIntervalFn = (...args) => globalThis.setInterval(...args),
  clearIntervalFn = (...args) => globalThis.clearInterval(...args)
}) {
  let timerInterval = null;
  let timerServerSyncInterval = null;
  let timerSnapshotRemaining = 0;
  let timerSnapshotAtMs = now();
  let timerRunning = false;
  let timerExpiredFeedbackShown = false;

  function stop() {
    clearIntervalFn(timerInterval);
    clearIntervalFn(timerServerSyncInterval);
    timerInterval = null;
    timerServerSyncInterval = null;
  }

  function currentDisplayedTimerSeconds() {
    if (!timerRunning) return Math.max(0, Math.floor(timerSnapshotRemaining));
    const elapsed = Math.floor(Math.max(0, now() - timerSnapshotAtMs) / 1000);
    return Math.max(0, Math.floor(timerSnapshotRemaining) - elapsed);
  }

  function updateTimerActionButton(timer) {
    const pauseBtn = documentRef()?.getElementById('pauseBtn');
    if (!pauseBtn) return;
    const expired = !!timer?.is_expired;
    const label = expired ? translate('live.finished') : (timerRunning ? translate('live.pause') : translate('live.start'));
    pauseBtn.textContent = label;
    pauseBtn.setAttribute('aria-label', label);
    pauseBtn.disabled = expired;
    pauseBtn.classList.toggle('opacity-50', expired);
  }

  function syncTimerFromServer(timer) {
    clearIntervalFn(timerInterval);
    timerSnapshotRemaining = Math.max(0, Number(timer?.remaining_seconds || 0));
    timerSnapshotAtMs = now();
    timerRunning = !!timer?.is_running;
    timerExpiredFeedbackShown = timerSnapshotRemaining <= 0;
    updateTimerActionButton(timer);
    updateTimerDisplay();

    timerInterval = setIntervalFn(() => updateTimerDisplay(), 250);
    clearIntervalFn(timerServerSyncInterval);
    timerServerSyncInterval = setIntervalFn(async () => {
      const match = getActiveMatch();
      if (!match?.id || !match?.timer?.enabled) return;
      try {
        const serverTimer = await fetchTimer(match.id);
        if (serverTimer && !serverTimer.error) {
          const current = getActiveMatch();
          if (current) current.timer = serverTimer;
          timerSnapshotRemaining = Math.max(0, Number(serverTimer.remaining_seconds || 0));
          timerSnapshotAtMs = now();
          timerRunning = !!serverTimer.is_running;
          updateTimerActionButton(serverTimer);
        }
      } catch (_) {
        // Behåll senaste serversnapshot om nätverket tillfälligt försvinner.
      }
    }, 5000);
  }

  function resetTurnTimer(seconds) {
    timerSnapshotRemaining = Math.max(0, Number(seconds || 0));
    timerSnapshotAtMs = now();
    timerRunning = true;
    timerExpiredFeedbackShown = false;
    updateTimerDisplay();
  }

  async function toggleTimer() {
    const match = getActiveMatch();
    if (!match?.timer?.enabled) return;
    haptic();
    const res = timerRunning
      ? await pauseTimer(match.id)
      : await resumeTimer(match.id);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alertFn(translate('live.timer_failed', { error: errorMessage(data) || res.status }));
      return;
    }
    if (data.match) {
      setActiveMatch(data.match);
      syncTimerFromServer(data.match.timer);
    } else {
      await refreshActiveMatch();
    }
  }

  function updateTimerDisplay() {
    const remaining = currentDisplayedTimerSeconds();
    const doc = documentRef();
    const timerCard = doc?.getElementById('timerCard');
    const display = doc?.getElementById('timerDisplay');
    if (!timerCard || !display) return;

    if (remaining <= 0) {
      timerCard.classList.add('bg-red-900/50', 'border-red-500');
      display.innerHTML = translate('live.time_up');
      if (!timerExpiredFeedbackShown) {
        timerExpiredFeedbackShown = true;
        haptic();
        const nav = navigatorRef?.();
        if (nav && 'vibrate' in nav) {
          try { nav.vibrate([200, 100, 200]); } catch (_) {}
        }
      }
      return;
    }

    timerExpiredFeedbackShown = false;
    timerCard.classList.remove('bg-red-900/50', 'border-red-500');
    const m = String(Math.floor(remaining / 60)).padStart(2, '0');
    const sec = String(remaining % 60).padStart(2, '0');
    display.innerHTML = `${m}:${sec}`;
  }

  return {
    stop,
    syncTimerFromServer,
    resetTurnTimer,
    toggleTimer,
    updateTimerDisplay,
    currentDisplayedTimerSeconds,
    isRunning: () => timerRunning
  };
}
