import {
  fetchAdminSummary, postAdminPlayerPassword, deleteAdminPlayer, restoreAdminPlayer,
  permanentlyDeleteAdminPlayer, deleteAdminDeck, restoreAdminDeck, permanentlyDeleteAdminDeck,
  deleteAdminMatch, postAdminResetMatches, postAdminResetDecks, postAdminResetPlayers,
  postAdminFactoryReset, fetchAdminAuditLog, fetchAdminSystemStatus, fetchAdminSystemLogs,
  postAdminManualBackup, fetchAdminBackups, adminBackupDownloadUrl,
  putAdminBackupSettings, postAdminRestoreBackup, fetchAdminRecoveryDiagnostics,
  fetchAdminRestorePlan, postAdminSafeRepair
} from './api.js';
import { escapeHtml } from './dashboard.js';
import { t, apiErrorMessage, formatDateTime } from './i18n.js';
import { matchFormatLabel, matchPlayModeLabel } from './matchFormatUi.js';

async function readJson(res) {
  return res.json().catch(() => ({}));
}

function showStatus(message, isError=false) {
  const el = document.getElementById('adminStatus');
  if (!el) return;
  el.textContent = message;
  el.className = `rounded-lg border px-3 py-2 text-sm ${isError ? 'bg-red-950/60 border-red-800 text-red-200' : 'bg-green-950/50 border-green-800 text-green-200'}`;
  el.classList.remove('hidden');
}

function typedConfirmation(message, expected) {
  if (!confirm(message)) return null;
  const value = prompt(t('common.confirm_irreversible', { expected }));
  return value === expected ? value : null;
}

function playerCard(p, currentUserId) {
  const archived = !!p.archived;
  return `
    <div class="admin-card ${archived ? 'opacity-70' : ''}">
      <div class="flex flex-wrap justify-between gap-2 items-start">
        <div>
          <div class="font-bold text-amber-300">${escapeHtml(p.name)} ${p.is_admin ? `<span class="admin-badge">${t('admin.superuser')}</span>` : ''}</div>
          <div class="text-xs text-gray-400">${t('admin.active_decks_matches', { decks: p.deck_count, matches: p.match_count })}${archived ? t('admin.archived_suffix') : ''}</div>
        </div>
        ${p.is_admin ? `<span class="text-xs text-gray-500">${t('common.protected_account')}</span>` : archived
          ? `<div class="flex flex-wrap gap-2">
               <button type="button" class="admin-restore-player admin-btn" data-id="${p.id}">${t('common.restore')}</button>
               <button type="button" class="admin-permanent-player admin-btn admin-btn-danger" data-id="${p.id}" data-name="${escapeHtml(p.name)}">${t('common.delete_permanent')}</button>
             </div>`
          : `<button type="button" class="admin-delete-player admin-btn admin-btn-danger" data-id="${p.id}" data-name="${escapeHtml(p.name)}">${t('common.archive')}</button>`}
      </div>
      ${!archived ? `
        <div class="mt-3 flex flex-wrap gap-2">
          <input type="password" minlength="4" autocomplete="new-password" placeholder="${t('admin.new_password')}" class="admin-password flex-1 min-w-[180px] p-2 rounded bg-gray-950 border border-gray-700 text-sm" data-id="${p.id}">
          <button type="button" class="admin-set-password admin-btn" data-id="${p.id}" data-self="${p.id === currentUserId ? '1' : '0'}">${t('admin.set_password')}</button>
        </div>` : ''}
    </div>`;
}

function deckCard(d) {
  return `
    <div class="admin-card ${d.archived ? 'opacity-70' : ''}">
      <div class="flex flex-wrap justify-between gap-2 items-center">
        <div><span class="font-bold text-gray-200">${escapeHtml(d.name)}</span><span class="text-xs text-gray-500"> · ${escapeHtml(d.owner_name)} · ${escapeHtml(d.format || '')} · ${t('admin.deck_matches', { count: d.match_count })}</span></div>
        ${d.archived
          ? `<div class="flex flex-wrap gap-2">
               <button type="button" class="admin-restore-deck admin-btn" data-id="${d.id}">${t('common.restore')}</button>
               <button type="button" class="admin-permanent-deck admin-btn admin-btn-danger" data-id="${d.id}" data-name="${escapeHtml(d.name)}" ${d.in_active_match ? `disabled title="${escapeHtml(t('admin.active_match_title'))}"` : ''}>${t('common.delete_permanent')}</button>
             </div>`
          : `<button type="button" class="admin-delete-deck admin-btn admin-btn-danger" data-id="${d.id}" data-name="${escapeHtml(d.name)}" ${d.in_active_match ? `disabled title="${escapeHtml(t('admin.active_match_title'))}"` : ''}>${t('common.archive')}</button>`}
      </div>
    </div>`;
}

function matchCard(m) {
  const label = m.table_name || `Match #${m.id}`;
  return `
    <div class="admin-card">
      <div class="flex flex-wrap justify-between gap-2 items-center">
        <div>
          <div class="font-bold text-gray-200">${escapeHtml(label)} <span class="text-xs text-amber-400">#${m.id}</span></div>
          <div class="text-xs text-gray-400">${escapeHtml(matchFormatLabel(m))} · ${escapeHtml(matchPlayModeLabel(m))} · ${escapeHtml(t(`status.${m.status}`, {}, m.status))} · ${escapeHtml(m.player_names || '')}</div>
        </div>
        <button type="button" class="admin-delete-match admin-btn admin-btn-danger" data-id="${m.id}" ${m.status === 'active' ? `disabled title="${escapeHtml(t('admin.match_active_block'))}"` : ''}>${t('common.delete_permanent')}</button>
      </div>
    </div>`;
}

function renderResetCounts(counts={}) {
  const el = document.getElementById('adminResetCounts');
  if (!el) return;
  el.textContent = t('admin.counts', { players: counts.players || 0, decks: counts.decks || 0, matches: counts.matches || 0, active: counts.active_matches || 0 });
}


function formatBytes(value) {
  const bytes = Number(value || 0);
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB'];
  let size = bytes / 1024;
  let unit = units[0];
  for (let i = 1; i < units.length && size >= 1024; i += 1) {
    size /= 1024;
    unit = units[i];
  }
  return `${size.toFixed(size >= 10 ? 1 : 2)} ${unit}`;
}

function formatDuration(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds || 0)));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if (days) return `${days}d ${hours}h`;
  if (hours) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

function formatLocalDate(value) {
  if (!value) return t('common.missing');
  return formatDateTime(value, { dateStyle: 'short', timeStyle: 'medium' });
}

function statusCard(title, value, detail = '', tone = 'normal') {
  const toneClass = tone === 'good' ? 'system-status-good' : tone === 'warn' ? 'system-status-warn' : 'system-status-neutral';
  return `<div class="system-status-card ${toneClass}">
    <div class="system-status-label">${escapeHtml(title)}</div>
    <div class="system-status-value">${escapeHtml(String(value))}</div>
    ${detail ? `<div class="system-status-detail">${escapeHtml(detail)}</div>` : ''}
  </div>`;
}

export async function loadSystemStatus() {
  const output = document.getElementById('adminSystemStatus');
  if (!output) return;
  const res = await fetchAdminSystemStatus();
  if (!res.ok) {
    const data = await readJson(res);
    output.innerHTML = `<div class="text-sm text-red-300">${escapeHtml(apiErrorMessage(data, 'admin.system.read_failed'))}</div>`;
    return;
  }
  const data = await res.json();
  const c = data.database?.counts || {};
  const dbHealthy = data.database?.health === 'ok';
  const latest = data.backup?.latest;
  const addresses = data.server?.local_addresses || [];
  output.innerHTML = `
    <div class="system-status-grid">
      ${statusCard(t('admin.status.server'), data.status === 'ok' ? 'OK' : t('admin.status.warning'), `v${data.server?.app_version || '?'} · API v${data.server?.api_version || '?'} · ${formatDuration(data.server?.uptime_seconds)}`, data.status === 'ok' ? 'good' : 'warn')}
      ${statusCard(t('admin.status.database'), dbHealthy ? 'OK' : data.database?.health || t('admin.status.warning'), t('admin.status.database_detail', { schema: data.database?.schema_version ?? '?', db_size: formatBytes(data.database?.file_bytes), wal_size: formatBytes(data.database?.wal_bytes) }), dbHealthy ? 'good' : 'warn')}
      ${statusCard(t('admin.status.players'), c.players || 0, t('admin.status.players_detail', { active: c.players_active || 0, archived: c.players_archived || 0 }))}
      ${statusCard(t('admin.status.decks'), c.decks || 0, t('admin.status.players_detail', { active: c.decks_active || 0, archived: c.decks_archived || 0 }))}
      ${statusCard(t('admin.status.matches'), c.matches || 0, t('admin.status.matches_detail', { active: c.matches_active || 0, completed: c.matches_completed || 0, aborted: c.matches_aborted || 0 }))}
      ${statusCard(t('admin.status.events'), c.events || 0, t('admin.status.offline_imports', { count: c.offline_imported_matches || 0 }))}
      ${statusCard(t('admin.status.sync'), `P ${data.sync?.players_revision || 0} / D ${data.sync?.decks_revision || 0}`, t('admin.status.sync_detail', { players: data.sync?.player_tombstones || 0, decks: data.sync?.deck_tombstones || 0 }))}
      ${statusCard(t('admin.status.backup'), latest ? formatLocalDate(latest.created_at) : t('admin.status.none_yet'), t('admin.status.files_keep', { count: data.backup?.count || 0, keep: data.backup?.keep || 0 }), latest ? 'good' : 'warn')}
      ${statusCard(t('admin.status.next_backup'), data.backup?.enabled ? (data.backup?.next_run_at ? formatLocalDate(data.backup.next_run_at) : t('admin.status.scheduled')) : t('admin.status.off'), data.backup?.enabled ? t('admin.status.auto_local', { time: `${String(data.backup?.hour ?? 3).padStart(2,'0')}:${String(data.backup?.minute ?? 0).padStart(2,'0')}` }) : '')}
      ${statusCard(t('admin.status.memory'), formatBytes(data.process?.rss_bytes), t('admin.status.heap', { used: formatBytes(data.process?.heap_used_bytes), total: formatBytes(data.process?.heap_total_bytes) }))}
      ${statusCard(t('admin.status.log'), t('admin.status.log_files', { count: data.logging?.files?.length || 0 }), t('admin.status.log_detail', { size: formatBytes(data.logging?.max_bytes) }))}
    </div>
    <div class="mt-3 grid gap-2 md:grid-cols-2 text-xs">
      <div class="admin-card"><span class="text-gray-500">${t('admin.status.instance_uid')}</span><div class="mt-1 font-mono text-amber-200 break-all">${escapeHtml(data.server?.instance_uid || t('admin.status.missing'))}</div><div class="mt-1 text-gray-500">${t('admin.status.instance_uid_help')}</div></div>
      <div class="admin-card"><span class="text-gray-500">${t('admin.status.last_restore')}</span><div class="mt-1 ${data.restore?.last?.failed ? 'text-red-300' : 'text-gray-300'}">${data.restore?.last ? escapeHtml(data.restore.last.failed ? t('admin.status.rejected', { date: formatLocalDate(data.restore.last.failed_at) }) : formatLocalDate(data.restore.last.applied_at)) : t('admin.status.no_restore')}</div>${data.restore?.last?.source_backup ? `<div class="mt-1 font-mono text-gray-500 break-all">${escapeHtml(data.restore.last.source_backup)}</div>` : ''}${data.restore?.last?.error ? `<div class="mt-1 text-xs text-red-300">${escapeHtml(data.restore.last.error)}</div>` : ''}</div>
      <div class="admin-card"><span class="text-gray-500">${t('admin.status.local_addresses')}</span><div class="mt-1 font-mono text-amber-200 break-all">${addresses.length ? addresses.map(escapeHtml).join('<br>') : t('admin.status.no_lan')}</div></div>
      <div class="admin-card"><span class="text-gray-500">${t('admin.status.runtime')}</span><div class="mt-1 text-gray-300">Node ${escapeHtml(data.server?.node_version || '')} · ${escapeHtml(data.server?.platform || '')} · PID ${escapeHtml(String(data.server?.pid || ''))}</div></div>
    </div>`;
}

export async function loadSystemLogs() {
  const output = document.getElementById('adminSystemLogs');
  if (!output) return;
  const category = document.getElementById('adminLogCategory')?.value || '';
  const level = document.getElementById('adminLogLevel')?.value || '';
  const res = await fetchAdminSystemLogs({ limit: 150, category, level });
  if (!res.ok) {
    const data = await readJson(res);
    output.innerHTML = `<div class="text-sm text-red-300">${escapeHtml(apiErrorMessage(data, 'admin.logs.read_failed'))}</div>`;
    return;
  }
  const data = await res.json();
  const rows = data.logs || [];
  output.innerHTML = rows.length ? rows.map(row => {
    const meta = [
      row.status ? `HTTP ${row.status}` : '',
      row.duration_ms != null ? `${row.duration_ms}ms` : '',
      row.request_id ? `req ${row.request_id}` : '',
      row.actor_name ? t('admin.logs.user_meta', { name: row.actor_name }) : ''
    ].filter(Boolean).join(' · ');
    return `<div class="system-log-row system-log-${escapeHtml(row.level || 'info')}">
      <div class="system-log-head"><span>${escapeHtml(formatLocalDate(row.ts))}</span><span class="system-log-category">${escapeHtml(row.category || 'system')}</span><span>${escapeHtml(row.level || 'info')}</span></div>
      <div class="system-log-message">${escapeHtml(row.message || '')}</div>
      ${meta ? `<div class="system-log-meta">${escapeHtml(meta)}</div>` : ''}
    </div>`;
  }).join('') : `<div class="text-sm text-gray-500">${t('admin.logs.empty')}</div>`;
}


function recoveryRecommendationRow(item) {
  const severity = item.severity || 'info';
  const tone = severity === 'critical' ? 'text-red-300' : severity === 'warning' ? 'text-amber-300' : 'text-green-300';
  return `<div class="text-xs ${tone}"><span class="font-mono">${escapeHtml(item.code || '')}</span> · ${escapeHtml(item.action || '')}</div>`;
}

export async function loadRecoveryDiagnostics() {
  const output = document.getElementById('adminRecoveryDiagnostics');
  if (!output) return;
  output.innerHTML = `<div class="text-sm text-gray-500">${escapeHtml(t('admin.recovery.loading'))}</div>`;
  const res = await fetchAdminRecoveryDiagnostics();
  const data = await readJson(res);
  if (!res.ok) {
    output.innerHTML = `<div class="text-sm text-red-300">${escapeHtml(apiErrorMessage(data, 'admin.recovery.failed'))}</div>`;
    return;
  }
  const active = data.active_database || {};
  const healthy = !!data.ok;
  const pending = data.pending_restore || {};
  output.innerHTML = `
    <div class="system-status-grid">
      ${statusCard(t('admin.recovery.active_db'), active.integrity_check === 'ok' && Number(active.foreign_key_issues || 0) === 0 ? 'OK' : t('admin.status.warning'), t('admin.recovery.active_detail', { schema: active.schema_version ?? '?', fk: active.foreign_key_issues ?? '?' }), active.integrity_check === 'ok' && Number(active.foreign_key_issues || 0) === 0 ? 'good' : 'warn')}
      ${statusCard(t('admin.recovery.backups'), `${data.backups?.quick_healthy || 0}/${data.backups?.count || 0}`, t('admin.recovery.backups_detail', { unhealthy: data.backups?.quick_unhealthy || 0 }), (data.backups?.count || 0) > 0 && (data.backups?.quick_unhealthy || 0) === 0 ? 'good' : 'warn')}
      ${statusCard(t('admin.recovery.pending_restore'), pending.staged_database || pending.staged_manifest ? t('admin.recovery.pending_yes') : t('admin.recovery.pending_no'), pending.consistent_pair === false ? t('admin.recovery.pending_incomplete') : '', pending.consistent_pair === false ? 'warn' : 'good')}
      ${statusCard(t('admin.recovery.contract'), `v${data.backup_restore_repair_version || '?'}`, healthy ? t('admin.recovery.no_repair') : t('admin.recovery.attention'), healthy ? 'good' : 'warn')}
    </div>
    <div class="mt-3 space-y-1">${(data.recommendations || []).map(recoveryRecommendationRow).join('')}</div>`;
}

function backupRow(item, currentInstanceUid) {
  const healthy = item.health === 'ok' && item.required_tables_ok !== false;
  const sameInstance = !!item.instance_uid && item.instance_uid === currentInstanceUid;
  const identity = item.instance_uid
    ? (sameInstance ? t('admin.backup.identity_same') : t('admin.backup.identity_other'))
    : t('admin.backup.before_uid');
  const counts = [item.players != null ? t('admin.backup.players_count', { count: item.players }) : '', item.decks != null ? t('admin.backup.decks_count', { count: item.decks }) : '', item.matches != null ? t('admin.backup.matches_count', { count: item.matches }) : ''].filter(Boolean).join(' · ');
  return `<div class="admin-card" data-backup-row="${escapeHtml(item.name)}">
    <div class="flex flex-wrap justify-between gap-3 items-start">
      <div class="min-w-0">
        <div class="font-mono text-sm text-amber-200 break-all">${escapeHtml(item.name)}</div>
        <div class="text-xs text-gray-400 mt-1">${escapeHtml(formatLocalDate(item.created_at))} · ${formatBytes(item.bytes)} · ${escapeHtml(t('admin.backup.schema_label', { schema: item.schema_version ?? '?' }))}</div>
        <div class="text-xs mt-1 ${healthy ? 'text-green-300' : 'text-red-300'}">${healthy ? t('admin.backup.sqlite_ok') : `⚠ ${escapeHtml(item.health || t('admin.backup.unknown_status'))}`} · ${escapeHtml(identity)}</div>
        ${counts ? `<div class="text-xs text-gray-500 mt-1">${escapeHtml(counts)}</div>` : ''}
      </div>
      <div class="flex flex-wrap gap-2">
        <a class="admin-btn inline-flex items-center" href="${escapeHtml(adminBackupDownloadUrl(item.name))}">${t('admin.backup.download')}</a>
        <button type="button" class="admin-verify-backup admin-btn" data-name="${escapeHtml(item.name)}">${t('admin.backup.verify')}</button>
        <button type="button" class="admin-restore-backup admin-btn admin-btn-danger" data-name="${escapeHtml(item.name)}" ${healthy ? '' : `disabled title="${escapeHtml(t('admin.backup.integrity_title'))}"`}>${t('admin.backup.restore')}</button>
      </div>
    </div>
    <div class="admin-backup-row-status hidden mt-3 rounded-lg border px-3 py-2 text-sm" role="status" aria-live="polite"></div>
  </div>`;
}

function showBackupRowStatus(button, message, isError = false) {
  const row = button?.closest?.('[data-backup-row]');
  const el = row?.querySelector?.('.admin-backup-row-status');
  if (!el) {
    showStatus(message, isError);
    return;
  }
  el.textContent = message;
  el.className = `admin-backup-row-status mt-3 rounded-lg border px-3 py-2 text-sm ${isError ? 'bg-red-950/60 border-red-800 text-red-200' : 'bg-green-950/50 border-green-800 text-green-200'}`;
  el.classList.remove('hidden');
}

async function waitForServerAfterRestore() {
  const deadline = Date.now() + 45_000;
  await new Promise(resolve => setTimeout(resolve, 1800));
  while (Date.now() < deadline) {
    try {
      const res = await fetch('/api/v1/meta', { cache: 'no-store' });
      if (res.ok) {
        location.reload();
        return;
      }
    } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  alert(t('admin.restore.restart_unconfirmed'));
}

export async function loadBackupManagement() {
  const output = document.getElementById('adminBackupList');
  if (!output) return;
  const res = await fetchAdminBackups();
  if (!res.ok) {
    const data = await readJson(res);
    output.innerHTML = `<div class="text-sm text-red-300">${escapeHtml(apiErrorMessage(data, 'admin.backup.read_failed'))}</div>`;
    return;
  }

  const data = await res.json();
  const settings = data.settings || {};
  const enabled = document.getElementById('backupAutoEnabled');
  const keep = document.getElementById('backupKeepCount');
  const time = document.getElementById('backupAutoTime');
  if (enabled) enabled.checked = !!settings.enabled;
  if (keep) keep.value = String(settings.keep ?? 14);
  if (time) time.value = `${String(settings.hour ?? 3).padStart(2,'0')}:${String(settings.minute ?? 0).padStart(2,'0')}`;

  const scheduleInfo = document.getElementById('backupScheduleInfo');
  if (scheduleInfo) {
    scheduleInfo.textContent = settings.enabled
      ? t('admin.backup.daily_enabled', { keep: settings.keep })
      : t('admin.backup.disabled');
  }

  const rows = data.backups || [];
  output.innerHTML = rows.length
    ? rows.map(item => backupRow(item, data.current_instance_uid)).join('')
    : `<div class="text-sm text-gray-500">${t('admin.backup.none')}</div>`;

  document.querySelectorAll('.admin-verify-backup').forEach(btn => {
    btn.addEventListener('click', async () => {
      const name = btn.dataset.name;
      btn.disabled = true;
      try {
        showBackupRowStatus(btn, t('admin.backup.verifying', { name }));
        const planRes = await fetchAdminRestorePlan(name);
        const plan = await readJson(planRes);
        if (!planRes.ok) return showBackupRowStatus(btn, apiErrorMessage(plan, 'admin.backup.verify_failed'), true);
        showBackupRowStatus(btn, t(plan.cross_instance_restore ? 'admin.backup.verified_other' : 'admin.backup.verified', {
          name,
          schema: plan.source_schema_version ?? '?'
        }));
      } finally {
        btn.disabled = false;
      }
    });
  });

  document.querySelectorAll('.admin-restore-backup').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (btn.disabled) return;
      const name = btn.dataset.name;
      btn.disabled = true;
      try {
        showBackupRowStatus(btn, t('admin.backup.verifying', { name }));
        const planRes = await fetchAdminRestorePlan(name);
        const plan = await readJson(planRes);
        if (!planRes.ok) return showBackupRowStatus(btn, apiErrorMessage(plan, 'admin.backup.verify_failed'), true);
        showBackupRowStatus(btn, t(plan.cross_instance_restore ? 'admin.backup.verified_other' : 'admin.backup.verified', {
          name,
          schema: plan.source_schema_version ?? '?'
        }));

        const crossInstance = !!plan.cross_instance_restore;
        const confirmation = typedConfirmation(
          t(crossInstance ? 'admin.restore.confirm_other' : 'admin.restore.confirm', { name }),
          t(crossInstance ? 'admin.tokens.restore_other' : 'admin.tokens.restore')
        );
        if (!confirmation) return showStatus(t('admin.restore.confirmation_mismatch'), true);
        const password = prompt(t('admin.restore.password_prompt'));
        if (!password) return showStatus(t('admin.restore.password_missing'), true);

        showStatus(t('admin.restore.preparing', { name }));
        const restoreRes = await postAdminRestoreBackup(name, confirmation, password, true, crossInstance);
        const restoreData = await readJson(restoreRes);
        if (!restoreRes.ok) return showStatus(apiErrorMessage(restoreData, 'admin.restore.failed'), true);
        showStatus(t('admin.restore.staged', {
          backup: restoreData.pre_restore_backup || t('admin.restore.safety_created')
        }));
        await waitForServerAfterRestore();
      } finally {
        btn.disabled = false;
      }
    });
  });
}


function bindSystemControls() {
  const refreshStatus = document.getElementById('refreshSystemStatusBtn');
  if (refreshStatus && !refreshStatus.dataset.bound) {
    refreshStatus.dataset.bound = '1';
    refreshStatus.addEventListener('click', loadSystemStatus);
  }
  const recoveryBtn = document.getElementById('runRecoveryDiagnosticsBtn');
  if (recoveryBtn && !recoveryBtn.dataset.bound) {
    recoveryBtn.dataset.bound = '1';
    recoveryBtn.addEventListener('click', loadRecoveryDiagnostics);
  }
  const safeRepairBtn = document.getElementById('runSafeRepairBtn');
  if (safeRepairBtn && !safeRepairBtn.dataset.bound) {
    safeRepairBtn.dataset.bound = '1';
    safeRepairBtn.addEventListener('click', async () => {
      const expected = t('admin.tokens.safe_repair');
      const confirmation = typedConfirmation(t('admin.recovery.safe_repair_confirm'), expected);
      if (!confirmation) return showStatus(t('admin.recovery.safe_repair_cancelled'), true);
      safeRepairBtn.disabled = true;
      try {
        showStatus(t('admin.recovery.safe_repair_running'));
        const res = await postAdminSafeRepair(confirmation);
        const data = await readJson(res);
        if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.recovery.safe_repair_failed'), true);
        showStatus(t('admin.recovery.safe_repair_done', { backup: data.pre_repair_backup || t('common.missing') }));
        await Promise.all([loadRecoveryDiagnostics(), loadSystemStatus(), loadBackupManagement(), loadSystemLogs(), loadAuditLog()]);
      } finally {
        safeRepairBtn.disabled = false;
      }
    });
  }
  const refreshLogs = document.getElementById('refreshSystemLogsBtn');
  if (refreshLogs && !refreshLogs.dataset.bound) {
    refreshLogs.dataset.bound = '1';
    refreshLogs.addEventListener('click', loadSystemLogs);
  }

  const backupBtn = document.getElementById('createManualBackupBtn');
  if (backupBtn && !backupBtn.dataset.bound) {
    backupBtn.dataset.bound = '1';
    backupBtn.addEventListener('click', async () => {
      backupBtn.disabled = true;
      try {
        showStatus(t('admin.backup.creating'));
        const res = await postAdminManualBackup();
        const data = await readJson(res);
        if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.backup.create_failed'), true);
        showStatus(t('admin.backup.created', { name: data.backup?.name || 'database-backup' }));
        await Promise.all([loadSystemStatus(), loadRecoveryDiagnostics(), loadBackupManagement(), loadSystemLogs(), loadAuditLog()]);
      } finally {
        backupBtn.disabled = false;
      }
    });
  }

  const refreshBackups = document.getElementById('refreshBackupsBtn');
  if (refreshBackups && !refreshBackups.dataset.bound) {
    refreshBackups.dataset.bound = '1';
    refreshBackups.addEventListener('click', loadBackupManagement);
  }

  const saveBackupSettings = document.getElementById('saveBackupSettingsBtn');
  if (saveBackupSettings && !saveBackupSettings.dataset.bound) {
    saveBackupSettings.dataset.bound = '1';
    saveBackupSettings.addEventListener('click', async () => {
      const enabled = !!document.getElementById('backupAutoEnabled')?.checked;
      const keep = Number(document.getElementById('backupKeepCount')?.value || 14);
      const [hourRaw, minuteRaw] = String(document.getElementById('backupAutoTime')?.value || '03:00').split(':');
      const hour = Number(hourRaw);
      const minute = Number(minuteRaw);
      if (!Number.isInteger(keep) || keep < 1 || keep > 100) return showStatus(t('admin.backup.keep_invalid'), true);
      if (!Number.isInteger(hour) || !Number.isInteger(minute)) return showStatus(t('admin.backup.time_invalid'), true);

      saveBackupSettings.disabled = true;
      try {
        const res = await putAdminBackupSettings({ enabled, keep, hour, minute });
        const data = await readJson(res);
        if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.backup.settings_failed'), true);
        showStatus(t('admin.backup.settings_saved'));
        await Promise.all([loadSystemStatus(), loadBackupManagement(), loadAuditLog()]);
      } finally {
        saveBackupSettings.disabled = false;
      }
    });
  }

  for (const id of ['adminLogCategory', 'adminLogLevel']) {
    const el = document.getElementById(id);
    if (el && !el.dataset.bound) {
      el.dataset.bound = '1';
      el.addEventListener('change', loadSystemLogs);
    }
  }
}

export async function loadAdminPanel(currentUser) {
  if (!currentUser?.is_admin) return;
  const res = await fetchAdminSummary();
  if (!res.ok) {
    const data = await readJson(res);
    showStatus(apiErrorMessage(data, 'admin.summary.read_failed'), true);
    return;
  }
  const data = await res.json();
  document.getElementById('adminPlayers').innerHTML = data.players.map(p => playerCard(p, currentUser.id)).join('');
  document.getElementById('adminDecks').innerHTML = data.decks.map(deckCard).join('') || `<p class="text-sm text-gray-500">${t('admin.no_decks')}</p>`;
  document.getElementById('adminMatches').innerHTML = data.matches.map(matchCard).join('') || `<p class="text-sm text-gray-500">${t('admin.no_matches')}</p>`;
  renderResetCounts(data.counts);
  bindAdminActions(currentUser);
  bindSystemControls();
  await Promise.all([loadSystemStatus(), loadRecoveryDiagnostics(), loadBackupManagement(), loadSystemLogs(), loadAuditLog()]);
}

async function loadAuditLog() {
  const res = await fetchAdminAuditLog();
  if (!res.ok) return;
  const rows = await res.json();
  document.getElementById('adminAudit').innerHTML = rows.length ? rows.map(r => `
    <div class="text-xs border-b border-gray-800 py-1.5"><span class="text-gray-500">${escapeHtml(r.created_at)}</span> · <span class="text-amber-300">${escapeHtml(r.actor_name || t('common.system'))}</span> · ${escapeHtml(r.action)} · ${escapeHtml(r.target_type)} #${escapeHtml(r.target_id || '')}</div>
  `).join('') : `<div class="text-xs text-gray-500">${t('admin.audit.empty')}</div>`;
}

function bindAdminActions(currentUser) {
  document.querySelectorAll('.admin-set-password').forEach(btn => btn.addEventListener('click', async () => {
    const id = Number(btn.dataset.id);
    const input = document.querySelector(`.admin-password[data-id="${id}"]`);
    const password = input?.value || '';
    if (password.length < 4) return showStatus(t('admin.password.min'), true);
    if (!confirm(t(id === currentUser.id ? 'admin.confirm.set_password_self' : 'admin.confirm.set_password_player'))) return;
    const res = await postAdminPlayerPassword(id, password);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.password.failed'), true);
    input.value = '';
    if (id === currentUser.id) {
      alert(t('admin.password.self_changed'));
      location.reload();
      return;
    }
    showStatus(t('admin.password.changed'));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-delete-player').forEach(btn => btn.addEventListener('click', async () => {
    if (!confirm(t('admin.confirm.archive_player', { name: btn.dataset.name }))) return;
    const res = await deleteAdminPlayer(btn.dataset.id);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.player.archive_failed'), true);
    showStatus(t('admin.player.archived'));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-restore-player').forEach(btn => btn.addEventListener('click', async () => {
    const res = await restoreAdminPlayer(btn.dataset.id);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.player.restore_failed'), true);
    showStatus(t('admin.player.restored'));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-permanent-player').forEach(btn => btn.addEventListener('click', async () => {
    const expected = t('admin.tokens.delete_player', { name: btn.dataset.name });
    const confirmation = typedConfirmation(
      t('admin.confirm.delete_player', { name: btn.dataset.name }),
      expected
    );
    if (!confirmation) return showStatus(t('admin.delete.cancelled'), true);
    const res = await permanentlyDeleteAdminPlayer(btn.dataset.id, confirmation);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.player.delete_failed'), true);
    showStatus(t('admin.player.deleted', { count: data.deleted_decks || 0 }));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-delete-deck').forEach(btn => btn.addEventListener('click', async () => {
    if (btn.disabled || !confirm(t('admin.confirm.archive_deck', { name: btn.dataset.name }))) return;
    const res = await deleteAdminDeck(btn.dataset.id);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.deck.archive_failed'), true);
    showStatus(t('admin.deck.archived'));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-restore-deck').forEach(btn => btn.addEventListener('click', async () => {
    const res = await restoreAdminDeck(btn.dataset.id);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.deck.restore_failed'), true);
    showStatus(t('admin.deck.restored'));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-permanent-deck').forEach(btn => btn.addEventListener('click', async () => {
    if (btn.disabled) return;
    const expected = t('admin.tokens.delete_deck', { name: btn.dataset.name });
    const confirmation = typedConfirmation(
      t('admin.confirm.delete_deck', { name: btn.dataset.name }),
      expected
    );
    if (!confirmation) return showStatus(t('admin.delete.cancelled'), true);
    const res = await permanentlyDeleteAdminDeck(btn.dataset.id, confirmation);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.deck.delete_failed'), true);
    showStatus(t('admin.deck.deleted'));
    await loadAdminPanel(currentUser);
  }));

  document.querySelectorAll('.admin-delete-match').forEach(btn => btn.addEventListener('click', async () => {
    if (btn.disabled) return;
    const expected = t('admin.tokens.delete_match', { id: btn.dataset.id });
    const confirmation = typedConfirmation(
      t('admin.confirm.delete_match', { id: btn.dataset.id }),
      expected
    );
    if (!confirmation) return showStatus(t('admin.match.delete_cancelled'), true);
    const res = await deleteAdminMatch(btn.dataset.id, confirmation);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.match.delete_failed'), true);
    showStatus(t('admin.match.deleted', { id: btn.dataset.id }));
    await loadAdminPanel(currentUser);
  }));

  document.getElementById('adminResetMatchesBtn')?.addEventListener('click', async () => {
    const expected = t('admin.tokens.reset_matches');
    const confirmation = typedConfirmation(t('admin.confirm.reset_matches'), expected);
    if (!confirmation) return showStatus(t('admin.reset.matches_cancelled'), true);
    const res = await postAdminResetMatches(confirmation);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.reset.matches_failed'), true);
    showStatus(t('admin.reset.matches_done', { count: data.deleted_matches || 0 }));
    await loadAdminPanel(currentUser);
  });

  document.getElementById('adminResetDecksBtn')?.addEventListener('click', async () => {
    const expected = t('admin.tokens.reset_decks');
    const confirmation = typedConfirmation(t('admin.confirm.reset_decks'), expected);
    if (!confirmation) return showStatus(t('admin.reset.decks_cancelled'), true);
    const res = await postAdminResetDecks(confirmation);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.reset.decks_failed'), true);
    showStatus(t('admin.reset.decks_done', { count: data.deleted_decks || 0 }));
    await loadAdminPanel(currentUser);
  });

  document.getElementById('adminResetPlayersBtn')?.addEventListener('click', async () => {
    const expected = t('admin.tokens.reset_players');
    const confirmation = typedConfirmation(t('admin.confirm.reset_players'), expected);
    if (!confirmation) return showStatus(t('admin.reset.players_cancelled'), true);
    const res = await postAdminResetPlayers(confirmation);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.reset.players_failed'), true);
    showStatus(t('admin.reset.players_done', { players: data.deleted_players || 0, decks: data.deleted_decks || 0 }));
    await loadAdminPanel(currentUser);
  });

  document.getElementById('adminFactoryResetBtn')?.addEventListener('click', async () => {
    const expected = t('admin.tokens.factory');
    const confirmation = typedConfirmation(t('admin.confirm.factory'), expected);
    if (!confirmation) return showStatus(t('admin.factory.cancelled'), true);

    const password = prompt(t('admin.factory.password_prompt'));
    if (!password) return showStatus(t('admin.factory.password_missing'), true);

    const res = await postAdminFactoryReset(confirmation, password);
    const data = await readJson(res);
    if (!res.ok) return showStatus(apiErrorMessage(data, 'admin.factory.failed'), true);
    showStatus(t('admin.factory.done'));
    await loadAdminPanel(currentUser);
  });
}
