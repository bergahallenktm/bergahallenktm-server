import { fetchDeckCatalog, postSaveDeck, deleteDeckApi, restoreDeckApi, postImportCsv } from './api.js';
import { currentUser, cardLinkPreference } from './main.js';
import { escapeHtml, loadDashboardData } from './dashboard.js';
import { t, apiErrorMessage } from './i18n.js';

const COLOR_ORDER = ['W', 'U', 'B', 'R', 'G'];
let deckUxListenersBound = false;
let allDeckFilterOptionsLoaded = false;
let allDeckCatalogSeed = [];

function normalizeColorIdentityClient(value) {
  if (!value) return null;
  const raw = String(value).toUpperCase();
  const found = new Set([...raw].filter(c => COLOR_ORDER.includes(c)));
  if (found.size) return COLOR_ORDER.filter(c => found.has(c)).join('');
  return raw.includes('C') ? 'C' : null;
}

function selectedDeckColorIdentity() {
  const checked = [...document.querySelectorAll('input[name="deckColor"]:checked')].map(el => el.value);
  if (checked.includes('C')) return checked.length === 1 ? 'C' : null;
  return COLOR_ORDER.filter(c => checked.includes(c)).join('') || null;
}

function setDeckColorIdentity(value) {
  const normalized = normalizeColorIdentityClient(value);
  document.querySelectorAll('input[name="deckColor"]').forEach(el => {
    el.checked = normalized === 'C' ? el.value === 'C' : !!normalized?.includes(el.value);
  });
}

function colorIdentityBadge(identity) {
  const normalized = normalizeColorIdentityClient(identity);
  return normalized
    ? `<span class="deck-identity-badge" title="${escapeHtml(t('decks.identity_title'))}">${escapeHtml(normalized)}</span>`
    : `<span class="deck-identity-badge deck-identity-unknown">${escapeHtml(t('decks.no_color'))}</span>`;
}

function deckStatusBadge(deck) {
  const archived = Number(deck.archived || 0) === 1;
  return archived
    ? `<span class="text-[10px] uppercase tracking-wide px-2 py-0.5 rounded-full border border-gray-600 text-gray-400">${escapeHtml(t('decks.archived'))}</span>`
    : `<span class="text-[10px] uppercase tracking-wide px-2 py-0.5 rounded-full border border-emerald-800/70 text-emerald-300">${escapeHtml(t('decks.active'))}</span>`;
}

function deckUpdatedText(deck) {
  if (!deck.updated_at) return '';
  const raw = String(deck.updated_at).replace(' ', 'T');
  const date = new Date(raw.endsWith('Z') ? raw : `${raw}Z`);
  if (Number.isNaN(date.getTime())) return '';
  return t('decks.updated_at', { value: date.toLocaleString() });
}

export let myDecks = [];

function countDeckCards(decklist) {
  if (!decklist) return 0;
  return String(decklist).split(/\r?\n/).reduce((total, rawLine) => {
    const line = rawLine.trim();
    if (!line || line.startsWith('//') || line.startsWith('#')) return total;
    const quantityMatch = line.match(/^(\d+)\s*(?:x\s+)?(.+)$/i);
    if (quantityMatch) {
      const quantity = Number.parseInt(quantityMatch[1], 10);
      return total + (Number.isFinite(quantity) && quantity > 0 ? quantity : 0);
    }
    return total + 1;
  }, 0);
}

// Legacy decklist metadata must remain comment-prefixed so the server card-count
// parser never mistakes section labels (for example COMMANDER) for physical cards.
function renderCardLinks(decklist) {
  if (!decklist) return escapeHtml(t('decks.no_list'));
  const lines = String(decklist).split(/\r?\n/).filter(line => line.trim());
  if (!lines.length) return escapeHtml(t('decks.no_list'));

  const baseUrl = cardLinkPreference === 'gatherer'
    ? 'https://gatherer.wizards.com/Pages/Card/Details.aspx?name='
    : 'https://scryfall.com/search?q=';

  return lines.map(line => {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('#')) {
      return `<span class="text-gray-500">${escapeHtml(line)}</span>`;
    }
    let cardName = trimmed;
    const qtyMatch = cardName.match(/^\d+\s+(?:x\s+)?(.+)/i);
    if (qtyMatch) cardName = qtyMatch[1];
    cardName = cardName.replace(/\s*\([^)]*\)\s*$/, '');
    cardName = cardName.replace(/\s+[A-Z0-9]+-\d+$/, '');
    cardName = cardName.trim();
    return `<a href="${baseUrl}${encodeURIComponent(cardName)}" target="_blank" rel="noopener noreferrer" class="card-link">${escapeHtml(line)}</a>`;
  }).join('\n');
}

function splitSort(value, fallback = 'name:asc') {
  const [sort, direction] = String(value || fallback).split(':');
  return { sort: sort || 'name', direction: direction === 'desc' ? 'desc' : 'asc' };
}

function catalogItem(deck, { mine = false } = {}) {
  const archived = Number(deck.archived || 0) === 1;
  const updated = deckUpdatedText(deck);
  const meta = [
    mine ? escapeHtml(deck.format || '') : `${escapeHtml(deck.owner_name || '')} · ${escapeHtml(deck.format || '')}`,
    `🃏 ${escapeHtml(t('decks.cards', { count: deck.card_count ?? countDeckCards(deck.decklist) }))}`
  ].filter(Boolean).join(' · ');

  const actions = mine
    ? archived
      ? `<button type="button" data-deck-id="${Number(deck.id)}" data-revision="${Number(deck.sync_revision || 0)}" class="btn-restore-deck text-xs bg-emerald-700 hover:bg-emerald-600 px-2.5 py-1 rounded font-semibold transition-all active:scale-95">↩ ${escapeHtml(t('decks.restore'))}</button>`
      : `<button type="button" data-deck-id="${Number(deck.id)}" class="btn-edit-deck text-xs bg-amber-600 hover:bg-amber-500 px-2.5 py-1 rounded font-semibold transition-all active:scale-95">✏️ ${escapeHtml(t('decks.edit'))}</button>
         <button type="button" data-deck-id="${Number(deck.id)}" data-revision="${Number(deck.sync_revision || 0)}" class="btn-delete-deck text-xs bg-gray-700 hover:bg-gray-600 px-2.5 py-1 rounded font-semibold transition-all active:scale-95">📦 ${escapeHtml(t('decks.archive'))}</button>`
    : '';

  return `
    <div class="bg-gray-800 p-4 rounded-lg border ${archived ? 'border-gray-700 opacity-75' : 'border-gray-700 hover:border-amber-500/50'} space-y-2 transition-all">
      <div class="flex justify-between gap-3 items-start">
        <div class="min-w-0">
          <div class="flex flex-wrap items-center gap-2">
            <h3 class="font-bold ${archived ? 'text-gray-300' : 'text-amber-400'} truncate">${escapeHtml(deck.name)}</h3>
            ${deckStatusBadge(deck)}
            ${colorIdentityBadge(deck.color_identity)}
          </div>
          <div class="text-xs text-gray-400 mt-1">${meta}</div>
          ${updated ? `<div class="text-[11px] text-gray-500 mt-1">${escapeHtml(updated)}</div>` : ''}
          ${!mine && currentUser && Number(deck.owner_id) !== Number(currentUser.id) ? `<div class="text-[11px] text-sky-300/80 mt-1">${escapeHtml(t('decks.borrowable_owner', { owner: deck.owner_name }))}</div>` : ''}
        </div>
        ${actions ? `<div class="flex flex-wrap justify-end gap-2 flex-shrink-0">${actions}</div>` : ''}
      </div>
      <details class="text-xs text-gray-300">
        <summary class="cursor-pointer text-amber-500/80 hover:text-amber-400 transition-all">${escapeHtml(t('decks.show_list'))}</summary>
        <pre class="mt-2 bg-gray-900 p-2 rounded font-mono text-xs overflow-x-auto whitespace-pre-wrap">${renderCardLinks(deck.decklist)}</pre>
      </details>
    </div>`;
}

async function seedAllDeckFilters(force = false) {
  if (allDeckFilterOptionsLoaded && !force) return;
  const data = await fetchDeckCatalog({ scope: 'all', limit: 500, sort: 'name', direction: 'asc' });
  allDeckCatalogSeed = Array.isArray(data?.items) ? data.items : [];
  const ownerEl = document.getElementById('deckFilterOwner');
  const formatEl = document.getElementById('deckFilterFormat');
  if (!ownerEl || !formatEl) return;
  const ownerValue = ownerEl.value;
  const formatValue = formatEl.value;
  const owners = [...new Map(allDeckCatalogSeed.map(d => [String(d.owner_id), d.owner_name])).entries()]
    .sort((a, b) => String(a[1]).localeCompare(String(b[1]), undefined, { sensitivity:'base' }));
  const formats = [...new Set(allDeckCatalogSeed.map(d => d.format).filter(Boolean))]
    .sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity:'base' }));
  ownerEl.innerHTML = `<option value="">${escapeHtml(t('decks.filter_all_owners'))}</option>${owners.map(([id, name]) => `<option value="${escapeHtml(id)}">${escapeHtml(name)}</option>`).join('')}`;
  formatEl.innerHTML = `<option value="">${escapeHtml(t('decks.filter_all_formats'))}</option>${formats.map(format => `<option value="${escapeHtml(format)}">${escapeHtml(format)}</option>`).join('')}`;
  if ([...ownerEl.options].some(o => o.value === ownerValue)) ownerEl.value = ownerValue;
  if ([...formatEl.options].some(o => o.value === formatValue)) formatEl.value = formatValue;
  allDeckFilterOptionsLoaded = true;
}

export async function renderAllDecksView({ refreshFilters = false } = {}) {
  await seedAllDeckFilters(refreshFilters);
  const search = document.getElementById('deckSearchAll')?.value || '';
  const ownerId = document.getElementById('deckFilterOwner')?.value || '';
  const format = document.getElementById('deckFilterFormat')?.value || '';
  const { sort, direction } = splitSort(document.getElementById('deckSortAll')?.value);
  const data = await fetchDeckCatalog({ scope:'all', q:search, owner_id:ownerId, format, sort, direction, limit:500 });
  const items = Array.isArray(data?.items) ? data.items : [];
  const view = document.getElementById('allDecksView');
  const empty = document.getElementById('allDecksEmpty');
  const count = document.getElementById('allDecksCount');
  if (view) view.innerHTML = items.map(d => catalogItem(d)).join('');
  if (empty) empty.classList.toggle('hidden', items.length > 0);
  if (count) count.textContent = t('decks.result_count', { count: Number(data?.total ?? items.length) });
}

function mineQuery() {
  const statusValue = document.getElementById('deckStatusMine')?.value || 'active';
  const { sort, direction } = splitSort(document.getElementById('deckSortMine')?.value);
  return {
    scope:'mine',
    include_archived: statusValue === 'active' ? 0 : 1,
    status: statusValue === 'all' ? '' : statusValue,
    q: document.getElementById('deckSearchMine')?.value || '',
    sort,
    direction,
    limit:500
  };
}

export async function loadMyDecks() {
  if (!currentUser) {
    myDecks = [];
    return;
  }
  const data = await fetchDeckCatalog(mineQuery());
  myDecks = Array.isArray(data?.items) ? data.items : [];
  const list = document.getElementById('myDecksList');
  const empty = document.getElementById('myDecksEmpty');
  const count = document.getElementById('myDecksCount');
  if (list) list.innerHTML = myDecks.map(d => catalogItem(d, { mine:true })).join('');
  if (empty) empty.classList.toggle('hidden', myDecks.length > 0);
  if (count) count.textContent = t('decks.result_count', { count:Number(data?.total ?? myDecks.length) });

  document.querySelectorAll('.btn-edit-deck').forEach(btn => btn.addEventListener('click', event => editDeck(Number(event.currentTarget.dataset.deckId))));
  document.querySelectorAll('.btn-delete-deck').forEach(btn => btn.addEventListener('click', event => archiveDeck(Number(event.currentTarget.dataset.deckId), Number(event.currentTarget.dataset.revision))));
  document.querySelectorAll('.btn-restore-deck').forEach(btn => btn.addEventListener('click', event => restoreDeck(Number(event.currentTarget.dataset.deckId), Number(event.currentTarget.dataset.revision))));
}

export function editDeck(id) {
  const deck = myDecks.find(d => Number(d.id) === Number(id));
  if (!deck || Number(deck.archived || 0) === 1) return;
  document.getElementById('deckId').value = deck.id;
  document.getElementById('deckRevision').value = Number(deck.sync_revision || 0);
  document.getElementById('deckName').value = deck.name;
  document.getElementById('deckFormat').value = deck.format;
  document.getElementById('decklist').value = deck.decklist || '';
  setDeckColorIdentity(deck.color_identity);
  document.getElementById('deckName').scrollIntoView({ behavior:'smooth', block:'center' });
}

export function clearDeckForm() {
  document.getElementById('deckId').value = '';
  document.getElementById('deckRevision').value = '';
  document.getElementById('deckName').value = '';
  document.getElementById('deckFormat').value = 'Commander';
  document.getElementById('decklist').value = '';
  setDeckColorIdentity(null);
}

async function refreshDeckViews({ refreshFilters = true } = {}) {
  allDeckFilterOptionsLoaded = false;
  await Promise.all([
    renderAllDecksView({ refreshFilters }),
    currentUser ? loadMyDecks() : Promise.resolve(),
    loadDashboardData()
  ]);
}

function handleDeckConflict(data) {
  if (data?.code !== 'DECK_REVISION_CONFLICT') return false;
  alert(t('decks.revision_conflict'));
  clearDeckForm();
  refreshDeckViews().catch(console.error);
  return true;
}

export async function saveDeck() {
  const id = document.getElementById('deckId').value;
  const revisionRaw = document.getElementById('deckRevision').value;
  const name = document.getElementById('deckName').value.trim();
  const format = document.getElementById('deckFormat').value;
  const decklist = document.getElementById('decklist').value;
  const color_identity = selectedDeckColorIdentity();

  if (!name) return alert(t('decks.name_required'));
  const selectedColors = [...document.querySelectorAll('input[name="deckColor"]:checked')].map(el => el.value);
  if (selectedColors.includes('C') && selectedColors.length > 1) return alert(t('decks.colorless_conflict'));

  const payload = { name, format, decklist, color_identity };
  if (id && revisionRaw !== '') payload.expected_revision = Number(revisionRaw);
  const res = await postSaveDeck(id, payload);
  const data = await res.json().catch(() => ({}));
  if (res.ok) {
    clearDeckForm();
    await refreshDeckViews();
  } else if (!handleDeckConflict(data)) {
    alert(apiErrorMessage(data));
  }
}

export async function importManaBoxCsv() {
  const fileInput = document.getElementById('manaBoxCsvFile');
  const format = document.getElementById('importDeckFormat').value;
  if (!fileInput.files?.length) return alert(t('decks.file_required'));
  const file = fileInput.files[0];
  const reader = new FileReader();
  reader.onload = async event => {
    const res = await postImportCsv({ fileName:file.name, csvContent:event.target.result, format });
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      alert(t('decks.import_success', { name:data.name, count:data.cardCount }));
      fileInput.value = '';
      await refreshDeckViews();
    } else alert(t('decks.import_failed', { error:apiErrorMessage(data) }));
  };
  reader.readAsText(file);
}

export async function archiveDeck(id, expectedRevision = null) {
  if (!confirm(t('decks.archive_confirm'))) return;
  const res = await deleteDeckApi(id, expectedRevision);
  const data = await res.json().catch(() => ({}));
  if (res.ok) {
    if (String(document.getElementById('deckId')?.value) === String(id)) clearDeckForm();
    await refreshDeckViews();
  } else if (!handleDeckConflict(data)) alert(apiErrorMessage(data));
}

// Backward-compatible exported name used by older imports/tests.
export const deleteDeck = archiveDeck;

export async function restoreDeck(id, expectedRevision = null) {
  const res = await restoreDeckApi(id, expectedRevision);
  const data = await res.json().catch(() => ({}));
  if (res.ok) await refreshDeckViews();
  else if (!handleDeckConflict(data)) alert(apiErrorMessage(data));
}

export function setupDeckUxListeners() {
  if (deckUxListenersBound) return;
  deckUxListenersBound = true;
  const debounce = (fn, wait = 180) => {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), wait);
    };
  };
  const rerenderAll = debounce(() => renderAllDecksView().catch(console.error));
  const rerenderMine = debounce(() => loadMyDecks().catch(console.error));
  document.getElementById('deckSearchAll')?.addEventListener('input', rerenderAll);
  document.getElementById('deckFilterOwner')?.addEventListener('change', rerenderAll);
  document.getElementById('deckFilterFormat')?.addEventListener('change', rerenderAll);
  document.getElementById('deckSortAll')?.addEventListener('change', rerenderAll);
  document.getElementById('deckSearchMine')?.addEventListener('input', rerenderMine);
  document.getElementById('deckStatusMine')?.addEventListener('change', rerenderMine);
  document.getElementById('deckSortMine')?.addEventListener('change', rerenderMine);
}
