export function createLiveMatchMutationQueue({
  getMatch,
  setMatch,
  postLife,
  postPoison,
  postTax,
  onRefresh,
  onSuccess,
  onError,
  debounceMs = 1000,
  setTimeoutFn = setTimeout,
  clearTimeoutFn = clearTimeout
}) {
  const pending = { life:Object.create(null), poison:Object.create(null), tax:Object.create(null) };
  const timers = { life:Object.create(null), poison:Object.create(null), tax:Object.create(null) };

  function add(kind, playerId, change) {
    pending[kind][playerId] = (pending[kind][playerId] || 0) + change;
    clearTimeoutFn(timers[kind][playerId]);
    timers[kind][playerId] = setTimeoutFn(() => { void send(kind, playerId); }, debounceMs);
    return pending[kind][playerId];
  }

  async function send(kind, playerId) {
    const change = pending[kind][playerId] || 0;
    pending[kind][playerId] = 0;
    if (!change) return null;
    const match = getMatch();
    if (!match) return null;

    const sender = kind === 'life' ? postLife : kind === 'poison' ? postPoison : postTax;
    try {
      const res = await sender(match.id, Number(playerId), change);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        onError?.(kind, Number(playerId), { response:res, data });
        onRefresh?.();
        return { ok:false, response:res, data };
      }

      const data = kind === 'life'
        ? await res.json()
        : (kind === 'poison' ? await res.json().catch(() => ({})) : {});
      if (data.match) setMatch(data.match);
      onSuccess?.(kind, Number(playerId), data);
      return { ok:true, response:res, data };
    } catch (error) {
      onError?.(kind, Number(playerId), { error });
      onRefresh?.();
      return { ok:false, error };
    }
  }

  async function flushAll() {
    const promises = [];
    for (const kind of ['life','poison','tax']) {
      for (const playerId of Object.keys(pending[kind])) {
        if (pending[kind][playerId] !== 0) {
          clearTimeoutFn(timers[kind][playerId]);
          promises.push(send(kind, Number(playerId)));
        }
      }
    }
    if (promises.length) await Promise.all(promises);
  }

  function pendingChange(kind, playerId) {
    return Number(pending[kind]?.[playerId] || 0);
  }

  function hasPending() {
    return ['life','poison','tax'].some(kind =>
      Object.values(pending[kind]).some(change => Number(change) !== 0)
    );
  }

  return Object.freeze({
    addLife:(id,c)=>add('life',id,c),
    addPoison:(id,c)=>add('poison',id,c),
    addTax:(id,c)=>add('tax',id,c),
    send,
    flushAll,
    pendingChange,
    hasPending
  });
}
