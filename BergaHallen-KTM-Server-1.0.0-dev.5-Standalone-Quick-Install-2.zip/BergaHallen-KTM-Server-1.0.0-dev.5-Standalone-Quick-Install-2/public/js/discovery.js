import { fetchMeta, fetchDiscoveryProvision, discoveryQrUrl } from './api.js';
import { t } from './i18n.js';

let initialized = false;
let lastProvision = null;
let lastStatus = { key: 'discovery.loading', kind: 'info', vars: {} };

function isLoopbackHost(hostname) {
  const value = String(hostname || '').toLowerCase();
  return value === 'localhost' || value === '127.0.0.1' || value === '::1' || value === '[::1]';
}

function shortUid(uid) {
  const value = String(uid || '');
  return value.length > 12 ? `${value.slice(0, 8)}…${value.slice(-4)}` : value;
}

function endpointUrls(provision) {
  const urls = (provision?.endpoints || []).map(item => item?.url).filter(Boolean);
  if (!urls.length && provision?.url) urls.push(provision.url); // legacy response safety
  return [...new Set(urls)];
}

function renderStatus() {
  const el = document.getElementById('serverDiscoveryStatus');
  if (!el) return;
  const { key, kind, vars } = lastStatus;
  el.textContent = t(key, vars);
  el.className = kind === 'error' ? 'text-xs text-red-300' : kind === 'warn' ? 'text-xs text-amber-300' : 'text-xs text-gray-400';
}

function setStatus(key, kind='info', vars={}) {
  lastStatus = { key, kind, vars };
  renderStatus();
}

function setLoading(loading) {
  for (const id of ['serverDiscoveryRefreshBtn','serverDiscoveryCopyBtn']) {
    const el = document.getElementById(id);
    if (el) el.disabled = !!loading;
  }
}

function renderEndpointList(urls) {
  const el = document.getElementById('serverDiscoveryEndpoints');
  if (!el) return;
  el.textContent = '';
  for (const url of urls) {
    const row = document.createElement('div');
    row.className = 'font-mono text-xs text-sky-200 break-all';
    row.textContent = url;
    el.appendChild(row);
  }
  el.classList.toggle('hidden', urls.length <= 1);
}

function setIdentity(meta) {
  const instance = document.getElementById('serverDiscoveryInstance');
  if (instance) instance.textContent = shortUid(meta?.instance_uid);
  const version = document.getElementById('serverDiscoveryVersion');
  if (version) version.textContent = meta?.app_version || '';
}

function configureQr(urls, browserEndpoint) {
  const qr = document.getElementById('serverConnectQr');
  if (!qr) return;
  const candidates = urls.length ? urls : [browserEndpoint];
  const separator = candidates.length ? '&' : '?';
  qr.alt = t('discovery.qr_alt');
  qr.onload = () => { qr.classList.remove('hidden'); };
  qr.onerror = () => {
    qr.classList.add('hidden');
    setStatus('discovery.qr_failed', 'error');
  };
  qr.src = `${discoveryQrUrl({ endpoints:candidates })}${separator}r=${Date.now()}`;
}

export async function refreshDiscoveryPanel() {
  const panel = document.getElementById('serverDiscoveryPanel');
  if (!panel) return;
  setLoading(true);
  setStatus('discovery.loading');

  const browserEndpoint = window.location.origin;

  try {
    // /meta is the normative final verification source. Populate identity first,
    // independently of the optional /discovery probe and provisioning helpers.
    const meta = await fetchMeta();
    setIdentity(meta);

    let provision;
    try {
      provision = await fetchDiscoveryProvision({ endpoints:[browserEndpoint] });
    } catch (error) {
      console.error('Discovery provisioning failed.', error);
      lastProvision = { endpoints:[{ url: browserEndpoint }], url:browserEndpoint };
      const input = document.getElementById('serverConnectUrl');
      if (input) input.value = browserEndpoint;
      renderEndpointList([browserEndpoint]);
      configureQr([browserEndpoint], browserEndpoint);
      setStatus('discovery.provision_failed', 'error');
      return;
    }

    lastProvision = provision;
    const urls = endpointUrls(provision);
    const primary = urls[0] || browserEndpoint;
    const input = document.getElementById('serverConnectUrl');
    if (input) input.value = primary;
    renderEndpointList(urls);
    configureQr(urls, browserEndpoint);

    if (isLoopbackHost(window.location.hostname) && urls.every(url => {
      try { return isLoopbackHost(new URL(url).hostname); } catch (_) { return true; }
    })) {
      setStatus('discovery.loopback_warning', 'warn');
    } else if (urls.length > 1) {
      setStatus('discovery.multiple_ready', 'info', { count:String(urls.length) });
    } else {
      setStatus('discovery.ready');
    }
  } catch (error) {
    console.error('Discovery panel failed.', error);
    setIdentity(null);
    setStatus('discovery.load_failed', 'error');
  } finally {
    setLoading(false);
  }
}

async function copyAddress() {
  const urls = endpointUrls(lastProvision);
  const value = urls[0] || document.getElementById('serverConnectUrl')?.value || window.location.origin;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
    } else {
      const input = document.getElementById('serverConnectUrl');
      input?.focus(); input?.select(); document.execCommand('copy');
    }
    setStatus('discovery.copied');
  } catch (_) {
    setStatus('discovery.copy_failed', 'error');
  }
}

export function initDiscoveryPanel({ refresh=true } = {}) {
  if (!initialized) {
    document.getElementById('serverDiscoveryRefreshBtn')?.addEventListener('click', refreshDiscoveryPanel);
    document.getElementById('serverDiscoveryCopyBtn')?.addEventListener('click', copyAddress);
    window.addEventListener('bergahallen:locale-changed', renderStatus);
    initialized = true;
  }
  if (refresh) return refreshDiscoveryPanel();
  return Promise.resolve();
}
