import { 
  fetchActiveMatch, fetchActiveMatches, fetchMyActiveMatch, postLifeChange, postPoisonChange, postTaxChange, 
  postUndo, postNextTurn, postFinishMatch, postFinishTeamMatch, deleteAbortMatch, postConcede,
  postCommanderDamage, postReorderMatchSeats, postPauseTimer, postResumeTimer, fetchMatchTimer,
  postRevealHiddenRole, postClaimHiddenTarget, postClaimThrone, postDeclineThrone, postDayNightState
} from './api.js';
import { escapeHtml } from './dashboard.js';
import { matchFormatLabel, matchPlayModeLabel, matchLimitedFormatLabel, matchModifierLabels } from './matchFormatUi.js';
import { triggerHaptic } from './dice.js';
import { t, apiErrorMessage } from './i18n.js';
import {
  deckIdentityPresentation, boardLayoutStorageKey, normalizeRotation, rotationClassFor,
  deriveBoardLayout, turnOrderFromDisplayOrder
} from './liveMatchPresentation.js';
import { createLiveMatchTimerController } from './liveMatchTimer.js';
import { createLiveMatchMutationQueue } from './liveMatchMutationQueue.js';

export let activeMatchData = null;
let selectedActiveMatchId = null;

let wakeLock = null;

const indicatorHideTimers = {};

// Klick inom detta fönster räknas som samma sammanhängande serie.
// 1000 ms gör att normal mänsklig klickrytm inte delas upp i +2, +3, +1 osv.
const COUNTER_BATCH_WINDOW_MS = 1000;
const LIFE_INDICATOR_HIDE_MS = 1800;

const liveMatchTimer = createLiveMatchTimerController({
  getActiveMatch: () => activeMatchData,
  setActiveMatch: match => { activeMatchData = match; },
  refreshActiveMatch: () => checkActiveMatch(),
  fetchTimer: fetchMatchTimer,
  pauseTimer: postPauseTimer,
  resumeTimer: postResumeTimer,
  haptic: triggerHaptic,
  translate: t,
  errorMessage: apiErrorMessage
});

const liveMatchMutationQueue = createLiveMatchMutationQueue({
  getMatch: () => activeMatchData,
  setMatch: match => { activeMatchData = match; },
  postLife: postLifeChange,
  postPoison: postPoisonChange,
  postTax: postTaxChange,
  onRefresh: () => checkActiveMatch(),
  onSuccess: (kind, playerId, data) => {
    if (kind === 'life') {
      if (activeMatchData?.rules?.life_scope === 'team') renderCompanionGrid();
      const player = activeMatchData?.players?.find(p => p.player_id === playerId);
      if (player && data.isEliminated) {
        player.is_eliminated = 1;
        player.eliminated_reason = '0 HP';
        updatePlayerCardEliminationState(playerId, t('live.eliminated_with_reason', { reason: '0 HP' }));
        checkAutoWin();
      }
      return;
    }
    if (kind === 'poison') {
      if (activeMatchData?.rules?.poison_scope === 'team') renderCompanionGrid();
      if (data.isEliminated || activeMatchData?.status === 'completed') checkAutoWin();
    }
  },
  onError: (kind, _playerId, detail) => {
    if (detail.error) {
      console.error(`Error saving ${kind} change:`, detail.error);
      alert(t(`live.${kind}_server_failed`, { error: detail.error.message }));
      return;
    }
    alert(t(`live.${kind}_save_failed`, { error: apiErrorMessage(detail.data) || detail.response?.status }));
  },
  debounceMs: COUNTER_BATCH_WINDOW_MS
});

const bgColors = [
  'bg-gradient-to-br from-sky-700 to-sky-900',
  'bg-gradient-to-br from-emerald-700 to-emerald-900',
  'bg-gradient-to-br from-amber-700 to-amber-900',
  'bg-gradient-to-br from-purple-700 to-purple-900',
  'bg-gradient-to-br from-rose-700 to-rose-900',
  'bg-gradient-to-br from-cyan-700 to-cyan-900'
];


// Bordslayout är lokal för varje webbläsare/enhet. En surfplatta som ligger på
// bordet kan alltså ha en annan placering/orientering än en spelares telefon.
let boardArrangeMode = false;
let selectedLayoutPlayerId = null;
let rotationResizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(rotationResizeTimer);
  rotationResizeTimer = setTimeout(() => applyPlayerRotationGeometry(), 80);
});


function getBoardLayout() {
  if (!activeMatchData) return { order: [], rotations: {} };
  let saved = null;
  try {
    saved = JSON.parse(localStorage.getItem(boardLayoutStorageKey(activeMatchData.id)) || 'null');
  } catch (_) {
    saved = null;
  }
  return deriveBoardLayout(activeMatchData.players || [], saved);
}

function saveBoardLayout(layout) {
  if (!activeMatchData) return;
  localStorage.setItem(boardLayoutStorageKey(activeMatchData.id), JSON.stringify(layout));
}

function updateBoardArrangeControls() {
  const arrangeBtn = document.getElementById('arrangeBoardBtn');
  const resetBtn = document.getElementById('resetBoardLayoutBtn');
  if (arrangeBtn) {
    arrangeBtn.innerHTML = boardArrangeMode ? t('live.arrange_done') : t('live.arrange');
    arrangeBtn.classList.toggle('bg-amber-600', boardArrangeMode);
    arrangeBtn.classList.toggle('text-gray-950', boardArrangeMode);
    arrangeBtn.classList.toggle('bg-gray-800', !boardArrangeMode);
  }
  if (resetBtn) resetBtn.classList.toggle('hidden', !boardArrangeMode);
}


async function saveVisualTurnOrder(layoutSnapshot = null) {
  if (!activeMatchData) return true;

  // Ta en fristående kopia innan servern ändrar seat_index och returnerar matchen
  // i den nya turordningen. Den lokala sittplaceringen är en separat sak och ska
  // aldrig tappas bara för att serverns spelarlista sorteras om.
  const layout = layoutSnapshot || getBoardLayout();
  const preservedLayout = {
    order: [...layout.order],
    rotations: { ...layout.rotations }
  };
  const turnOrder = turnOrderFromDisplayOrder(preservedLayout.order);
  const matchId = activeMatchData.id;

  const res = await postReorderMatchSeats(matchId, turnOrder);
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    alert(t('live.save_order_failed', { error: apiErrorMessage(data) || res.status }));
    return false;
  }

  const data = await res.json().catch(() => ({}));
  if (data.match) activeMatchData = data.match;

  // Skriv tillbaka exakt den visuella layout som användaren godkände. Detta gör
  // att en server-render/fetch inte kan återställa korten efter "Klar".
  localStorage.setItem(boardLayoutStorageKey(matchId), JSON.stringify(preservedLayout));
  return true;
}

export async function toggleBoardArrangeMode() {
  if (boardArrangeMode) {
    const layoutSnapshot = getBoardLayout();
    const saved = await saveVisualTurnOrder(layoutSnapshot);
    if (!saved) return;
    // Extra försäkring: spara även efter att serverresponsen uppdaterat
    // activeMatchData, eftersom dess players-array nu har annan seat_index-sortering.
    saveBoardLayout(layoutSnapshot);
  }
  boardArrangeMode = !boardArrangeMode;
  selectedLayoutPlayerId = null;
  updateBoardArrangeControls();
  if (activeMatchData) renderCompanionGrid();
}

export function resetBoardLayout() {
  if (!activeMatchData) return;
  localStorage.removeItem(boardLayoutStorageKey(activeMatchData.id));
  selectedLayoutPlayerId = null;
  renderCompanionGrid();
}

function rotateLayoutPlayer(playerId) {
  const layout = getBoardLayout();
  const id = Number(playerId);
  if (!layout.order.includes(id)) return;

  const currentRotation = normalizeRotation(layout.rotations[id]);
  layout.rotations[id] = (currentRotation + 90) % 360;
  saveBoardLayout(layout);
  renderCompanionGrid();
}

function selectOrSwapLayoutPlayer(playerId) {
  const id = Number(playerId);
  if (!selectedLayoutPlayerId) {
    selectedLayoutPlayerId = id;
    renderCompanionGrid();
    return;
  }

  if (selectedLayoutPlayerId === id) {
    selectedLayoutPlayerId = null;
    renderCompanionGrid();
    return;
  }

  const layout = getBoardLayout();
  const a = layout.order.indexOf(Number(selectedLayoutPlayerId));
  const b = layout.order.indexOf(id);
  if (a !== -1 && b !== -1) {
    [layout.order[a], layout.order[b]] = [layout.order[b], layout.order[a]];
    saveBoardLayout(layout);
  }
  selectedLayoutPlayerId = null;
  renderCompanionGrid();
}

export async function requestWakeLock() {
  if ('wakeLock' in navigator) {
    try {
      wakeLock = await navigator.wakeLock.request('screen');
    } catch (err) {
      console.log('Wake Lock Error:', err);
    }
  }
}

export function releaseWakeLock() {
  if (wakeLock !== null) {
    wakeLock.release();
    wakeLock = null;
  }
}

function showWinnerCelebration(winnerName) {
  if (document.getElementById('auto-win-modal')) return;
  const overlay = document.createElement('div');
  overlay.id = 'auto-win-modal';
  overlay.className = 'fixed inset-0 bg-black/95 flex flex-col items-center justify-center p-4 z-[100] winner-glow backdrop-blur-sm';
  overlay.innerHTML = `
    <div class="text-center space-y-6 transform scale-0 animate-[popIn_0.6s_cubic-bezier(0.175,0.885,0.32,1.275)_forwards]">
      <h2 class="text-4xl sm:text-6xl font-black text-amber-400 drop-shadow-[0_0_20px_rgba(251,191,36,0.8)] tracking-wider">VENI, VIDI, VICI</h2>
      <p class="text-2xl sm:text-3xl text-gray-200 mt-6">${t('live.congrats', { name: `<span class="font-bold text-white">${escapeHtml(winnerName)}</span>` })}</p>
      <button type="button" id="close-celebration-btn" class="mt-12 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-gray-950 font-black py-4 px-12 rounded-full text-xl shadow-xl active:scale-95 transition-all border-4 border-amber-300">
        ${t('live.great_game')}
      </button>
    </div>
    <style>
      @keyframes popIn {
        0% { transform: scale(0.3); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
      }
    </style>
  `;
  document.body.appendChild(overlay);
  
  triggerHaptic();
  if ('vibrate' in navigator) {
    try { navigator.vibrate([100, 50, 100, 50, 400]); } catch(e){}
  }
  
  document.getElementById('close-celebration-btn').addEventListener('click', () => {
    overlay.remove();
    releaseWakeLock();
    activeMatchData = null;
    document.getElementById('nav-dashboard').click();
  });
}

function checkAutoWin() {
  if (!activeMatchData) return false;
  const rules = activeMatchData.rules || {};
  const winners = activeMatchData.players.filter(p => p.is_winner);

  if (activeMatchData.status === 'completed' && winners.length) {
    if (['team','emperor_team'].includes(rules.winner_scope) || activeMatchData.team_mode === 'teams') {
      const teamNumber = Number(winners[0].team_number);
      const members = activeMatchData.players.filter(p => Number(p.team_number) === teamNumber);
      const names = members.map(p => p.player_name).join(' & ');
      showWinnerCelebration(t('live.winner.team_name', { number: teamNumber, names }));
    } else if (rules.winner_scope === 'role_condition') {
      showWinnerCelebration(winners.map(p => p.player_name).join(' & '));
    } else {
      showWinnerCelebration(winners[0].player_name);
    }
    return true;
  }

  // Lokalt snabbfeedback för vanliga profiler. Emperor avgörs av Emperor-rollen
  // och lämnas därför alltid åt serverns auktoritativa resultat.
  if (rules.winner_scope === 'emperor_team' || rules.winner_scope === 'role_condition') return false;
  const alivePlayers = activeMatchData.players.filter(p => !p.is_eliminated);
  if (rules.winner_scope === 'team' || activeMatchData.team_mode === 'teams') {
    const aliveTeams = [...new Set(alivePlayers.map(p => Number(p.team_number)))];
    if (aliveTeams.length === 1) {
      const teamNumber = aliveTeams[0];
      const members = activeMatchData.players.filter(p => Number(p.team_number) === teamNumber);
      const names = members.map(p => p.player_name).join(' & ');
      showWinnerCelebration(t('live.winner.team_name', { number: teamNumber, names }));
      return true;
    }
    return false;
  }
  if (alivePlayers.length === 1) {
    showWinnerCelebration(alivePlayers[0].player_name);
    return true;
  }
  return false;
}

export function selectActiveMatch(matchId) {
  selectedActiveMatchId = Number(matchId) || null;
  activeMatchData = null;
}

function renderActiveMatchChooser(matches) {
  const chooser = document.getElementById('activeMatchesChooser');
  if (!chooser) return;
  if (!matches || matches.length === 0) {
    chooser.innerHTML = '';
    return;
  }

  chooser.innerHTML = `
    <div class="mt-4 space-y-3">
      <p class="text-sm text-gray-400">${t('live.choose_table')}</p>
      ${matches.map(match => `
        <button type="button" data-match-id="${match.id}" class="open-active-match-btn w-full text-left bg-gray-800 hover:bg-gray-700 border border-gray-700 hover:border-amber-500/60 rounded-xl p-4 transition-all">
          <div class="flex justify-between gap-3">
            <span class="font-black text-amber-400">${escapeHtml(match.table_name || t('live.table', { id: match.id }))}</span>
            <span class="text-xs text-gray-400">${escapeHtml(matchFormatLabel(match))}${matchLimitedFormatLabel(match) ? ` · 📦 ${escapeHtml(matchLimitedFormatLabel(match))}` : ''} · ${escapeHtml(matchPlayModeLabel(match))}${matchModifierLabels(match).map(label => ` · 🌀 ${escapeHtml(label)}`).join('')}${match.team_mode === 'teams' ? ` · 🤝 ${match.teams?.map(team => team.player_count).join('v') || t('live.team_short')}` : ''}</span>
          </div>
          <div class="text-sm text-gray-300 mt-2">${match.players.map(p => `${escapeHtml(p.player_name)} – ${escapeHtml(p.deck_name || t('limited.no_registered_deck'))}`).join('<br>')}</div>
        </button>
      `).join('')}
    </div>
  `;

  chooser.querySelectorAll('.open-active-match-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      selectActiveMatch(btn.dataset.matchId);
      checkActiveMatch();
    });
  });
}

export async function checkActiveMatch() {
  if (liveMatchMutationQueue.hasPending()) return;

  let newMatchData = null;

  if (selectedActiveMatchId) {
    newMatchData = await fetchActiveMatch(selectedActiveMatchId);
    if (!newMatchData) selectedActiveMatchId = null;
  }

  if (!newMatchData) {
    const ownMatch = await fetchMyActiveMatch();
    if (ownMatch) {
      newMatchData = ownMatch;
      selectedActiveMatchId = ownMatch.id;
    }
  }

  if (!newMatchData) {
    const matches = await fetchActiveMatches();
    if (matches.length === 1) {
      newMatchData = matches[0];
      selectedActiveMatchId = matches[0].id;
    } else {
      document.getElementById('noActiveMatch').classList.remove('hidden');
      document.getElementById('activeMatchContainer').classList.add('hidden');
      renderActiveMatchChooser(matches);
      releaseWakeLock();
      liveMatchTimer.stop();
      return;
    }
  }

  renderActiveMatchChooser([]);
  document.getElementById('noActiveMatch').classList.add('hidden');
  document.getElementById('activeMatchContainer').classList.remove('hidden');
  requestWakeLock();
  activeMatchData = newMatchData;
  const finishButton = document.getElementById('finishMatchModalBtn');
  if (finishButton) finishButton.classList.toggle('hidden', !!activeMatchData.rules?.hidden_information);

  document.getElementById('currentRoundDisplay').innerText = activeMatchData.current_round;
  const activePlayer = activeMatchData.players[activeMatchData.active_player_index];
  const turnPlayers = Array.isArray(activeMatchData.active_turn_players) && activeMatchData.active_turn_players.length
    ? activeMatchData.active_turn_players
    : (activePlayer ? [activePlayer] : []);
  document.getElementById('turnPlayerDisplay').innerHTML = turnPlayers.length
    ? `<span class="text-amber-400 font-bold">${turnPlayers.map(p => escapeHtml(p.player_name)).join(' & ')}</span>${activeMatchData.rules?.turn_scope === 'team' ? ` <span class="team-badge ml-1">${t('team.team', { number: turnPlayers[0].team_number })}</span>` : ''}`
    : '';

  const specialBanner = document.getElementById('specialRulesBanner');
  if (specialBanner) {
    const mode = activeMatchData.play_mode;
    const key = ['two_headed_giant','emperor','archenemy','archenemy_commander','attack_left_defend_right','kingdoms','assassin'].includes(mode)
      ? `live.special.${mode}` : null;
    specialBanner.classList.toggle('hidden', !key);
    specialBanner.textContent = key ? t(key) : '';
  }

  updateDayNightControl();

  if (activeMatchData.timer?.enabled) {
    document.getElementById('timerContainer').classList.remove('hidden');
    liveMatchTimer.syncTimerFromServer(activeMatchData.timer);
  } else {
    document.getElementById('timerContainer').classList.add('hidden');
    liveMatchTimer.stop();
  }

  renderCompanionGrid();
}

function normalizedDayNightState(value) {
  return ['day','night'].includes(String(value || '').toLowerCase())
    ? String(value).toLowerCase()
    : 'none';
}

function updateDayNightControl() {
  const badge = document.getElementById('dayNightStateBadge');
  const dayBtn = document.getElementById('dayNightDayBtn');
  const nightBtn = document.getElementById('dayNightNightBtn');
  if (!badge || !dayBtn || !nightBtn) return;

  const state = normalizedDayNightState(activeMatchData?.day_night_state);
  badge.className = 'text-xs font-bold px-2 py-1 rounded';
  if (state === 'day') {
    badge.textContent = t('dayNight.status_day');
    badge.classList.add('text-amber-200','bg-amber-900/50','border','border-amber-500/40');
  } else if (state === 'night') {
    badge.textContent = t('dayNight.status_night');
    badge.classList.add('text-indigo-200','bg-indigo-950/70','border','border-indigo-500/40');
  } else {
    badge.textContent = t('dayNight.status_none');
    badge.classList.add('text-gray-300','bg-gray-800/70');
  }

  dayBtn.disabled = state === 'day';
  nightBtn.disabled = state === 'night';
  dayBtn.classList.toggle('opacity-40', state === 'day');
  nightBtn.classList.toggle('opacity-40', state === 'night');
  dayBtn.title = state === 'night' ? t('dayNight.switch_to_day') : t('dayNight.set_day');
  nightBtn.title = state === 'day' ? t('dayNight.switch_to_night') : t('dayNight.set_night');
}

export async function setDayNightState(state) {
  if (!activeMatchData?.id) return;
  const normalized = String(state || '').toLowerCase();
  if (!['day','night'].includes(normalized)) return;
  triggerHaptic();
  await flushAllPendingChanges();
  const res = await postDayNightState(activeMatchData.id, normalized);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    alert(t('dayNight.change_failed', { error: apiErrorMessage(data) || res.status }));
    return;
  }
  if (data.match) activeMatchData = data.match;
  else activeMatchData = await fetchActiveMatch(activeMatchData.id);
  updateDayNightControl();
}

// Publika exportnamn behålls för äldre UI-kod, medan timer-state och
// server-synk nu ägs av liveMatchTimer-controller.
export function resetTurnTimer(seconds) {
  return liveMatchTimer.resetTurnTimer(seconds);
}

export async function toggleTimer() {
  return liveMatchTimer.toggleTimer();
}

export function updateTimerDisplay() {
  return liveMatchTimer.updateTimerDisplay();
}

function translatedEliminationReason(reason) {
  const raw = String(reason || '').trim();
  const normalized = raw.toLowerCase();
  if (!raw) return t('live.eliminated');
  if (normalized.includes('conced') || normalized.includes('gav upp')) return t('live.elimination.conceded');
  if (normalized.includes('poison') || normalized.includes('gift')) return t('live.elimination.poison');
  if (normalized.includes('commander')) return t('live.elimination.commander');
  if (normalized.includes('life') || normalized.includes('liv') || normalized.includes('eliminat') || normalized.includes('utslagen')) return t('live.elimination.life');
  return raw;
}

export function renderCompanionGrid() {
  const container = document.getElementById('companionGrid');
  const board = document.getElementById('matchBoard');
  if (!container || !activeMatchData) return;

  const pCount = activeMatchData.players.length;
  const activePlayer = activeMatchData.players[activeMatchData.active_player_index];
  const activeTurnIds = new Set((activeMatchData.active_turn_players || (activePlayer ? [activePlayer] : [])).map(p => Number(p.player_id)));
  const poisonThreshold = Math.max(1, Number(activeMatchData.rules?.poison_loss_threshold || 10));
  const layout = getBoardLayout();
  const playersById = new Map(activeMatchData.players.map(p => [Number(p.player_id), p]));
  const displayPlayers = layout.order.map(id => playersById.get(Number(id))).filter(Boolean);

  let gridLayout = 'grid-cols-1 grid-rows-2';
  if (pCount === 2) gridLayout = 'grid-cols-2 grid-rows-1';
  if (pCount === 3) gridLayout = 'grid-cols-2 grid-rows-2';
  if (pCount === 4) gridLayout = 'grid-cols-2 grid-rows-2';
  if (pCount >= 5) gridLayout = 'grid-cols-2 grid-rows-3';

  if (board) board.classList.toggle('center-turn-cutouts', pCount >= 2);
  container.className = `grid h-[78vh] w-full gap-2 rounded-xl overflow-hidden bg-gray-950 p-1 ${gridLayout} ${boardArrangeMode ? 'board-arrange-mode' : ''}`;
  updateBoardArrangeControls();

  container.innerHTML = displayPlayers.map((p, displayIdx) => {
    const originalIdx = activeMatchData.players.findIndex(ap => Number(ap.player_id) === Number(p.player_id));
    const color = bgColors[(originalIdx >= 0 ? originalIdx : displayIdx) % bgColors.length];
    const isTurn = activeTurnIds.has(Number(p.player_id));
    const isEliminated = p.is_eliminated || p.current_life <= 0 || p.poison_counters >= poisonThreshold;
    const lifeColor = p.current_life <= 5 ? 'text-red-400' : (p.current_life <= 15 ? 'text-amber-400' : 'text-white');
    const identityPresentation = deckIdentityPresentation(p);
    const rotation = normalizeRotation(layout.rotations[Number(p.player_id)]);
    const layoutSelected = Number(selectedLayoutPlayerId) === Number(p.player_id);

    let notchClass = '';
    let actionsShellClass = 'justify-center';
    let layoutToolsClass = 'layout-tools-center';
    if (pCount === 2) {
      // 1v1 använder samma rotationsmedvetna centrumskydd som mittkorten
      // i 5–6-spelarläget. Avsluta tur ligger mitt på den gemensamma kanten,
      // så hela innehållet måste känna till vilken fysisk sida som är blockerad.
      if (displayIdx === 0) {
        notchClass = 'center-notch-middle-right center-safe-right center-life-safe-right duel-center-card';
        actionsShellClass = 'justify-start';
        layoutToolsClass = 'layout-tools-left';
      }
      if (displayIdx === 1) {
        notchClass = 'center-notch-middle-left center-safe-left center-life-safe-left duel-center-card';
        actionsShellClass = 'justify-end';
        layoutToolsClass = 'layout-tools-right';
      }
    } else if (pCount === 3 || pCount === 4) {
      if (displayIdx === 0) { notchClass = 'center-notch-bottom-right center-safe-right'; actionsShellClass = 'justify-start'; layoutToolsClass = 'layout-tools-left'; }
      if (displayIdx === 1) { notchClass = 'center-notch-bottom-left center-safe-left'; actionsShellClass = 'justify-end'; layoutToolsClass = 'layout-tools-right'; }
      if (displayIdx === 2) { notchClass = 'center-notch-top-right center-safe-right'; actionsShellClass = 'justify-start'; layoutToolsClass = 'layout-tools-left'; }
      if (displayIdx === 3) { notchClass = 'center-notch-top-left center-safe-left'; actionsShellClass = 'justify-end'; layoutToolsClass = 'layout-tools-right'; }
    } else if (pCount >= 5) {
      if (displayIdx === 2) { notchClass = 'center-notch-middle-right center-safe-right center-life-safe-right'; actionsShellClass = 'justify-start'; layoutToolsClass = 'layout-tools-left'; }
      if (displayIdx === 3) { notchClass = 'center-notch-middle-left center-safe-left center-life-safe-left'; actionsShellClass = 'justify-end'; layoutToolsClass = 'layout-tools-right'; }
    }

    const hasPrivateHiddenInfo = activeMatchData.status === 'active' && !!activeMatchData.rules?.hidden_information &&
      (activeMatchData.play_mode === 'assassin' || p.role_visibility !== 'public' || !p.role_key);

    return `
      <div id="player-card-${p.player_id}"
           data-layout-player-id="${p.player_id}"
           data-player-rotation="${rotation}"
           class="player-life-card ${identityPresentation.className} ${notchClass} relative ${identityPresentation.className ? '' : color} ${isTurn ? 'active-turn-card' : ''} ${layoutSelected ? 'layout-card-selected' : ''} ${isEliminated ? 'opacity-40 grayscale' : ''} rounded-xl text-white select-none transition-all overflow-hidden ${boardArrangeMode ? 'cursor-pointer' : ''}" style="${identityPresentation.style}">

        ${boardArrangeMode ? `
          <div class="layout-card-tools ${layoutToolsClass} absolute inset-x-2 top-2 z-50 pointer-events-none">
            <span class="layout-move-hint bg-gray-950/90 border border-amber-400 text-amber-300 px-2 py-1 rounded-lg text-xs font-black pointer-events-none">
              ${layoutSelected ? t('live.move_swap') : t('live.move')}
            </span>
            <button type="button" data-rotate-player-id="${p.player_id}" class="btn-rotate-layout pointer-events-auto bg-gray-950/95 hover:bg-gray-800 border border-gray-600 px-3 py-2 rounded-lg font-black text-sm touch-manipulation">${t('live.rotate')}</button>
          </div>
        ` : ''}

        <div class="player-card-rotator" data-rotation="${rotation}" style="--player-rotation:${rotation}deg; --player-rotation-scale:1;">
          <div class="player-card-content flex flex-col justify-between items-center p-2 w-full h-full ${boardArrangeMode ? 'pointer-events-none opacity-80' : ''}">
            <div class="player-readable-content flex flex-col items-center w-full z-10 pt-1">
              <span class="text-base sm:text-xl font-black uppercase tracking-wider drop-shadow-md">${escapeHtml(p.player_name)}</span>
              <span class="text-xs sm:text-sm font-semibold opacity-90">${escapeHtml(p.deck_name || t('limited.no_registered_deck'))}</span>
              ${activeMatchData.team_mode === 'teams' ? `<span class="team-badge mt-1">🤝 ${t('team.team', { number: p.team_number })}</span>` : ''}
              ${p.role_key ? `<span class="special-role-badge mt-1">${escapeHtml(t(`role.${p.role_key}`, {}, p.role_key))}${p.range_of_influence ? ` · ${escapeHtml(t('live.range', { count:p.range_of_influence }))}` : ''}</span>` : ''}
              ${hasPrivateHiddenInfo ? `<button type="button" data-hidden-player-id="${p.player_id}" ${boardArrangeMode ? 'disabled' : ''} class="btn-hidden-role-reveal mt-1 bg-purple-950/85 hover:bg-purple-900 border border-purple-400/50 text-purple-100 px-3 py-1 rounded-lg text-xs font-black active:scale-95 transition-all touch-manipulation disabled:opacity-50">${escapeHtml(t('hidden.show_secret'))}</button>` : ''}
              ${isTurn ? `<span class="active-turn-badge mt-1">${t(activeMatchData.rules?.turn_scope === 'team' ? 'live.active_team_turn' : 'live.active_turn')}</span>` : ''}
              <button type="button" data-player-id="${p.player_id}" ${isEliminated || boardArrangeMode ? 'disabled' : ''}
                      class="btn-concede-btn mt-2 bg-red-900/75 hover:bg-red-800 px-3 py-1 rounded-lg font-bold text-xs sm:text-sm border border-red-500/50 active:scale-95 transition-all touch-manipulation disabled:opacity-50">
                ${t('live.concede')}
              </button>
            </div>

            <div class="relative flex items-center justify-center w-full flex-1 my-1">
              <button type="button" data-player-id="${p.player_id}" data-change="-1" ${isEliminated || boardArrangeMode ? 'disabled' : ''}
                      class="btn-life-change absolute left-0 top-0 bottom-0 w-1/2 flex items-center justify-start pl-2 sm:pl-4 text-4xl sm:text-6xl font-extrabold opacity-70 active:opacity-100 z-10 focus:outline-none touch-manipulation">−</button>

              <div id="life-display-${p.player_id}" class="${lifeColor} text-6xl sm:text-8xl font-black font-mono tracking-tight pointer-events-none drop-shadow-lg z-0 transition-all duration-150">
                ${p.current_life}
              </div>

              <div id="life-change-indicator-${p.player_id}" class="hidden absolute pointer-events-none z-20 font-black text-2xl sm:text-4xl px-4 py-1.5 rounded-full bg-black/90 shadow-2xl border-2 border-white/20 transition-all scale-110"></div>

              <button type="button" data-player-id="${p.player_id}" data-change="1" ${isEliminated || boardArrangeMode ? 'disabled' : ''}
                      class="btn-life-change absolute right-0 top-0 bottom-0 w-1/2 flex items-center justify-end pr-2 sm:pr-4 text-4xl sm:text-6xl font-extrabold opacity-70 active:opacity-100 z-10 focus:outline-none touch-manipulation">+</button>
            </div>

            <div class="player-quick-actions-shell flex items-center ${actionsShellClass} z-10 pb-1 w-full">
              <div class="player-quick-actions flex flex-wrap gap-1 sm:gap-2 items-center justify-center">
                <button type="button" data-player-id="${p.player_id}" data-change="-5" ${isEliminated || boardArrangeMode ? 'disabled' : ''}
                        class="btn-life-change bg-black/50 hover:bg-black/70 px-2 sm:px-3 py-1 rounded-lg font-black text-xs sm:text-sm border border-white/20 active:scale-95 transition-all touch-manipulation">-5</button>

                <button type="button" id="poison-btn-${p.player_id}" data-player-id="${p.player_id}" ${boardArrangeMode ? 'disabled' : ''}
                        class="btn-poison-btn bg-green-900/70 hover:bg-green-800 px-2 sm:px-3 py-1 rounded-lg font-bold text-xs sm:text-sm border border-green-500/40 active:scale-95 transition-all touch-manipulation">
                  ${t('live.poison', { count: p.poison_counters || 0 })}
                </button>

                <button type="button" id="tax-btn-${p.player_id}" data-player-id="${p.player_id}" ${boardArrangeMode ? 'disabled' : ''}
                        class="btn-tax-btn bg-amber-900/70 hover:bg-amber-800 px-2 sm:px-3 py-1 rounded-lg font-bold text-xs sm:text-sm border border-amber-500/40 active:scale-95 transition-all touch-manipulation">
                  ${t('live.tax', { count: p.commander_tax || 0 })}
                </button>

                <button type="button" id="cmdr-dmg-btn-${p.player_id}" data-player-id="${p.player_id}" ${isEliminated || boardArrangeMode ? 'disabled' : ''}
                        class="btn-cmdr-dmg-btn bg-purple-900/70 hover:bg-purple-800 px-2 sm:px-3 py-1 rounded-lg font-bold text-xs sm:text-sm border border-purple-500/40 active:scale-95 transition-all touch-manipulation">
                  ${t('live.cmdr_dmg')}
                </button>

                <button type="button" data-player-id="${p.player_id}" data-change="5" ${isEliminated || boardArrangeMode ? 'disabled' : ''}
                        class="btn-life-change bg-black/50 hover:bg-black/70 px-2 sm:px-3 py-1 rounded-lg font-black text-xs sm:text-sm border border-white/20 active:scale-95 transition-all touch-manipulation">+5</button>
              </div>
            </div>
          </div>

          <div id="eliminated-banner-${p.player_id}" class="${isEliminated ? '' : 'hidden'} absolute inset-0 flex items-center justify-center font-black text-red-500 text-xl sm:text-3xl tracking-widest z-20 bg-black/50 backdrop-blur-sm">
            <span id="eliminated-text-${p.player_id}">${escapeHtml(translatedEliminationReason(p.eliminated_reason))}</span>
          </div>
        </div>
      </div>
    `;
  }).join('');

  applyPlayerRotationGeometry(container);
  attachCompanionEventListeners();

  if (boardArrangeMode) {
    container.querySelectorAll('.btn-rotate-layout').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        rotateLayoutPlayer(Number(button.dataset.rotatePlayerId));
      });
    });

    container.querySelectorAll('[data-layout-player-id]').forEach((card) => {
      card.addEventListener('click', (event) => {
        if (event.target.closest('.btn-rotate-layout')) return;
        event.preventDefault();
        selectOrSwapLayoutPlayer(Number(card.dataset.layoutPlayerId));
      });
    });
  }
}

function applyPlayerRotationGeometry(container = document.getElementById('companionGrid')) {
  if (!container) return;

  container.querySelectorAll('.player-life-card').forEach((card) => {
    const rotator = card.querySelector('.player-card-rotator');
    if (!rotator) return;

    const rotation = normalizeRotation(card.dataset.playerRotation);
    const w = Math.max(card.clientWidth, 1);
    const h = Math.max(card.clientHeight, 1);

    // Vid 90°/270° byter innehållsytan bredd och höjd INNAN den roteras.
    // Då fyller den samma fysiska kort utan att text och knappar behöver
    // skalas ned till svårlästa/svårtryckta storlekar.
    if (rotation === 90 || rotation === 270) {
      rotator.style.setProperty('--player-rotator-width', `${h}px`);
      rotator.style.setProperty('--player-rotator-height', `${w}px`);
    } else {
      rotator.style.setProperty('--player-rotator-width', `${w}px`);
      rotator.style.setProperty('--player-rotator-height', `${h}px`);
    }

    rotator.style.setProperty('--player-rotation', `${rotation}deg`);

    // Mittkorten i 5–6-spelarläget har en fysisk förbjuden zon mot
    // Avsluta tur-knappen. När kortet roteras måste den fysiska vänster-/
    // högersidan översättas till rätt sida i spelarens lokala koordinater.
    // På så sätt hålls namn, liv, ± och snabbknappar borta från centrum som
    // en sammanhängande layout i alla fyra rotationer.
    const safePhysicalSide = card.classList.contains('center-life-safe-right')
      ? 'right'
      : (card.classList.contains('center-life-safe-left') ? 'left' : null);

    const localSafeSide = (() => {
      if (!safePhysicalSide) return null;
      if (safePhysicalSide === 'right') {
        return ({ 0: 'right', 90: 'top', 180: 'left', 270: 'bottom' })[rotation];
      }
      return ({ 0: 'left', 90: 'bottom', 180: 'right', 270: 'top' })[rotation];
    })();

    const content = rotator.querySelector('.player-card-content');
    if (content) {
      content.dataset.centerSafeSide = localSafeSide || '';
    }
  });
}

function openCommanderDamageModal(targetPlayerId) {
  triggerHaptic();
  const targetPlayer = activeMatchData.players.find(p => p.player_id === targetPlayerId);
  if (!targetPlayer || targetPlayer.is_eliminated) return;

  const opponents = activeMatchData.players.filter(p =>
    p.player_id !== targetPlayerId &&
    (activeMatchData.team_mode !== 'teams' || Number(p.team_number) !== Number(targetPlayer.team_number))
  );
  
  let cmdrDmg = {};
  try { cmdrDmg = JSON.parse(targetPlayer.commander_damage || '{}'); } catch(e){}

  const overlay = document.createElement('div');
  overlay.id = 'cmdr-dmg-modal';
  overlay.className = 'fixed inset-0 bg-black/90 flex flex-col items-center justify-center p-4 z-[60] backdrop-blur-sm';
  
  let opponentsHtml = opponents.map(opp => {
    const dmg = cmdrDmg[opp.player_id] || 0;
    let textClass = "text-white";
    if (dmg >= 15 && dmg < 21) textClass = "text-orange-400";
    else if (dmg >= 21) textClass = "text-red-500 animate-pulse";

    return `
      <div class="flex flex-col bg-gray-800 rounded-xl p-4 border border-gray-700">
        <div class="text-center mb-3">
          <span class="font-bold text-amber-400 text-lg">${escapeHtml(opp.player_name)}</span>
          <div class="text-xs text-gray-400">${escapeHtml(opp.deck_name || t('limited.no_registered_deck'))}</div>
        </div>
        <div class="flex justify-between items-center gap-4">
          <button type="button" class="btn-cmdr-change bg-red-900/80 hover:bg-red-800 text-white font-black text-4xl w-16 h-16 rounded-lg active:scale-95 touch-manipulation" data-target="${targetPlayerId}" data-source="${opp.player_id}" data-change="-1">−</button>
          
          <span id="cmdr-dmg-val-${opp.player_id}" class="text-5xl font-mono font-black ${textClass} w-20 text-center">${dmg}</span>
          
          <button type="button" class="btn-cmdr-change bg-green-900/80 hover:bg-green-800 text-white font-black text-4xl w-16 h-16 rounded-lg active:scale-95 touch-manipulation" data-target="${targetPlayerId}" data-source="${opp.player_id}" data-change="1">+</button>
        </div>
      </div>
    `;
  }).join('');

  overlay.innerHTML = `
    <div class="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
      <div class="bg-purple-900/50 p-4 text-center border-b border-purple-500/30">
        <h3 class="text-xl font-black text-purple-300">${t('live.commander_damage_title')}</h3>
        <p class="text-sm text-gray-300 mt-1">${t('live.received_by', { name: `<span class="font-bold text-white">${escapeHtml(targetPlayer.player_name)}</span>` })}</p>
      </div>
      
      <div class="p-4 space-y-4 overflow-y-auto">
        ${opponentsHtml}
      </div>
      
      <div class="p-4 border-t border-gray-800 bg-gray-900">
        <button type="button" id="close-cmdr-modal" class="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-4 rounded-xl text-lg active:scale-95 transition-all touch-manipulation">${t('live.close')}</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  document.getElementById('close-cmdr-modal').addEventListener('click', () => {
    overlay.remove();
    checkActiveMatch();
  });

  overlay.querySelectorAll('.btn-cmdr-change').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      triggerHaptic();
      const target = Number(e.currentTarget.getAttribute('data-target'));
      const source = Number(e.currentTarget.getAttribute('data-source'));
      const change = Number(e.currentTarget.getAttribute('data-change'));
      
      const valEl = document.getElementById(`cmdr-dmg-val-${source}`);
      let currentVal = parseInt(valEl.innerText);
      let newVal = Math.max(0, currentVal + change);
      valEl.innerText = newVal;

      if (newVal >= 21) valEl.className = "text-5xl font-mono font-black text-red-500 w-20 text-center animate-pulse";
      else if (newVal >= 15) valEl.className = "text-5xl font-mono font-black text-orange-400 w-20 text-center";
      else valEl.className = "text-5xl font-mono font-black text-white w-20 text-center";

      try {
        const res = await postCommanderDamage(activeMatchData.id, target, source, change);
        const data = await res.json();
        
        if (!res.ok) {
          valEl.innerText = currentVal;
          const errorData = data || {};
          alert(t('live.cmdr_save_failed', { error: apiErrorMessage(errorData) || res.status }));
          return;
        }

        // Servern kopplar commander damage till vanlig skada. Håll därför
        // även den lokala livstotalen i synk medan modalen är öppen.
        if (data.match) activeMatchData = data.match;
        if (Number.isInteger(data.current_life)) {
          targetPlayer.current_life = data.current_life;
          if (activeMatchData.rules?.life_scope === 'team') {
            activeMatchData.players.filter(p => Number(p.team_number) === Number(targetPlayer.team_number)).forEach(member => {
              member.current_life = data.current_life;
              const el = document.getElementById(`life-display-${member.player_id}`);
              if (el) el.innerText = data.current_life;
            });
          } else {
            const lifeEl = document.getElementById(`life-display-${target}`);
            if (lifeEl) lifeEl.innerText = data.current_life;
          }
        }
        targetPlayer.commander_damage = JSON.stringify(data.commander_damage || {});

        if (data.isEliminated) {
          overlay.remove();
          targetPlayer.is_eliminated = 1;
          targetPlayer.eliminated_reason = data.eliminated_reason || 'Commander damage';
          updatePlayerCardEliminationState(target, t('live.eliminated_with_reason', { reason: translatedEliminationReason(targetPlayer.eliminated_reason) }));
          if (!checkAutoWin()) {
            checkActiveMatch();
          }
        }
      } catch(err) {
        console.error(err);
      }
    });
  });
}

function hiddenRoleRevealToken(matchId, playerId) {
  if (typeof sessionStorage === 'undefined') return '';
  try { return sessionStorage.getItem(`ktm:hidden-role:${matchId}:${playerId}`) || ''; }
  catch (_) { return ''; }
}

function hiddenRoleModalElements() {
  return {
    modal: document.getElementById('hiddenRoleModal'),
    title: document.getElementById('hiddenRoleModalTitle'),
    player: document.getElementById('hiddenRolePlayerName'),
    privacy: document.getElementById('hiddenRolePrivacyStep'),
    secret: document.getElementById('hiddenRoleSecretStep'),
    body: document.getElementById('hiddenRoleSecretBody'),
    actions: document.getElementById('hiddenRoleActions'),
    reveal: document.getElementById('hiddenRoleRevealNowBtn'),
    close: document.getElementById('hiddenRoleCloseBtn')
  };
}

function closeHiddenRoleModal() {
  const els = hiddenRoleModalElements();
  if (!els.modal) return;
  els.modal.classList.add('hidden');
  els.modal.dataset.playerId = '';
  if (els.body) els.body.innerHTML = '';
  if (els.actions) els.actions.innerHTML = '';
  if (els.secret) els.secret.classList.add('hidden');
  if (els.privacy) els.privacy.classList.remove('hidden');
}

function ensureHiddenRoleModalListeners() {
  const els = hiddenRoleModalElements();
  if (!els.modal || els.modal.dataset.listenersBound === '1') return;
  els.modal.dataset.listenersBound = '1';
  els.close?.addEventListener('click', closeHiddenRoleModal);
  els.reveal?.addEventListener('click', async () => {
    const playerId = Number(els.modal.dataset.playerId || 0);
    if (playerId) await revealHiddenRoleSecret(playerId);
  });
  els.modal.addEventListener('click', (event) => {
    if (event.target === els.modal) closeHiddenRoleModal();
  });
  els.modal.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeHiddenRoleModal();
  });
}

function openHiddenRolePrivacyModal(playerId) {
  if (!activeMatchData?.rules?.hidden_information) return;
  const player = activeMatchData.players.find(p => Number(p.player_id) === Number(playerId));
  const els = hiddenRoleModalElements();
  if (!player || !els.modal) return;
  ensureHiddenRoleModalListeners();
  triggerHaptic();
  els.modal.dataset.playerId = String(playerId);
  els.title.textContent = t('hidden.privacy_title');
  els.player.textContent = player.player_name;
  els.privacy.classList.remove('hidden');
  els.secret.classList.add('hidden');
  els.body.innerHTML = '';
  els.actions.innerHTML = '';
  els.modal.classList.remove('hidden');
  requestAnimationFrame(() => els.reveal?.focus());
}

function hiddenActionButton(action, labelKey, extraClass = '') {
  return `<button type="button" data-hidden-action="${escapeHtml(action)}" class="hidden-role-action w-full rounded-xl border px-4 py-3 font-black active:scale-95 transition-all ${extraClass}">${escapeHtml(t(labelKey))}</button>`;
}

async function performHiddenRoleAction(action, playerId) {
  if (!activeMatchData) return;
  const token = hiddenRoleRevealToken(activeMatchData.id, playerId);
  let res;
  if (action === 'claim_target') res = await postClaimHiddenTarget(activeMatchData.id, playerId, token);
  else if (action === 'claim_throne') res = await postClaimThrone(activeMatchData.id, playerId, token);
  else if (action === 'decline_throne_claim') res = await postDeclineThrone(activeMatchData.id, playerId, token);
  else return;

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    alert(t('hidden.action_failed', { error: apiErrorMessage(data) || res.status }));
    return;
  }
  if (data.match) {
    activeMatchData = data.match;
    renderCompanionGrid();
  }
  if (data.secret && activeMatchData?.status === 'active') {
    renderHiddenRoleSecret(data.secret, playerId);
  } else {
    closeHiddenRoleModal();
    if (!checkAutoWin()) await checkActiveMatch();
  }
}

function renderHiddenRoleSecret(secret, playerId) {
  const els = hiddenRoleModalElements();
  if (!els.modal) return;
  const roleKey = secret?.role_key || '';
  const roleLabel = roleKey ? t(`role.${roleKey}`, {}, roleKey) : t('hidden.unknown_role');
  const targetLabel = secret?.target?.player_name || t('hidden.no_target');
  const victoryKey = secret?.victory_condition_key || '';
  const victoryLabel = victoryKey ? t(`hidden.victory.${victoryKey}`, {}, victoryKey) : '';

  els.privacy.classList.add('hidden');
  els.secret.classList.remove('hidden');
  els.title.textContent = t('hidden.secret_title');
  els.body.innerHTML = `
    <div class="rounded-xl bg-gray-950/80 border border-purple-500/30 p-4 text-left space-y-3">
      <div><div class="text-xs uppercase tracking-wider text-gray-400">${escapeHtml(t('hidden.role'))}</div><div class="text-xl font-black text-purple-200">${escapeHtml(roleLabel)}</div></div>
      ${activeMatchData?.play_mode === 'assassin' ? `<div><div class="text-xs uppercase tracking-wider text-gray-400">${escapeHtml(t('hidden.target'))}</div><div class="text-xl font-black text-red-200">${escapeHtml(targetLabel)}</div></div>` : ''}
      ${victoryLabel ? `<div><div class="text-xs uppercase tracking-wider text-gray-400">${escapeHtml(t('hidden.victory_condition'))}</div><div class="text-sm font-bold text-amber-200">${escapeHtml(victoryLabel)}</div></div>` : ''}
      ${activeMatchData?.play_mode === 'assassin' ? `<div class="text-sm text-gray-300">${escapeHtml(t('hidden.objective_score', { count:Number(secret?.objective_score || 0) }))}</div>` : ''}
    </div>`;

  const actions = secret?.actions || {};
  const buttons = [];
  if (actions.claim_target) buttons.push(hiddenActionButton('claim_target', 'hidden.claim_target', 'bg-red-950/70 border-red-500/50 text-red-100 hover:bg-red-900'));
  if (actions.claim_throne) buttons.push(hiddenActionButton('claim_throne', 'hidden.claim_throne', 'bg-amber-950/70 border-amber-500/50 text-amber-100 hover:bg-amber-900'));
  if (actions.decline_throne_claim) buttons.push(hiddenActionButton('decline_throne_claim', 'hidden.decline_throne', 'bg-gray-800 border-gray-600 text-gray-100 hover:bg-gray-700'));
  els.actions.innerHTML = buttons.join('');
  els.actions.querySelectorAll('.hidden-role-action').forEach(button => {
    button.addEventListener('click', async () => {
      button.disabled = true;
      try { await performHiddenRoleAction(button.dataset.hiddenAction, playerId); }
      finally { if (button.isConnected) button.disabled = false; }
    });
  });
}

async function revealHiddenRoleSecret(playerId) {
  if (!activeMatchData) return;
  const els = hiddenRoleModalElements();
  const token = hiddenRoleRevealToken(activeMatchData.id, playerId);
  els.reveal.disabled = true;
  try {
    const res = await postRevealHiddenRole(activeMatchData.id, playerId, token);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alert(t('hidden.reveal_failed', { error: apiErrorMessage(data) || res.status }));
      return;
    }
    renderHiddenRoleSecret(data, playerId);
  } catch (err) {
    alert(t('hidden.reveal_failed', { error: err?.message || '' }));
  } finally {
    els.reveal.disabled = false;
  }
}

function attachCompanionEventListeners() {
  ensureHiddenRoleModalListeners();
  document.querySelectorAll('.btn-life-change').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      const change = Number(e.currentTarget.getAttribute('data-change'));
      changeLife(pid, change);
    });
    // BORTTAGET: e.preventDefault() för touchstart som förstörde mobilklick!
  });

  document.querySelectorAll('.btn-poison-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      changePoison(pid, 1);
    });
    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      changePoison(pid, -1);
    });
    let longPressTimer = null;
    btn.addEventListener('touchstart', (e) => {
      longPressTimer = setTimeout(() => {
        const pid = Number(e.currentTarget.getAttribute('data-player-id'));
        changePoison(pid, -1);
        triggerHaptic();
      }, 500);
    });
    btn.addEventListener('touchend', () => clearTimeout(longPressTimer));
    btn.addEventListener('touchmove', () => clearTimeout(longPressTimer));
  });

  document.querySelectorAll('.btn-tax-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      changeTax(pid, 2);
    });
    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      changeTax(pid, -2);
    });
    let longPressTimer = null;
    btn.addEventListener('touchstart', (e) => {
      longPressTimer = setTimeout(() => {
        const pid = Number(e.currentTarget.getAttribute('data-player-id'));
        changeTax(pid, -2);
        triggerHaptic();
      }, 500);
    });
    btn.addEventListener('touchend', () => clearTimeout(longPressTimer));
    btn.addEventListener('touchmove', () => clearTimeout(longPressTimer));
  });

  document.querySelectorAll('.btn-cmdr-dmg-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      openCommanderDamageModal(pid);
    });
  });

  document.querySelectorAll('.btn-hidden-role-reveal').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = Number(e.currentTarget.getAttribute('data-hidden-player-id'));
      openHiddenRolePrivacyModal(pid);
    });
  });

  document.querySelectorAll('.btn-concede-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pid = Number(e.currentTarget.getAttribute('data-player-id'));
      concedePlayer(pid);
    });
  });
}

export function changeLife(player_id, change) {
  triggerHaptic();
  const player = activeMatchData.players.find(p => p.player_id === player_id);
  if (!player || player.is_eliminated) return;

  const affectedPlayers = activeMatchData.rules?.life_scope === 'team'
    ? activeMatchData.players.filter(p => Number(p.team_number) === Number(player.team_number))
    : [player];
  affectedPlayers.forEach(member => {
    member.current_life += change;
    const lifeEl = document.getElementById(`life-display-${member.player_id}`);
    if (!lifeEl) return;
    lifeEl.innerText = member.current_life;
    lifeEl.classList.remove('scale-110');
    void lifeEl.offsetWidth;
    lifeEl.classList.add('scale-110');
    setTimeout(() => lifeEl.classList.remove('scale-110'), 150);
    lifeEl.className = lifeEl.className.replace(/text-\w+-\d+/g, '');
    if (member.current_life <= 5) lifeEl.classList.add('text-red-400');
    else if (member.current_life <= 15) lifeEl.classList.add('text-amber-400');
    else lifeEl.classList.add('text-white');
  });

  const netChange = liveMatchMutationQueue.addLife(player_id, change);

  const indicatorEl = document.getElementById(`life-change-indicator-${player_id}`);
  if (indicatorEl) {
    if (netChange !== 0) {
      indicatorEl.innerText = netChange > 0 ? `+${netChange}` : `${netChange}`;
      indicatorEl.className = indicatorEl.className.replace('hidden', '').trim();
      indicatorEl.classList.remove('text-green-400', 'text-red-400');
      indicatorEl.classList.add(netChange > 0 ? 'text-green-400' : 'text-red-400');
    } else {
      indicatorEl.classList.add('hidden');
    }
  }

  clearTimeout(indicatorHideTimers[player_id]);
  indicatorHideTimers[player_id] = setTimeout(() => {
    if (indicatorEl) indicatorEl.classList.add('hidden');
  }, LIFE_INDICATOR_HIDE_MS);

}

export function changePoison(player_id, change) {
  triggerHaptic();
  const player = activeMatchData.players.find(p => p.player_id === player_id);
  if (!player || (player.is_eliminated && change > 0)) return;
  const threshold = Math.max(1, Number(activeMatchData.rules?.poison_loss_threshold || 10));
  const affectedPlayers = activeMatchData.rules?.poison_scope === 'team'
    ? activeMatchData.players.filter(p => Number(p.team_number) === Number(player.team_number))
    : [player];

  affectedPlayers.forEach(member => {
    member.poison_counters = Math.max(0, (member.poison_counters || 0) + change);
    if (member.poison_counters < threshold && member.current_life > 0 && String(member.eliminated_reason || '').startsWith('Poison')) {
      member.is_eliminated = 0;
      member.eliminated_reason = null;
      document.getElementById(`player-card-${member.player_id}`)?.classList.remove('opacity-40', 'grayscale');
      document.getElementById(`eliminated-banner-${member.player_id}`)?.classList.add('hidden');
    }
    const btnEl = document.getElementById(`poison-btn-${member.player_id}`);
    if (btnEl) btnEl.innerHTML = t('live.poison', { count: member.poison_counters });
    if (member.poison_counters >= threshold) {
      member.is_eliminated = 1;
      member.eliminated_reason = `Poison (${threshold}+)`;
      updatePlayerCardEliminationState(member.player_id, t('live.eliminated_with_reason', { reason: t('live.elimination.poison_short') }));
    }
  });

  const btnEl = document.getElementById(`poison-btn-${player_id}`);
  if (btnEl) {
    btnEl.classList.remove('scale-110');
    void btnEl.offsetWidth;
    btnEl.classList.add('scale-110');
    setTimeout(() => btnEl.classList.remove('scale-110'), 150);
  }

  liveMatchMutationQueue.addPoison(player_id, change);
}

export function changeTax(player_id, change) {
  triggerHaptic();
  const player = activeMatchData.players.find(p => p.player_id === player_id);
  if (!player) return;

  player.commander_tax = Math.max(0, (player.commander_tax || 0) + change);
  const btnEl = document.getElementById(`tax-btn-${player_id}`);
  if (btnEl) btnEl.innerHTML = t('live.tax', { count: player.commander_tax });

  if (btnEl) {
    btnEl.classList.remove('scale-110');
    void btnEl.offsetWidth;
    btnEl.classList.add('scale-110');
    setTimeout(() => btnEl.classList.remove('scale-110'), 150);
  }

  liveMatchMutationQueue.addTax(player_id, change);
}

export function updatePlayerCardEliminationState(player_id, reasonText) {
  const cardEl = document.getElementById(`player-card-${player_id}`);
  const bannerEl = document.getElementById(`eliminated-banner-${player_id}`);
  const textEl = document.getElementById(`eliminated-text-${player_id}`);

  if (cardEl) cardEl.classList.add('opacity-40', 'grayscale');
  if (textEl) textEl.innerText = reasonText;
  if (bannerEl) bannerEl.classList.remove('hidden');
}

export async function flushAllPendingChanges() {
  await liveMatchMutationQueue.flushAll();
}

export async function undoLastLifeChange() {
  if (!activeMatchData) return;

  await flushAllPendingChanges();

  const res = await postUndo(activeMatchData.id);
  if (res.ok) {
    const data = await res.json().catch(() => ({}));
    activeMatchData = data.match || await fetchActiveMatch(activeMatchData.id);
    if (activeMatchData) { renderCompanionGrid(); updateDayNightControl(); }
    triggerHaptic();
  } else {
    const data = await res.json().catch(() => ({}));
    alert(t('live.undo_failed', { error: apiErrorMessage(data) || res.status }));
  }
}

export async function concedePlayer(player_id) {
  if (!confirm(t('live.concede_confirm'))) return;
  await flushAllPendingChanges();
  
  const res = await postConcede(activeMatchData.id, player_id);
  
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    alert(t('live.concede_failed', { error: apiErrorMessage(data) || res.status }));
    checkActiveMatch();
  } else {
    const data = await res.json().catch(() => ({}));
    if (data.match) activeMatchData = data.match;
    const player = activeMatchData.players.find(p => p.player_id === player_id);
    if (player) {
      player.is_eliminated = 1;
      player.eliminated_reason = 'Conceded';
      updatePlayerCardEliminationState(player_id, t('live.conceded'));
    }
    
    if (!checkAutoWin()) {
      checkActiveMatch();
    }
  }
}

let abortMatchInFlight = false;

export async function abortMatchWithoutStats(onSuccessCallback) {
  if (!activeMatchData || abortMatchInFlight) return;
  if (!confirm(t('live.abort_confirm'))) return;

  abortMatchInFlight = true;
  const matchId = activeMatchData.id;

  try {
    const res = await deleteAbortMatch(matchId);
    if (res.ok) {
      releaseWakeLock();
      activeMatchData = null;
      if (typeof onSuccessCallback === 'function') onSuccessCallback();
      return;
    }

    const data = await res.json().catch(() => ({}));
    alert(t('live.abort_failed', { error: apiErrorMessage(data) }));
  } finally {
    abortMatchInFlight = false;
  }
}

export async function nextTurn() {
  triggerHaptic();
  await flushAllPendingChanges();
  const res = await postNextTurn(activeMatchData.id);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    alert(t('live.end_turn_failed', { error: apiErrorMessage(data) || res.status }));
    return;
  }
  if (data.match) {
    activeMatchData = data.match;
    liveMatchTimer.syncTimerFromServer(activeMatchData.timer);
  }
  checkActiveMatch();
}

export function openWinnerModal() {
  if (!activeMatchData) return;
  if (activeMatchData.rules?.hidden_information) {
    alert(t('hidden.auto_finish'));
    return;
  }
  const grid = document.getElementById('winnerOptionsGrid');
  const subtitle = document.getElementById('winnerModalSubtitle');

  if (activeMatchData.team_mode === 'teams') {
    const teams = Array.isArray(activeMatchData.teams) ? activeMatchData.teams : [];
    if (subtitle) subtitle.textContent = t('winner.team_question');
    grid.innerHTML = teams.map(team => `
      <button type="button" data-team-number="${team.team_number}" class="btn-select-winning-team bg-amber-600 hover:bg-amber-500 py-3 px-3 rounded-lg font-bold text-white transition-all active:scale-95">
        <span class="block text-lg">${t('winner.team_button', { number: team.team_number })}</span>
        <span class="block text-xs font-medium opacity-90 mt-1">${team.players.map(p => escapeHtml(p.player_name)).join(' · ')}</span>
      </button>
    `).join('');

    grid.querySelectorAll('.btn-select-winning-team').forEach(btn => {
      btn.addEventListener('click', () => finishMatchWithTeam(Number(btn.dataset.teamNumber)));
    });
  } else {
    if (subtitle) subtitle.textContent = t('winner.player_question');
    grid.innerHTML = activeMatchData.players.map(p => `
      <button type="button" data-player-id="${p.player_id}" class="btn-select-winner bg-amber-600 hover:bg-amber-500 py-3 rounded-lg font-bold text-lg text-white transition-all active:scale-95">
        ${t('winner.player_button', { name: escapeHtml(p.player_name) })}
      </button>
    `).join('');

    grid.querySelectorAll('.btn-select-winner').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = Number(e.currentTarget.getAttribute('data-player-id'));
        finishMatchWithWinner(pid);
      });
    });
  }

  const winnerModal = document.getElementById('winnerModal');
  winnerModal.classList.remove('hidden');
  requestAnimationFrame(() => winnerModal.querySelector('#winnerOptionsGrid button, #closeWinnerModalBtn')?.focus());
}

export function closeWinnerModal() {
  document.getElementById('winnerModal').classList.add('hidden');
  document.getElementById('finishMatchModalBtn')?.focus();
}

export async function finishMatchWithWinner(winner_player_id) {
  await flushAllPendingChanges();
  const res = await postFinishMatch(activeMatchData.id, winner_player_id);
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    alert(t('live.finish_failed', { error: apiErrorMessage(data) || res.status }));
    return;
  }
  releaseWakeLock();
  closeWinnerModal();
  document.getElementById('nav-dashboard').click();
}

export async function finishMatchWithTeam(winner_team_number) {
  await flushAllPendingChanges();
  const res = await postFinishTeamMatch(activeMatchData.id, winner_team_number);
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    alert(t('live.finish_team_failed', { error: apiErrorMessage(data) || res.status }));
    return;
  }
  releaseWakeLock();
  closeWinnerModal();
  document.getElementById('nav-dashboard').click();
}
