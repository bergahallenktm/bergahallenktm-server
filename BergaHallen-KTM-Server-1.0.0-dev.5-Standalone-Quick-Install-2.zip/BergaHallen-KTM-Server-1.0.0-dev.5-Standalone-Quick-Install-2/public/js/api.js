const API_BASE = '/api/v1';
const DISCOVERY_TIMEOUT_MS = 7000;

async function fetchJsonWithTimeout(url, label, { timeoutMs = DISCOVERY_TIMEOUT_MS } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { cache: 'no-store', signal: controller.signal });
    if (!res.ok) throw new Error(`${label} request failed: ${res.status}`);
    return await res.json();
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`${label} request timed out`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchDiscovery(options = {}) {
  return fetchJsonWithTimeout(`${API_BASE}/discovery`, 'Discovery', options);
}

function discoveryQuery(options = {}) {
  if (typeof options === 'string') return queryString({ url: options }); // legacy caller
  const search = new URLSearchParams();
  const endpoints = Array.isArray(options?.endpoints) ? options.endpoints : [];
  for (const endpoint of endpoints) {
    const value = typeof endpoint === 'object' ? endpoint?.url : endpoint;
    if (value != null && String(value).trim() !== '') search.append('endpoint', String(value));
  }
  if (options?.url) search.set('url', String(options.url)); // legacy shorthand
  if (options?.base_url) search.set('base_url', String(options.base_url)); // 3.9.11 compatibility
  const text = search.toString();
  return text ? `?${text}` : '';
}

export async function fetchDiscoveryProvision(options = {}) {
  return fetchJsonWithTimeout(`${API_BASE}/discovery/provision${discoveryQuery(options)}`, 'Provision');
}

export function discoveryQrUrl(options = {}) {
  return `${API_BASE}/discovery/qr.svg${discoveryQuery(options)}`;
}

export async function fetchFormats() {
  const res = await fetch(`${API_BASE}/formats`);
  return res.json();
}

export async function fetchMatchOptions() {
  const res = await fetch(`${API_BASE}/match-options`);
  return res.json();
}

export async function fetchMeta(options = {}) {
  return fetchJsonWithTimeout(`${API_BASE}/meta`, 'Meta', options);
}

export async function fetchAuthPolicy() {
  const res = await fetch(`${API_BASE}/auth/policy`);
  return res.json();
}

export async function fetchAuthMe() {
  const res = await fetch(`${API_BASE}/auth/me`);
  return res.json();
}

export async function postLogin(name, password) {
  return fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, password })
  });
}

export async function postRegister(name, password, preferredLocale = 'en') {
  return fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, password, preferred_locale: preferredLocale })
  });
}

export async function postLogout() {
  return fetch(`${API_BASE}/auth/logout`, { method: 'POST' });
}

export async function fetchAccountDeletionPreview() {
  return fetch(`${API_BASE}/account/deletion`, { cache: 'no-store' });
}

export async function postAccountDeletion(currentPassword) {
  return fetch(`${API_BASE}/account/deletion`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ current_password: currentPassword, confirm: true })
  });
}

export async function postLocalePreference(preference) {
  const body = typeof preference === 'string' ? { locale: preference } : (preference || {});
  return fetch(`${API_BASE}/auth/locale`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
}

// Ny funktion för att spara kortlänksinställning
export async function postCardLinkPreference(preference) {
  return fetch(`${API_BASE}/auth/card-link-preference`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ preference })
  });
}

export async function fetchPlayers() {
  const res = await fetch(`${API_BASE}/players`);
  return res.json();
}

export async function fetchAllDecks() {
  const res = await fetch(`${API_BASE}/all-decks`);
  return res.json();
}


export async function fetchDeckCatalog(filters = {}) {
  const res = await fetch(`${API_BASE}/decks/catalog${queryString(filters)}`);
  return res.json();
}

export async function fetchUserDecks(userId) {
  const res = await fetch(`${API_BASE}/players/${userId}/decks`);
  return res.json();
}

function queryString(params = {}) {
  const search = new URLSearchParams();
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && String(value).trim() !== '') search.set(key, String(value));
  });
  const text = search.toString();
  return text ? `?${text}` : '';
}

export async function fetchStats(filters = null) {
  const res = await fetch(`${API_BASE}/stats${filters ? queryString(filters) : ''}`);
  return res.json();
}

export async function fetchStatsV2(filters = {}) {
  const res = await fetch(`${API_BASE}/stats/v2${queryString(filters)}`);
  return res.json();
}

export async function fetchMatches(filters = {}) {
  const res = await fetch(`${API_BASE}/matches${queryString(filters)}`);
  return res.json();
}

export async function fetchMatchHistoryPage(filters = {}, { limit = 25, offset = 0 } = {}) {
  const res = await fetch(`${API_BASE}/matches/history-page${queryString({ ...filters, limit, offset })}`);
  return res.json();
}

export async function postStartMatch(payload) {
  return fetch(`${API_BASE}/matches/start`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
}

export async function postCheckMatchAvailability(payload) {
  return fetch(`${API_BASE}/matches/check-availability`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
}

export async function fetchActiveMatch(matchId = null) {
  const url = matchId ? `${API_BASE}/matches/active/${matchId}` : `${API_BASE}/matches/active`;
  const res = await fetch(url);
  if (!res.ok) return null;
  return res.json();
}

export async function fetchActiveMatches() {
  const res = await fetch(`${API_BASE}/matches/active-list`);
  return res.json();
}

export async function fetchMyActiveMatch() {
  const res = await fetch(`${API_BASE}/matches/my-active`);
  return res.json();
}

export async function postLifeChange(matchId, playerId, change) {
  return fetch(`${API_BASE}/matches/${matchId}/life`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId, change })
  });
}

export async function postPoisonChange(matchId, playerId, change) {
  return fetch(`${API_BASE}/matches/${matchId}/poison`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId, change })
  });
}

export async function postTaxChange(matchId, playerId, change) {
  return fetch(`${API_BASE}/matches/${matchId}/tax`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId, change })
  });
}

export async function postCommanderDamage(matchId, targetPlayerId, sourcePlayerId, change) {
  return fetch(`${API_BASE}/matches/${matchId}/cmdr-dmg`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target_player_id: targetPlayerId, source_player_id: sourcePlayerId, change })
  });
}

export async function postUndo(matchId) {
  return fetch(`${API_BASE}/matches/${matchId}/undo`, { method: 'POST' });
}

export async function postNextTurn(matchId) {
  return fetch(`${API_BASE}/matches/${matchId}/next-turn`, { method: 'POST' });
}


export async function postDayNightState(matchId, state) {
  return fetch(`${API_BASE}/matches/${matchId}/day-night`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ state })
  });
}


export async function postPauseTimer(matchId) {
  return fetch(`${API_BASE}/matches/${matchId}/timer/pause`, { method: 'POST' });
}

export async function postResumeTimer(matchId) {
  return fetch(`${API_BASE}/matches/${matchId}/timer/resume`, { method: 'POST' });
}

export async function fetchMatchTimer(matchId) {
  const res = await fetch(`${API_BASE}/matches/${matchId}/timer`);
  return res.json();
}

export async function postReorderMatchSeats(matchId, playerIds) {
  return fetch(`${API_BASE}/matches/${matchId}/reorder-seats`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_ids: playerIds })
  });
}

export async function postFinishMatch(matchId, winnerPlayerId) {
  return fetch(`${API_BASE}/matches/${matchId}/finish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ winner_player_id: winnerPlayerId })
  });
}

export async function postFinishTeamMatch(matchId, winnerTeamNumber) {
  return fetch(`${API_BASE}/matches/${matchId}/finish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ winner_team_number: winnerTeamNumber })
  });
}

export async function deleteAbortMatch(matchId) {
  return fetch(`${API_BASE}/matches/${matchId}/abort`, { method: 'DELETE' });
}

export async function postConcede(matchId, playerId) {
  return fetch(`${API_BASE}/matches/${matchId}/concede`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId })
  });
}

export async function fetchLifeHistory(matchId) {
  const res = await fetch(`${API_BASE}/matches/${matchId}/life-history`);
  return res.json();
}


export async function fetchMatchHistory(matchId) {
  const res = await fetch(`${API_BASE}/matches/${matchId}/history`);
  return res.json();
}

export async function fetchMatchEvents(matchId) {
  const res = await fetch(`${API_BASE}/matches/${matchId}/events`);
  return res.json();
}

export async function postSaveDeck(id, payload) {
  const method = id ? 'PUT' : 'POST';
  const url = id ? `${API_BASE}/decks/${id}` : `${API_BASE}/decks`;
  return fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
}

export async function deleteDeckApi(id, expectedRevision = null) {
  const suffix = expectedRevision === null || expectedRevision === undefined ? '' : `?expected_revision=${encodeURIComponent(expectedRevision)}`;
  return fetch(`${API_BASE}/decks/${id}${suffix}`, { method: 'DELETE' });
}

export async function restoreDeckApi(id, expectedRevision = null) {
  return fetch(`${API_BASE}/decks/${id}/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(expectedRevision === null || expectedRevision === undefined ? {} : { expected_revision: expectedRevision })
  });
}

export async function postImportCsv(payload) {
  return fetch(`${API_BASE}/decks/import-csv`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
}

// ===== Admin API =====
// Dessa endpoints är sessionsskyddade på servern. UI:t döljs för vanliga
// användare, men säkerheten ligger alltid i requireAdmin på serversidan.
export async function fetchAdminSummary() {
  return fetch(`${API_BASE}/admin/summary`);
}
export async function postAdminPlayerPassword(playerId, password) {
  return fetch(`${API_BASE}/admin/players/${playerId}/password`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password })
  });
}
export async function deleteAdminPlayer(playerId) {
  return fetch(`${API_BASE}/admin/players/${playerId}`, { method: 'DELETE' });
}
export async function restoreAdminPlayer(playerId) {
  return fetch(`${API_BASE}/admin/players/${playerId}/restore`, { method: 'POST' });
}
export async function permanentlyDeleteAdminPlayer(playerId, confirmation) {
  return fetch(`${API_BASE}/admin/players/${playerId}/permanent`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ confirmation })
  });
}
export async function deleteAdminDeck(deckId) {
  return fetch(`${API_BASE}/admin/decks/${deckId}`, { method: 'DELETE' });
}
export async function restoreAdminDeck(deckId) {
  return fetch(`${API_BASE}/admin/decks/${deckId}/restore`, { method: 'POST' });
}
export async function permanentlyDeleteAdminDeck(deckId, confirmation) {
  return fetch(`${API_BASE}/admin/decks/${deckId}/permanent`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ confirmation })
  });
}
export async function deleteAdminMatch(matchId, confirmation) {
  return fetch(`${API_BASE}/admin/matches/${matchId}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ confirmation })
  });
}
export async function postAdminResetMatches(confirmation) {
  return fetch(`${API_BASE}/admin/reset/matches`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirmation })
  });
}
export async function postAdminResetDecks(confirmation) {
  return fetch(`${API_BASE}/admin/reset/decks`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirmation })
  });
}
export async function postAdminResetPlayers(confirmation) {
  return fetch(`${API_BASE}/admin/reset/players`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirmation })
  });
}
export async function postAdminFactoryReset(confirmation, password) {
  return fetch(`${API_BASE}/admin/reset/factory`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirmation, password })
  });
}
export async function fetchAdminAuditLog() {
  return fetch(`${API_BASE}/admin/audit-log`);
}


// ===== Steg 3.9.5: Systemstatus / diagnostik =====
export async function fetchAdminSystemStatus() {
  return fetch(`${API_BASE}/admin/system/status`);
}

export async function fetchAdminSystemLogs({ limit = 120, category = '', level = '' } = {}) {
  const params = new URLSearchParams({ limit: String(limit) });
  if (category) params.set('category', category);
  if (level) params.set('level', level);
  return fetch(`${API_BASE}/admin/system/logs?${params.toString()}`);
}

export async function postAdminManualBackup() {
  return fetch(`${API_BASE}/admin/system/backup`, { method: 'POST' });
}

export async function fetchAdminBackups() {
  return fetch(`${API_BASE}/admin/system/backups`);
}

export async function fetchAdminRecoveryDiagnostics() {
  return fetch(`${API_BASE}/admin/system/recovery-diagnostics`, { cache: 'no-store' });
}

export async function fetchAdminRestorePlan(name) {
  return fetch(`${API_BASE}/admin/system/backups/${encodeURIComponent(name)}/restore-plan`, { cache: 'no-store' });
}

export async function postAdminSafeRepair(confirmation) {
  return fetch(`${API_BASE}/admin/system/repair-safe`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ confirmation })
  });
}

export function adminBackupDownloadUrl(name) {
  return `${API_BASE}/admin/system/backups/${encodeURIComponent(name)}/download`;
}

export async function putAdminBackupSettings(settings) {
  return fetch(`${API_BASE}/admin/system/backup-settings`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings)
  });
}

export async function postAdminRestoreBackup(name, confirmation, password, restartAfterRestore = true, allowCrossInstanceRestore = false) {
  return fetch(`${API_BASE}/admin/system/backups/${encodeURIComponent(name)}/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      confirmation,
      password,
      restart_after_restore: restartAfterRestore,
      allow_cross_instance_restore: allowCrossInstanceRestore
    })
  });
}

// 3.9.8.3 Social / Hidden Role. Hemligheter hämtas endast efter en explicit
// reveal och skickas aldrig med den publika MatchDto:n.
export async function fetchMyHiddenRole(matchId) {
  return fetch(`${API_BASE}/matches/${matchId}/my-secret`);
}

export async function postRevealHiddenRole(matchId, playerId, revealToken) {
  return fetch(`${API_BASE}/matches/${matchId}/hidden-role/reveal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId, reveal_token: revealToken || undefined })
  });
}

function postHiddenRoleAction(matchId, action, playerId, revealToken) {
  return fetch(`${API_BASE}/matches/${matchId}/hidden-role/${action}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId, reveal_token: revealToken || undefined })
  });
}

export async function postClaimHiddenTarget(matchId, playerId, revealToken) {
  return postHiddenRoleAction(matchId, 'claim-target', playerId, revealToken);
}

export async function postClaimThrone(matchId, playerId, revealToken) {
  return postHiddenRoleAction(matchId, 'claim-throne', playerId, revealToken);
}

export async function postDeclineThrone(matchId, playerId, revealToken) {
  return postHiddenRoleAction(matchId, 'decline-throne', playerId, revealToken);
}
