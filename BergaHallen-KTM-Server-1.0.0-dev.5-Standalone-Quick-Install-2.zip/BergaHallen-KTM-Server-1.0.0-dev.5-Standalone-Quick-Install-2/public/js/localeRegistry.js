import enMessages from './locales/en.js';
import svMessages from './locales/sv.js';

export const FALLBACK_LOCALE = 'en';

export const LOCALE_REGISTRY = Object.freeze({
  en: Object.freeze({ code: 'en', nativeName: 'English', intlLocale: 'en-GB', messages: enMessages }),
  sv: Object.freeze({ code: 'sv', nativeName: 'Svenska', intlLocale: 'sv-SE', messages: svMessages })
});

export function baseLanguage(value) {
  const raw = String(value || '').trim().toLowerCase().replaceAll('_', '-');
  return raw ? raw.split('-')[0] : null;
}

export function clientSupportedLocales() {
  return Object.keys(LOCALE_REGISTRY);
}

export function canRenderLocale(value) {
  const base = baseLanguage(value);
  return !!base && Object.prototype.hasOwnProperty.call(LOCALE_REGISTRY, base);
}

export function intlLocaleFor(value) {
  const base = baseLanguage(value);
  return LOCALE_REGISTRY[base]?.intlLocale || LOCALE_REGISTRY[FALLBACK_LOCALE].intlLocale;
}
