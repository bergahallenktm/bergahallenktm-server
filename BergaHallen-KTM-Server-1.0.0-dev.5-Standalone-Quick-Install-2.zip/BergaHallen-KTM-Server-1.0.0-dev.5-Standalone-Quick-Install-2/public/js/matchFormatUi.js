import { t } from './i18n.js';

export function matchFormatLabel(match = {}) {
  const profile = String(match.match_profile || '').trim();
  const deckFormat = String(match.deck_format || '').trim();

  if (profile === 'constructed' && deckFormat) {
    return t(`deckFormat.${deckFormat}`, {}, deckFormat);
  }
  if (profile && profile !== 'legacy') {
    return t(`matchProfile.${profile}`, {}, match.match_type || profile);
  }
  return match.match_type || t('matchProfile.kitchen_table');
}

export function matchPlayModeLabel(match = {}) {
  const mode = String(match.play_mode || '').trim();
  if (mode) return t(`playMode.${mode}`, {}, mode);
  return match.team_mode === 'teams' ? t('playMode.teams') : t('playMode.ffa');
}

export function matchLimitedFormatLabel(match = {}) {
  const limited = String(match.limited_format || '').trim();
  return limited ? t(`limitedFormat.${limited}`, {}, limited) : '';
}

export function matchModifierLabels(match = {}) {
  const modifiers = Array.isArray(match.modifiers) ? match.modifiers : [];
  return modifiers.filter(Boolean).map(modifier => t(`modifier.${modifier}`, {}, modifier));
}

export function matchCompactLabel(match = {}) {
  const labels = [matchFormatLabel(match), matchLimitedFormatLabel(match), matchPlayModeLabel(match), ...matchModifierLabels(match)].filter(Boolean);
  return labels.join(' · ');
}
