const mtgIdentityPalette = {
  W: ['#5A5135', '#9E8E57', '#F0E5B9'],
  U: ['#082F57', '#1266A8', '#62B5EE'],
  B: ['#0A0B0E', '#27242D', '#64596E'],
  R: ['#5B1012', '#A52625', '#F06A49'],
  G: ['#0C3421', '#1F7042', '#69B86F'],
  C: ['#293036', '#56616A', '#B0BCC4']
};

export function normalizeDeckIdentity(value) {
  if (!value) return null;
  const raw = String(value).toUpperCase();
  const order = ['W','U','B','R','G'];
  const found = new Set([...raw].filter(c => order.includes(c)));
  if (found.size) return order.filter(c => found.has(c)).join('');
  return raw.includes('C') ? 'C' : null;
}

export function deckIdentityPresentation(player) {
  const identity = normalizeDeckIdentity(player?.deck_color_identity);
  if (!identity) return { className: '', style: '' };
  const symbols = identity === 'C' ? ['C'] : [...identity];
  const seed = Math.abs(Number(player.deck_id || player.player_id || 1));
  const angle = 125 + (seed % 70);
  const colors = symbols.map(s => mtgIdentityPalette[s] || mtgIdentityPalette.C);
  const mids = colors.map(p => p[1]);
  const glows = colors.map(p => p[2]);
  const deep = colors.map(p => p[0]);
  const stops = mids.length === 1
    ? `${deep[0]} 0%, ${mids[0]} 52%, ${deep[0]} 100%`
    : mids.map((c, i) => `${c} ${Math.round(i * 100 / (mids.length - 1))}%`).join(', ');
  const blooms = glows.map((c, i) => {
    const x = 18 + ((seed * (i + 3) * 17) % 68);
    const y = 18 + ((seed * (i + 5) * 23) % 65);
    return `radial-gradient(circle at ${x}% ${y}%, ${c}66 0%, ${c}1f 24%, transparent 52%)`;
  });
  const veins = colors.map((p, i) => {
    const x = 12 + ((seed + i * 29) % 70);
    return `radial-gradient(ellipse at ${x}% ${i % 2 ? 78 : 24}%, ${p[2]}24 0%, transparent 48%)`;
  });
  const layers = [...blooms, ...veins, `linear-gradient(${angle}deg, ${stops})`].join(', ');
  return {
    className: 'deck-identity-surface',
    style: `--deck-identity-background:${layers};`
  };
}

export function boardLayoutStorageKey(matchId) {
  return `bergahallen-board-layout-${matchId}`;
}

export function defaultRotationForPosition(playerCount, index) {
  if (playerCount === 2 && index === 0) return 180;
  if (playerCount >= 3 && index < 2) return 180;
  return 0;
}

export function normalizeRotation(value) {
  const rotation = Number(value);
  return [0, 90, 180, 270].includes(rotation) ? rotation : 0;
}

export function rotationClassFor(value) {
  const rotation = normalizeRotation(value);
  return rotation === 0 ? '' : `table-rotation-${rotation}`;
}

export function deriveBoardLayout(players = [], saved = null) {
  const playerIds = players.map(p => Number(p.player_id));
  const savedOrder = Array.isArray(saved?.order) ? saved.order.map(Number) : [];
  const validSavedOrder = savedOrder.filter(id => playerIds.includes(id));
  const missingIds = playerIds.filter(id => !validSavedOrder.includes(id));
  const order = [...validSavedOrder, ...missingIds];
  const rotations = {};
  playerIds.forEach((id, originalIndex) => {
    const savedRotation = Number(saved?.rotations?.[id]);
    rotations[id] = [0, 90, 180, 270].includes(savedRotation)
      ? savedRotation
      : defaultRotationForPosition(players.length, originalIndex);
  });
  return { order, rotations };
}

export function turnOrderFromDisplayOrder(displayOrder) {
  const ids = displayOrder.map(Number);
  const ringByCount = {
    2: [0, 1],
    3: [0, 1, 2],
    4: [0, 1, 3, 2],
    5: [0, 1, 3, 4, 2],
    6: [0, 1, 3, 5, 4, 2]
  };
  const ring = ringByCount[ids.length] || ids.map((_, index) => index);
  return ring.map(index => ids[index]).filter(Number.isInteger);
}
