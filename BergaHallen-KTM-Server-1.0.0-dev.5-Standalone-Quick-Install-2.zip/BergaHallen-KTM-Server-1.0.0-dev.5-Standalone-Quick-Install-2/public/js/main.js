import { fetchFormats, fetchMatchOptions, fetchMeta, fetchAuthMe, postLogin, postRegister, postLogout, postCardLinkPreference, postLocalePreference, fetchMyActiveMatch, fetchAccountDeletionPreview, postAccountDeletion } from './api.js';
import { loadDashboardData, addParticipantRow, escapeHtml, setMatchTeamMode, setMatchBuilderParticipantLimits, setMatchDeckSelectionMode } from './dashboard.js';
import { initiateDiceRollPhase, confirmAndStartMatchWithWinner, closeDiceModal } from './dice.js';
import { 
  checkActiveMatch, toggleTimer, undoLastLifeChange, abortMatchWithoutStats, 
  openWinnerModal, closeWinnerModal, nextTurn, selectActiveMatch, toggleBoardArrangeMode, resetBoardLayout, setDayNightState
} from './liveMatch.js';
import { renderAllDecksView, loadMyDecks, saveDeck, clearDeckForm, importManaBoxCsv, setupDeckUxListeners } from './decks.js';
import { loadAdminPanel } from './admin.js';
import { initI18n, getLocale, getLocalePreference, resolveAutoLocale, applyGuestLocalePreference, setGuestLocalePreference, applyAccountLocaleSettings, t, apiErrorMessage, applyTranslations } from './i18n.js';
import { initDiscoveryPanel, refreshDiscoveryPanel } from './discovery.js';

export let currentUser = null;
export let availableFormats = {};
export let matchOptions = { profiles: {}, deck_formats: {}, play_modes: {} };
export let cardLinkPreference = 'scryfall'; // Standard
let serverMeta = null;
let serverInstanceUid = null;
let localeChangeInFlight = false;
let accountDeletionInFlight = false;

function showAppInitError(error = null) {
  if (error) console.error('Application data refresh failed.', error);
  const status = document.getElementById('appInitError');
  if (!status) return;
  status.textContent = t('app.init_error');
  status.classList.remove('hidden');
}

function clearAppInitError() {
  const status = document.getElementById('appInitError');
  if (!status) return;
  status.classList.add('hidden');
}

export function showTab(tab) {
  ['dashboard', 'live', 'decks', 'profile', 'admin'].forEach(t => {
    const tabEl = document.getElementById(`tab-${t}`);
    const navEl = document.getElementById(`nav-${t}`);
    if (tabEl) tabEl.classList.toggle('hidden', t !== tab);
    if (navEl) {
      const isActive = t === tab;
      navEl.classList.toggle('app-nav-button-active', isActive);
      if (isActive) navEl.setAttribute('aria-current', 'page');
      else navEl.removeAttribute('aria-current');
    }
  });
  if (tab === 'dashboard') loadDashboardData();
  if (tab === 'live') checkActiveMatch();
  if (tab === 'decks') {
    renderAllDecksView();
    loadMyDecks();
  }
  if (tab === 'profile') {
    refreshDiscoveryPanel();
    loadMyDecks();
  }
  if (tab === 'profile' && currentUser && !currentUser.is_admin) {
    refreshAccountDeletionPreview();
  }
  if (tab === 'admin') {
    if (!currentUser?.is_admin) return showTab('dashboard');
    loadAdminPanel(currentUser);
  }
}

async function loadFormats() {
  const [legacyFormats, normalizedOptions] = await Promise.all([
    fetchFormats(),
    fetchMatchOptions()
  ]);
  availableFormats = legacyFormats || {};
  matchOptions = normalizedOptions || { profiles: {}, deck_formats: {}, play_modes: {} };

  const profileSelect = document.getElementById('matchProfile');
  profileSelect.innerHTML = Object.values(matchOptions.profiles || {})
    .map(profile => `<option value="${escapeHtml(profile.key)}">${escapeHtml(t(profile.name_key, {}, profile.key))}</option>`)
    .join('');

  // Commander är fortsatt standard för BergaHallen, men övriga defaults styrs
  // nu helt av formatmotorn i stället för hårdkodade fält i HTML.
  if (matchOptions.profiles?.commander) profileSelect.value = 'commander';

  const deckFormatSelect = document.getElementById('matchDeckFormat');
  // Keep locked profile formats (Commander/Oathbreaker) as hidden options.
  // That lets the normalized payload keep the correct deck_format even when
  // the selector itself is hidden for a locked profile.
  deckFormatSelect.innerHTML = Object.values(matchOptions.deck_formats || {})
    .map(format => `<option value="${escapeHtml(format.key)}"${format.active_for_constructed ? '' : ' hidden'}>${escapeHtml(t(format.name_key, {}, format.stored_value || format.key))}</option>`)
    .join('');

  const limitedSelect = document.getElementById('matchLimitedFormat');
  if (limitedSelect) {
    limitedSelect.innerHTML = [
      `<option value="">${escapeHtml(t('limitedFormat.none'))}</option>`,
      ...Object.values(matchOptions.limited_formats || {}).map(format =>
        `<option value="${escapeHtml(format.key)}">${escapeHtml(t(format.name_key, {}, format.key))}</option>`
      )
    ].join('');
  }

  // Deck-editorerna använder samma centrala formatlista. Värdet som sparas i
  // decks.format är avsiktligt läsbart för äldre klienter.
  const editorFormats = Object.values(matchOptions.deck_formats || {})
    .map(format => ({ value: format.stored_value || format.key, label: t(format.name_key, {}, format.stored_value || format.key) }));
  const knownValues = new Set(editorFormats.map(format => format.value));
  for (const [legacyKey, config] of Object.entries(availableFormats)) {
    if (!knownValues.has(legacyKey)) editorFormats.push({ value: legacyKey, label: t(config.name_key || `format.${legacyKey}`, {}, config.name || legacyKey) });
  }
  const editorOptionsHtml = editorFormats
    .map(format => `<option value="${escapeHtml(format.value)}">${escapeHtml(format.label)}</option>`)
    .join('');
  document.getElementById('deckFormat').innerHTML = editorOptionsHtml;
  document.getElementById('importDeckFormat').innerHTML = editorOptionsHtml;

  document.getElementById('startingLife').innerHTML = [20, 30, 40, 50, 60]
    .map(value => `<option value="${value}">${value}</option>`)
    .join('');

  document.getElementById('timerMinutes').innerHTML = [
    `<option value="0">${t('dashboard.timer.off')}</option>`,
    ...[1,2,3,4,5].map(n => `<option value="${n}">${t(n === 1 ? 'dashboard.timer.minute' : 'dashboard.timer.minutes', { count: n })}</option>`)
  ].join('');

  applyMatchProfileDefaults({ adjustRows: false });
}

function currentProfile() {
  return matchOptions.profiles?.[document.getElementById('matchProfile')?.value] || null;
}

function currentPlayMode() {
  return matchOptions.play_modes?.[document.getElementById('matchPlayMode')?.value] || null;
}

function currentLimitedFormat() {
  const key = document.getElementById('matchLimitedFormat')?.value || '';
  return key ? matchOptions.limited_formats?.[key] || null : null;
}

function selectedModifiers() {
  const modifiers = [];
  if (document.getElementById('modifierPlanechase')?.checked && matchOptions.modifiers?.planechase) modifiers.push('planechase');
  return modifiers;
}

function profileSupportsLimited(profile) {
  if (!profile) return false;
  return Object.values(matchOptions.limited_formats || {}).some(format => Array.isArray(format.allowed_profiles) && format.allowed_profiles.includes(profile.key));
}

function specialDefaultLife(profile, mode) {
  if (!profile || !mode) return 20;
  if (mode.key === 'two_headed_giant') return Number(profile.key === 'commander' ? mode.commander_team_life || 60 : mode.default_team_life || 30);
  if (mode.key === 'archenemy_commander') return Number(mode.default_team_life || 60);
  if (mode.key === 'archenemy') return Number(mode.role_life?.hero || 20);
  if (mode.key === 'kingdoms') return Number(mode.role_life?.knight || 40);
  return Number(profile.default_life || 20);
}

function specialHelpKey(modeKey) {
  return ({
    two_headed_giant:'matchBuilder.special.two_headed_giant',
    emperor:'matchBuilder.special.emperor',
    archenemy:'matchBuilder.special.archenemy',
    archenemy_commander:'matchBuilder.special.archenemy_commander',
    attack_left_defend_right:'matchBuilder.special.attack_left_defend_right',
    kingdoms:'matchBuilder.special.kingdoms',
    assassin:'matchBuilder.special.assassin'
  })[modeKey] || null;
}

function populatePlayModes(profile, preferred = null) {
  const select = document.getElementById('matchPlayMode');
  const limited = currentLimitedFormat();
  let allowed = Array.isArray(profile?.allowed_play_modes) ? [...profile.allowed_play_modes] : ['ffa'];
  if (limited && Array.isArray(limited.allowed_play_modes)) {
    allowed = allowed.filter(key => limited.allowed_play_modes.includes(key));
  }
  select.innerHTML = allowed
    .map(key => matchOptions.play_modes?.[key])
    .filter(Boolean)
    .map(mode => `<option value="${escapeHtml(mode.key)}">${escapeHtml(t(mode.name_key, {}, mode.key))}</option>`)
    .join('');
  let next = preferred && allowed.includes(preferred) ? preferred : profile?.default_play_mode;
  if (limited && !allowed.includes(next)) next = allowed[0];
  if (next && [...select.options].some(option => option.value === next)) select.value = next;
}

function applyBuilderLimits({ adjustRows = true } = {}) {
  const profile = currentProfile();
  const mode = currentPlayMode();
  if (!profile || !mode) return;
  const limited = currentLimitedFormat();
  setMatchDeckSelectionMode(limited?.deck_selection_mode || 'required');
  let min = Math.max(Number(profile.min_players || 2), Number(mode.min_players || 2));
  let max = Math.min(Number(profile.max_players || 6), Number(mode.max_players || 6));
  let recommended = mode.key === profile.default_play_mode
    ? Number(profile.recommended_players || min)
    : Number(mode.recommended_players || min);
  if (limited) {
    if (mode.key === 'duel') { min = 2; max = 2; recommended = 2; }
    else if (mode.key === 'two_headed_giant') { min = 4; max = 4; recommended = 4; }
    else {
      min = Number(limited.min_players || min);
      max = Number(limited.max_players || max);
      recommended = Number(limited.recommended_players || min);
    }
  }
  setMatchBuilderParticipantLimits({ min, max, recommended }, { adjustEmpty: adjustRows });
}

function updateMatchRulesSummary() {
  const profile = currentProfile();
  const mode = currentPlayMode();
  if (!profile || !mode) return;
  const deckFormat = matchOptions.deck_formats?.[document.getElementById('matchDeckFormat')?.value];
  const life = Number(document.getElementById('startingLife')?.value || specialDefaultLife(profile, mode));
  const limited = currentLimitedFormat();
  let min = Math.max(Number(profile.min_players || 2), Number(mode.min_players || 2));
  let max = Math.min(Number(profile.max_players || 6), Number(mode.max_players || 6));
  if (limited) {
    if (mode.key === 'duel') { min = 2; max = 2; }
    else if (mode.key === 'two_headed_giant') { min = 4; max = 4; }
    else { min = Number(limited.min_players || min); max = Number(limited.max_players || max); }
  }
  const formatLabel = profile.deck_format_selectable && deckFormat
    ? t(deckFormat.name_key, {}, deckFormat.stored_value || deckFormat.key)
    : t(profile.name_key, {}, profile.key);
  const chips = [
    formatLabel,
    t(mode.name_key, {}, mode.key),
    min === max ? t('matchBuilder.players_exact', { count: min }) : t('matchBuilder.players_range', { min, max })
  ];
  if (limited) {
    chips.splice(1, 0, t(limited.name_key, {}, limited.key));
    if (limited.deck_selection_mode === 'optional') chips.push(t('matchBuilder.deck_optional'));
    if (limited.team_shape === '3v3') chips.push(t('matchBuilder.team_3v3'));
    if (limited.team_shape === 'equal_teams') chips.push(t('matchBuilder.equal_teams'));
  }
  for (const modifier of selectedModifiers()) {
    const config = matchOptions.modifiers?.[modifier];
    chips.push(`🌀 ${t(config?.name_key || `modifier.${modifier}`, {}, modifier)}`);
  }

  if (mode.starting_life_mode === 'uniform') chips.splice(2, 0, t('matchBuilder.life_chip', { count: life }));
  if (mode.life_scope === 'team') chips.splice(2, 0, t('matchBuilder.shared_team_life', { count: specialDefaultLife(profile, mode) }));
  if (mode.key === 'archenemy') chips.splice(2, 0, t('matchBuilder.archenemy_life', { archenemy: mode.role_life?.archenemy || 40, heroes: mode.role_life?.hero || 20 }));
  if (mode.turn_scope === 'team') chips.push(t('matchBuilder.team_turns'));
  if (mode.poison_scope === 'team') chips.push(t('matchBuilder.shared_poison', { count: mode.poison_loss_threshold || 15 }));
  if (mode.key === 'emperor') chips.push(t('matchBuilder.emperor_range'));
  if (mode.key === 'attack_left_defend_right') chips.push(t('matchBuilder.attack_left'));
  if (mode.key === 'kingdoms') {
    chips.splice(2, 0, t('matchBuilder.kingdoms_life', { king: mode.role_life?.king || 50, others: mode.role_life?.knight || 40 }));
    chips.push(t('matchBuilder.hidden_roles'));
  }
  if (mode.key === 'assassin') {
    chips.push(t('matchBuilder.secret_target'));
    chips.push(t('matchBuilder.hidden_targets'));
  }

  document.getElementById('matchRulesSummary').innerHTML = chips.map(value => `<span class="match-rule-chip">${escapeHtml(value)}</span>`).join('');
  const help = document.getElementById('specialModeHelp');
  const helpKey = specialHelpKey(mode.key);
  if (help) {
    const helpParts = [];
    if (helpKey) helpParts.push(t(helpKey));
    if (limited) helpParts.push(t('matchBuilder.special.limited'));
    if (selectedModifiers().includes('planechase')) helpParts.push(t('matchBuilder.planechase_metadata'));
    help.classList.toggle('hidden', helpParts.length === 0);
    help.textContent = helpParts.join(' ');
  }
}

function applyMatchProfileDefaults({ adjustRows = true } = {}) {
  const profile = currentProfile();
  if (!profile) return;
  document.getElementById('matchType').value = profile.legacy_match_type || 'KTM';
  document.getElementById('matchDeckFormat').value = profile.default_deck_format;
  document.getElementById('matchDeckFormatWrap').classList.toggle('hidden', !profile.deck_format_selectable);
  const limitedWrap = document.getElementById('matchLimitedFormatWrap');
  const limitedSelect = document.getElementById('matchLimitedFormat');
  const supportsLimited = profileSupportsLimited(profile);
  limitedWrap?.classList.toggle('hidden', !supportsLimited);
  if (limitedSelect && !supportsLimited) limitedSelect.value = '';
  if (limitedSelect && supportsLimited) limitedSelect.value = '';
  if (document.getElementById('modifierPlanechase')) document.getElementById('modifierPlanechase').checked = false;
  populatePlayModes(profile, profile.default_play_mode);
  const mode = currentPlayMode();
  document.getElementById('startingLife').value = String(specialDefaultLife(profile, mode));
  document.getElementById('startingLifeWrap')?.classList.toggle('hidden', mode?.starting_life_mode !== 'uniform');
  document.getElementById('timerMinutes').value = String(profile.default_timer_minutes ?? 3);
  applyBuilderLimits({ adjustRows });
  setMatchTeamMode();
  updateMatchRulesSummary();
}

function onLimitedFormatChange() {
  const profile = currentProfile();
  const limited = currentLimitedFormat();
  populatePlayModes(profile, limited?.allowed_play_modes?.[0] || profile?.default_play_mode);
  const mode = currentPlayMode();
  document.getElementById('startingLife').value = String(specialDefaultLife(profile, mode));
  document.getElementById('startingLifeWrap')?.classList.toggle('hidden', mode?.starting_life_mode !== 'uniform');
  applyBuilderLimits({ adjustRows: true });
  setMatchTeamMode();
  updateMatchRulesSummary();
}

function onMatchPlayModeChange() {
  const profile = currentProfile();
  const mode = currentPlayMode();
  document.getElementById('startingLife').value = String(specialDefaultLife(profile, mode));
  document.getElementById('startingLifeWrap')?.classList.toggle('hidden', mode?.starting_life_mode !== 'uniform');
  applyBuilderLimits({ adjustRows: true });
  setMatchTeamMode();
  updateMatchRulesSummary();
}

function resetMatchBuilderDefaults() {
  applyMatchProfileDefaults({ adjustRows: true });
}

function setAccountDeletionUiAvailable() {
  const panel = document.getElementById('accountDeletionPanel');
  if (!panel) return false;
  const available = !!currentUser && !currentUser.is_admin;
  panel.classList.toggle('hidden', !available);
  if (!available) closeAccountDeletionModal();
  return available;
}

async function refreshAccountDeletionPreview() {
  if (!setAccountDeletionUiAvailable()) return null;
  const summary = document.getElementById('accountDeletionSummary');
  try {
    const res = await fetchAccountDeletionPreview();
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (summary) summary.textContent = apiErrorMessage(data, 'accountDeletion.load_failed');
      return null;
    }
    const activeMatches = Number(data.active_match_count || 0);
    const ownedDecks = Number(data.owned_deck_count || 0);
    document.getElementById('accountDeletionActiveMatches').textContent = String(activeMatches);
    document.getElementById('accountDeletionOwnedDecks').textContent = String(ownedDecks);
    if (summary) summary.textContent = t('accountDeletion.summary', { matches: activeMatches, decks: ownedDecks });
    return data;
  } catch (error) {
    console.error('Account deletion preview failed:', error);
    if (summary) summary.textContent = t('accountDeletion.load_failed');
    return null;
  }
}

async function openAccountDeletionModal() {
  if (!currentUser || currentUser.is_admin) return;
  const preview = await refreshAccountDeletionPreview();
  if (!preview) return;
  const modal = document.getElementById('accountDeletionModal');
  document.getElementById('accountDeletionPassword').value = '';
  document.getElementById('accountDeletionConfirm').checked = false;
  const status = document.getElementById('accountDeletionStatus');
  status.textContent = '';
  status.classList.add('hidden');
  modal.classList.remove('hidden');
  document.getElementById('accountDeletionPassword').focus();
}

function closeAccountDeletionModal() {
  if (accountDeletionInFlight) return;
  document.getElementById('accountDeletionModal')?.classList.add('hidden');
}

async function confirmAccountDeletion() {
  if (accountDeletionInFlight || !currentUser || currentUser.is_admin) return;
  const password = document.getElementById('accountDeletionPassword')?.value || '';
  const confirmed = !!document.getElementById('accountDeletionConfirm')?.checked;
  const status = document.getElementById('accountDeletionStatus');
  if (!password) {
    status.textContent = t('accountDeletion.password_required');
    status.classList.remove('hidden');
    return;
  }
  if (!confirmed) {
    status.textContent = t('accountDeletion.confirm_required');
    status.classList.remove('hidden');
    return;
  }

  const button = document.getElementById('confirmAccountDeletionBtn');
  accountDeletionInFlight = true;
  button.disabled = true;
  status.textContent = t('accountDeletion.deleting');
  status.classList.remove('hidden');
  try {
    const res = await postAccountDeletion(password);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      status.textContent = apiErrorMessage(data, 'accountDeletion.failed');
      return;
    }
    currentUser = null;
    document.getElementById('accountDeletionModal').classList.add('hidden');
    await checkAuth();
    showTab('profile');
    alert(t('accountDeletion.deleted'));
  } catch (error) {
    console.error('Account deletion request failed:', error);
    status.textContent = t('accountDeletion.failed');
  } finally {
    accountDeletionInFlight = false;
    button.disabled = false;
  }
}

async function checkAuth() {
  const beforeLocale = getLocale();
  const data = await fetchAuthMe();
  currentUser = data.user;
  document.getElementById('authForms').classList.toggle('hidden', !!currentUser);
  document.getElementById('userProfile').classList.toggle('hidden', !currentUser);
  document.getElementById('nav-admin').classList.toggle('hidden', !currentUser?.is_admin);
  setAccountDeletionUiAvailable();
  if (currentUser) {
    document.getElementById('loggedInUserDisplay').innerText = currentUser.name;
    const roleBadge = document.getElementById('accountRoleBadge');
    if (roleBadge) roleBadge.textContent = t(currentUser.role === 'admin' ? 'auth.role_admin' : 'auth.role_player');
    await applyAccountLocaleSettings(currentUser, serverInstanceUid, currentUser.locale_settings, { emit: false });
    if (beforeLocale !== getLocale()) await loadFormats();
    if (currentUser.card_link_preference) {
      cardLinkPreference = currentUser.card_link_preference;
      document.querySelectorAll('input[name="cardLinkPreference"]').forEach(el => {
        el.checked = el.value === cardLinkPreference;
      });
    }
    await loadMyDecks();
    await refreshAccountDeletionPreview();
  } else {
    const roleBadge = document.getElementById('accountRoleBadge');
    if (roleBadge) roleBadge.textContent = '';
    await applyGuestLocalePreference({ emit: false });
    if (beforeLocale !== getLocale()) await loadFormats();
  }
}

async function login() {
  const name = document.getElementById('loginName').value;
  const password = document.getElementById('loginPass').value;
  if (!name || !password) {
    alert(t('auth.fill_fields'));
    return;
  }
  try {
    const res = await postLogin(name, password);
    if (res.ok) {
      await checkAuth();
      loadDashboardData();
      const ownMatch = await fetchMyActiveMatch();
      if (ownMatch) { selectActiveMatch(ownMatch.id); showTab('live'); }
      document.getElementById('loginName').value = '';
      document.getElementById('loginPass').value = '';
    } else {
      const data = await res.json().catch(() => ({}));
      alert(`❌ ${apiErrorMessage(data, 'auth.login_failed').replace(/^❌\s*/, '')}`);
    }
  } catch (err) {
    console.error('Login request failed:', err);
    alert(`❌ ${t('auth.network_failed')}`);
  }
}

let registerInFlight = false;

async function register() {
  if (registerInFlight) return;
  const name = document.getElementById('regName').value;
  const password = document.getElementById('regPass').value;
  if (!name || !password || password.length < 4) {
    alert(t('auth.register_validation'));
    return;
  }

  registerInFlight = true;
  const btn = document.getElementById('registerBtn');
  const originalText = btn.innerText;
  btn.disabled = true;
  btn.innerText = t('auth.registering');

  try {
    const res = await postRegister(name, password, getLocale());
    if (res.ok) {
      await checkAuth();
      loadDashboardData();
      const ownMatch = await fetchMyActiveMatch();
      if (ownMatch) { selectActiveMatch(ownMatch.id); showTab('live'); }
      document.getElementById('regName').value = '';
      document.getElementById('regPass').value = '';
    } else {
      const data = await res.json().catch(() => ({}));
      alert(`❌ ${apiErrorMessage(data, 'auth.register_failed').replace(/^❌\s*/, '')}`);
    }
  } catch (err) {
    console.error('Registration request failed:', err);
    alert(`❌ ${t('auth.network_failed')}`);
  } finally {
    registerInFlight = false;
    btn.disabled = false;
    btn.innerText = originalText;
  }
}

async function logout() {
  await postLogout();
  currentUser = null;
  await checkAuth();
  await refreshCurrentViewForLocale();
}

async function saveCardLinkPreference() {
  if (!currentUser) {
    alert(t('auth.must_login'));
    return;
  }
  
  const selected = document.querySelector('input[name="cardLinkPreference"]:checked');
  if (!selected) return;
  
  const preference = selected.value;
  cardLinkPreference = preference;
  
  const res = await postCardLinkPreference(preference);
  if (res.ok) {
    // Uppdatera decklistor om de visas just nu
    renderAllDecksView();
    loadMyDecks();
  } else {
    alert(t('auth.preference_failed'));
  }
}

async function refreshCurrentViewForLocale() {
  applyTranslations(document);
  if (!document.getElementById('tab-dashboard')?.classList.contains('hidden')) await loadDashboardData();
  if (!document.getElementById('tab-live')?.classList.contains('hidden')) await checkActiveMatch();
  if (!document.getElementById('tab-decks')?.classList.contains('hidden')) {
    await renderAllDecksView();
    if (currentUser) await loadMyDecks();
  }
  if (!document.getElementById('tab-admin')?.classList.contains('hidden') && currentUser?.is_admin) {
    await loadAdminPanel(currentUser);
  }
}

function setupEventListeners() {
  document.getElementById('brandHomeLink')?.addEventListener('click', (event) => {
    event.preventDefault();
    showTab('dashboard');
  });

  document.getElementById('languageSelector')?.addEventListener('change', async (event) => {
    const selector = event.currentTarget || event.target;
    const selected = String(selector?.value || 'auto');
    if (localeChangeInFlight) return;

    localeChangeInFlight = true;
    if (selector) selector.disabled = true;

    try {
      // Always refresh /auth/me immediately before an authenticated locale
      // mutation. A different browser/Android client may have advanced the
      // revision since this page last rendered. Using a stale in-memory
      // revision made the first successful choice appear to "lock" the
      // selector behind repeated LOCALE_PREFERENCE_CONFLICT responses.
      const freshAuth = await fetchAuthMe();
      const freshUser = freshAuth?.user || null;

      if (!freshUser) {
        currentUser = null;
        if (selected === 'auto') await setGuestLocalePreference('auto');
        else await setGuestLocalePreference('manual', selected);
      } else {
        currentUser = freshUser;
        const freshSettings = freshUser.locale_settings || getLocalePreference();
        const expectedRevision = Math.max(0, Number(freshSettings?.revision || 0));
        const requestBody = selected === 'auto'
          ? { mode: 'auto', effective_locale: resolveAutoLocale(), expected_revision: expectedRevision }
          : { mode: 'manual', locale: selected, expected_revision: expectedRevision };

        const res = await postLocalePreference(requestBody);
        const data = await res.json().catch(() => ({}));
        if (res.ok) {
          currentUser.locale_settings = data.locale_settings;
          if (data.preferred_locale) currentUser.preferred_locale = data.preferred_locale;
          await applyAccountLocaleSettings(currentUser, serverInstanceUid, data.locale_settings, { emit: true });
        } else if (res.status === 409 && data.locale_settings) {
          // A true race can still happen between the fresh GET and POST. The
          // server remains authoritative; load its newest state. A subsequent
          // explicit user choice will fetch the new revision and can proceed.
          currentUser.locale_settings = data.locale_settings;
          if (data.preferred_locale) currentUser.preferred_locale = data.preferred_locale;
          await applyAccountLocaleSettings(currentUser, serverInstanceUid, data.locale_settings, { emit: true });
          alert(t('language.conflict'));
        } else {
          await applyAccountLocaleSettings(currentUser, serverInstanceUid, currentUser.locale_settings, { emit: false });
          alert(apiErrorMessage(data, 'language.save_failed'));
        }
      }

      try {
        await loadFormats();
        await refreshCurrentViewForLocale();
        clearAppInitError();
      } catch (refreshError) {
        showAppInitError(refreshError);
      }
    } catch (error) {
      if (currentUser?.locale_settings) {
        await applyAccountLocaleSettings(currentUser, serverInstanceUid, currentUser.locale_settings, { emit: false });
      } else {
        await applyGuestLocalePreference({ emit: false });
      }
      alert(t('language.save_failed'));
      showAppInitError(error);
    } finally {
      localeChangeInFlight = false;
      if (selector) selector.disabled = false;
    }
  });

  document.getElementById('nav-dashboard').addEventListener('click', () => showTab('dashboard'));
  document.getElementById('nav-live').addEventListener('click', () => showTab('live'));
  document.getElementById('nav-decks').addEventListener('click', () => showTab('decks'));
  document.getElementById('nav-profile').addEventListener('click', () => showTab('profile'));
  document.getElementById('nav-admin').addEventListener('click', () => showTab('admin'));
  document.getElementById('refreshAdminBtn').addEventListener('click', () => {
    if (currentUser?.is_admin) loadAdminPanel(currentUser);
  });

  document.getElementById('matchProfile').addEventListener('change', () => applyMatchProfileDefaults({ adjustRows: true }));
  document.getElementById('matchDeckFormat').addEventListener('change', updateMatchRulesSummary);
  document.getElementById('matchLimitedFormat')?.addEventListener('change', onLimitedFormatChange);
  document.getElementById('modifierPlanechase')?.addEventListener('change', updateMatchRulesSummary);
  document.getElementById('matchPlayMode').addEventListener('change', onMatchPlayModeChange);
  document.getElementById('startingLife').addEventListener('change', updateMatchRulesSummary);
  document.getElementById('resetMatchDefaultsBtn').addEventListener('click', resetMatchBuilderDefaults);
  document.getElementById('addParticipantBtn').addEventListener('click', addParticipantRow);
  document.getElementById('startDicePhaseBtn').addEventListener('click', initiateDiceRollPhase);

  document.getElementById('closeDiceModalBtn').addEventListener('click', closeDiceModal);
  document.getElementById('confirmStartMatchBtn').addEventListener('click', () => {
    confirmAndStartMatchWithWinner((data) => {
      if (data?.matchId) selectActiveMatch(data.matchId);
      showTab('live');
    });
  });

  document.getElementById('pauseBtn').addEventListener('click', toggleTimer);
  document.getElementById('undoBtn').addEventListener('click', undoLastLifeChange);
  document.getElementById('abortMatchBtn').addEventListener('click', () => {
    abortMatchWithoutStats(() => showTab('dashboard'));
  });
  document.getElementById('finishMatchModalBtn').addEventListener('click', openWinnerModal);
  document.getElementById('closeWinnerModalBtn').addEventListener('click', closeWinnerModal);
  document.getElementById('diceModal').addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeDiceModal();
  });
  document.getElementById('winnerModal').addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeWinnerModal();
  });
  document.getElementById('nextTurnBtn').addEventListener('click', nextTurn);
  document.getElementById('dayNightDayBtn').addEventListener('click', () => setDayNightState('day'));
  document.getElementById('dayNightNightBtn').addEventListener('click', () => setDayNightState('night'));
  document.getElementById('arrangeBoardBtn').addEventListener('click', toggleBoardArrangeMode);
  document.getElementById('resetBoardLayoutBtn').addEventListener('click', resetBoardLayout);

  document.getElementById('loginBtn').addEventListener('click', login);
  document.getElementById('registerBtn').addEventListener('click', register);
  document.getElementById('logoutBtn').addEventListener('click', logout);
  document.getElementById('openAccountDeletionBtn')?.addEventListener('click', openAccountDeletionModal);
  document.getElementById('cancelAccountDeletionBtn')?.addEventListener('click', closeAccountDeletionModal);
  document.getElementById('confirmAccountDeletionBtn')?.addEventListener('click', confirmAccountDeletion);
  document.getElementById('accountDeletionModal')?.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeAccountDeletionModal();
  });

  document.getElementById('importCsvBtn').addEventListener('click', importManaBoxCsv);
  document.getElementById('saveDeckBtn').addEventListener('click', saveDeck);
  document.getElementById('clearDeckFormBtn').addEventListener('click', clearDeckForm);
  setupDeckUxListeners();
  initDiscoveryPanel({ refresh:false }).catch(error => console.error('Discovery listener initialization failed.', error));
  
  // Spara kortlänksinställning
  document.getElementById('saveCardLinkPreference').addEventListener('click', saveCardLinkPreference);

  // Enter key support for login/register
  document.getElementById('loginPass').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') login();
  });
  document.getElementById('regPass').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') register();
  });
}

async function initApp() {
  // Bind core UI events first so a failing data endpoint never leaves the page
  // completely inert. Initialization is deliberately step-isolated: one
  // transient endpoint failure should not prevent authentication or language
  // recovery from running.
  setupEventListeners();
  let hadInitError = false;

  try {
    serverMeta = await fetchMeta().catch(() => null);
    serverInstanceUid = serverMeta?.instance_uid || null;
    await initI18n(serverMeta);
    // Discovery status is dynamic. Start it after i18n initialization so the
    // translation pass cannot overwrite an error/success state with the static
    // "Loading connection information" placeholder.
    await refreshDiscoveryPanel();
  } catch (error) {
    hadInitError = true;
    console.error('i18n initialization failed; continuing with embedded HTML.', error);
  }

  try {
    await loadFormats();
  } catch (error) {
    hadInitError = true;
    console.error('format initialization failed; continuing with remaining data.', error);
  }

  try {
    await checkAuth();
  } catch (error) {
    hadInitError = true;
    console.error('authentication initialization failed; continuing in recoverable state.', error);
  }

  try {
    await loadDashboardData();
  } catch (error) {
    hadInitError = true;
    console.error('dashboard initialization failed.', error);
  }

  try {
    const ownMatch = await fetchMyActiveMatch();
    if (ownMatch) {
      selectActiveMatch(ownMatch.id);
      showTab('live');
    }
  } catch (error) {
    hadInitError = true;
    console.error('active-match initialization failed.', error);
  }

  if (hadInitError) showAppInitError();
  else clearAppInitError();
}

initApp().catch(error => showAppInitError(error));
