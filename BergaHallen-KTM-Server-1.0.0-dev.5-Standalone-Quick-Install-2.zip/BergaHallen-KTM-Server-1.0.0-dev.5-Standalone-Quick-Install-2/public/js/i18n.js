import {
  FALLBACK_LOCALE,
  LOCALE_REGISTRY,
  baseLanguage,
  clientSupportedLocales,
  canRenderLocale,
  intlLocaleFor
} from './localeRegistry.js';

const GUEST_STORAGE_KEY = 'bergahallen.locale.guest.v1';
const LEGACY_STORAGE_KEY = 'bergahallen.locale';
const ACCOUNT_STORAGE_PREFIX = 'bergahallen.locale.account.v1';

let locale = FALLBACK_LOCALE;
let messages = LOCALE_REGISTRY[FALLBACK_LOCALE].messages;
let fallbackMessages = LOCALE_REGISTRY[FALLBACK_LOCALE].messages;
let initialized = false;
let serverSupportedLocales = clientSupportedLocales();
let serverFallbackLocale = FALLBACK_LOCALE;
let preferenceState = { mode: 'auto', preferred_locale: null, revision: 0, scope: 'guest' };

function normalizeRenderableLocale(value) {
  const base = baseLanguage(value);
  return base && canRenderLocale(base) ? base : null;
}

function normalizedServerLocales(values) {
  const out = [];
  for (const value of Array.isArray(values) ? values : []) {
    const base = baseLanguage(value);
    if (base && !out.includes(base)) out.push(base);
  }
  return out.length ? out : clientSupportedLocales();
}

export function configureLocaleCapabilities(meta = null) {
  serverSupportedLocales = normalizedServerLocales(meta?.localization?.supported_locales);
  const requestedFallback = baseLanguage(meta?.localization?.fallback_locale);
  serverFallbackLocale = requestedFallback && canRenderLocale(requestedFallback) ? requestedFallback : FALLBACK_LOCALE;
  return {
    serverSupportedLocales: [...serverSupportedLocales],
    clientSupportedLocales: clientSupportedLocales(),
    effectiveSupportedLocales: getEffectiveSupportedLocales(),
    fallbackLocale: serverFallbackLocale
  };
}

export function getEffectiveSupportedLocales() {
  const client = new Set(clientSupportedLocales());
  return serverSupportedLocales.filter(code => client.has(code));
}

function resolveFallbackLocale() {
  return canRenderLocale(serverFallbackLocale) ? serverFallbackLocale : FALLBACK_LOCALE;
}

export function resolveAutoLocale(deviceLocale = (typeof navigator !== 'undefined' ? navigator.language : null)) {
  const candidate = baseLanguage(deviceLocale);
  return candidate && getEffectiveSupportedLocales().includes(candidate) ? candidate : resolveFallbackLocale();
}

export function resolveManualLocale(accountPreference) {
  const candidate = baseLanguage(accountPreference);
  return candidate && getEffectiveSupportedLocales().includes(candidate) ? candidate : resolveFallbackLocale();
}

function loadMessages(targetLocale) {
  return LOCALE_REGISTRY[targetLocale]?.messages || LOCALE_REGISTRY[FALLBACK_LOCALE].messages;
}

function interpolate(text, vars = {}) {
  return String(text).replace(/\{([A-Za-z0-9_]+)\}/g, (_, key) =>
    Object.prototype.hasOwnProperty.call(vars, key) ? String(vars[key]) : `{${key}}`
  );
}

function safeParse(raw) {
  try { return raw ? JSON.parse(raw) : null; } catch (_) { return null; }
}

function normalizedPreference(raw, fallbackMode = 'auto') {
  const mode = raw?.mode === 'manual' ? 'manual' : fallbackMode === 'manual' ? 'manual' : 'auto';
  const preferred = mode === 'manual' ? baseLanguage(raw?.preferred_locale) : null;
  return {
    mode,
    preferred_locale: preferred,
    revision: Math.max(0, Number(raw?.revision || 0))
  };
}

function loadGuestPreference() {
  const current = safeParse(localStorage.getItem(GUEST_STORAGE_KEY));
  if (current?.mode === 'auto' || current?.mode === 'manual') return normalizedPreference(current);

  // The pre-3.9.9.1 key was global and could have been written while any
  // authenticated account was active. It is deliberately NOT migrated into
  // guest state, because that could leak one account's setting into another
  // user's logged-out experience. Account preferences are recovered from the
  // server after authentication; a fresh guest starts in Auto.
  if (localStorage.getItem(LEGACY_STORAGE_KEY) != null) localStorage.removeItem(LEGACY_STORAGE_KEY);
  return { mode: 'auto', preferred_locale: null, revision: 0 };
}

function accountIdentity(user) {
  const uid = String(user?.entity_uid || '').trim();
  if (uid) return `uid:${uid}`;
  const id = Number(user?.id || 0);
  return id > 0 ? `id:${id}` : null;
}

export function accountLocaleStorageKey(instanceUid, user) {
  const instance = String(instanceUid || '').trim();
  const identity = accountIdentity(user);
  return instance && identity ? `${ACCOUNT_STORAGE_PREFIX}:${instance}:${identity}` : null;
}

function persistAccountPreference(instanceUid, user, settings) {
  const key = accountLocaleStorageKey(instanceUid, user);
  if (!key) return;
  localStorage.setItem(key, JSON.stringify({
    version: 1,
    mode: settings.mode,
    preferred_locale: settings.mode === 'manual' ? settings.preferred_locale : null,
    revision: Math.max(0, Number(settings.revision || 0))
  }));
}

export function getCachedAccountLocaleSettings(instanceUid, user) {
  const key = accountLocaleStorageKey(instanceUid, user);
  return key ? safeParse(localStorage.getItem(key)) : null;
}

function effectiveLocaleForPreference(settings) {
  return settings.mode === 'manual'
    ? resolveManualLocale(settings.preferred_locale)
    : resolveAutoLocale();
}

function renderLanguageSelector() {
  const selector = document.getElementById('languageSelector');
  if (!selector) return;
  const effectiveSupported = getEffectiveSupportedLocales();
  const options = [
    { value: 'auto', label: t('language.auto') },
    ...effectiveSupported.map(code => ({ value: code, label: LOCALE_REGISTRY[code]?.nativeName || code }))
  ];

  // Preserve a forward manual account preference even when this client build
  // cannot render it. It is shown read-only and must never be rewritten to en.
  if (preferenceState.mode === 'manual' && preferenceState.preferred_locale
      && !effectiveSupported.includes(preferenceState.preferred_locale)) {
    options.push({
      value: preferenceState.preferred_locale,
      label: t('language.unavailable_manual', { locale: preferenceState.preferred_locale }),
      disabled: true
    });
  }

  selector.innerHTML = options.map(option =>
    `<option value="${String(option.value).replaceAll('&','&amp;').replaceAll('"','&quot;')}"${option.disabled ? ' disabled' : ''}>${String(option.label).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}</option>`
  ).join('');
  selector.value = preferenceState.mode === 'auto' ? 'auto' : preferenceState.preferred_locale || locale;
}

export function getLocale() {
  return locale;
}

export function getLocalePreference() {
  return { ...preferenceState };
}

export function getSupportedLocales() {
  return getEffectiveSupportedLocales();
}

export function t(key, vars = {}, fallback = null) {
  const value = messages[key] ?? fallbackMessages[key] ?? fallback ?? key;
  return interpolate(value, vars);
}

export function hasTranslation(key) {
  return Object.prototype.hasOwnProperty.call(messages, key) || Object.prototype.hasOwnProperty.call(fallbackMessages, key);
}

export function formatDateTime(value, options = {}) {
  if (!value) return '';
  const raw = String(value);
  const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T') + 'Z';
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return raw;
  return new Intl.DateTimeFormat(intlLocaleFor(locale), options).format(date);
}

export function formatNumber(value, options = {}) {
  return new Intl.NumberFormat(intlLocaleFor(locale), options).format(Number(value || 0));
}

export function formatDurationSeconds(value) {
  const total = Math.max(0, Math.floor(Number(value || 0)));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  if (hours > 0) return t('duration.hms', { hours, minutes, seconds });
  if (minutes > 0) return t('duration.ms', { minutes, seconds });
  return t('duration.s', { seconds });
}

export function apiErrorMessage(data, fallbackKey = 'errors.GENERIC') {
  const code = String(data?.code || data?.error || '').trim();
  const codeKey = code && /^[A-Z0-9_]+$/.test(code) ? `errors.${code}` : null;
  if (codeKey && hasTranslation(codeKey)) return t(codeKey);
  return data?.error || data?.message || t(fallbackKey);
}

function setTranslatedAttribute(el, attribute, key) {
  if (!key) return;
  el.setAttribute(attribute, t(key));
}

export function applyTranslations(root = document) {
  root.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  root.querySelectorAll('[data-i18n-html]').forEach(el => {
    el.innerHTML = t(el.dataset.i18nHtml);
  });
  root.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    setTranslatedAttribute(el, 'placeholder', el.dataset.i18nPlaceholder);
  });
  root.querySelectorAll('[data-i18n-title]').forEach(el => {
    setTranslatedAttribute(el, 'title', el.dataset.i18nTitle);
  });
  root.querySelectorAll('[data-i18n-aria-label]').forEach(el => {
    setTranslatedAttribute(el, 'aria-label', el.dataset.i18nAriaLabel);
  });
  root.querySelectorAll('[data-i18n-alt]').forEach(el => {
    setTranslatedAttribute(el, 'alt', el.dataset.i18nAlt);
  });
  document.documentElement.lang = locale;
  renderLanguageSelector();
}

async function setEffectiveLocale(nextLocale, { emit = true } = {}) {
  const normalized = normalizeRenderableLocale(nextLocale) || resolveFallbackLocale();
  if (!initialized || normalized !== locale) {
    messages = loadMessages(normalized);
    locale = normalized;
  }
  applyTranslations(document);
  if (emit) window.dispatchEvent(new CustomEvent('bergahallen:locale-changed', { detail: { locale } }));
  return locale;
}

// Compatibility helper retained for modules/tests from the pre-contract i18n API.
// It only changes the effective locale; preference persistence is handled by the
// explicit guest/account functions below.
export async function setLocale(nextLocale, { persist = false, emit = true } = {}) {
  const normalized = normalizeRenderableLocale(nextLocale) || resolveFallbackLocale();
  if (persist) {
    preferenceState = { mode: 'manual', preferred_locale: normalized, revision: 0, scope: 'guest' };
    localStorage.setItem(GUEST_STORAGE_KEY, JSON.stringify(preferenceState));
  }
  return setEffectiveLocale(normalized, { emit });
}

export async function applyGuestLocalePreference({ emit = false } = {}) {
  const guest = loadGuestPreference();
  preferenceState = { ...guest, scope: 'guest' };
  return setEffectiveLocale(effectiveLocaleForPreference(guest), { emit });
}

export async function setGuestLocalePreference(mode, preferredLocale = null, { emit = true } = {}) {
  const next = mode === 'manual'
    ? { mode: 'manual', preferred_locale: baseLanguage(preferredLocale), revision: 0 }
    : { mode: 'auto', preferred_locale: null, revision: 0 };
  if (next.mode === 'manual' && !getEffectiveSupportedLocales().includes(next.preferred_locale)) {
    next.preferred_locale = resolveFallbackLocale();
  }
  localStorage.setItem(GUEST_STORAGE_KEY, JSON.stringify(next));
  localStorage.removeItem(LEGACY_STORAGE_KEY);
  preferenceState = { ...next, scope: 'guest' };
  return setEffectiveLocale(effectiveLocaleForPreference(next), { emit });
}

export async function applyAccountLocaleSettings(user, instanceUid, settings = null, { emit = false } = {}) {
  const source = settings || user?.locale_settings || null;
  const normalized = source?.version >= 1
    ? normalizedPreference(source, source.mode)
    : { mode: 'manual', preferred_locale: baseLanguage(user?.preferred_locale) || resolveFallbackLocale(), revision: 0 };
  preferenceState = { ...normalized, scope: 'account' };
  persistAccountPreference(instanceUid, user, normalized);
  return setEffectiveLocale(effectiveLocaleForPreference(normalized), { emit });
}

export async function initI18n(meta = null) {
  fallbackMessages = loadMessages(FALLBACK_LOCALE);
  configureLocaleCapabilities(meta);
  initialized = true;
  return applyGuestLocalePreference({ emit: false });
}

export function preferredLocaleFromBrowser() {
  return resolveAutoLocale();
}
