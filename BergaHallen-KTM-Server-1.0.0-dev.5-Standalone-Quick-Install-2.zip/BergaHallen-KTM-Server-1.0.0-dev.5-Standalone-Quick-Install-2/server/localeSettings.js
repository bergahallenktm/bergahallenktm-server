const LOCALE_SETTINGS_VERSION = 1;
const FALLBACK_LOCALE = 'en';
const SUPPORTED_LOCALES = Object.freeze(['en', 'sv']);
// Legacy clients from the pre-3.9.9.1 contract only know these concrete values.
const LEGACY_SAFE_LOCALES = Object.freeze(['en', 'sv']);

function baseLanguage(value) {
  const raw = String(value || '').trim().toLowerCase().replaceAll('_', '-');
  return raw ? raw.split('-')[0] : null;
}

function normalizeSupportedLocale(value) {
  const base = baseLanguage(value);
  return base && SUPPORTED_LOCALES.includes(base) ? base : null;
}

function normalizeLegacyLocale(value) {
  const base = baseLanguage(value);
  return base && LEGACY_SAFE_LOCALES.includes(base) ? base : FALLBACK_LOCALE;
}

function normalizeMode(value) {
  return String(value || '').trim().toLowerCase() === 'auto' ? 'auto' : 'manual';
}

function localeSettingsForPlayer(player) {
  const mode = normalizeMode(player?.locale_mode);
  const revision = Math.max(0, Number(player?.locale_revision || 0));
  const accountPreference = mode === 'manual'
    ? (normalizeSupportedLocale(player?.locale_preference) || normalizeSupportedLocale(player?.preferred_locale) || FALLBACK_LOCALE)
    : null;
  return {
    version: LOCALE_SETTINGS_VERSION,
    mode,
    preferred_locale: accountPreference,
    revision
  };
}

function legacyLocaleForPlayer(player) {
  return normalizeLegacyLocale(player?.preferred_locale);
}

function legacyLocaleForAccountPreference(locale) {
  const normalized = normalizeSupportedLocale(locale);
  return normalized && LEGACY_SAFE_LOCALES.includes(normalized) ? normalized : FALLBACK_LOCALE;
}

function publicLocalizationMetadata() {
  return {
    supported_locales: [...SUPPORTED_LOCALES],
    fallback_locale: FALLBACK_LOCALE,
    auto_detection: 'primary_device_locale_base_language'
  };
}

module.exports = {
  LOCALE_SETTINGS_VERSION,
  FALLBACK_LOCALE,
  SUPPORTED_LOCALES,
  LEGACY_SAFE_LOCALES,
  baseLanguage,
  normalizeSupportedLocale,
  normalizeLegacyLocale,
  normalizeMode,
  localeSettingsForPlayer,
  legacyLocaleForPlayer,
  legacyLocaleForAccountPreference,
  publicLocalizationMetadata
};
