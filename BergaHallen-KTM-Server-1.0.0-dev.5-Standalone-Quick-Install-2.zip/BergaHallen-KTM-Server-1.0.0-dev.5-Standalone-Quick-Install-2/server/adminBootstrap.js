const bcrypt = require('bcryptjs');
const crypto = require('crypto');

function makePassword() {
  return crypto.randomBytes(18).toString('base64url');
}

function availableAdminName(db, preferred) {
  if (!db.prepare('SELECT 1 FROM players WHERE name=? COLLATE NOCASE').get(preferred)) return preferred;
  const base = `${preferred}-superuser`;
  if (!db.prepare('SELECT 1 FROM players WHERE name=? COLLATE NOCASE').get(base)) return base;
  for (let i = 2; i < 1000; i++) {
    const candidate = `${base}-${i}`;
    if (!db.prepare('SELECT 1 FROM players WHERE name=? COLLATE NOCASE').get(candidate)) return candidate;
  }
  throw new Error('Kunde inte hitta ett ledigt namn för superuser-kontot.');
}

function ensureAdminAccount(db) {
  const configuredName = String(process.env.ADMIN_USERNAME || 'admin').trim() || 'admin';
  const configuredPassword = String(process.env.ADMIN_PASSWORD || '');
  const existingAdmin = db.prepare('SELECT * FROM players WHERE is_admin=1 AND archived=0 ORDER BY id LIMIT 1').get();

  if (existingAdmin) {
    // ADMIN_PASSWORD fungerar som återställningsväg om superuser-lösenordet
    // glömts. Hashen skrivs bara om när lösenordet faktiskt skiljer sig.
    if (configuredPassword && existingAdmin.name.toLowerCase() === configuredName.toLowerCase()
        && !bcrypt.compareSync(configuredPassword, existingAdmin.password_hash || '')) {
      db.prepare('UPDATE players SET password_hash=?,auth_revision=auth_revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?')
        .run(bcrypt.hashSync(configuredPassword, 12), existingAdmin.id);
      console.log(`🛡️ ADMIN: lösenordet för "${existingAdmin.name}" uppdaterades från ADMIN_PASSWORD.`);
    }
    return { id: existingAdmin.id, name: existingAdmin.name };
  }

  const nameCollision = db.prepare('SELECT * FROM players WHERE name=? COLLATE NOCASE').get(configuredName);
  const initialPassword = configuredPassword || makePassword();
  const hash = bcrypt.hashSync(initialPassword, 12);
  let admin;

  if (nameCollision && configuredPassword) {
    // Att främja ett befintligt konto kräver ett uttryckligt ADMIN_PASSWORD.
    // Vi gör det aldrig automatiskt bara för att någon råkar heta "admin".
    db.prepare(`
      UPDATE players
      SET is_admin=1,archived=0,archived_at=NULL,password_hash=?,
          auth_revision=auth_revision+1,updated_at=CURRENT_TIMESTAMP,sync_revision=?
      WHERE id=?
    `).run(hash, db.nextSyncRevision('players'), nameCollision.id);
    admin = { id: nameCollision.id, name: nameCollision.name };
  } else {
    const safeName = availableAdminName(db, configuredName);
    const info = db.prepare(`
      INSERT INTO players
        (name,password_hash,card_link_preference,preferred_locale,locale_mode,locale_preference,locale_revision,
         is_admin,archived,auth_revision,created_at,updated_at,sync_revision)
      VALUES (?,?,'scryfall','en','auto',NULL,0,1,0,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?)
    `).run(safeName, hash, db.nextSyncRevision('players'));
    admin = { id: Number(info.lastInsertRowid), name: safeName };
  }

  if (configuredPassword) {
    console.log(`🛡️ ADMIN: superuser "${admin.name}" är klar. Lösenord hämtades från ADMIN_PASSWORD.`);
  } else {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`🛡️ ADMIN: första superuser-kontot skapades: ${admin.name}`);
    console.log(`🔑 ADMIN: engångsvis initialt lösenord: ${initialPassword}`);
    console.log('   Logga in och byt lösenordet från Admin-fliken.');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  }
  return admin;
}

module.exports = { ensureAdminAccount };
