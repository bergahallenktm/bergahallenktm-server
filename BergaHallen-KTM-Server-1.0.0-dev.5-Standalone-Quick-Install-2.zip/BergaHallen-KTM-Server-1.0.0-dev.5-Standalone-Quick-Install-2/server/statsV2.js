const db = require('./db');

const MAX_FILTER_VALUE = 160;

function formatDuration(seconds) {
  if (seconds === null || seconds === undefined || Number(seconds) < 0) return '0s';
  const value = Math.max(0, Math.round(Number(seconds) || 0));
  const hours = Math.floor(value / 3600);
  const mins = Math.floor((value % 3600) / 60);
  const secs = value % 60;
  if (hours > 0) return `${hours}h ${mins}m ${secs}s`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

function cleanText(value) {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  if (!text) return null;
  return text.slice(0, MAX_FILTER_VALUE);
}

function normalizeDate(value, endOfDay = false) {
  const text = cleanText(value);
  if (!text) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return `${text} ${endOfDay ? '23:59:59' : '00:00:00'}`;
  const parsed = new Date(text);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed.toISOString().slice(0, 19).replace('T', ' ');
}

function parseStatsFilters(query = {}) {
  return {
    from: normalizeDate(query.from, false),
    to: normalizeDate(query.to, true),
    player_uid: cleanText(query.player_uid),
    deck_uid: cleanText(query.deck_uid),
    match_profile: cleanText(query.match_profile),
    deck_format: cleanText(query.deck_format),
    play_mode: cleanText(query.play_mode),
    limited_format: cleanText(query.limited_format),
    modifier: cleanText(query.modifier),
    team_mode: cleanText(query.team_mode)
  };
}

function publicFilters(filters) {
  return Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== null));
}

function buildWhere(filters, alias = 'm') {
  const where = [`${alias}.status='completed'`];
  const params = [];
  if (filters.from) { where.push(`${alias}.started_at >= ?`); params.push(filters.from); }
  if (filters.to) { where.push(`${alias}.started_at <= ?`); params.push(filters.to); }
  for (const key of ['match_profile','deck_format','play_mode','limited_format','team_mode']) {
    if (filters[key]) { where.push(`${alias}.${key} = ?`); params.push(filters[key]); }
  }
  if (filters.modifier) {
    where.push(`${alias}.modifiers_json LIKE ?`);
    params.push(`%\"${filters.modifier.replace(/[\"%_]/g, '')}\"%`);
  }
  if (filters.player_uid) {
    where.push(`EXISTS (SELECT 1 FROM match_players filter_player WHERE filter_player.match_id=${alias}.id AND filter_player.player_uid=?)`);
    params.push(filters.player_uid);
  }
  if (filters.deck_uid) {
    where.push(`EXISTS (SELECT 1 FROM match_players filter_deck WHERE filter_deck.match_id=${alias}.id AND filter_deck.deck_uid=?)`);
    params.push(filters.deck_uid);
  }
  return { sql: where.join(' AND '), params };
}

function hasActiveFilters(filters) {
  return Object.values(filters).some(Boolean);
}

function summary(filters) {
  const { sql, params } = buildWhere(filters);
  const row = db.prepare(`
    SELECT
      COUNT(*) AS total_matches,
      COALESCE(SUM((SELECT COUNT(*) FROM match_players mp WHERE mp.match_id=m.id)),0) AS participant_entries,
      ROUND(AVG(CASE WHEN m.ended_at IS NOT NULL THEN (julianday(m.ended_at)-julianday(m.started_at))*86400 END)) AS avg_seconds,
      MIN(CASE WHEN m.ended_at IS NOT NULL THEN CAST((julianday(m.ended_at)-julianday(m.started_at))*86400 AS INTEGER) END) AS shortest_seconds,
      MAX(CASE WHEN m.ended_at IS NOT NULL THEN CAST((julianday(m.ended_at)-julianday(m.started_at))*86400 AS INTEGER) END) AS longest_seconds,
      MIN(m.started_at) AS first_match_at,
      MAX(m.started_at) AS latest_match_at
    FROM matches m
    WHERE ${sql}
  `).get(...params);

  const playerRow = db.prepare(`
    SELECT COUNT(DISTINCT mp.player_uid) AS distinct_players,
           COUNT(DISTINCT mp.deck_uid) AS distinct_decks
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id
    WHERE ${sql}
  `).get(...params);

  return {
    total_matches: Number(row?.total_matches || 0),
    participant_entries: Number(row?.participant_entries || 0),
    distinct_players: Number(playerRow?.distinct_players || 0),
    distinct_decks: Number(playerRow?.distinct_decks || 0),
    avg_seconds: row?.avg_seconds == null ? null : Number(row.avg_seconds),
    avg_game_length: formatDuration(row?.avg_seconds),
    shortest_seconds: row?.shortest_seconds == null ? null : Number(row.shortest_seconds),
    longest_seconds: row?.longest_seconds == null ? null : Number(row.longest_seconds),
    first_match_at: row?.first_match_at || null,
    latest_match_at: row?.latest_match_at || null
  };
}

function bestDeckForPlayerUid(playerUid, filters) {
  const { sql, params } = buildWhere(filters);
  const row = db.prepare(`
    SELECT
      mp.deck_uid,
      COALESCE(MAX(d.name),MAX(mp.deck_name_snapshot),'Raderad kortlek') AS name,
      CASE WHEN MAX(d.id) IS NULL THEN 1 ELSE 0 END AS deleted,
      COUNT(*) AS games,
      COALESCE(SUM(mp.is_winner),0) AS wins,
      ROUND(CAST(COALESCE(SUM(mp.is_winner),0) AS FLOAT)/MAX(COUNT(*),1)*100,1) AS win_rate
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id
    LEFT JOIN decks d ON d.entity_uid=mp.deck_uid
    WHERE ${sql} AND mp.player_uid=? AND mp.deck_uid IS NOT NULL
    GROUP BY mp.deck_uid
    ORDER BY win_rate DESC,wins DESC,games DESC, name COLLATE NOCASE
    LIMIT 1
  `).get(...params, playerUid);
  if (!row || Number(row.games || 0) <= 0) return null;
  return { name: row.name, deleted: !!row.deleted, win_rate: Number(row.win_rate || 0) };
}

function players(filters) {
  const { sql, params } = buildWhere(filters);
  const rows = db.prepare(`
    SELECT
      mp.player_uid AS uid,
      MAX(p.id) AS id,
      COALESCE(MAX(p.name),MAX(mp.player_name_snapshot),'Raderad spelare') AS name,
      CASE WHEN MAX(p.id) IS NULL THEN 1 ELSE 0 END AS deleted,
      COALESCE(MAX(p.archived),0) AS archived,
      COUNT(*) AS total_games,
      COALESCE(SUM(mp.is_winner),0) AS wins,
      COUNT(*)-COALESCE(SUM(mp.is_winner),0) AS losses,
      ROUND(CAST(COALESCE(SUM(mp.is_winner),0) AS FLOAT)/MAX(COUNT(*),1)*100,1) AS win_rate
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id
    LEFT JOIN players p ON p.entity_uid=mp.player_uid
    WHERE ${sql} AND mp.player_uid IS NOT NULL
    GROUP BY mp.player_uid
  `).all(...params);

  const map = new Map(rows.map(row => [row.uid, row]));
  if (!hasActiveFilters(filters)) {
    const current = db.prepare(`SELECT id,entity_uid AS uid,name,archived FROM players WHERE is_admin=0 ORDER BY name COLLATE NOCASE`).all();
    for (const p of current) {
      const existing = map.get(p.uid);
      if (existing) Object.assign(existing, { id:p.id, name:p.name, deleted:0, archived:Number(p.archived || 0) });
      else map.set(p.uid, { ...p, deleted:0, archived:Number(p.archived || 0), total_games:0, wins:0, losses:0, win_rate:0 });
    }
  }

  return [...map.values()].map(row => {
    const best = Number(row.total_games || 0) > 0 ? bestDeckForPlayerUid(row.uid, filters) : null;
    return {
      ...row,
      total_games:Number(row.total_games || 0), wins:Number(row.wins || 0), losses:Number(row.losses || 0), win_rate:Number(row.win_rate || 0),
      best_deck: best ? `${best.name}${best.deleted ? ' · raderad' : ''} (${best.win_rate}%)` : 'Inga matcher',
      best_deck_name: best?.name || null,
      best_deck_deleted: !!best?.deleted,
      best_deck_win_rate: best?.win_rate ?? null
    };
  }).sort((a,b) => b.wins-a.wins || b.total_games-a.total_games || String(a.name).localeCompare(String(b.name)));
}

function decks(filters) {
  const { sql, params } = buildWhere(filters);
  const rows = db.prepare(`
    SELECT
      mp.deck_uid AS uid,
      MAX(d.id) AS id,
      COALESCE(MAX(d.name),MAX(mp.deck_name_snapshot),'Raderad kortlek') AS deck_name,
      COALESCE(MAX(owner.name),MAX(mp.deck_owner_name_snapshot),'Raderad spelare') AS owner_name,
      CASE WHEN MAX(d.id) IS NULL THEN 1 ELSE 0 END AS deleted,
      COALESCE(MAX(d.archived),0) AS archived,
      COUNT(*) AS total_games,
      COALESCE(SUM(mp.is_winner),0) AS wins,
      COUNT(*)-COALESCE(SUM(mp.is_winner),0) AS losses,
      ROUND(CAST(COALESCE(SUM(mp.is_winner),0) AS FLOAT)/MAX(COUNT(*),1)*100,1) AS win_rate,
      ROUND(AVG(CASE WHEN m.ended_at IS NOT NULL THEN (julianday(m.ended_at)-julianday(m.started_at))*86400 END)) AS avg_seconds
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id
    LEFT JOIN decks d ON d.entity_uid=mp.deck_uid
    LEFT JOIN players owner ON owner.id=d.owner_id
    WHERE ${sql} AND mp.deck_uid IS NOT NULL
    GROUP BY mp.deck_uid
  `).all(...params);

  const map = new Map(rows.map(row => [row.uid, row]));
  if (!hasActiveFilters(filters)) {
    const current = db.prepare(`
      SELECT d.id,d.entity_uid AS uid,d.name AS deck_name,d.archived,p.name AS owner_name
      FROM decks d JOIN players p ON p.id=d.owner_id WHERE p.is_admin=0
    `).all();
    for (const d of current) {
      const existing = map.get(d.uid);
      if (existing) Object.assign(existing, { id:d.id, deck_name:d.deck_name, owner_name:d.owner_name, deleted:0, archived:Number(d.archived || 0) });
      else map.set(d.uid, { ...d, deleted:0, archived:Number(d.archived || 0), total_games:0,wins:0,losses:0,win_rate:0,avg_seconds:null });
    }
  }
  return [...map.values()].map(row => ({
    ...row,
    total_games:Number(row.total_games || 0), wins:Number(row.wins || 0), losses:Number(row.losses || 0), win_rate:Number(row.win_rate || 0),
    avg_seconds: row.avg_seconds == null ? null : Number(row.avg_seconds),
    avg_game_length: formatDuration(row.avg_seconds)
  })).sort((a,b) => b.wins-a.wins || b.total_games-a.total_games || String(a.deck_name).localeCompare(String(b.deck_name)));
}

function playerDecks(filters) {
  const { sql, params } = buildWhere(filters);
  return db.prepare(`
    SELECT
      mp.player_uid,
      COALESCE(MAX(p.name),MAX(mp.player_name_snapshot),'Raderad spelare') AS player_name,
      CASE WHEN MAX(p.id) IS NULL THEN 1 ELSE 0 END AS player_deleted,
      mp.deck_uid,
      COALESCE(MAX(d.name),MAX(mp.deck_name_snapshot),'Raderad kortlek') AS deck_name,
      CASE WHEN MAX(d.id) IS NULL THEN 1 ELSE 0 END AS deck_deleted,
      COALESCE(MAX(owner.name),MAX(mp.deck_owner_name_snapshot),'Raderad spelare') AS deck_owner_name,
      COUNT(*) AS total_games,
      COALESCE(SUM(mp.is_winner),0) AS wins,
      COUNT(*)-COALESCE(SUM(mp.is_winner),0) AS losses,
      ROUND(CAST(COALESCE(SUM(mp.is_winner),0) AS FLOAT)/MAX(COUNT(*),1)*100,1) AS win_rate
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id
    LEFT JOIN players p ON p.entity_uid=mp.player_uid
    LEFT JOIN decks d ON d.entity_uid=mp.deck_uid
    LEFT JOIN players owner ON owner.id=d.owner_id
    WHERE ${sql} AND mp.player_uid IS NOT NULL AND mp.deck_uid IS NOT NULL
    GROUP BY mp.player_uid,mp.deck_uid
    ORDER BY wins DESC,total_games DESC,player_name COLLATE NOCASE,deck_name COLLATE NOCASE
  `).all(...params).map(row => ({ ...row, total_games:Number(row.total_games||0), wins:Number(row.wins||0), losses:Number(row.losses||0), win_rate:Number(row.win_rate||0) }));
}

function playModes(filters) {
  const { sql, params } = buildWhere(filters);
  const rows = db.prepare(`
    SELECT COALESCE(NULLIF(TRIM(m.play_mode),''),CASE WHEN m.team_mode='teams' THEN 'teams' ELSE 'ffa' END) AS play_mode,
           CASE WHEN m.team_mode='teams' THEN 'teams' ELSE 'ffa' END AS team_mode,
           COUNT(*) AS total_matches
    FROM matches m WHERE ${sql}
    GROUP BY COALESCE(NULLIF(TRIM(m.play_mode),''),CASE WHEN m.team_mode='teams' THEN 'teams' ELSE 'ffa' END)
    ORDER BY total_matches DESC,play_mode COLLATE NOCASE
  `).all(...params);
  const total = rows.reduce((sum,row)=>sum+Number(row.total_matches||0),0);
  return rows.map(row => ({ play_mode:row.play_mode, team_mode:row.team_mode, total_matches:Number(row.total_matches||0), share_percent: total ? Math.round(Number(row.total_matches||0)/total*1000)/10 : 0 }));
}

function formats(filters) {
  const { sql, params } = buildWhere(filters);
  const total = db.prepare(`SELECT COUNT(*) AS count FROM matches m WHERE ${sql}`).get(...params)?.count || 0;
  const profileRows = db.prepare(`SELECT COALESCE(NULLIF(TRIM(m.match_profile),''),'legacy') AS match_profile,COUNT(*) AS total_matches FROM matches m WHERE ${sql} GROUP BY COALESCE(NULLIF(TRIM(m.match_profile),''),'legacy') ORDER BY total_matches DESC`).all(...params);
  const deckRows = db.prepare(`SELECT COALESCE(NULLIF(TRIM(m.deck_format),''),NULLIF(TRIM(m.match_type),''),'legacy') AS deck_format,COUNT(*) AS total_matches FROM matches m WHERE ${sql} GROUP BY COALESCE(NULLIF(TRIM(m.deck_format),''),NULLIF(TRIM(m.match_type),''),'legacy') ORDER BY total_matches DESC`).all(...params);
  const identityRows = db.prepare(`SELECT m.limited_format,m.modifiers_json FROM matches m WHERE ${sql}`).all(...params);
  const limited = new Map();
  const modifiers = new Map();
  for (const row of identityRows) {
    const limitedKey = String(row.limited_format || '').trim();
    if (limitedKey) limited.set(limitedKey,(limited.get(limitedKey)||0)+1);
    let mods=[]; try { mods=JSON.parse(row.modifiers_json||'[]'); } catch (_) { mods=[]; }
    if (Array.isArray(mods)) for (const key of new Set(mods.filter(Boolean).map(String))) modifiers.set(key,(modifiers.get(key)||0)+1);
  }
  const withShare = (rows,key) => rows.map(row => ({ ...row, [key]:row[key], total_matches:Number(row.total_matches||0), share_percent: total ? Math.round(Number(row.total_matches||0)/Number(total)*1000)/10 : 0 }));
  return {
    matchProfileStats: withShare(profileRows,'match_profile'),
    deckFormatStats: withShare(deckRows,'deck_format'),
    limitedFormatStats: [...limited.entries()].map(([limited_format,total_matches])=>({ limited_format,total_matches,share_percent:total?Math.round(total_matches/Number(total)*1000)/10:0 })).sort((a,b)=>b.total_matches-a.total_matches),
    modifierStats: [...modifiers.entries()].map(([modifier,total_matches])=>({ modifier,total_matches,share_percent:total?Math.round(total_matches/Number(total)*1000)/10:0 })).sort((a,b)=>b.total_matches-a.total_matches)
  };
}

function matchups(filters) {
  const { sql, params } = buildWhere(filters);
  const raw = db.prepare(`
    SELECT mp1.deck_uid AS deck1_uid,
           COALESCE(d1.name,mp1.deck_name_snapshot,'Raderad kortlek') AS deck1_name,
           CASE WHEN d1.id IS NULL THEN 1 ELSE 0 END AS deck1_deleted,
           mp2.deck_uid AS deck2_uid,
           COALESCE(d2.name,mp2.deck_name_snapshot,'Raderad kortlek') AS deck2_name,
           CASE WHEN d2.id IS NULL THEN 1 ELSE 0 END AS deck2_deleted,
           mp1.is_winner AS deck1_won,mp2.is_winner AS deck2_won,
           mp1.team_number AS deck1_team,mp2.team_number AS deck2_team
    FROM match_players mp1
    JOIN match_players mp2 ON mp1.match_id=mp2.match_id AND mp1.id<mp2.id
    JOIN matches m ON m.id=mp1.match_id
    LEFT JOIN decks d1 ON d1.entity_uid=mp1.deck_uid
    LEFT JOIN decks d2 ON d2.entity_uid=mp2.deck_uid
    WHERE ${sql} AND mp1.deck_uid IS NOT NULL AND mp2.deck_uid IS NOT NULL
  `).all(...params);
  const map = new Map();
  for (const row of raw) {
    if (Number(row.deck1_team) === Number(row.deck2_team)) continue;
    let left={uid:row.deck1_uid,name:row.deck1_name,deleted:!!row.deck1_deleted,won:!!row.deck1_won};
    let right={uid:row.deck2_uid,name:row.deck2_name,deleted:!!row.deck2_deleted,won:!!row.deck2_won};
    if (String(left.uid).localeCompare(String(right.uid)) > 0) [left,right]=[right,left];
    const key=`${left.uid}:${right.uid}`;
    if (!map.has(key)) map.set(key,{ deck1_uid:left.uid,deck2_uid:right.uid,deck1:left.name,deck2:right.name,deck1_deleted:left.deleted,deck2_deleted:right.deleted,total:0,deck1_wins:0,deck2_wins:0,neither_won:0 });
    const item=map.get(key); item.total++;
    if (left.won&&!right.won) item.deck1_wins++; else if (right.won&&!left.won) item.deck2_wins++; else item.neither_won++;
  }
  return [...map.values()].sort((a,b)=>b.total-a.total || a.deck1.localeCompare(b.deck1));
}


function dayNight(filters) {
  const { sql, params } = buildWhere(filters);
  const row = db.prepare(`
    SELECT
      COUNT(DISTINCT CASE WHEN e.id IS NOT NULL THEN m.id END) AS matches_with_day_night,
      COUNT(e.id) AS total_events,
      COALESCE(SUM(CASE WHEN e.prev_value=0 AND e.new_value IN (1,2) THEN 1 ELSE 0 END),0) AS establishments,
      COALESCE(SUM(CASE WHEN e.prev_value=1 AND e.new_value=2 THEN 1 ELSE 0 END),0) AS day_to_night,
      COALESCE(SUM(CASE WHEN e.prev_value=2 AND e.new_value=1 THEN 1 ELSE 0 END),0) AS night_to_day,
      COALESCE(SUM(CASE WHEN (e.prev_value=1 AND e.new_value=2) OR (e.prev_value=2 AND e.new_value=1) THEN 1 ELSE 0 END),0) AS switches,
      COALESCE(SUM(CASE WHEN m.day_night_state='day' THEN 1 ELSE 0 END),0) AS event_rows_in_final_day,
      COALESCE(SUM(CASE WHEN m.day_night_state='night' THEN 1 ELSE 0 END),0) AS event_rows_in_final_night
    FROM matches m
    LEFT JOIN match_events e ON e.match_id=m.id AND e.event_type='DAY_NIGHT_CHANGE'
    WHERE ${sql}
  `).get(...params);

  const finalRows = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN m.day_night_state='day' THEN 1 ELSE 0 END),0) AS final_day_matches,
      COALESCE(SUM(CASE WHEN m.day_night_state='night' THEN 1 ELSE 0 END),0) AS final_night_matches,
      COALESCE(SUM(CASE WHEN m.day_night_state IN ('day','night') THEN 1 ELSE 0 END),0) AS matches_ending_with_designation
    FROM matches m
    WHERE ${sql}
  `).get(...params);

  const perMatch = db.prepare(`
    SELECT m.id,
           m.table_name,
           m.started_at,
           COUNT(e.id) AS total_events,
           COALESCE(SUM(CASE WHEN (e.prev_value=1 AND e.new_value=2) OR (e.prev_value=2 AND e.new_value=1) THEN 1 ELSE 0 END),0) AS switches
    FROM matches m
    JOIN match_events e ON e.match_id=m.id AND e.event_type='DAY_NIGHT_CHANGE'
    WHERE ${sql}
    GROUP BY m.id
    ORDER BY switches DESC,total_events DESC,m.started_at DESC,m.id DESC
    LIMIT 1
  `).get(...params);

  const switches = Number(row?.switches || 0);
  const trackedMatches = Number(row?.matches_with_day_night || 0);
  return {
    contract_version: 1,
    matches_with_day_night: trackedMatches,
    total_events: Number(row?.total_events || 0),
    establishments: Number(row?.establishments || 0),
    switches,
    day_to_night: Number(row?.day_to_night || 0),
    night_to_day: Number(row?.night_to_day || 0),
    final_day_matches: Number(finalRows?.final_day_matches || 0),
    final_night_matches: Number(finalRows?.final_night_matches || 0),
    matches_ending_with_designation: Number(finalRows?.matches_ending_with_designation || 0),
    avg_switches_per_tracked_match: trackedMatches ? Math.round((switches / trackedMatches) * 100) / 100 : 0,
    most_switches_match: perMatch ? {
      match_id: Number(perMatch.id),
      table_name: perMatch.table_name || null,
      started_at: perMatch.started_at || null,
      switches: Number(perMatch.switches || 0),
      total_events: Number(perMatch.total_events || 0)
    } : null
  };
}

function trend(filters) {
  const { sql, params } = buildWhere(filters);
  return db.prepare(`
    SELECT substr(m.started_at,1,7) AS period,COUNT(*) AS total_matches,
           ROUND(AVG(CASE WHEN m.ended_at IS NOT NULL THEN (julianday(m.ended_at)-julianday(m.started_at))*86400 END)) AS avg_seconds
    FROM matches m WHERE ${sql}
    GROUP BY substr(m.started_at,1,7)
    ORDER BY period ASC
  `).all(...params).map(row => ({ period:row.period,total_matches:Number(row.total_matches||0),avg_seconds:row.avg_seconds==null?null:Number(row.avg_seconds) }));
}

function buildStatsV2(filters) {
  const formatSections = formats(filters);
  return {
    contract_version: 5,
    filters: publicFilters(filters),
    summary: summary(filters),
    playerStats: players(filters),
    deckStats: decks(filters),
    playerDeckStats: playerDecks(filters),
    playModeStats: playModes(filters),
    ...formatSections,
    matchups: matchups(filters),
    dayNightStats: dayNight(filters),
    trendStats: trend(filters)
  };
}

module.exports = {
  parseStatsFilters,
  publicFilters,
  buildWhere,
  buildStatsV2,
  summary,
  players,
  decks,
  playerDecks,
  playModes,
  formats,
  matchups,
  dayNight,
  trend
};
