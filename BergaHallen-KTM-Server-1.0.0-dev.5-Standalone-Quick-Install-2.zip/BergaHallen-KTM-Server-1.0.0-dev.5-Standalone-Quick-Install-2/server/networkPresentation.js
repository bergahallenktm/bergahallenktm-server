function localAddresses(port, { tlsRuntime = null, networkInterfaces = {} } = {}) {
  // Production Server Mode is HTTPS/IP-first. The container's diagnostic
  // HTTP listener is loopback-only and must never be presented as a LAN URL.
  // Installer TLS State is the authoritative source for the production URL.
  if (tlsRuntime?.httpsRequired && tlsRuntime.canonicalHttpsUrl) {
    return [String(tlsRuntime.canonicalHttpsUrl)];
  }

  // Cleartext addresses are useful only in explicit development mode.
  const values = [];
  for (const rows of Object.values(networkInterfaces || {})) {
    for (const row of rows || []) {
      if (row.family !== 'IPv4' || row.internal) continue;
      values.push(`http://${row.address}:${port}`);
    }
  }
  return [...new Set(values)];
}

module.exports = { localAddresses };
