const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const dataDir = process.env.BERGAHALLEN_DATA_DIR ? path.resolve(process.env.BERGAHALLEN_DATA_DIR) : path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, 'mtg_tracker_v7.db');
const db = new Database(dbPath);

db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');

// Grundschema för nya installationer. Befintliga installationer uppgraderas
// därefter via de versionsstyrda migreringarna längre ned i filen.
db.exec(`
  CREATE TABLE IF NOT EXISTS players (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    password_hash TEXT,
    card_link_preference TEXT DEFAULT 'scryfall',
    is_admin INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0,
    archived_at DATETIME,
    auth_revision INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    sync_revision INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS decks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    format TEXT DEFAULT 'Commander',
    decklist TEXT,
    archived INTEGER NOT NULL DEFAULT 0,
    archived_at DATETIME,
    client_uid TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    sync_revision INTEGER NOT NULL DEFAULT 0,
    color_identity TEXT,
    FOREIGN KEY (owner_id) REFERENCES players(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_type TEXT NOT NULL,
    team_mode TEXT NOT NULL DEFAULT 'ffa',
    table_name TEXT,
    status TEXT DEFAULT 'completed',
    current_round INTEGER DEFAULT 1,
    active_player_index INTEGER DEFAULT 0,
    timer_seconds INTEGER DEFAULT 0,
    turn_started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME
  );

  CREATE TABLE IF NOT EXISTS match_players (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL,
    player_id INTEGER NOT NULL,
    deck_id INTEGER NOT NULL,
    seat_index INTEGER DEFAULT 0,
    team_number INTEGER DEFAULT 1,
    initial_life INTEGER DEFAULT 40,
    current_life INTEGER DEFAULT 40,
    poison_counters INTEGER DEFAULT 0,
    commander_tax INTEGER DEFAULT 0,
    is_eliminated INTEGER DEFAULT 0,
    eliminated_reason TEXT,
    is_winner INTEGER NOT NULL DEFAULT 0,
    commander_damage TEXT DEFAULT '{}',
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES players(id),
    FOREIGN KEY (deck_id) REFERENCES decks(id),
    UNIQUE(match_id, player_id)
  );

  CREATE TABLE IF NOT EXISTS match_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL,
    player_id INTEGER,
    related_player_id INTEGER,
    event_type TEXT NOT NULL,
    change_value INTEGER NOT NULL,
    prev_value INTEGER NOT NULL,
    new_value INTEGER NOT NULL,
    round_number INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES players(id),
    FOREIGN KEY (related_player_id) REFERENCES players(id)
  );

  CREATE TABLE IF NOT EXISTS sync_state (
    scope TEXT PRIMARY KEY,
    revision INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE INDEX IF NOT EXISTS idx_match_players_match_id ON match_players(match_id);
  CREATE INDEX IF NOT EXISTS idx_match_players_player_id ON match_players(player_id);
  CREATE INDEX IF NOT EXISTS idx_match_players_deck_id ON match_players(deck_id);
  CREATE INDEX IF NOT EXISTS idx_match_events_match_id ON match_events(match_id);
  CREATE INDEX IF NOT EXISTS idx_decks_owner_id ON decks(owner_id);
  CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
`);

function hasColumn(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some(c => c.name === column);
}

function ensureColumn(table, column, definition) {
  if (!hasColumn(table, column)) {
    console.log(`🔧 Migrering: lägger till kolumn ${table}.${column}`);
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

function migrationApplied(version) {
  return !!db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?').get(version);
}

function logMigrationFailure(version, name, err) {
  const code = err?.code ? ` [${err.code}]` : '';
  const message = err?.message || String(err);
  console.error(`❌ Databasmigrering v${version} (${name}) misslyckades${code}: ${message}`);
}

function applyMigration(version, name, migrate) {
  if (migrationApplied(version)) return;

  console.log(`🔧 Databasmigrering v${version}: ${name}`);
  const tx = db.transaction(() => {
    migrate();
    db.prepare('INSERT INTO schema_migrations (version, name) VALUES (?, ?)').run(version, name);
  });
  try {
    tx();
  } catch (err) {
    logMigrationFailure(version, name, err);
    throw err;
  }
}

function quoteSqlIdentifier(value) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

// Table rebuilds måste explicit ta hand om schemaobjekt som försvinner med
// parent-tabellen eller vars SQL-body refererar till tabellen. Det är särskilt
// viktigt för trg_match_players_identity_snapshot, som läser från decks trots
// att triggern själv tillhör match_players.
function captureTableRebuildDependencies(tableName) {
  const token = `%${String(tableName).toLowerCase()}%`;
  return db.prepare(`
    SELECT type,name,tbl_name,sql
      FROM sqlite_master
     WHERE sql IS NOT NULL
       AND name NOT LIKE 'sqlite_%'
       AND (
         (type='index' AND tbl_name=?)
         OR (type IN ('trigger','view') AND lower(sql) LIKE ?)
       )
     ORDER BY CASE type WHEN 'trigger' THEN 1 WHEN 'view' THEN 2 WHEN 'index' THEN 3 ELSE 4 END,
              name
  `).all(tableName, token);
}

function dropTableRebuildDependencies(objects) {
  for (const object of objects.filter(item => item.type === 'trigger')) {
    db.exec(`DROP TRIGGER IF EXISTS ${quoteSqlIdentifier(object.name)}`);
  }
  for (const object of objects.filter(item => item.type === 'view')) {
    db.exec(`DROP VIEW IF EXISTS ${quoteSqlIdentifier(object.name)}`);
  }
  for (const object of objects.filter(item => item.type === 'index')) {
    db.exec(`DROP INDEX IF EXISTS ${quoteSqlIdentifier(object.name)}`);
  }
}

function recreateTableRebuildDependencies(objects) {
  // Indexer skapas först på den nya tabellen, därefter views och sist triggers.
  // Triggers på views behöver då att viewn redan finns.
  for (const type of ['index','view','trigger']) {
    for (const object of objects.filter(item => item.type === type)) {
      db.exec(object.sql);
    }
  }
}

// SQLite kan inte ta bort en table-level UNIQUE-constraint med DROP INDEX.
// Migrationer som måste bygga om en refererad parent-tabell körs därför med
// foreign_keys tillfälligt avstängt UTANFÖR transaktionen. All DDL/data-copy,
// dependency restore, foreign_key_check och schema-version commit ligger i samma
// transaktion. Vid fel förblir source schema/data intakt och processen kastar
// vidare felet så server-start avslutas non-zero innan HTTP health kan bli ready.
function applyForeignKeyRebuildMigration(version, name, migrate) {
  if (migrationApplied(version)) return;

  console.log(`🔧 Databasmigrering v${version}: ${name}`);
  db.pragma('foreign_keys = OFF');
  try {
    const tx = db.transaction(() => {
      migrate();
      const violations = db.prepare('PRAGMA foreign_key_check').all();
      if (violations.length) {
        const err = new Error(`Foreign-key-kontroll misslyckades efter migrering v${version}.`);
        err.code = 'FOREIGN_KEY_CHECK_FAILED';
        err.violations = violations;
        throw err;
      }
      db.prepare('INSERT INTO schema_migrations (version, name) VALUES (?, ?)').run(version, name);
    });
    try {
      tx();
    } catch (err) {
      logMigrationFailure(version, name, err);
      throw err;
    }
  } finally {
    db.pragma('foreign_keys = ON');
  }
}

// OBS: migreringarna är avsiktligt idempotenta. Det gör att även databaser som
// tidigare har uppgraderats av de äldre startup-migreringarna kan tas över av
// det versionsstyrda systemet utan att data behöver återskapas.
const hadTeamNumberBeforeMigration = hasColumn('match_players', 'team_number');

applyMigration(1, 'legacy-schema-baseline', () => {
  ensureColumn('players', 'password_hash', 'TEXT');
  ensureColumn('players', 'card_link_preference', "TEXT DEFAULT 'scryfall'");
  ensureColumn('decks', 'format', "TEXT DEFAULT 'Commander'");
  ensureColumn('decks', 'decklist', 'TEXT');
  ensureColumn('matches', 'table_name', 'TEXT');
  ensureColumn('matches', 'status', "TEXT DEFAULT 'completed'");
  ensureColumn('matches', 'current_round', 'INTEGER DEFAULT 1');
  ensureColumn('matches', 'active_player_index', 'INTEGER DEFAULT 0');
  ensureColumn('matches', 'timer_seconds', 'INTEGER DEFAULT 0');
  ensureColumn('matches', 'turn_started_at', 'DATETIME');
  ensureColumn('matches', 'ended_at', 'DATETIME');
  ensureColumn('match_players', 'seat_index', 'INTEGER DEFAULT 0');
  ensureColumn('match_players', 'team_number', 'INTEGER DEFAULT 1');
  ensureColumn('match_players', 'initial_life', 'INTEGER DEFAULT 40');
  ensureColumn('match_players', 'current_life', 'INTEGER DEFAULT 40');
  ensureColumn('match_players', 'poison_counters', 'INTEGER DEFAULT 0');
  ensureColumn('match_players', 'commander_tax', 'INTEGER DEFAULT 0');
  ensureColumn('match_players', 'is_eliminated', 'INTEGER DEFAULT 0');
  ensureColumn('match_players', 'eliminated_reason', 'TEXT');
  ensureColumn('match_players', 'is_winner', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('match_players', 'commander_damage', "TEXT DEFAULT '{}'");
  ensureColumn('match_events', 'related_player_id', 'INTEGER');
  ensureColumn('match_events', 'round_number', 'INTEGER DEFAULT 1');

  // Äldre versioner tillät bara en aktiv match i hela databasen.
  db.exec('DROP INDEX IF EXISTS idx_one_active_match');

  if (!hadTeamNumberBeforeMigration) {
    db.prepare('UPDATE match_players SET team_number = seat_index + 1').run();
  } else {
    db.prepare('UPDATE match_players SET team_number = seat_index + 1 WHERE team_number IS NULL OR team_number < 1').run();
  }
});

applyMigration(2, 'deck-archive-and-sync-metadata', () => {
  ensureColumn('decks', 'archived', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('decks', 'archived_at', 'DATETIME');
  ensureColumn('decks', 'client_uid', 'TEXT');
  // CURRENT_TIMESTAMP kan inte användas som ALTER TABLE-default på alla SQLite-
  // versioner, därför läggs dessa kolumner till utan default på gamla databaser.
  // Alla skrivande endpoints sätter dem explicit framöver.
  ensureColumn('decks', 'created_at', 'DATETIME');
  ensureColumn('decks', 'updated_at', 'DATETIME');

  db.prepare('UPDATE decks SET archived = 0 WHERE archived IS NULL').run();
  db.prepare('UPDATE decks SET created_at = COALESCE(created_at, CURRENT_TIMESTAMP), updated_at = COALESCE(updated_at, CURRENT_TIMESTAMP)').run();
});

applyMigration(3, 'indexes-for-active-decks-and-mobile-sync', () => {
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_decks_archived ON decks(archived);
    CREATE INDEX IF NOT EXISTS idx_decks_updated_at ON decks(updated_at);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_decks_owner_client_uid
      ON decks(owner_id, client_uid)
      WHERE client_uid IS NOT NULL;
  `);
});

applyMigration(4, 'monotonic-deck-sync-revision', () => {
  ensureColumn('decks', 'sync_revision', 'INTEGER NOT NULL DEFAULT 0');
  db.exec(`
    CREATE TABLE IF NOT EXISTS sync_state (
      scope TEXT PRIMARY KEY,
      revision INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_decks_sync_revision ON decks(sync_revision);
  `);
  db.prepare("INSERT OR IGNORE INTO sync_state (scope, revision) VALUES ('decks', 0)").run();
});


applyMigration(5, 'server-timer-and-turn-events', () => {
  // Separera riktig turstart från timerankaret. Android och webb kan därmed
  // alltid läsa samma timerstatus från servern, även efter omladdning/enhetsbyte.
  ensureColumn('matches', 'timer_remaining_seconds', 'INTEGER');
  ensureColumn('matches', 'timer_is_running', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('matches', 'timer_anchor_at', 'DATETIME');

  // Turn/eventhistoriken behöver varaktighet och valfri maskinläsbar metadata.
  ensureColumn('match_events', 'duration_seconds', 'INTEGER');
  ensureColumn('match_events', 'metadata_json', 'TEXT');

  db.exec(`CREATE INDEX IF NOT EXISTS idx_match_events_match_type_id ON match_events(match_id, event_type, id);`);

  // Ta över eventuella aktiva matcher från äldre versioner. Om timern varit
  // aktiv räknas den från befintlig turn_started_at, i stället för att starta om.
  db.prepare(`
    UPDATE matches
    SET timer_remaining_seconds = COALESCE(timer_remaining_seconds, timer_seconds, 0),
        timer_is_running = CASE WHEN COALESCE(timer_seconds, 0) > 0 THEN 1 ELSE 0 END,
        timer_anchor_at = COALESCE(timer_anchor_at, turn_started_at, CURRENT_TIMESTAMP),
        turn_started_at = COALESCE(turn_started_at, started_at, CURRENT_TIMESTAMP)
    WHERE status = 'active'
  `).run();

  // Befintliga aktiva matcher får ett TURN_START om de saknar ett öppet sådant.
  const activeMatches = db.prepare(`SELECT id, active_player_index, current_round, turn_started_at FROM matches WHERE status='active'`).all();
  for (const match of activeMatches) {
    const players = db.prepare('SELECT player_id FROM match_players WHERE match_id=? ORDER BY seat_index').all(match.id);
    const activePlayer = players[Number(match.active_player_index)] || players[0];
    if (!activePlayer) continue;
    const latestStart = db.prepare("SELECT id FROM match_events WHERE match_id=? AND event_type='TURN_START' ORDER BY id DESC LIMIT 1").get(match.id);
    const latestEnd = db.prepare("SELECT id FROM match_events WHERE match_id=? AND event_type='TURN_END' ORDER BY id DESC LIMIT 1").get(match.id);
    if (!latestStart || (latestEnd && latestEnd.id > latestStart.id)) {
      db.prepare(`
        INSERT INTO match_events
          (match_id, player_id, event_type, change_value, prev_value, new_value, round_number, created_at, metadata_json)
        VALUES (?, ?, 'TURN_START', 0, 0, 0, ?, COALESCE(?, CURRENT_TIMESTAMP), ?)
      `).run(match.id, activePlayer.player_id, match.current_round || 1, match.turn_started_at, JSON.stringify({ migrated: true }));
    }
  }
});


applyMigration(6, 'explicit-team-match-mode', () => {
  // team_number har funnits länge, men från Steg 2.2 lagrar matchen även om
  // den uttryckligen är FFA eller lagmatch. Det gör API-kontraktet tydligt för
  // både webb och Android och undviker att klienter måste gissa av lagnumren.
  ensureColumn('matches', 'team_mode', "TEXT NOT NULL DEFAULT 'ffa'");

  // Om någon äldre/API-skapad match redan har flera spelare med samma
  // team_number bevaras den semantiken och markeras som lagmatch.
  db.prepare(`
    UPDATE matches
    SET team_mode='teams'
    WHERE EXISTS (
      SELECT 1
      FROM match_players a
      JOIN match_players b
        ON a.match_id=b.match_id
       AND a.id < b.id
       AND a.team_number=b.team_number
      WHERE a.match_id=matches.id
    )
  `).run();

  db.prepare("UPDATE matches SET team_mode='ffa' WHERE team_mode IS NULL OR team_mode NOT IN ('ffa','teams')").run();
  db.exec('CREATE INDEX IF NOT EXISTS idx_matches_team_mode ON matches(team_mode);');
});

applyMigration(7, 'admin-superuser-and-player-tombstones', () => {
  // Spelare får samma soft-delete/synkprincip som decks. Det gör att en
  // framtida Androidklient kan ta emot tombstones i stället för att gissa
  // varför en tidigare känd spelare plötsligt saknas.
  ensureColumn('players', 'is_admin', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('players', 'archived', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('players', 'archived_at', 'DATETIME');
  ensureColumn('players', 'auth_revision', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('players', 'created_at', 'DATETIME');
  ensureColumn('players', 'updated_at', 'DATETIME');
  ensureColumn('players', 'sync_revision', 'INTEGER NOT NULL DEFAULT 0');

  db.prepare('UPDATE players SET archived=0 WHERE archived IS NULL').run();
  db.prepare('UPDATE players SET is_admin=0 WHERE is_admin IS NULL').run();
  db.prepare('UPDATE players SET auth_revision=0 WHERE auth_revision IS NULL').run();
  db.prepare('UPDATE players SET created_at=COALESCE(created_at,CURRENT_TIMESTAMP), updated_at=COALESCE(updated_at,CURRENT_TIMESTAMP)').run();

  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_players_archived ON players(archived);
    CREATE INDEX IF NOT EXISTS idx_players_sync_revision ON players(sync_revision);
    CREATE TABLE IF NOT EXISTS admin_audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_player_id INTEGER,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT,
      details_json TEXT,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (actor_player_id) REFERENCES players(id)
    );
    CREATE INDEX IF NOT EXISTS idx_admin_audit_created_at ON admin_audit_log(created_at);
  `);
  db.prepare("INSERT OR IGNORE INTO sync_state (scope, revision) VALUES ('players', 0)").run();
});


applyMigration(8, 'deck-mtg-color-identity', () => {
  // Semantisk MTG-färgidentitet. Klienterna bestämmer själva gradient/palett.
  ensureColumn('decks', 'color_identity', 'TEXT');
  db.exec('CREATE INDEX IF NOT EXISTS idx_decks_color_identity ON decks(color_identity);');

  // Ge alla befintliga decks en ny revisionspunkt. Android 3.8.3 nollställer
  // sin deck-cursor vid Room-migreringen och ska då säkert få även gamla decks
  // som tidigare råkade ha sync_revision=0.
  db.prepare("INSERT OR IGNORE INTO sync_state (scope, revision) VALUES ('decks', 0)").run();
  let revision = Number(db.prepare("SELECT revision FROM sync_state WHERE scope='decks'").get()?.revision || 0);
  const existingDecks = db.prepare('SELECT id FROM decks ORDER BY id').all();
  const bumpDeck = db.prepare('UPDATE decks SET sync_revision=?, updated_at=COALESCE(updated_at,CURRENT_TIMESTAMP) WHERE id=?');
  for (const deck of existingDecks) {
    revision += 1;
    bumpDeck.run(revision, deck.id);
  }
  db.prepare("UPDATE sync_state SET revision=? WHERE scope='decks'").run(revision);
});


applyMigration(9, 'offline-match-import-idempotency', () => {
  // Android 3.9.0 skapar matcher helt offline. client_match_uid är en stabil
  // UUID/idempotensnyckel så att WorkManager kan försöka samma uppladdning
  // flera gånger utan att skapa dubbla historik-/statistikposter.
  ensureColumn('matches', 'client_match_uid', 'TEXT');
  ensureColumn('matches', 'imported_offline', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('matches', 'imported_at', 'DATETIME');
  ensureColumn('matches', 'imported_by_player_id', 'INTEGER');

  db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_matches_client_match_uid
      ON matches(client_match_uid)
      WHERE client_match_uid IS NOT NULL;

    CREATE INDEX IF NOT EXISTS idx_matches_imported_offline
      ON matches(imported_offline);
  `);
});


applyMigration(10, 'offline-match-import-audit', () => {
  // Android 3.9.1: audit ska alltid komma från den autentiserade
  // serversessionen, aldrig från ett påstått user-id i klientpayloaden.
  ensureColumn('matches', 'imported_by_user_id', 'INTEGER');
  ensureColumn('matches', 'import_source', 'TEXT');

  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_matches_imported_by_user_id
      ON matches(imported_by_user_id);

    CREATE INDEX IF NOT EXISTS idx_matches_import_source
      ON matches(import_source);
  `);

  // Bakåtkompatibel backfill för matcher som importerades med 3.9.0.
  db.prepare(`
    UPDATE matches
    SET imported_by_user_id = imported_by_player_id
    WHERE imported_offline = 1
      AND imported_by_user_id IS NULL
      AND imported_by_player_id IS NOT NULL
  `).run();

  db.prepare(`
    UPDATE matches
    SET import_source = 'android_offline'
    WHERE imported_offline = 1
      AND (import_source IS NULL OR import_source = '')
  `).run();
});


applyMigration(11, 'global-match-events-without-player', () => {
  // Offlinejournalen och serverhändelser som ABORT/NEXT_TURN/TIMER kan vara
  // matchglobala och saknar legitimt player_id. Äldre schema krävde spelare
  // och gjorde därför att sådana events tappades vid offlineimport.
  const playerColumn = db.prepare('PRAGMA table_info(match_events)').all()
    .find(column => column.name === 'player_id');

  if (playerColumn && Number(playerColumn.notnull) === 1) {
    db.exec(`
      CREATE TABLE match_events_v11 (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        match_id INTEGER NOT NULL,
        player_id INTEGER,
        related_player_id INTEGER,
        event_type TEXT NOT NULL,
        change_value INTEGER NOT NULL,
        prev_value INTEGER NOT NULL,
        new_value INTEGER NOT NULL,
        round_number INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        duration_seconds INTEGER,
        metadata_json TEXT,
        FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
        FOREIGN KEY (player_id) REFERENCES players(id),
        FOREIGN KEY (related_player_id) REFERENCES players(id)
      );

      INSERT INTO match_events_v11
        (id, match_id, player_id, related_player_id, event_type, change_value,
         prev_value, new_value, round_number, created_at, duration_seconds, metadata_json)
      SELECT id, match_id, player_id, related_player_id, event_type, change_value,
             prev_value, new_value, round_number, created_at, duration_seconds, metadata_json
      FROM match_events;

      DROP TABLE match_events;
      ALTER TABLE match_events_v11 RENAME TO match_events;
    `);
  }

  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_match_events_match_id ON match_events(match_id);
    CREATE INDEX IF NOT EXISTS idx_match_events_match_type_id ON match_events(match_id, event_type, id);
  `);
});


applyMigration(12, 'historical-identities-hard-delete-and-sync-tombstones', () => {
  // Permanent borttagning får inte göra gamla matcher/statistik oläsbara.
  // Varje spelare/deck får därför en stabil server-UID och matchtabellerna
  // sparar immutable snapshots av identiteten som den såg ut när matchen spelades.
  ensureColumn('players', 'entity_uid', 'TEXT');
  ensureColumn('decks', 'entity_uid', 'TEXT');

  for (const row of db.prepare("SELECT id FROM players WHERE entity_uid IS NULL OR entity_uid=''").all()) {
    db.prepare('UPDATE players SET entity_uid=? WHERE id=?').run(crypto.randomUUID(), row.id);
  }
  for (const row of db.prepare("SELECT id FROM decks WHERE entity_uid IS NULL OR entity_uid=''").all()) {
    db.prepare('UPDATE decks SET entity_uid=? WHERE id=?').run(crypto.randomUUID(), row.id);
  }

  db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_players_entity_uid ON players(entity_uid);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_decks_entity_uid ON decks(entity_uid);

    CREATE TABLE match_players_v12 (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      match_id INTEGER NOT NULL,
      player_id INTEGER,
      deck_id INTEGER,
      seat_index INTEGER DEFAULT 0,
      team_number INTEGER DEFAULT 1,
      initial_life INTEGER DEFAULT 40,
      current_life INTEGER DEFAULT 40,
      poison_counters INTEGER DEFAULT 0,
      commander_tax INTEGER DEFAULT 0,
      is_eliminated INTEGER DEFAULT 0,
      eliminated_reason TEXT,
      is_winner INTEGER NOT NULL DEFAULT 0,
      commander_damage TEXT DEFAULT '{}',
      player_uid TEXT,
      player_name_snapshot TEXT,
      deck_uid TEXT,
      deck_name_snapshot TEXT,
      deck_owner_uid TEXT,
      deck_owner_name_snapshot TEXT,
      deck_color_identity_snapshot TEXT,
      FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
      FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE SET NULL,
      FOREIGN KEY (deck_id) REFERENCES decks(id) ON DELETE SET NULL,
      UNIQUE(match_id, player_id)
    );

    INSERT INTO match_players_v12
      (id,match_id,player_id,deck_id,seat_index,team_number,initial_life,current_life,
       poison_counters,commander_tax,is_eliminated,eliminated_reason,is_winner,commander_damage,
       player_uid,player_name_snapshot,deck_uid,deck_name_snapshot,
       deck_owner_uid,deck_owner_name_snapshot,deck_color_identity_snapshot)
    SELECT
      mp.id,mp.match_id,mp.player_id,mp.deck_id,mp.seat_index,mp.team_number,
      mp.initial_life,mp.current_life,mp.poison_counters,mp.commander_tax,
      mp.is_eliminated,mp.eliminated_reason,mp.is_winner,mp.commander_damage,
      p.entity_uid,p.name,d.entity_uid,d.name,owner.entity_uid,owner.name,d.color_identity
    FROM match_players mp
    LEFT JOIN players p ON p.id=mp.player_id
    LEFT JOIN decks d ON d.id=mp.deck_id
    LEFT JOIN players owner ON owner.id=d.owner_id;

    DROP TABLE match_players;
    ALTER TABLE match_players_v12 RENAME TO match_players;

    CREATE INDEX IF NOT EXISTS idx_match_players_match_id ON match_players(match_id);
    CREATE INDEX IF NOT EXISTS idx_match_players_player_id ON match_players(player_id);
    CREATE INDEX IF NOT EXISTS idx_match_players_deck_id ON match_players(deck_id);
    CREATE INDEX IF NOT EXISTS idx_match_players_player_uid ON match_players(player_uid);
    CREATE INDEX IF NOT EXISTS idx_match_players_deck_uid ON match_players(deck_uid);

    CREATE TABLE match_events_v12 (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      match_id INTEGER NOT NULL,
      player_id INTEGER,
      related_player_id INTEGER,
      event_type TEXT NOT NULL,
      change_value INTEGER NOT NULL,
      prev_value INTEGER NOT NULL,
      new_value INTEGER NOT NULL,
      round_number INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      duration_seconds INTEGER,
      metadata_json TEXT,
      player_uid TEXT,
      player_name_snapshot TEXT,
      related_player_uid TEXT,
      related_player_name_snapshot TEXT,
      FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
      FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE SET NULL,
      FOREIGN KEY (related_player_id) REFERENCES players(id) ON DELETE SET NULL
    );

    INSERT INTO match_events_v12
      (id,match_id,player_id,related_player_id,event_type,change_value,prev_value,new_value,
       round_number,created_at,duration_seconds,metadata_json,
       player_uid,player_name_snapshot,related_player_uid,related_player_name_snapshot)
    SELECT
      e.id,e.match_id,e.player_id,e.related_player_id,e.event_type,e.change_value,e.prev_value,e.new_value,
      e.round_number,e.created_at,e.duration_seconds,e.metadata_json,
      p.entity_uid,p.name,rp.entity_uid,rp.name
    FROM match_events e
    LEFT JOIN players p ON p.id=e.player_id
    LEFT JOIN players rp ON rp.id=e.related_player_id;

    DROP TABLE match_events;
    ALTER TABLE match_events_v12 RENAME TO match_events;

    CREATE INDEX IF NOT EXISTS idx_match_events_match_id ON match_events(match_id);
    CREATE INDEX IF NOT EXISTS idx_match_events_match_type_id ON match_events(match_id,event_type,id);
    CREATE INDEX IF NOT EXISTS idx_match_events_player_uid ON match_events(player_uid);

    CREATE TABLE IF NOT EXISTS sync_tombstones (
      resource TEXT NOT NULL,
      legacy_id INTEGER NOT NULL,
      entity_uid TEXT,
      owner_id INTEGER,
      client_uid TEXT,
      deleted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      sync_revision INTEGER NOT NULL,
      PRIMARY KEY(resource, legacy_id)
    );
    CREATE INDEX IF NOT EXISTS idx_sync_tombstones_revision ON sync_tombstones(resource,sync_revision);
    CREATE INDEX IF NOT EXISTS idx_sync_tombstones_client_uid ON sync_tombstones(resource,owner_id,client_uid);

    CREATE TRIGGER IF NOT EXISTS trg_players_entity_uid
    AFTER INSERT ON players
    WHEN NEW.entity_uid IS NULL OR NEW.entity_uid=''
    BEGIN
      UPDATE players SET entity_uid=lower(hex(randomblob(16))) WHERE id=NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS trg_decks_entity_uid
    AFTER INSERT ON decks
    WHEN NEW.entity_uid IS NULL OR NEW.entity_uid=''
    BEGIN
      UPDATE decks SET entity_uid=lower(hex(randomblob(16))) WHERE id=NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS trg_match_players_identity_snapshot
    AFTER INSERT ON match_players
    BEGIN
      UPDATE match_players
      SET player_uid=COALESCE(player_uid,(SELECT entity_uid FROM players WHERE id=NEW.player_id)),
          player_name_snapshot=COALESCE(player_name_snapshot,(SELECT name FROM players WHERE id=NEW.player_id)),
          deck_uid=COALESCE(deck_uid,(SELECT entity_uid FROM decks WHERE id=NEW.deck_id)),
          deck_name_snapshot=COALESCE(deck_name_snapshot,(SELECT name FROM decks WHERE id=NEW.deck_id)),
          deck_owner_uid=COALESCE(deck_owner_uid,(
            SELECT owner.entity_uid FROM decks d JOIN players owner ON owner.id=d.owner_id WHERE d.id=NEW.deck_id
          )),
          deck_owner_name_snapshot=COALESCE(deck_owner_name_snapshot,(
            SELECT owner.name FROM decks d JOIN players owner ON owner.id=d.owner_id WHERE d.id=NEW.deck_id
          )),
          deck_color_identity_snapshot=COALESCE(deck_color_identity_snapshot,(
            SELECT color_identity FROM decks WHERE id=NEW.deck_id
          ))
      WHERE id=NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS trg_match_events_identity_snapshot
    AFTER INSERT ON match_events
    BEGIN
      UPDATE match_events
      SET player_uid=COALESCE(player_uid,(SELECT entity_uid FROM players WHERE id=NEW.player_id)),
          player_name_snapshot=COALESCE(player_name_snapshot,(SELECT name FROM players WHERE id=NEW.player_id)),
          related_player_uid=COALESCE(related_player_uid,(SELECT entity_uid FROM players WHERE id=NEW.related_player_id)),
          related_player_name_snapshot=COALESCE(related_player_name_snapshot,(SELECT name FROM players WHERE id=NEW.related_player_id))
      WHERE id=NEW.id;
    END;
  `);
});


applyMigration(13, 'system-settings-instance-identity-and-backup-config', () => {
  db.exec(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);
});


applyMigration(14, 'player-preferred-locale', () => {
  if (!hasColumn('players', 'preferred_locale')) {
    db.exec(`ALTER TABLE players ADD COLUMN preferred_locale TEXT NOT NULL DEFAULT 'sv'`);
  }
  db.exec(`UPDATE players SET preferred_locale='sv' WHERE preferred_locale IS NULL OR preferred_locale NOT IN ('sv','en')`);
});


applyMigration(15, 'match-format-engine-v1', () => {
  ensureColumn('matches', 'match_profile', "TEXT NOT NULL DEFAULT 'legacy'");
  ensureColumn('matches', 'deck_format', 'TEXT');
  ensureColumn('matches', 'play_mode', "TEXT NOT NULL DEFAULT 'ffa'");
  ensureColumn('matches', 'limited_format', 'TEXT');
  ensureColumn('matches', 'modifiers_json', "TEXT NOT NULL DEFAULT '[]'");
  ensureColumn('matches', 'rules_profile', "TEXT NOT NULL DEFAULT 'legacy'");
  ensureColumn('matches', 'rules_version', 'INTEGER NOT NULL DEFAULT 1');
  ensureColumn('matches', 'rules_json', "TEXT NOT NULL DEFAULT '{}'");

  // Backfill äldre matcher utan att ändra deras gamla match_type. Det gör att
  // historik och äldre Androidklienter fortsätter fungera samtidigt som nya
  // klienter kan använda den normaliserade modellen.
  db.exec(`
    UPDATE matches
    SET match_profile = CASE
          WHEN lower(match_type)='commander' THEN 'commander'
          WHEN lower(match_type)='oathbreaker' THEN 'oathbreaker'
          WHEN lower(match_type) IN ('1v1','constructed') THEN 'constructed'
          WHEN lower(match_type) IN ('ktm','casual 4+','kitchen table') THEN 'kitchen_table'
          ELSE 'legacy'
        END,
        deck_format = CASE
          WHEN lower(match_type)='commander' THEN 'commander'
          WHEN lower(match_type)='oathbreaker' THEN 'oathbreaker'
          ELSE COALESCE(deck_format,'freeform')
        END,
        play_mode = CASE
          WHEN team_mode='teams' THEN 'teams'
          WHEN lower(match_type)='1v1' THEN 'duel'
          ELSE 'ffa'
        END,
        rules_profile = CASE
          WHEN lower(match_type)='commander' THEN 'commander'
          WHEN lower(match_type)='oathbreaker' THEN 'oathbreaker'
          WHEN lower(match_type) IN ('1v1','constructed') THEN 'constructed'
          WHEN lower(match_type) IN ('ktm','casual 4+','kitchen table') THEN 'freeform'
          ELSE 'legacy'
        END,
        rules_version = 1,
        modifiers_json = COALESCE(NULLIF(modifiers_json,''),'[]'),
        rules_json = COALESCE(NULLIF(rules_json,''),'{}')
    WHERE match_profile IS NULL OR match_profile='' OR match_profile='legacy';

    CREATE INDEX IF NOT EXISTS idx_matches_match_profile ON matches(match_profile);
    CREATE INDEX IF NOT EXISTS idx_matches_deck_format ON matches(deck_format);
    CREATE INDEX IF NOT EXISTS idx_matches_play_mode ON matches(play_mode);
  `);
});

applyMigration(16, 'special-multiplayer-rules-v1', () => {
  ensureColumn('matches', 'active_turn_group', 'INTEGER');
  ensureColumn('match_players', 'role_key', 'TEXT');
  ensureColumn('match_players', 'turn_group', 'INTEGER');
  ensureColumn('match_players', 'range_of_influence', 'INTEGER');
  ensureColumn('match_players', 'attack_rule', 'TEXT');

  db.exec(`
    CREATE TABLE IF NOT EXISTS match_teams (
      match_id INTEGER NOT NULL,
      team_number INTEGER NOT NULL,
      role_key TEXT,
      life_scope TEXT NOT NULL DEFAULT 'player',
      initial_life INTEGER,
      current_life INTEGER,
      poison_scope TEXT NOT NULL DEFAULT 'player',
      poison_counters INTEGER,
      poison_loss_threshold INTEGER NOT NULL DEFAULT 10,
      is_eliminated INTEGER NOT NULL DEFAULT 0,
      is_winner INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY(match_id, team_number),
      FOREIGN KEY(match_id) REFERENCES matches(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_match_teams_match_id ON match_teams(match_id);

    UPDATE match_players
    SET turn_group = CASE
      WHEN turn_group IS NOT NULL THEN turn_group
      WHEN team_number IS NOT NULL THEN CASE
        WHEN match_id IN (
          SELECT id FROM matches WHERE play_mode IN ('two_headed_giant','archenemy','archenemy_commander')
        ) THEN team_number
        ELSE seat_index + 1
      END
      ELSE seat_index + 1
    END;

    UPDATE matches
    SET active_turn_group = COALESCE(
      active_turn_group,
      (SELECT COALESCE(mp.turn_group, mp.seat_index + 1)
       FROM match_players mp
       WHERE mp.match_id=matches.id
       ORDER BY mp.seat_index
       LIMIT 1)
    );
  `);
});


applyMigration(17, 'social-hidden-role-v1', () => {
  ensureColumn('matches', 'variant_state_json', "TEXT NOT NULL DEFAULT '{}'");
  ensureColumn('match_players', 'role_visibility', "TEXT NOT NULL DEFAULT 'public'");
  ensureColumn('match_players', 'secret_target_player_id', 'INTEGER');
  ensureColumn('match_players', 'secret_target_player_uid', 'TEXT');
  ensureColumn('match_players', 'secret_target_name_snapshot', 'TEXT');
  ensureColumn('match_players', 'victory_condition_key', 'TEXT');
  ensureColumn('match_players', 'objective_score', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('match_players', 'secret_state_json', "TEXT NOT NULL DEFAULT '{}'");
  ensureColumn('match_players', 'reveal_token_hash', 'TEXT');

  // Roller från äldre specialformat (Emperor/Archenemy/THG) är publika. Denna
  // migration maskerar alltså inget historiskt innehåll. Hidden-role-format
  // skapas först efter att schema 17 finns.
  db.exec(`
    UPDATE match_players
       SET role_visibility='public'
     WHERE role_visibility IS NULL OR role_visibility='';

    UPDATE matches
       SET variant_state_json='{}'
     WHERE variant_state_json IS NULL OR variant_state_json='';

    CREATE INDEX IF NOT EXISTS idx_match_players_secret_target
      ON match_players(match_id, secret_target_player_id);
  `);
});


applyMigration(18, 'locale-settings-contract-v1', () => {
  ensureColumn('players', 'locale_mode', "TEXT NOT NULL DEFAULT 'auto'");
  ensureColumn('players', 'locale_preference', 'TEXT');
  ensureColumn('players', 'locale_revision', 'INTEGER NOT NULL DEFAULT 0');

  // Contract v1 migration is deliberately conservative. Every pre-3.9.9.1
  // account had a concrete preferred_locale, but the server cannot know whether
  // Swedish came from the historical default or from an explicit user choice.
  // Both sv and en are therefore preserved as MANUAL to avoid changing anyone's
  // observable language during upgrade.
  db.exec(`
    UPDATE players
       SET preferred_locale = CASE
             WHEN lower(COALESCE(preferred_locale,'')) IN ('sv','en') THEN lower(preferred_locale)
             ELSE 'en'
           END;

    UPDATE players
       SET locale_mode='manual',
           locale_preference=preferred_locale,
           locale_revision=COALESCE(locale_revision,0)
     WHERE locale_preference IS NULL OR trim(locale_preference)='';

    UPDATE players
       SET locale_mode='manual'
     WHERE locale_mode NOT IN ('auto','manual') OR locale_mode IS NULL;

    UPDATE players
       SET locale_revision=0
     WHERE locale_revision IS NULL OR locale_revision < 0;
  `);
});


applyMigration(19, 'day-night-match-state-v1', () => {
  ensureColumn('matches', 'day_night_state', "TEXT NOT NULL DEFAULT 'none'");

  // Day/Night Contract v1 är additivt. Äldre matcher har aldrig haft en
  // designation och börjar därför i none. Okända/trasiga historiska värden
  // normaliseras defensivt till none.
  db.exec(`
    UPDATE matches
       SET day_night_state='none'
     WHERE day_night_state IS NULL
        OR lower(trim(day_night_state)) NOT IN ('none','day','night');

    UPDATE matches
       SET day_night_state=lower(trim(day_night_state));

    CREATE INDEX IF NOT EXISTS idx_match_events_type_match
      ON match_events(event_type, match_id, id);
  `);
});


applyForeignKeyRebuildMigration(20, 'deck-active-name-uniqueness-v1', () => {
  // Deck Contract v2 har alltid definierat namnkonflikt mellan AKTIVA decks.
  // Äldre grundschema hade däremot UNIQUE(owner_id,name) på hela tabellen och
  // blockerade därför legitimt fallet arkiverad "Alpha" + aktiv "Alpha".
  // Schema 20 gör databasen konsekvent med API-kontraktet.
  const activeNameConflicts = db.prepare(`
    SELECT owner_id, lower(name) AS normalized_name, COUNT(*) AS count
      FROM decks
     WHERE archived=0
     GROUP BY owner_id, lower(name)
    HAVING COUNT(*) > 1
     LIMIT 20
  `).all();
  if (activeNameConflicts.length) {
    const err = new Error('Aktiva decks med kolliderande namn måste lösas innan schema 20 kan aktiveras.');
    err.code = 'DECK_ACTIVE_NAME_MIGRATION_CONFLICT';
    err.conflicts = activeNameConflicts;
    throw err;
  }

  const deckDependencies = captureTableRebuildDependencies('decks');
  const identitySnapshotTrigger = deckDependencies.find(object =>
    object.type === 'trigger' && object.name === 'trg_match_players_identity_snapshot'
  );
  if (!identitySnapshotTrigger) {
    const err = new Error('Förväntad trigger trg_match_players_identity_snapshot saknas före decks-rebuild.');
    err.code = 'DECK_REBUILD_DEPENDENCY_MISSING';
    throw err;
  }

  // Known schema-20 regression gate:
  // trg_match_players_identity_snapshot tillhör match_players men läser decks.
  // Om triggern lämnas aktiv när decks droppas blir sqlite_master temporärt
  // ogiltig och SQLite stoppar migrationen med "no such table: main.decks".
  // Alla berörda triggers/views/indexer fångas, droppas och återskapas explicit
  // inom samma transaction som table rebuild + foreign_key_check.
  dropTableRebuildDependencies(deckDependencies);

  db.exec(`
    CREATE TABLE decks_v20 (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      format TEXT DEFAULT 'Commander',
      decklist TEXT,
      archived INTEGER NOT NULL DEFAULT 0,
      archived_at DATETIME,
      client_uid TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      sync_revision INTEGER NOT NULL DEFAULT 0,
      color_identity TEXT,
      entity_uid TEXT,
      FOREIGN KEY (owner_id) REFERENCES players(id) ON DELETE CASCADE
    );

    INSERT INTO decks_v20
      (id,owner_id,name,format,decklist,archived,archived_at,client_uid,created_at,updated_at,sync_revision,color_identity,entity_uid)
    SELECT
      id,owner_id,name,format,decklist,COALESCE(archived,0),archived_at,client_uid,created_at,updated_at,COALESCE(sync_revision,0),color_identity,entity_uid
      FROM decks;

    DROP TABLE decks;
    ALTER TABLE decks_v20 RENAME TO decks;
  `);

  // Återställ alla schemaobjekt som source-databasen hade och som v20-rebuilden
  // temporärt tog ned. Därmed bevaras även views och framtida kompatibla index
  // i den deklarerade source-schema-range utan att migrationen behöver gissa.
  recreateTableRebuildDependencies(deckDependencies);

  // Säkerställ target-schemaobjekten. IF NOT EXISTS gör detta kompatibelt med
  // source-indexer som redan återskapades ovan.
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_decks_owner_id ON decks(owner_id);
    CREATE INDEX IF NOT EXISTS idx_decks_archived ON decks(archived);
    CREATE INDEX IF NOT EXISTS idx_decks_updated_at ON decks(updated_at);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_decks_owner_client_uid
      ON decks(owner_id, client_uid)
      WHERE client_uid IS NOT NULL;
    CREATE INDEX IF NOT EXISTS idx_decks_sync_revision ON decks(sync_revision);
    CREATE INDEX IF NOT EXISTS idx_decks_color_identity ON decks(color_identity);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_decks_entity_uid ON decks(entity_uid);

    CREATE UNIQUE INDEX IF NOT EXISTS idx_decks_owner_active_name_nocase
      ON decks(owner_id, name COLLATE NOCASE)
      WHERE archived=0;

    CREATE TRIGGER IF NOT EXISTS trg_decks_entity_uid
    AFTER INSERT ON decks
    WHEN NEW.entity_uid IS NULL OR NEW.entity_uid=''
    BEGIN
      UPDATE decks SET entity_uid=lower(hex(randomblob(16))) WHERE id=NEW.id;
    END;
  `);

  const restoredIdentityTrigger = db.prepare(`
    SELECT sql FROM sqlite_master
     WHERE type='trigger' AND name='trg_match_players_identity_snapshot'
  `).get();
  if (!restoredIdentityTrigger?.sql || !/\bdecks\b/i.test(restoredIdentityTrigger.sql)) {
    const err = new Error('trg_match_players_identity_snapshot kunde inte verifieras efter decks-rebuild.');
    err.code = 'DECK_REBUILD_TRIGGER_VERIFY_FAILED';
    throw err;
  }
});


applyMigration(21, 'api-v1-offline-reliability-v1', () => {
  // Reliability Contract v1: client_match_uid is the single canonical stable
  // server/wire identity for matches. Preserve every existing value and only
  // backfill legacy/web rows that never had one.
  const missing = db.prepare(`
    SELECT id FROM matches
    WHERE client_match_uid IS NULL OR TRIM(client_match_uid)=''
    ORDER BY id
  `).all();
  const updateUid = db.prepare('UPDATE matches SET client_match_uid=? WHERE id=?');
  for (const row of missing) updateUid.run(crypto.randomUUID(), row.id);

  db.exec(`
    DROP INDEX IF EXISTS idx_matches_client_match_uid;
    CREATE UNIQUE INDEX IF NOT EXISTS idx_matches_client_match_uid
      ON matches(client_match_uid);

    CREATE TABLE IF NOT EXISTS idempotency_operations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key_type TEXT NOT NULL,
      idempotency_key TEXT NOT NULL,
      operation_kind TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id INTEGER,
      target_uid TEXT,
      actor_uid TEXT,
      request_fingerprint TEXT NOT NULL,
      result_status INTEGER NOT NULL DEFAULT 200,
      server_event_id INTEGER,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(key_type,idempotency_key)
    );
    CREATE INDEX IF NOT EXISTS idx_idempotency_target
      ON idempotency_operations(target_type,target_id,target_uid);
    CREATE INDEX IF NOT EXISTS idx_idempotency_created
      ON idempotency_operations(created_at);
  `);
});


function getSetting(key) {
  return db.prepare('SELECT value FROM system_settings WHERE key=?').get(String(key))?.value ?? null;
}

function setSetting(key, value) {
  db.prepare(`
    INSERT INTO system_settings (key,value,updated_at)
    VALUES (?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP
  `).run(String(key), String(value));
  return String(value);
}

function ensureSetting(key, value) {
  if (getSetting(key) == null) setSetting(key, value);
  return getSetting(key);
}

// Stabil installationsidentitet för Androids restore/reset-detektering.
// Den ligger i databasen och följer därför med en normal backup/restore.
// Factory reset roterar den explicit i admin-routen.
ensureSetting('instance_uid', crypto.randomUUID());
ensureSetting('backup_enabled', String(process.env.BACKUP_ENABLED || 'true').toLowerCase() === 'false' ? 'false' : 'true');

const initialBackupKeepRaw = Number(process.env.BACKUP_KEEP);
const initialBackupHourRaw = Number(process.env.BACKUP_HOUR);
const initialBackupMinuteRaw = Number(process.env.BACKUP_MINUTE);
const initialBackupKeep = Number.isInteger(initialBackupKeepRaw) ? Math.max(1, Math.min(100, initialBackupKeepRaw)) : 14;
const initialBackupHour = Number.isInteger(initialBackupHourRaw) ? Math.max(0, Math.min(23, initialBackupHourRaw)) : 3;
const initialBackupMinute = Number.isInteger(initialBackupMinuteRaw) ? Math.max(0, Math.min(59, initialBackupMinuteRaw)) : 0;

ensureSetting('backup_keep', String(initialBackupKeep));
ensureSetting('backup_hour', String(initialBackupHour));
ensureSetting('backup_minute', String(initialBackupMinute));

function rotateInstanceUid() {
  const next = crypto.randomUUID();
  setSetting('instance_uid', next);
  db.instanceUid = next;
  return next;
}


function nextSyncRevision(scope = 'decks') {
  db.prepare('INSERT OR IGNORE INTO sync_state (scope, revision) VALUES (?, 0)').run(scope);
  db.prepare('UPDATE sync_state SET revision = revision + 1 WHERE scope = ?').run(scope);
  return Number(db.prepare('SELECT revision FROM sync_state WHERE scope = ?').get(scope).revision);
}

function currentSyncRevision(scope = 'decks') {
  const row = db.prepare('SELECT revision FROM sync_state WHERE scope = ?').get(scope);
  return Number(row?.revision || 0);
}

const schemaVersion = db.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version;

// Migreringar har automatiska regressionsfall och v1.0 är nu kompatibilitetsrot.
// För framtida publika releaser ska stöd från närmast stödda publika baseline
// verifieras explicit. Godtyckliga pre-v1.0 utvecklingssnapshotar är best-effort.

db.schemaVersion = Number(schemaVersion);
db.dbPath = dbPath;
db.nextSyncRevision = nextSyncRevision;
db.currentSyncRevision = currentSyncRevision;
db.getSetting = getSetting;
db.setSetting = setSetting;
db.rotateInstanceUid = rotateInstanceUid;
db.instanceUid = getSetting('instance_uid');

module.exports = db;
