// Express 4 fångar INTE automatiskt fel som kastas i en async route-handler
// (t.ex. "await bcrypt.hash(...)" som failar). Utan detta wrapper-lager kan
// sådana fel hänga sig tyst istället för att visas i loggen. Denna funktion
// ser till att alla fel - synkrona som asynkrona - alltid hamnar hos
// felhanteraren i server.js, som loggar dem tydligt.
module.exports = function asyncHandler(fn) {
  return function (req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
