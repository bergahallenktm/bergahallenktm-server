const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const STATE_FILENAME = 'upgrade_state.json';
const LAST_UPGRADE_FILENAME = 'last_upgrade.json';
const DEFAULT_PUBLIC_BASELINE = Object.freeze({
  release: 'v1.0',
  development_version: '3.9.14.2',
  app_version: '0.9.14.2',
  schema_version: 21
});

function dataDirectory() {
  return process.env.BERGAHALLEN_DATA_DIR
    ? path.resolve(process.env.BERGAHALLEN_DATA_DIR)
    : path.join(__dirname, '../data');
}

function activeDbPath(dataDir = dataDirectory()) {
  return path.join(dataDir, 'mtg_tracker_v7.db');
}

function statePath(dataDir = dataDirectory()) {
  return path.join(dataDir, STATE_FILENAME);
}

function lastUpgradePath(dataDir = dataDirectory()) {
  return path.join(dataDir, LAST_UPGRADE_FILENAME);
}

function readJson(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); }
  catch (_) { return null; }
}

function atomicWriteJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(tmp, 0o600); } catch (_) {}
  fs.renameSync(tmp, filePath);
  try { fs.chmodSync(filePath, 0o600); } catch (_) {}
}

function inspectDatabase(dbPath) {
  if (!fs.existsSync(dbPath)) {
    return {
      exists: false,
      schema_version: 0,
      instance_uid: null,
      quick_check: null,
      tables: []
    };
  }

  let db;
  try {
    db = new Database(dbPath, { readonly: true, fileMustExist: true });
    const quick = String(db.pragma('quick_check', { simple: true }) || 'unknown');
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(row => row.name);
    const tableSet = new Set(tables);
    const schemaVersion = tableSet.has('schema_migrations')
      ? Number(db.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migrations').get()?.version || 0)
      : 0;
    const instanceUid = tableSet.has('system_settings')
      ? db.prepare("SELECT value FROM system_settings WHERE key='instance_uid'").get()?.value || null
      : null;

    return {
      exists: true,
      schema_version: schemaVersion,
      instance_uid: instanceUid,
      quick_check: quick,
      tables
    };
  } finally {
    try { db?.close(); } catch (_) {}
  }
}

function releaseProfile(rootDir = path.join(__dirname, '..')) {
  const releasePath = path.join(rootDir, 'BERGAHALLEN-SERVER-RELEASE.json');
  const release = JSON.parse(fs.readFileSync(releasePath, 'utf8'));
  const upgrade = release.upgrade || {};
  const compatibilityRoot = upgrade.public_compatibility_root || DEFAULT_PUBLIC_BASELINE;
  return {
    app_version: release.app_version,
    development_version: release.development_version,
    api_version: Number(release.api_version),
    target_schema: Number(release.db_schema_version),
    public_compatibility_root: {
      release: compatibilityRoot.release || 'v1.0',
      development_version: compatibilityRoot.development_version || DEFAULT_PUBLIC_BASELINE.development_version,
      app_version: compatibilityRoot.app_version || DEFAULT_PUBLIC_BASELINE.app_version,
      schema_version: Number(compatibilityRoot.schema_version || DEFAULT_PUBLIC_BASELINE.schema_version)
    }
  };
}

function backupDirectory(dataDir) {
  return path.join(dataDir, 'backups');
}

function quoteSqlString(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function makeUpgradeBackup(dbPath, dataDir, sourceSchema, targetSchema) {
  const dir = backupDirectory(dataDir);
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupPath = path.join(dir, `mtg_tracker_${stamp}_pre-upgrade-schema${sourceSchema}-to-${targetSchema}.db`);
  let db;
  try {
    db = new Database(dbPath, { readonly: false, fileMustExist: true });
    const quick = String(db.pragma('quick_check', { simple: true }) || 'unknown');
    if (quick !== 'ok') {
      const err = new Error(`Databasen klarade inte quick_check före uppgradering: ${quick}`);
      err.code = 'PRE_UPGRADE_INTEGRITY_FAILED';
      throw err;
    }
    db.exec(`VACUUM INTO ${quoteSqlString(backupPath)}`);
    try { fs.chmodSync(backupPath, 0o600); } catch (_) {}
  } finally {
    try { db?.close(); } catch (_) {}
  }
  return backupPath;
}

function verifyUpgradeBackup(backupPath, expected) {
  const inspected = inspectDatabase(backupPath);
  if (!inspected.exists || inspected.quick_check !== 'ok') {
    const err = new Error('Pre-upgrade-backup kunde inte verifieras.');
    err.code = 'PRE_UPGRADE_BACKUP_INVALID';
    throw err;
  }
  if (Number(inspected.schema_version) !== Number(expected.schema_version)) {
    const err = new Error(`Pre-upgrade-backup har schema ${inspected.schema_version}, förväntat ${expected.schema_version}.`);
    err.code = 'PRE_UPGRADE_BACKUP_SCHEMA_MISMATCH';
    throw err;
  }
  if ((expected.instance_uid || null) !== (inspected.instance_uid || null)) {
    const err = new Error('Pre-upgrade-backup har annan instance_uid än källdatabasen.');
    err.code = 'PRE_UPGRADE_BACKUP_IDENTITY_MISMATCH';
    throw err;
  }
  return inspected;
}

function supportLevel(sourceSchema, publicBaselineSchema) {
  if (Number(sourceSchema) >= Number(publicBaselineSchema)) return 'supported-public-baseline';
  return 'best-effort-pre-v1';
}

function inspectUpgradePlan({ dataDir = dataDirectory(), profile = releaseProfile() } = {}) {
  const dbPath = activeDbPath(dataDir);
  const database = inspectDatabase(dbPath);
  const pending = readJson(statePath(dataDir));
  const sourceSchema = Number(database.schema_version || 0);
  const targetSchema = Number(profile.target_schema);
  const publicBaselineSchema = Number(profile.public_compatibility_root.schema_version);

  return {
    database,
    pending_upgrade: pending,
    target_schema: targetSchema,
    migration_required: database.exists && sourceSchema < targetSchema,
    source_newer_than_server: database.exists && sourceSchema > targetSchema,
    support_level: database.exists ? supportLevel(sourceSchema, publicBaselineSchema) : 'fresh-install',
    public_compatibility_root: profile.public_compatibility_root,
    pre_upgrade_backup_required: database.exists && sourceSchema < targetSchema
  };
}

function prepareStartupUpgrade({ dataDir = dataDirectory(), profile = releaseProfile() } = {}) {
  fs.mkdirSync(dataDir, { recursive: true });
  const dbPath = activeDbPath(dataDir);
  const plan = inspectUpgradePlan({ dataDir, profile });
  const source = plan.database;
  const targetSchema = Number(profile.target_schema);

  if (!source.exists) return { required: false, fresh_install: true, ...plan };

  if (source.schema_version > targetSchema) {
    const err = new Error(`Databasschema ${source.schema_version} är nyare än Serverns stödda schema ${targetSchema}.`);
    err.code = 'DB_SCHEMA_NEWER_THAN_SERVER';
    err.source_schema = source.schema_version;
    err.target_schema = targetSchema;
    throw err;
  }

  const pendingPath = statePath(dataDir);
  const previousState = readJson(pendingPath);
  if (previousState && ['prepared', 'failed'].includes(previousState.status)) {
    if (Number(previousState.target_schema) !== targetSchema) {
      const err = new Error('En ofullständig uppgradering finns för ett annat målschema. Recovery krävs innan ny uppgradering.');
      err.code = 'UPGRADE_STATE_TARGET_MISMATCH';
      throw err;
    }
    if (!previousState.backup_path || !fs.existsSync(previousState.backup_path)) {
      const err = new Error('Ofullständig uppgradering saknar sin verifierade pre-upgrade-backup.');
      err.code = 'UPGRADE_RECOVERY_BACKUP_MISSING';
      throw err;
    }
    verifyUpgradeBackup(previousState.backup_path, {
      schema_version: previousState.source_schema,
      instance_uid: previousState.source_instance_uid || null
    });
    return { required: true, resumed: true, state: previousState, ...plan };
  }

  if (source.schema_version === targetSchema) {
    return { required: false, fresh_install: false, ...plan };
  }

  if (source.quick_check !== 'ok') {
    const err = new Error(`Databasen klarade inte quick_check före uppgradering: ${source.quick_check}`);
    err.code = 'PRE_UPGRADE_INTEGRITY_FAILED';
    throw err;
  }

  const backupPath = makeUpgradeBackup(dbPath, dataDir, source.schema_version, targetSchema);
  verifyUpgradeBackup(backupPath, {
    schema_version: source.schema_version,
    instance_uid: source.instance_uid
  });

  const state = {
    format_version: 1,
    status: 'prepared',
    started_at: new Date().toISOString(),
    source_schema: Number(source.schema_version),
    target_schema: targetSchema,
    source_instance_uid: source.instance_uid || null,
    backup_path: backupPath,
    backup_name: path.basename(backupPath),
    support_level: plan.support_level,
    public_compatibility_root: profile.public_compatibility_root,
    source_app_version: null,
    target_app_version: profile.app_version,
    target_development_version: profile.development_version
  };
  atomicWriteJson(pendingPath, state);
  return { required: true, resumed: false, state, ...plan };
}

function markStartupUpgradeFailed(error, { dataDir = dataDirectory() } = {}) {
  const file = statePath(dataDir);
  const state = readJson(file);
  if (!state) return null;
  const failed = {
    ...state,
    status: 'failed',
    failed_at: new Date().toISOString(),
    error_code: error?.code || null,
    error: error?.message || String(error)
  };
  atomicWriteJson(file, failed);
  return failed;
}

function finalizeStartupUpgrade(db, { dataDir = dataDirectory(), profile = releaseProfile() } = {}) {
  const file = statePath(dataDir);
  const state = readJson(file);
  if (!state) return { completed: false, reason: 'no_pending_upgrade' };

  const targetSchema = Number(profile.target_schema);
  const actualSchema = Number(db.schemaVersion);
  if (actualSchema !== targetSchema) {
    const err = new Error(`Uppgraderingen nådde schema ${actualSchema}, förväntat ${targetSchema}.`);
    err.code = 'UPGRADE_TARGET_SCHEMA_NOT_REACHED';
    throw err;
  }

  const integrity = db.pragma('integrity_check');
  const foreignKeys = db.pragma('foreign_key_check');
  const integrityOk = integrity.length === 1 && integrity[0].integrity_check === 'ok';
  if (!integrityOk || foreignKeys.length) {
    const err = new Error('Databaskontroll efter uppgradering misslyckades.');
    err.code = 'POST_UPGRADE_INTEGRITY_FAILED';
    err.integrity_check = integrity;
    err.foreign_key_issues = foreignKeys;
    throw err;
  }

  const actualInstanceUid = db.getSetting?.('instance_uid') || db.instanceUid || null;
  if ((state.source_instance_uid || null) !== (actualInstanceUid || null)) {
    const err = new Error('instance_uid ändrades under Serveruppgraderingen.');
    err.code = 'POST_UPGRADE_IDENTITY_CHANGED';
    throw err;
  }

  const completed = {
    ...state,
    status: 'completed',
    completed_at: new Date().toISOString(),
    target_schema: actualSchema,
    target_instance_uid: actualInstanceUid || null,
    integrity_check: 'ok',
    foreign_key_issues: 0
  };
  atomicWriteJson(lastUpgradePath(dataDir), completed);
  try { fs.unlinkSync(file); } catch (_) {}
  return { completed: true, state: completed };
}

function getUpgradeStatus({ dataDir = dataDirectory() } = {}) {
  return {
    pending: readJson(statePath(dataDir)),
    last: readJson(lastUpgradePath(dataDir))
  };
}

function publicUpgradeStatus({ dataDir = dataDirectory() } = {}) {
  const status = getUpgradeStatus({ dataDir });
  const pending = status.pending ? {
    status: status.pending.status || null,
    source_schema: status.pending.source_schema ?? null,
    target_schema: status.pending.target_schema ?? null,
    support_level: status.pending.support_level || null,
    started_at: status.pending.started_at || null,
    failed_at: status.pending.failed_at || null,
    error_code: status.pending.error_code || null
  } : null;
  const last = status.last ? {
    status: status.last.status || null,
    source_schema: status.last.source_schema ?? null,
    target_schema: status.last.target_schema ?? null,
    support_level: status.last.support_level || null,
    completed_at: status.last.completed_at || null
  } : null;
  return { pending, last };
}

module.exports = {
  DEFAULT_PUBLIC_BASELINE,
  STATE_FILENAME,
  LAST_UPGRADE_FILENAME,
  dataDirectory,
  activeDbPath,
  statePath,
  lastUpgradePath,
  releaseProfile,
  inspectDatabase,
  inspectUpgradePlan,
  prepareStartupUpgrade,
  finalizeStartupUpgrade,
  markStartupUpgradeFailed,
  getUpgradeStatus,
  publicUpgradeStatus,
  verifyUpgradeBackup,
  supportLevel
};
