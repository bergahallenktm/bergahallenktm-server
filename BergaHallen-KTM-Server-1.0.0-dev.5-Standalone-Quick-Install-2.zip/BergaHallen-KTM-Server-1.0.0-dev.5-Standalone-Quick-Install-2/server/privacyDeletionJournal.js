'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DELETION_TOMBSTONE_JOURNAL_SCHEMA = 1;
const DEFAULT_JOURNAL_PATH = '/var/lib/bergahallen-ktm/privacy/deletion-tombstones.jsonl';
const DEFAULT_KEY_PATH = '/etc/bergahallen-ktm/privacy/deletion-journal.key';
const MIN_KEY_BYTES = 32;

function configuredPaths(env = process.env) {
  const production = String(env.NODE_ENV || '').trim().toLowerCase() === 'production';
  const localDataDir = env.BERGAHALLEN_DATA_DIR
    ? path.resolve(env.BERGAHALLEN_DATA_DIR)
    : path.join(__dirname, '../data');
  const defaultJournal = production ? DEFAULT_JOURNAL_PATH : path.join(localDataDir, 'privacy', 'deletion-tombstones.jsonl');
  const defaultKey = production ? DEFAULT_KEY_PATH : path.join(localDataDir, 'privacy', 'deletion-journal.key');
  return {
    journalPath: path.resolve(String(env.BERGAHALLEN_DELETION_JOURNAL_PATH || defaultJournal)),
    keyPath: path.resolve(String(env.BERGAHALLEN_DELETION_JOURNAL_KEY_PATH || defaultKey))
  };
}

function ensurePrivateDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dirPath, 0o700); } catch (_) {}
}

function readKey(keyPath) {
  const raw = fs.readFileSync(keyPath, 'utf8').trim();
  let bytes;
  try { bytes = Buffer.from(raw, 'base64url'); } catch (_) { bytes = Buffer.alloc(0); }
  if (bytes.length < MIN_KEY_BYTES) {
    const err = new Error('Deletion-journal key är ogiltig eller för kort.');
    err.code = 'PRIVACY_JOURNAL_KEY_INVALID';
    throw err;
  }
  return raw;
}

function createKey(keyPath) {
  ensurePrivateDir(path.dirname(keyPath));
  const value = crypto.randomBytes(48).toString('base64url');
  try {
    fs.writeFileSync(keyPath, `${value}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
    return { key: readKey(keyPath), created: false };
  }
  try { fs.chmodSync(keyPath, 0o600); } catch (_) {}
  return { key: value, created: true };
}

function ensureJournalFile(journalPath, { allowCreate }) {
  ensurePrivateDir(path.dirname(journalPath));
  if (!fs.existsSync(journalPath)) {
    if (!allowCreate) {
      const err = new Error('Deletion-journal saknas trots befintlig journalnyckel.');
      err.code = 'PRIVACY_JOURNAL_MISSING';
      throw err;
    }
    fs.writeFileSync(journalPath, '', { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  }
  try { fs.chmodSync(journalPath, 0o600); } catch (_) {}
  return journalPath;
}

function ensurePrivacyMaterial({ env = process.env } = {}) {
  const { journalPath, keyPath } = configuredPaths(env);
  const keyExisted = fs.existsSync(keyPath);
  const { key, created } = createKey(keyPath);
  ensureJournalFile(journalPath, { allowCreate: created || !keyExisted });
  return { key, keyPath, journalPath, keyCreated: created };
}

function keyBuffer(key) {
  return Buffer.from(String(key), 'base64url');
}

function accountMarker({ key, accountUid }) {
  const stableUid = String(accountUid || '').trim();
  if (!stableUid) {
    const err = new Error('Stable account UID krävs för deletion marker.');
    err.code = 'PRIVACY_ACCOUNT_IDENTITY_MISSING';
    throw err;
  }
  // players.entity_uid is stable across normal backup/restore. Do not mix in
  // display names, database row ids or instance_uid; the latter could change
  // during an explicitly approved cross-instance restore.
  return crypto.createHmac('sha256', keyBuffer(key))
    .update(`bergahallen-account-v1\0${stableUid}`, 'utf8')
    .digest('hex');
}

function appendRecord(journalPath, record) {
  const safe = {
    schema_version: DELETION_TOMBSTONE_JOURNAL_SCHEMA,
    account_marker: String(record.account_marker || ''),
    deleted_at: String(record.deleted_at || new Date().toISOString()),
    deletion_receipt_id: String(record.deletion_receipt_id || ''),
    state: String(record.state || 'finalized'),
    event_at: String(record.event_at || new Date().toISOString())
  };
  if (!/^[a-f0-9]{64}$/.test(safe.account_marker)) {
    const err = new Error('Ogiltig account marker.');
    err.code = 'PRIVACY_ACCOUNT_MARKER_INVALID';
    throw err;
  }
  if (!/^[A-Za-z0-9_-]{16,128}$/.test(safe.deletion_receipt_id)) {
    const err = new Error('Ogiltigt deletion receipt id.');
    err.code = 'PRIVACY_DELETION_RECEIPT_INVALID';
    throw err;
  }
  if (!['prepared', 'finalized', 'cancelled'].includes(safe.state)) {
    const err = new Error('Ogiltigt journal state.');
    err.code = 'PRIVACY_JOURNAL_STATE_INVALID';
    throw err;
  }

  const fd = fs.openSync(journalPath, 'a', 0o600);
  try {
    fs.writeSync(fd, `${JSON.stringify(safe)}\n`, null, 'utf8');
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  try { fs.chmodSync(journalPath, 0o600); } catch (_) {}
  return safe;
}

function parseJournal(journalPath) {
  if (!fs.existsSync(journalPath)) return [];
  const text = fs.readFileSync(journalPath, 'utf8');
  const rows = [];
  for (const [index, line] of text.split(/\r?\n/).entries()) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); }
    catch (_) {
      const err = new Error(`Deletion-journal innehåller ogiltig JSON på rad ${index + 1}.`);
      err.code = 'PRIVACY_JOURNAL_CORRUPT';
      throw err;
    }
    if (Number(row.schema_version) !== DELETION_TOMBSTONE_JOURNAL_SCHEMA
        || !/^[a-f0-9]{64}$/.test(String(row.account_marker || ''))
        || !/^[A-Za-z0-9_-]{16,128}$/.test(String(row.deletion_receipt_id || ''))
        || !['prepared', 'finalized', 'cancelled'].includes(String(row.state || 'finalized'))) {
      const err = new Error(`Deletion-journal har ogiltigt schema/innehåll på rad ${index + 1}.`);
      err.code = 'PRIVACY_JOURNAL_CORRUPT';
      throw err;
    }
    rows.push({
      schema_version: DELETION_TOMBSTONE_JOURNAL_SCHEMA,
      account_marker: String(row.account_marker),
      deleted_at: String(row.deleted_at || ''),
      deletion_receipt_id: String(row.deletion_receipt_id),
      state: String(row.state || 'finalized'),
      event_at: String(row.event_at || row.deleted_at || '')
    });
  }
  return rows;
}

function activeTombstones(journalPath) {
  const latestByReceipt = new Map();
  for (const row of parseJournal(journalPath)) latestByReceipt.set(row.deletion_receipt_id, row);
  const byMarker = new Map();
  for (const row of latestByReceipt.values()) {
    if (row.state === 'cancelled') continue;
    const existing = byMarker.get(row.account_marker);
    if (!existing || String(row.event_at) >= String(existing.event_at)) byMarker.set(row.account_marker, row);
  }
  return [...byMarker.values()];
}

function permissionMode(filePath) {
  return (fs.statSync(filePath).mode & 0o777).toString(8).padStart(4, '0');
}

function diagnostics({ env = process.env } = {}) {
  const { journalPath, keyPath } = configuredPaths(env);
  const out = {
    schema_version: DELETION_TOMBSTONE_JOURNAL_SCHEMA,
    key_present: fs.existsSync(keyPath),
    journal_present: fs.existsSync(journalPath),
    key_mode: null,
    journal_mode: null,
    active_tombstones: 0,
    status: 'ok'
  };
  try {
    if (out.key_present) {
      readKey(keyPath);
      out.key_mode = permissionMode(keyPath);
    }
    if (out.journal_present) {
      out.journal_mode = permissionMode(journalPath);
      out.active_tombstones = activeTombstones(journalPath).length;
    }
    if (!out.key_present || !out.journal_present || out.key_mode !== '0600' || out.journal_mode !== '0600') out.status = 'degraded';
  } catch (err) {
    out.status = 'error';
    out.error_code = err.code || 'PRIVACY_JOURNAL_ERROR';
  }
  return out;
}

module.exports = {
  DELETION_TOMBSTONE_JOURNAL_SCHEMA,
  DEFAULT_JOURNAL_PATH,
  DEFAULT_KEY_PATH,
  configuredPaths,
  ensurePrivacyMaterial,
  accountMarker,
  appendRecord,
  parseJournal,
  activeTombstones,
  diagnostics
};
