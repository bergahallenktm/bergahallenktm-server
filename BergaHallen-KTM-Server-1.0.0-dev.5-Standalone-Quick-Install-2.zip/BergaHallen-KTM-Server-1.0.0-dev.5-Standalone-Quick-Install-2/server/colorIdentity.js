const COLOR_ORDER = ['W', 'U', 'B', 'R', 'G'];
const VALID = new Set([...COLOR_ORDER, 'C']);

function normalizeColorIdentity(input, { strict = false } = {}) {
  if (input === undefined || input === null || input === '') return null;

  const raw = Array.isArray(input) ? input.join('') : String(input);
  let normalizedText = raw.toUpperCase().trim();
  if (!normalizedText) return null;

  normalizedText = normalizedText
    .replace(/COLORLESS/g, 'C')
    .replace(/WHITE/g, 'W')
    .replace(/BLUE/g, 'U')
    .replace(/BLACK/g, 'B')
    .replace(/RED/g, 'R')
    .replace(/GREEN/g, 'G');

  const tokens = normalizedText.match(/[WUBRGC]/g) || [];
  const invalidRemainder = normalizedText.replace(/[WUBRGC\s,{}+\-/|]/g, '');
  if (strict && invalidRemainder) {
    const err = new Error('Ogiltig färgidentitet. Använd W, U, B, R, G eller C.');
    err.code = 'INVALID_COLOR_IDENTITY';
    throw err;
  }

  const found = new Set(tokens.filter(symbol => VALID.has(symbol)));
  const colored = COLOR_ORDER.filter(symbol => found.has(symbol));

  if (colored.length > 0) {
    if (strict && found.has('C')) {
      const err = new Error('Colorless (C) kan inte kombineras med W/U/B/R/G.');
      err.code = 'INVALID_COLOR_IDENTITY';
      throw err;
    }
    return colored.join('');
  }
  if (found.has('C')) return 'C';

  if (strict) {
    const err = new Error('Ogiltig färgidentitet. Välj minst en MTG-färg eller Colorless.');
    err.code = 'INVALID_COLOR_IDENTITY';
    throw err;
  }
  return null;
}

module.exports = { COLOR_ORDER, normalizeColorIdentity };
