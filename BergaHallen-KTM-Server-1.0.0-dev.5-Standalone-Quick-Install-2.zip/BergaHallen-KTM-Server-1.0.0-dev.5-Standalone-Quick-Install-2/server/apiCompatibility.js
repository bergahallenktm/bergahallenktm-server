const API_VERSION = 1;
const MIN_SUPPORTED_API_VERSION = 1;
const API_COMPATIBILITY_CONTRACT_VERSION = 1;
const ERROR_ENVELOPE_VERSION = 1;
const RETRY_POLICY_VERSION = 2;
const IDEMPOTENCY_POLICY_VERSION = 2;
const OFFLINE_RELIABILITY_CONTRACT_VERSION = 1;
const REPLAY_POLICY_VERSION = 2;

const COMPATIBILITY_POLICY = 'api_v1_additive';
const COMPATIBILITY_PATH = '/api/v1/compatibility';

// retryable=true describes whether the *failure condition* is transient. It is
// deliberately not permission to replay a mutation. Automatic replay safety is
// an endpoint property and is documented separately below.
const ERROR_ENVELOPE = Object.freeze({
  version: ERROR_ENVELOPE_VERSION,
  required_fields: Object.freeze(['success', 'code', 'message', 'retryable', 'request_id']),
  preserved_legacy_fields: Object.freeze(['error']),
  optional_fields: Object.freeze([
    'details',
    'required_permission',
    'role',
    'authorization_revision',
    'auth_state',
    'authentication_required',
    'reauth_required'
  ]),
  semantics: Object.freeze({
    success: 'false_on_error',
    code: 'stable_machine_code',
    message: 'human_readable_not_for_branching',
    retryable: 'transient_failure_only_not_auto_retry_permission',
    request_id: 'correlates_response_with_server_logs',
    http_401: 'reauth_or_authentication_required',
    http_403: 'authorization_denial_do_not_fallback_to_local_authority'
  })
});

const ENDPOINT_POLICIES = Object.freeze([
  Object.freeze({ method:'GET', path:'/api/v1/*', mutation:false, replay_policy:'safe_read' }),
  Object.freeze({ method:'POST', path:'/api/v1/matches/check-availability', mutation:false, replay_policy:'safe_read' }),
  Object.freeze({ method:'POST', path:'/api/v1/auth/login', mutation:'session_only', replay_policy:'naturally_idempotent' }),
  Object.freeze({ method:'POST', path:'/api/v1/auth/logout', mutation:'session_only', replay_policy:'naturally_idempotent' }),
  Object.freeze({ method:'POST', path:'/api/v1/auth/register', mutation:true, replay_policy:'never_auto_replay' }),
  Object.freeze({ method:'POST', path:'/api/v1/auth/locale', mutation:true, replay_policy:'revision_guarded_reconcile', concurrency_token:'expected_revision' }),
  Object.freeze({ method:'POST', path:'/api/v1/auth/card-link-preference', mutation:true, replay_policy:'naturally_idempotent' }),
  Object.freeze({ method:'POST', path:'/api/v1/account/deletion', mutation:true, replay_policy:'never_auto_replay' }),
  Object.freeze({ method:'POST', path:'/api/v1/decks', mutation:true, replay_policy:'idempotent_by_client_uid', idempotency_key:'client_uid' }),
  Object.freeze({ method:'POST', path:'/api/v1/decks/import-csv', mutation:true, replay_policy:'never_auto_replay' }),
  Object.freeze({ method:'PUT', path:'/api/v1/decks/:id', mutation:true, replay_policy:'revision_guarded_reconcile', concurrency_token:'expected_revision', stable_identity_guard:'entity_uid' }),
  Object.freeze({ method:'POST', path:'/api/v1/decks/:id/restore', mutation:true, replay_policy:'revision_guarded_reconcile', concurrency_token:'expected_revision', stable_identity_guard:'entity_uid' }),
  Object.freeze({ method:'DELETE', path:'/api/v1/decks/:id', mutation:true, replay_policy:'revision_guarded_reconcile', concurrency_token:'expected_revision', stable_identity_guard:'entity_uid' }),
  Object.freeze({ method:'POST', path:'/api/v1/matches/start', mutation:true, replay_policy:'idempotent_by_client_match_uid', idempotency_key:'client_match_uid' }),
  Object.freeze({ method:'POST', path:'/api/v1/matches/offline-sync', mutation:true, replay_policy:'idempotent_by_client_match_uid', idempotency_key:'client_match_uid' }),
  Object.freeze({ method:'POST', path:'/api/v1/matches/:id/hidden-role/reveal', mutation:false, replay_policy:'never_auto_replay' }),
  ...[
    'life','poison','tax','concede','cmdr-dmg','undo','reorder-seats','next-turn','finish','day-night','timer/pause','timer/resume',
    'hidden-role/claim-target','hidden-role/claim-throne','hidden-role/decline-throne'
  ].map(path => Object.freeze({ method:'POST', path:`/api/v1/matches/:id/${path}`, mutation:true, replay_policy:'idempotent_by_client_operation_uid', idempotency_header:'X-BergaHallen-Client-Operation-Uid', stable_identity_header:'X-BergaHallen-Expected-Match-Uid' })),
  Object.freeze({ method:'DELETE', path:'/api/v1/matches/:id/abort', mutation:true, replay_policy:'naturally_idempotent', stable_identity_header:'X-BergaHallen-Expected-Match-Uid' }),
  Object.freeze({ method:'POST', path:'/api/v1/admin/*', mutation:true, replay_policy:'never_auto_replay' }),
  Object.freeze({ method:'PUT', path:'/api/v1/admin/*', mutation:true, replay_policy:'never_auto_replay' }),
  Object.freeze({ method:'DELETE', path:'/api/v1/admin/*', mutation:true, replay_policy:'never_auto_replay' })
]);

// 3.9.14 cross-client audit: Android 3.9.14.1 consumes replay policy by
// operation key (e.g. "matches/life"). Keep endpoint_policies[] as the
// detailed normative table and expose this additive projection from the same
// source of truth so the two views cannot drift semantically.
function endpointPolicy(method, path) {
  return ENDPOINT_POLICIES.find(p => p.method === method && p.path === path) || null;
}

function replayPolicy(method, path) {
  return endpointPolicy(method, path)?.replay_policy || 'never_auto_replay';
}

const OPERATION_POLICIES = Object.freeze({
  'matches/check-availability': replayPolicy('POST', '/api/v1/matches/check-availability'),
  'auth/login': replayPolicy('POST', '/api/v1/auth/login'),
  'auth/logout': replayPolicy('POST', '/api/v1/auth/logout'),
  'auth/register': replayPolicy('POST', '/api/v1/auth/register'),
  'auth/locale': replayPolicy('POST', '/api/v1/auth/locale'),
  'auth/card-link-preference': replayPolicy('POST', '/api/v1/auth/card-link-preference'),
  'account/deletion': replayPolicy('POST', '/api/v1/account/deletion'),
  'decks/create': replayPolicy('POST', '/api/v1/decks'),
  'decks/import-csv': replayPolicy('POST', '/api/v1/decks/import-csv'),
  'decks/update': replayPolicy('PUT', '/api/v1/decks/:id'),
  'decks/restore': replayPolicy('POST', '/api/v1/decks/:id/restore'),
  'decks/delete': replayPolicy('DELETE', '/api/v1/decks/:id'),
  'matches/start': replayPolicy('POST', '/api/v1/matches/start'),
  'matches/offline-sync': replayPolicy('POST', '/api/v1/matches/offline-sync'),
  'matches/hidden-role/reveal': replayPolicy('POST', '/api/v1/matches/:id/hidden-role/reveal'),
  'matches/life': replayPolicy('POST', '/api/v1/matches/:id/life'),
  'matches/poison': replayPolicy('POST', '/api/v1/matches/:id/poison'),
  'matches/tax': replayPolicy('POST', '/api/v1/matches/:id/tax'),
  'matches/concede': replayPolicy('POST', '/api/v1/matches/:id/concede'),
  'matches/cmdr-dmg': replayPolicy('POST', '/api/v1/matches/:id/cmdr-dmg'),
  'matches/undo': replayPolicy('POST', '/api/v1/matches/:id/undo'),
  'matches/reorder-seats': replayPolicy('POST', '/api/v1/matches/:id/reorder-seats'),
  'matches/next-turn': replayPolicy('POST', '/api/v1/matches/:id/next-turn'),
  'matches/finish': replayPolicy('POST', '/api/v1/matches/:id/finish'),
  'matches/day-night': replayPolicy('POST', '/api/v1/matches/:id/day-night'),
  'matches/timer/pause': replayPolicy('POST', '/api/v1/matches/:id/timer/pause'),
  'matches/timer/resume': replayPolicy('POST', '/api/v1/matches/:id/timer/resume'),
  'matches/hidden-role/claim-target': replayPolicy('POST', '/api/v1/matches/:id/hidden-role/claim-target'),
  'matches/hidden-role/claim-throne': replayPolicy('POST', '/api/v1/matches/:id/hidden-role/claim-throne'),
  'matches/hidden-role/decline-throne': replayPolicy('POST', '/api/v1/matches/:id/hidden-role/decline-throne'),
  'matches/abort': replayPolicy('DELETE', '/api/v1/matches/:id/abort')
});

function compatibilityMeta() {
  return {
    api_compatibility_contract_version: API_COMPATIBILITY_CONTRACT_VERSION,
    error_envelope_version: ERROR_ENVELOPE_VERSION,
    retry_policy_version: RETRY_POLICY_VERSION,
    idempotency_policy_version: IDEMPOTENCY_POLICY_VERSION,
    offline_reliability_contract_version: OFFLINE_RELIABILITY_CONTRACT_VERSION,
    replay_policy_version: REPLAY_POLICY_VERSION,
    api_compatibility_policy: COMPATIBILITY_POLICY,
    api_compatibility_path: COMPATIBILITY_PATH
  };
}

function compatibilityManifest() {
  return {
    status: 'ok',
    product: 'bergahallen-ktm-server',
    api_version: API_VERSION,
    min_supported_api_version: MIN_SUPPORTED_API_VERSION,
    api_compatibility_contract_version: API_COMPATIBILITY_CONTRACT_VERSION,
    offline_reliability_contract_version: OFFLINE_RELIABILITY_CONTRACT_VERSION,
    replay_policy_version: REPLAY_POLICY_VERSION,
    policy: COMPATIBILITY_POLICY,
    compatibility: {
      old_client_new_server: 'supported_with_additive_fields_and_capabilities',
      new_client_old_server: 'client_must_evaluate_meta_and_degrade_or_block_unsupported_features',
      breaking_v1_changes: 'forbidden_without_new_api_or_contract_version',
      unknown_response_fields: 'ignore_and_preserve_server_authority',
      unknown_capabilities: 'ignore_and_do_not_enable_unknown_behavior',
      absent_additive_fields: 'use_contract_documented_legacy_fallback_only'
    },
    error_envelope: ERROR_ENVELOPE,
    retry: {
      version: RETRY_POLICY_VERSION,
      retryable_field_semantics: 'transient_failure_only_not_auto_retry_permission',
      network_failure_semantics: 'unknown_commit_state_for_mutations',
      unknown_mutation_auto_retry: 'never_auto_replay',
      replay_policy_version: REPLAY_POLICY_VERSION,
      reads: 'safe_to_retry',
      mutations: 'follow_endpoint_policy_and_reuse_the_same_idempotency_key_when_required'
    },
    idempotency: {
      version: IDEMPOTENCY_POLICY_VERSION,
      deck_create_key: 'client_uid',
      match_create_key: 'client_match_uid',
      offline_match_sync_key: 'client_match_uid',
      match_operation_header: 'X-BergaHallen-Client-Operation-Uid',
      expected_match_uid_header: 'X-BergaHallen-Expected-Match-Uid',
      revision_guard: 'expected_revision',
      deck_identity_guard: 'entity_uid',
      generic_match_delta_mutations: 'idempotent_by_client_operation_uid_when_keyed'
    },
    endpoint_policies: ENDPOINT_POLICIES,
    operations: OPERATION_POLICIES
  };
}

module.exports = {
  API_VERSION,
  MIN_SUPPORTED_API_VERSION,
  API_COMPATIBILITY_CONTRACT_VERSION,
  ERROR_ENVELOPE_VERSION,
  RETRY_POLICY_VERSION,
  IDEMPOTENCY_POLICY_VERSION,
  OFFLINE_RELIABILITY_CONTRACT_VERSION,
  REPLAY_POLICY_VERSION,
  COMPATIBILITY_POLICY,
  COMPATIBILITY_PATH,
  ERROR_ENVELOPE,
  ENDPOINT_POLICIES,
  OPERATION_POLICIES,
  compatibilityMeta,
  compatibilityManifest
};
