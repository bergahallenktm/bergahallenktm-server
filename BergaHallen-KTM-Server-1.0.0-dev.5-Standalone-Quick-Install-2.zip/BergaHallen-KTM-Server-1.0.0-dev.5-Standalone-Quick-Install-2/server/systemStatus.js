const fs = require('fs');
const path = require('path');
const os = require('os');
const packageInfo = require('../package.json');
const { API_VERSION } = require('./apiCompatibility');
const { listBackups, getBackupSettings, schedulerState } = require('./backup');
const { getLastRestoreInfo } = require('./restoreBootstrap');
const { publicPendingRestore, BACKUP_RESTORE_REPAIR_VERSION } = require('./recovery');
const logger = require('./localLogger');
const { diagnostics: privacyJournalDiagnostics } = require('./privacyDeletionJournal');
const { getActiveTlsRuntime } = require('./tlsRuntime');
const { localAddresses } = require('./networkPresentation');

function fileInfo(filePath) {
  try {
    const stat = fs.statSync(filePath);
    return { exists: true, bytes: stat.size, modified_at: stat.mtime.toISOString() };
  } catch (_) {
    return { exists: false, bytes: 0, modified_at: null };
  }
}

function scalar(db, sql, fallback = 0) {
  try {
    const row = db.prepare(sql).get();
    return Number(row?.value ?? fallback);
  } catch (_) {
    return fallback;
  }
}

function buildSystemStatus(db) {
  const port = Number(process.env.PORT || 3010);
  let quickCheck = 'unknown';
  try { quickCheck = String(db.pragma('quick_check', { simple: true }) || 'unknown'); }
  catch (err) { quickCheck = `error: ${err.message}`; }

  const dbFile = fileInfo(db.dbPath);
  const walFile = fileInfo(`${db.dbPath}-wal`);
  const shmFile = fileInfo(`${db.dbPath}-shm`);
  const backups = listBackups(db);
  const latestBackup = backups[0] || null;
  const latestBackupInfo = latestBackup ? fileInfo(latestBackup.fullPath) : null;
  const backupSettings = getBackupSettings(db);
  const backupSchedule = schedulerState(db);
  const lastRestore = getLastRestoreInfo();
  const pendingRestore = publicPendingRestore(path.dirname(db.dbPath));
  const mem = process.memoryUsage();

  const counts = {
    players: scalar(db, 'SELECT COUNT(*) AS value FROM players'),
    players_active: scalar(db, 'SELECT COUNT(*) AS value FROM players WHERE archived=0 AND is_admin=0'),
    players_archived: scalar(db, 'SELECT COUNT(*) AS value FROM players WHERE archived=1'),
    admins: scalar(db, 'SELECT COUNT(*) AS value FROM players WHERE is_admin=1'),
    decks: scalar(db, 'SELECT COUNT(*) AS value FROM decks'),
    decks_active: scalar(db, 'SELECT COUNT(*) AS value FROM decks WHERE archived=0'),
    decks_archived: scalar(db, 'SELECT COUNT(*) AS value FROM decks WHERE archived=1'),
    matches: scalar(db, 'SELECT COUNT(*) AS value FROM matches'),
    matches_active: scalar(db, "SELECT COUNT(*) AS value FROM matches WHERE status='active'"),
    matches_completed: scalar(db, "SELECT COUNT(*) AS value FROM matches WHERE status='completed'"),
    matches_aborted: scalar(db, "SELECT COUNT(*) AS value FROM matches WHERE status='aborted'"),
    offline_imported_matches: scalar(db, 'SELECT COUNT(*) AS value FROM matches WHERE imported_offline=1'),
    events: scalar(db, 'SELECT COUNT(*) AS value FROM match_events'),
    player_tombstones: scalar(db, "SELECT COUNT(*) AS value FROM sync_tombstones WHERE resource='players'"),
    deck_tombstones: scalar(db, "SELECT COUNT(*) AS value FROM sync_tombstones WHERE resource='decks'"),
    admin_audit_entries: scalar(db, 'SELECT COUNT(*) AS value FROM admin_audit_log')
  };

  return {
    status: quickCheck === 'ok' ? 'ok' : 'warning',
    generated_at: new Date().toISOString(),
    server: {
      app: 'Bergahallen KTM',
      app_version: packageInfo.version,
      api_version: API_VERSION,
      instance_uid: db.instanceUid || null,
      node_version: process.version,
      platform: `${process.platform}/${process.arch}`,
      pid: process.pid,
      port,
      uptime_seconds: Math.floor(process.uptime()),
      local_addresses: localAddresses(port, { tlsRuntime: getActiveTlsRuntime(), networkInterfaces: os.networkInterfaces() })
    },
    database: {
      health: quickCheck,
      schema_version: Number(db.schemaVersion),
      filename: path.basename(db.dbPath),
      file_bytes: dbFile.bytes,
      wal_bytes: walFile.bytes,
      shm_bytes: shmFile.bytes,
      journal_mode: String(db.pragma('journal_mode', { simple: true }) || ''),
      foreign_keys: Number(db.pragma('foreign_keys', { simple: true }) || 0) === 1,
      counts
    },
    sync: {
      players_revision: Number(db.currentSyncRevision('players')),
      decks_revision: Number(db.currentSyncRevision('decks')),
      player_tombstones: counts.player_tombstones,
      deck_tombstones: counts.deck_tombstones,
      offline_imported_matches: counts.offline_imported_matches
    },
    backup: {
      enabled: backupSettings.enabled,
      keep: backupSettings.keep,
      hour: backupSettings.hour,
      minute: backupSettings.minute,
      next_run_at: backupSchedule.next_run_at || null,
      count: backups.length,
      latest: latestBackup ? {
        name: latestBackup.name,
        created_at: new Date(latestBackup.mtimeMs).toISOString(),
        bytes: latestBackupInfo?.bytes || 0
      } : null
    },
    restore: {
      contract_version: BACKUP_RESTORE_REPAIR_VERSION,
      pending: pendingRestore,
      last: lastRestore || null
    },
    privacy_deletion: privacyJournalDiagnostics(),
    process: {
      rss_bytes: mem.rss,
      heap_used_bytes: mem.heapUsed,
      heap_total_bytes: mem.heapTotal,
      external_bytes: mem.external
    },
    logging: logger.getInfo()
  };
}

module.exports = { buildSystemStatus };
