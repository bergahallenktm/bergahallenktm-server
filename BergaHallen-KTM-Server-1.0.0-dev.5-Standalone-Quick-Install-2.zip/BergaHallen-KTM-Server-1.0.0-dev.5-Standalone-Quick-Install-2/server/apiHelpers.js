const STATUS_CODES = {
  400: 'BAD_REQUEST',
  401: 'UNAUTHORIZED',
  403: 'FORBIDDEN',
  404: 'NOT_FOUND',
  408: 'REQUEST_TIMEOUT',
  409: 'CONFLICT',
  410: 'GONE',
  413: 'PAYLOAD_TOO_LARGE',
  422: 'VALIDATION_ERROR',
  429: 'TOO_MANY_REQUESTS',
  500: 'INTERNAL_ERROR',
  503: 'SERVICE_UNAVAILABLE'
};

const RETRYABLE_CODES = new Set([
  'DATABASE_UNAVAILABLE',
  'INTERNAL_ERROR',
  'INTERNAL_SERVER_ERROR',
  'SERVICE_UNAVAILABLE',
  'SERVER_BUSY',
  'TEMPORARY_DATABASE_BUSY',
  'TOO_MANY_REQUESTS'
]);

function defaultErrorCode(status) {
  return STATUS_CODES[Number(status)] || 'API_ERROR';
}

function isRetryableError(status, code) {
  const numericStatus = Number(status || 0);
  const normalizedCode = String(code || '').toUpperCase();

  // Auth/permission/validation/conflict failures require user action or
  // reconciliation. They must never become retryable merely because a code
  // happens to be added to a transient-code list later.
  if ([400, 401, 403, 404, 409, 410, 422].includes(numericStatus)) return false;
  if (numericStatus === 429) return true;
  if (RETRYABLE_CODES.has(normalizedCode)) return true;
  return numericStatus >= 500;
}

function normalizeErrorBody(body, status, requestId = null) {
  const source = body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  const code = source.code || defaultErrorCode(status);
  const humanError = typeof source.error === 'string' && source.error !== code ? source.error : null;
  const message = source.message || humanError || 'API-anropet kunde inte genomföras.';
  return {
    ...source,
    success: false,
    code,
    message,
    retryable: source.retryable === undefined ? isRetryableError(status, code) : !!source.retryable,
    ...(requestId ? { request_id: source.request_id || requestId } : {})
  };
}

function sendError(res, status, code, message, details, options = {}) {
  const body = normalizeErrorBody({
    error: message,
    code: code || defaultErrorCode(status),
    ...(details !== undefined ? { details } : {}),
    ...(options.retryable !== undefined ? { retryable: !!options.retryable } : {})
  }, status, options.requestId || null);
  return res.status(status).json(body);
}

module.exports = { defaultErrorCode, isRetryableError, normalizeErrorBody, sendError };
