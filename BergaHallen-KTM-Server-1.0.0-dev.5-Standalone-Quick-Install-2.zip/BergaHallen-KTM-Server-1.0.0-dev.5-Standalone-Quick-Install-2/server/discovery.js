const PRODUCT = 'bergahallen-ktm-server';
const QR_TYPE = 'bergahallen-server';
const QR_VERSION = 1;
const MAX_ENDPOINTS = 8;

function discoveryError(message, code='INVALID_DISCOVERY_BASE_URL', status=400) {
  return Object.assign(new Error(message), { code, status, expose:true });
}

function normalizeBaseUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) throw discoveryError('Serveradress saknas.');

  let url;
  try { url = new URL(raw); }
  catch (_) { throw discoveryError('Serveradressen är ogiltig.'); }

  if (!['http:', 'https:'].includes(url.protocol)) {
    throw discoveryError('Serveradressen måste använda http eller https.');
  }
  if (url.username || url.password) {
    throw discoveryError('Serveradressen får inte innehålla inloggningsuppgifter.');
  }

  // API v1 currently lives at the application origin. Network locations are
  // endpoint hints only; they are never server identity.
  return url.origin;
}

function endpointValues(value) {
  if (value == null || value === '') return [];
  if (Array.isArray(value)) return value.flatMap(endpointValues);
  if (typeof value === 'object' && value.url != null) return endpointValues(value.url);
  return [String(value)];
}

function normalizeEndpoints(values, { max=MAX_ENDPOINTS } = {}) {
  const seen = new Set();
  const endpoints = [];
  for (const raw of endpointValues(values)) {
    const url = normalizeBaseUrl(raw);
    if (seen.has(url)) continue;
    seen.add(url);
    endpoints.push({ url });
    if (endpoints.length >= max) break;
  }
  return endpoints;
}

function buildProvisioning({
  endpoints=[],
  url=null,
  baseUrl=null,
  preferredUrl=null,
  requestOrigin=null,
  instanceUid,
  serverName='Bergahallen KTM',
  appVersion,
  apiVersion=1,
  discoveryContractVersion=1
}) {
  const uid = String(instanceUid || '').trim();
  if (!uid) throw discoveryError('Serverinstansen saknar instance_uid.', 'DISCOVERY_INSTANCE_UID_MISSING', 503);

  // Order is preference only. Nothing in this list is identity.
  const ordered = [];
  if (preferredUrl) ordered.push(preferredUrl);
  ordered.push(...endpointValues(endpoints));
  // Legacy input compatibility. `url`/`baseUrl` are normalized to one endpoint.
  if (url) ordered.push(url);
  if (baseUrl) ordered.push(baseUrl);
  if (requestOrigin) ordered.push(requestOrigin);

  const normalizedEndpoints = normalizeEndpoints(ordered);
  const legacyUrl = normalizedEndpoints[0]?.url || null;

  return {
    type: QR_TYPE,
    version: QR_VERSION,
    product: PRODUCT,
    server_name: String(serverName || 'Bergahallen KTM'),
    instance_uid: uid,
    endpoints: normalizedEndpoints,
    // Compatibility field for provisioning consumers. Canonical QR uses endpoints[].
    url: legacyUrl,
    api_version: Number(apiVersion || 1),
    app_version: String(appVersion || ''),
    discovery_contract_version: Number(discoveryContractVersion || 1),
    verification_path: '/api/v1/meta',
    endpoint_semantics: 'replaceable_hints',
    numeric_id_scope: 'instance_uid'
  };
}

function canonicalQrDocument(provisioning) {
  const p = buildProvisioning({
    endpoints: provisioning.endpoints,
    url: provisioning.url || null,
    baseUrl: provisioning.base_url || null,
    instanceUid: provisioning.instance_uid,
    serverName: provisioning.server_name,
    appVersion: provisioning.app_version,
    apiVersion: provisioning.api_version,
    discoveryContractVersion: provisioning.discovery_contract_version
  });

  return {
    type: QR_TYPE,
    version: QR_VERSION,
    instance_uid: p.instance_uid,
    server_name: p.server_name,
    endpoints: p.endpoints
  };
}

function buildQrPayload(provisioning) {
  return JSON.stringify(canonicalQrDocument(provisioning));
}

function safeNormalizeConfiguredUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  try { return normalizeBaseUrl(raw); }
  catch (_) { return null; }
}

function preferredUrlFromEnv(env=process.env) {
  // Preferred/legacy addresses are optional bootstrap hints, never identity.
  // A stale or malformed installer value must therefore degrade gracefully
  // instead of taking /discovery/provision and the Account QR panel down.
  const preferred = safeNormalizeConfiguredUrl(env.BERGAHALLEN_PREFERRED_URL);
  if (preferred) return preferred;
  // Legacy alias only. It is not identity and must not be required.
  return safeNormalizeConfiguredUrl(env.BERGAHALLEN_LAN_URL);
}

module.exports = {
  PRODUCT,
  QR_TYPE,
  QR_VERSION,
  MAX_ENDPOINTS,
  normalizeBaseUrl,
  normalizeEndpoints,
  buildProvisioning,
  canonicalQrDocument,
  buildQrPayload,
  safeNormalizeConfiguredUrl,
  preferredUrlFromEnv
};
