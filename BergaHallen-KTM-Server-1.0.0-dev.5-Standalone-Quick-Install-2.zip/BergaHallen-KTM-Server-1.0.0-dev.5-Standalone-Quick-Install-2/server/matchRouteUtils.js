const crypto = require('crypto');

const DAY_NIGHT_STATES = Object.freeze(['none', 'day', 'night']);

function asPositiveInt(value, fieldName) {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw new Error(`${fieldName} måste vara ett giltigt heltal.`);
  return n;
}

function asInteger(value, fieldName) {
  const n = Number(value);
  if (!Number.isInteger(n)) throw new Error(`${fieldName} måste vara ett giltigt heltal.`);
  return n;
}

function stableCanonical(value) {
  if (Array.isArray(value)) return value.map(stableCanonical);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableCanonical(value[key])]));
  }
  return value;
}

function requestFingerprint(value) {
  return crypto.createHash('sha256').update(JSON.stringify(stableCanonical(value))).digest('hex');
}

function formatDuration(seconds) {
  if (seconds === null || seconds === undefined || seconds < 0) return '0s';
  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  if (hours > 0) return `${hours}h ${mins}m ${secs}s`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

function parseCommanderDamage(raw) {
  try {
    const parsed = JSON.parse(raw || '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (_) {
    return {};
  }
}

function normalizeTeamMode(rawMode, participants = []) {
  if (rawMode === 'ffa' || rawMode === 'teams') return rawMode;
  if (rawMode !== undefined && rawMode !== null && rawMode !== '') {
    throw new Error('team_mode måste vara "ffa" eller "teams".');
  }
  const supplied = participants
    .map(p => Number(p?.team_number))
    .filter(n => Number.isInteger(n) && n > 0);
  return supplied.length > 0 && new Set(supplied).size < supplied.length ? 'teams' : 'ffa';
}

function parseMatchRules(match) {
  try {
    const parsed = JSON.parse(match?.rules_json || '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (_) {
    return {};
  }
}

function parseStringArray(raw) {
  try {
    const parsed = Array.isArray(raw) ? raw : JSON.parse(raw || '[]');
    return Array.isArray(parsed) ? parsed.filter(Boolean).map(String) : [];
  } catch (_) {
    return [];
  }
}

function normalizeDayNightState(raw, { allowNone = true, fallback = 'none' } = {}) {
  const value = raw === undefined || raw === null || raw === ''
    ? fallback
    : String(raw).trim().toLowerCase();
  if (!DAY_NIGHT_STATES.includes(value) || (!allowNone && value === 'none')) {
    const err = new Error('Day/Night state måste vara "day" eller "night".');
    err.code = 'INVALID_DAY_NIGHT_STATE';
    err.status = 422;
    throw err;
  }
  return value;
}

function dayNightStateFromCode(code) {
  const numeric = Number(code);
  if (numeric === 0) return 'none';
  if (numeric === 1) return 'day';
  if (numeric === 2) return 'night';
  const err = new Error('Ogiltig Day/Night-eventkod.');
  err.code = 'INVALID_DAY_NIGHT_STATE';
  err.status = 422;
  throw err;
}

function sqliteTimestampToMs(value) {
  if (!value) return null;
  const normalized = String(value).includes('T') ? String(value) : String(value).replace(' ', 'T') + 'Z';
  const ms = Date.parse(normalized);
  return Number.isFinite(ms) ? ms : null;
}

function sqliteTimestampToIso(value) {
  const ms = sqliteTimestampToMs(value);
  return ms === null ? null : new Date(ms).toISOString();
}

function isCanonicalUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || '').trim());
}

function firstDefined(...values) {
  return values.find(value => value !== undefined && value !== null);
}

function parseJsonObject(value, fallback = null) {
  if (value == null) return fallback;
  if (typeof value === 'object') return value;
  if (typeof value !== 'string' || !value.trim()) return fallback;
  try { return JSON.parse(value); } catch (_) { return fallback; }
}

function normalizeOfflineTimestamp(value, fallback = null) {
  if (value === undefined || value === null || value === '') return fallback;
  let date = null;
  if (typeof value === 'number' || /^\d+$/.test(String(value))) {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) date = new Date(numeric < 100000000000 ? numeric * 1000 : numeric);
  } else {
    date = new Date(String(value).includes('T') ? String(value) : String(value).replace(' ', 'T') + 'Z');
  }
  if (!date || Number.isNaN(date.getTime())) return fallback;
  return date.toISOString().replace('T', ' ').replace(/\.\d{3}Z$/, '');
}

function canonicalOfflineEventType(raw) {
  const type = String(raw || '').trim().toUpperCase().replace(/[-\s]+/g, '_');
  const aliases = {
    LIFE: 'LIFE_CHANGE',
    POISON: 'POISON_CHANGE',
    TAX: 'TAX_CHANGE',
    COMMANDER_DAMAGE: 'CMDR_DMG',
    COMMANDER_DMG: 'CMDR_DMG',
    CMDR_DAMAGE: 'CMDR_DMG',
    NEXTTURN: 'NEXT_TURN',
    PAUSE: 'PAUSE_TIMER',
    RESUME: 'RESUME_TIMER',
    REORDER: 'REORDER_SEATS',
    CONCEDE_PLAYER: 'CONCEDE',
    DAYNIGHT: 'DAY_NIGHT_CHANGE',
    DAY_NIGHT: 'DAY_NIGHT_CHANGE'
  };
  return aliases[type] || type || 'OFFLINE_EVENT';
}

function cleanHistoryFilter(value, max = 160) {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text ? text.slice(0, max) : null;
}

function normalizeHistoryDate(value, endOfDay = false) {
  const text = cleanHistoryFilter(value);
  if (!text) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return `${text} ${endOfDay ? '23:59:59' : '00:00:00'}`;
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString().slice(0,19).replace('T',' ');
}

function parseHistoryFilters(query = {}) {
  return {
    from: normalizeHistoryDate(query.from, false),
    to: normalizeHistoryDate(query.to, true),
    player_uid: cleanHistoryFilter(query.player_uid),
    deck_uid: cleanHistoryFilter(query.deck_uid),
    match_profile: cleanHistoryFilter(query.match_profile),
    deck_format: cleanHistoryFilter(query.deck_format),
    play_mode: cleanHistoryFilter(query.play_mode),
    limited_format: cleanHistoryFilter(query.limited_format),
    modifier: cleanHistoryFilter(query.modifier),
    team_mode: cleanHistoryFilter(query.team_mode),
    q: cleanHistoryFilter(query.q, 120)
  };
}

function buildHistoryWhere(filters, alias = 'm') {
  const where = [`${alias}.status='completed'`];
  const params = [];
  if (filters.from) { where.push(`${alias}.started_at >= ?`); params.push(filters.from); }
  if (filters.to) { where.push(`${alias}.started_at <= ?`); params.push(filters.to); }
  for (const key of ['match_profile','deck_format','play_mode','limited_format','team_mode']) {
    if (filters[key]) { where.push(`${alias}.${key}=?`); params.push(filters[key]); }
  }
  if (filters.modifier) {
    where.push(`${alias}.modifiers_json LIKE ?`);
    params.push(`%\"${filters.modifier.replace(/[\"%_]/g,'')}\"%`);
  }
  if (filters.player_uid) {
    where.push(`EXISTS (SELECT 1 FROM match_players hp WHERE hp.match_id=${alias}.id AND hp.player_uid=?)`);
    params.push(filters.player_uid);
  }
  if (filters.deck_uid) {
    where.push(`EXISTS (SELECT 1 FROM match_players hd WHERE hd.match_id=${alias}.id AND hd.deck_uid=?)`);
    params.push(filters.deck_uid);
  }
  if (filters.q) {
    where.push(`(
      COALESCE(${alias}.table_name,'') LIKE ? OR COALESCE(${alias}.match_type,'') LIKE ? OR
      EXISTS (SELECT 1 FROM match_players hq WHERE hq.match_id=${alias}.id AND
        (COALESCE(hq.player_name_snapshot,'') LIKE ? OR COALESCE(hq.deck_name_snapshot,'') LIKE ? OR COALESCE(hq.deck_owner_name_snapshot,'') LIKE ?))
    )`);
    const needle = `%${filters.q.replace(/[%_]/g,'')}%`;
    params.push(needle,needle,needle,needle,needle);
  }
  return { sql: where.join(' AND '), params };
}

module.exports = {
  asPositiveInt,
  asInteger,
  stableCanonical,
  requestFingerprint,
  formatDuration,
  parseCommanderDamage,
  normalizeTeamMode,
  parseMatchRules,
  parseStringArray,
  normalizeDayNightState,
  dayNightStateFromCode,
  sqliteTimestampToMs,
  sqliteTimestampToIso,
  sqliteTimestampMs: sqliteTimestampToMs,
  isCanonicalUuid,
  firstDefined,
  parseJsonObject,
  normalizeOfflineTimestamp,
  canonicalOfflineEventType,
  cleanHistoryFilter,
  normalizeHistoryDate,
  parseHistoryFilters,
  buildHistoryWhere
};
