const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const net = require('net');

const TLS_CONTRACT_VERSION = 2;
const TLS_STATE_SCHEMA_VERSION = 2;
const DEFAULT_HTTPS_PORT = 8443;
const CANONICAL_HTTPS_PORT = 443;
const DEFAULT_DIAGNOSTIC_HTTP_PORT = 3010;
const DEFAULT_DIAGNOSTIC_HTTP_HOST = '127.0.0.1';
const DEFAULT_TLS_DIR = '/etc/bergahallen-ktm/tls';
const ENDPOINT_MODES = new Set(['simple_ip', 'mdns', 'dns']);
let activeTlsRuntime = null;

function tlsError(message, code = 'TLS_CONFIGURATION_INVALID', cause) {
  const err = new Error(message);
  err.code = code;
  if (cause) err.cause = cause;
  return err;
}

function boolFromEnv(value, fallback = false) {
  if (value === undefined || value === null || String(value).trim() === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).trim().toLowerCase());
}

function resolveTlsMode(env = process.env) {
  const raw = String(env.BERGAHALLEN_TLS_MODE || '').trim().toLowerCase();
  if (raw) {
    if (['required', 'https', 'production'].includes(raw)) return 'required';
    if (['disabled', 'http', 'development', 'off'].includes(raw)) return 'disabled';
    throw tlsError(`Ogiltigt BERGAHALLEN_TLS_MODE: ${raw}`, 'TLS_MODE_INVALID');
  }
  return String(env.NODE_ENV || '').trim().toLowerCase() === 'production' ? 'required' : 'disabled';
}

// Optional mDNS convenience name. Contract v2 no longer makes this the
// production identity; Simple LAN/IP is the default supported endpoint.
function canonicalHostname(instanceUid) {
  const compact = String(instanceUid || '').trim().toLowerCase().replace(/-/g, '');
  if (!/^[0-9a-f]{8,}$/.test(compact)) {
    throw tlsError('instance_uid kan inte användas för canonical TLS-hostname.', 'TLS_INSTANCE_UID_INVALID');
  }
  return `bergahallen-ktm-${compact.slice(0, 8)}.local`;
}

function normalizeHexFingerprint(value) {
  return String(value || '').trim().toLowerCase().replace(/:/g, '');
}

function sha256Hex(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function certSha256(cert) {
  return sha256Hex(cert.raw);
}

function spkiSha256(cert) {
  const der = cert.publicKey.export({ type: 'spki', format: 'der' });
  return sha256Hex(der);
}

function assertReadableFile(filePath, label) {
  try {
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) throw new Error('not a regular file');
    fs.accessSync(filePath, fs.constants.R_OK);
    return stat;
  } catch (err) {
    throw tlsError(`${label} saknas eller kan inte läsas: ${filePath}`, 'TLS_FILE_UNREADABLE', err);
  }
}

function assertPrivateKeyMode(filePath, stat) {
  const mode = stat.mode & 0o777;
  if (mode !== 0o600) {
    throw tlsError(`TLS private key måste ha mode 0600: ${filePath} har ${mode.toString(8).padStart(4, '0')}`, 'TLS_KEY_PERMISSIONS_INVALID');
  }
}

function readUtf8(filePath, label) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    throw tlsError(`${label} kunde inte läsas: ${filePath}`, 'TLS_FILE_UNREADABLE', err);
  }
}

function parseState(filePath) {
  const raw = readUtf8(filePath, 'TLS state');
  try {
    return JSON.parse(raw);
  } catch (err) {
    throw tlsError(`TLS state är inte giltig JSON: ${filePath}`, 'TLS_STATE_INVALID', err);
  }
}

function parseX509(pem, label) {
  try {
    return new crypto.X509Certificate(pem);
  } catch (err) {
    throw tlsError(`${label} är inte ett giltigt X.509-certifikat.`, 'TLS_CERTIFICATE_INVALID', err);
  }
}

function assertCertificateCurrent(cert, label, now = new Date()) {
  const from = Date.parse(cert.validFrom);
  const to = Date.parse(cert.validTo);
  const ts = now.getTime();
  if (!Number.isFinite(from) || !Number.isFinite(to) || ts < from || ts > to) {
    throw tlsError(`${label} ligger utanför sin giltighetstid.`, 'TLS_CERTIFICATE_TIME_INVALID');
  }
}

function resolvePaths(env = process.env) {
  const dir = path.resolve(env.BERGAHALLEN_TLS_DIR || DEFAULT_TLS_DIR);
  return {
    dir,
    caCert: path.resolve(env.BERGAHALLEN_TLS_CA_FILE || path.join(dir, 'ca.crt')),
    serverCert: path.resolve(env.BERGAHALLEN_TLS_CERT_FILE || path.join(dir, 'server.crt')),
    serverKey: path.resolve(env.BERGAHALLEN_TLS_KEY_FILE || path.join(dir, 'server.key')),
    state: path.resolve(env.BERGAHALLEN_TLS_STATE_FILE || path.join(dir, 'tls-state.json'))
  };
}

function normalizeDnsName(value) {
  const name = String(value || '').trim().toLowerCase().replace(/\.$/, '');
  if (!name) return null;
  if (name.length > 253 || !/^[a-z0-9.-]+$/.test(name) || name.includes('..')) {
    throw tlsError(`Ogiltigt DNS/mDNS-namn i TLS state: ${value}`, 'TLS_ENDPOINT_INVALID');
  }
  return name;
}

function parseCanonicalHttpsUrl(value) {
  let url;
  try { url = new URL(String(value || '').trim()); }
  catch (err) { throw tlsError('TLS state canonical_https_url är ogiltig.', 'TLS_HTTPS_URL_INVALID', err); }
  if (url.protocol !== 'https:' || url.username || url.password) {
    throw tlsError('TLS state canonical_https_url måste vara en credential-fri HTTPS-adress.', 'TLS_HTTPS_URL_INVALID');
  }
  if (url.port && url.port !== String(CANONICAL_HTTPS_PORT)) {
    throw tlsError('TLS state canonical_https_url måste använda canonical HTTPS-port 443.', 'TLS_HTTPS_URL_INVALID');
  }
  if ((url.pathname && url.pathname !== '/') || url.search || url.hash) {
    throw tlsError('TLS state canonical_https_url måste peka på serverns origin utan path/query/fragment.', 'TLS_HTTPS_URL_INVALID');
  }
  return url;
}

function assertIpSan(cert, ip, label = 'selected IP') {
  if (net.isIP(ip) !== 4) {
    throw tlsError(`${label} måste vara en IPv4-adress.`, 'TLS_ENDPOINT_INVALID');
  }
  if (!cert.checkIP(ip)) {
    throw tlsError(`Servercertifikatet saknar IP SAN för ${ip}.`, 'TLS_SAN_MISMATCH');
  }
}

function assertDnsSan(cert, name, label) {
  if (!name) return;
  if (!cert.checkHost(name)) {
    throw tlsError(`Servercertifikatet saknar DNS SAN för ${label}: ${name}`, 'TLS_SAN_MISMATCH');
  }
}

function loadTlsRuntime({ env = process.env, instanceUid, now = new Date() } = {}) {
  const mode = resolveTlsMode(env);
  const httpsPort = Number(env.HTTPS_PORT || env.BERGAHALLEN_HTTPS_PORT || DEFAULT_HTTPS_PORT);
  const diagnosticHttpPort = Number(env.PORT || env.BERGAHALLEN_DIAGNOSTIC_HTTP_PORT || DEFAULT_DIAGNOSTIC_HTTP_PORT);
  const diagnosticHttpHost = String(env.BERGAHALLEN_DIAGNOSTIC_HTTP_HOST || DEFAULT_DIAGNOSTIC_HTTP_HOST).trim();
  const diagnosticHttpEnabled = boolFromEnv(env.BERGAHALLEN_DIAGNOSTIC_HTTP_ENABLED, true);

  if (!Number.isInteger(httpsPort) || httpsPort < 1 || httpsPort > 65535) {
    throw tlsError('HTTPS-porten är ogiltig.', 'TLS_PORT_INVALID');
  }
  if (!Number.isInteger(diagnosticHttpPort) || diagnosticHttpPort < 1 || diagnosticHttpPort > 65535) {
    throw tlsError('Diagnostik-HTTP-porten är ogiltig.', 'TLS_DIAGNOSTIC_PORT_INVALID');
  }

  if (mode === 'disabled') {
    return Object.freeze({
      mode,
      httpsRequired: false,
      tlsContract: TLS_CONTRACT_VERSION,
      tlsStateSchema: TLS_STATE_SCHEMA_VERSION,
      httpsPort,
      canonicalHttpsPort: CANONICAL_HTTPS_PORT,
      diagnosticHttpEnabled: true,
      diagnosticHttpPort,
      diagnosticHttpHost: String(env.HOST || '0.0.0.0'),
      endpointMode: null,
      selectedIp: null,
      canonicalHostname: null,
      canonicalHttpsUrl: null,
      optionalMdnsName: null,
      optionalDnsName: null,
      caSpkiSha256: null,
      tlsOptions: null,
      paths: resolvePaths(env)
    });
  }

  const paths = resolvePaths(env);
  const keyStat = assertReadableFile(paths.serverKey, 'TLS server private key');
  assertPrivateKeyMode(paths.serverKey, keyStat);
  assertReadableFile(paths.serverCert, 'TLS server certificate');
  assertReadableFile(paths.caCert, 'TLS CA certificate');
  assertReadableFile(paths.state, 'TLS state');

  const keyPem = readUtf8(paths.serverKey, 'TLS server private key');
  const certPem = readUtf8(paths.serverCert, 'TLS server certificate');
  const caPem = readUtf8(paths.caCert, 'TLS CA certificate');
  const state = parseState(paths.state);

  if (Number(state.schema_version) !== TLS_STATE_SCHEMA_VERSION) {
    throw tlsError(`TLS state schema ${state.schema_version} stöds inte.`, 'TLS_STATE_SCHEMA_UNSUPPORTED');
  }
  if (String(state.instance_uid || '') !== String(instanceUid || '')) {
    throw tlsError('TLS state instance_uid matchar inte Server-installationen.', 'TLS_INSTANCE_UID_MISMATCH');
  }

  const endpointMode = String(state.endpoint_mode || '').trim().toLowerCase();
  if (!ENDPOINT_MODES.has(endpointMode)) {
    throw tlsError(`TLS state endpoint_mode stöds inte: ${endpointMode || '(saknas)'}`, 'TLS_ENDPOINT_MODE_UNSUPPORTED');
  }
  const canonicalUrl = parseCanonicalHttpsUrl(state.canonical_https_url);
  const selectedIp = String(state.selected_ip || '').trim();
  const optionalMdnsName = normalizeDnsName(state.optional_mdns_name);
  const optionalDnsName = normalizeDnsName(state.optional_dns_name);

  if (net.isIP(selectedIp) !== 4) {
    throw tlsError('TLS state selected_ip måste vara en IPv4-adress.', 'TLS_ENDPOINT_INVALID');
  }

  if (endpointMode === 'simple_ip') {
    if (canonicalUrl.hostname !== selectedIp) {
      throw tlsError('TLS state canonical_https_url matchar inte selected_ip i simple_ip-läge.', 'TLS_HTTPS_URL_MISMATCH');
    }
  } else if (endpointMode === 'mdns') {
    if (!optionalMdnsName || canonicalUrl.hostname.toLowerCase() !== optionalMdnsName) {
      throw tlsError('TLS state canonical_https_url matchar inte optional_mdns_name.', 'TLS_HTTPS_URL_MISMATCH');
    }
  } else if (endpointMode === 'dns') {
    if (!optionalDnsName || canonicalUrl.hostname.toLowerCase() !== optionalDnsName) {
      throw tlsError('TLS state canonical_https_url matchar inte optional_dns_name.', 'TLS_HTTPS_URL_MISMATCH');
    }
  }

  const caCert = parseX509(caPem, 'TLS CA certificate');
  const serverCert = parseX509(certPem, 'TLS server certificate');
  assertCertificateCurrent(caCert, 'TLS CA certificate', now);
  assertCertificateCurrent(serverCert, 'TLS server certificate', now);

  if (!caCert.ca) {
    throw tlsError('Konfigurerat CA-certifikat är inte markerat som CA.', 'TLS_CA_INVALID');
  }
  if (!serverCert.checkIssued(caCert) || !serverCert.verify(caCert.publicKey)) {
    throw tlsError('Servercertifikatet är inte signerat av den konfigurerade CA:n.', 'TLS_CHAIN_INVALID');
  }

  // Contract v2: selected LAN IP is always a supported endpoint, even when
  // optional mDNS/DNS is selected as the canonical convenience URL.
  assertIpSan(serverCert, selectedIp);
  if (optionalMdnsName) assertDnsSan(serverCert, optionalMdnsName, 'optional_mdns_name');
  if (optionalDnsName) assertDnsSan(serverCert, optionalDnsName, 'optional_dns_name');

  let privateKey;
  try {
    privateKey = crypto.createPrivateKey(keyPem);
  } catch (err) {
    throw tlsError('TLS server private key kan inte tolkas.', 'TLS_PRIVATE_KEY_INVALID', err);
  }
  if (!serverCert.checkPrivateKey(privateKey)) {
    throw tlsError('TLS server private key matchar inte servercertifikatet.', 'TLS_KEY_CERT_MISMATCH');
  }

  const caSpki = spkiSha256(caCert);
  const stateSpki = normalizeHexFingerprint(state.tls_ca_spki_sha256);
  if (!/^[0-9a-f]{64}$/.test(stateSpki) || stateSpki !== caSpki) {
    throw tlsError('TLS state CA SPKI SHA-256 matchar inte det faktiska CA-certifikatet.', 'TLS_CA_FINGERPRINT_MISMATCH');
  }

  const stateCaCertSha = normalizeHexFingerprint(state.ca_cert_sha256);
  if (stateCaCertSha && stateCaCertSha !== certSha256(caCert)) {
    throw tlsError('TLS state CA certificate SHA-256 matchar inte.', 'TLS_CA_CERT_FINGERPRINT_MISMATCH');
  }
  const stateLeafSha = normalizeHexFingerprint(state.leaf_cert_sha256);
  if (stateLeafSha && stateLeafSha !== certSha256(serverCert)) {
    throw tlsError('TLS state leaf certificate SHA-256 matchar inte.', 'TLS_LEAF_FINGERPRINT_MISMATCH');
  }

  const canonicalHost = net.isIP(canonicalUrl.hostname) ? null : canonicalUrl.hostname.toLowerCase();

  return Object.freeze({
    mode,
    httpsRequired: true,
    tlsContract: TLS_CONTRACT_VERSION,
    tlsStateSchema: TLS_STATE_SCHEMA_VERSION,
    httpsPort,
    canonicalHttpsPort: CANONICAL_HTTPS_PORT,
    diagnosticHttpEnabled,
    diagnosticHttpPort,
    diagnosticHttpHost,
    endpointMode,
    selectedIp,
    canonicalHostname: canonicalHost,
    canonicalHttpsUrl: canonicalUrl.origin,
    optionalMdnsName,
    optionalDnsName,
    caSpkiSha256: caSpki,
    paths,
    state,
    // Present leaf + local CA certificate. The CA private key is never read by Server.
    tlsOptions: Object.freeze({ key: keyPem, cert: `${certPem.trim()}\n${caPem.trim()}\n` })
  });
}

function publicTlsMetadata(runtime) {
  if (!runtime?.httpsRequired) {
    return {
      tls_contract: TLS_CONTRACT_VERSION,
      tls_state_schema: TLS_STATE_SCHEMA_VERSION,
      https_required: false,
      canonical_https_port: CANONICAL_HTTPS_PORT,
      canonical_https_url: null,
      canonical_hostname: null,
      tls_endpoint_mode: null,
      tls_ca_spki_sha256: null,
      tls_runtime_mode: 'development_cleartext'
    };
  }
  return {
    tls_contract: TLS_CONTRACT_VERSION,
    tls_state_schema: TLS_STATE_SCHEMA_VERSION,
    https_required: true,
    canonical_https_port: runtime.canonicalHttpsPort,
    canonical_https_url: runtime.canonicalHttpsUrl,
    canonical_hostname: runtime.canonicalHostname,
    tls_endpoint_mode: runtime.endpointMode,
    tls_ca_spki_sha256: runtime.caSpkiSha256,
    tls_runtime_mode: 'https_required'
  };
}

function setActiveTlsRuntime(runtime) {
  activeTlsRuntime = runtime || null;
}

function getActiveTlsRuntime() {
  return activeTlsRuntime;
}

module.exports = {
  TLS_CONTRACT_VERSION,
  TLS_STATE_SCHEMA_VERSION,
  DEFAULT_HTTPS_PORT,
  CANONICAL_HTTPS_PORT,
  DEFAULT_DIAGNOSTIC_HTTP_PORT,
  DEFAULT_DIAGNOSTIC_HTTP_HOST,
  DEFAULT_TLS_DIR,
  resolveTlsMode,
  canonicalHostname,
  normalizeHexFingerprint,
  spkiSha256,
  loadTlsRuntime,
  publicTlsMetadata,
  setActiveTlsRuntime,
  getActiveTlsRuntime
};
