const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const logger = require('./localLogger');
const { inspectDatabaseFile, verifyDatabaseFile, sha256File } = require('./recovery');

const DEFAULT_KEEP = 14;
const DEFAULT_HOUR = 3;
const DEFAULT_MINUTE = 0;
const PENDING_RESTORE_FILENAME = 'restore_pending.db';
const PENDING_RESTORE_MANIFEST = 'restore_pending.json';

let activeScheduler = null;

function backupDirectory(db) {
  return path.join(path.dirname(db.dbPath), 'backups');
}

function dataDirectory(db) {
  return path.dirname(db.dbPath);
}

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isInteger(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function boolValue(value, fallback = true) {
  if (value == null || value === '') return fallback;
  return String(value).toLowerCase() !== 'false' && String(value) !== '0';
}

function safeBackupName(name) {
  const value = String(name || '');
  if (!/^mtg_tracker_[A-Za-z0-9_.-]+\.db$/.test(value)) {
    const err = new Error('Ogiltigt backupnamn.');
    err.status = 400;
    err.code = 'INVALID_BACKUP_NAME';
    err.expose = true;
    throw err;
  }
  return value;
}

function backupPathByName(db, name) {
  return path.join(backupDirectory(db), safeBackupName(name));
}

function backupReason(value) {
  return String(value || 'manual')
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40) || 'manual';
}

function getBackupSettings(db) {
  const envEnabled = boolValue(process.env.BACKUP_ENABLED, true);
  const envKeep = clampInt(process.env.BACKUP_KEEP, 1, 100, DEFAULT_KEEP);
  const envHour = clampInt(process.env.BACKUP_HOUR, 0, 23, DEFAULT_HOUR);
  const envMinute = clampInt(process.env.BACKUP_MINUTE, 0, 59, DEFAULT_MINUTE);

  const get = typeof db.getSetting === 'function'
    ? key => db.getSetting(key)
    : () => null;

  return {
    enabled: boolValue(get('backup_enabled'), envEnabled),
    keep: clampInt(get('backup_keep'), 1, 100, envKeep),
    hour: clampInt(get('backup_hour'), 0, 23, envHour),
    minute: clampInt(get('backup_minute'), 0, 59, envMinute)
  };
}

function updateBackupSettings(db, { enabled, keep, hour, minute }) {
  if (typeof db.setSetting !== 'function') {
    throw new Error('Databasen saknar system_settings-stöd.');
  }
  const normalized = {
    enabled: !!enabled,
    keep: clampInt(keep, 1, 100, DEFAULT_KEEP),
    hour: clampInt(hour, 0, 23, DEFAULT_HOUR),
    minute: clampInt(minute, 0, 59, DEFAULT_MINUTE)
  };
  db.setSetting('backup_enabled', normalized.enabled ? 'true' : 'false');
  db.setSetting('backup_keep', String(normalized.keep));
  db.setSetting('backup_hour', String(normalized.hour));
  db.setSetting('backup_minute', String(normalized.minute));
  pruneBackups(db, normalized.keep);
  return normalized;
}

function inspectBackupFile(fullPath, { full = false, includeHash = false } = {}) {
  const info = inspectDatabaseFile(fullPath, { full, includeHash });
  return {
    health: info.quick_check || 'unknown',
    integrity_check: info.integrity_check,
    foreign_key_issues: info.foreign_key_issues,
    schema_version: info.schema_version,
    instance_uid: info.instance_uid,
    players: info.counts?.players ?? null,
    decks: info.counts?.decks ?? null,
    matches: info.counts?.matches ?? null,
    required_tables_ok: !!info.required_tables_ok,
    sha256: info.sha256 || null,
    file_mode: info.file_mode ?? null
  };
}

function listBackups(db, { inspect = false } = {}) {
  const dir = backupDirectory(db);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(name => name.startsWith('mtg_tracker_') && name.endsWith('.db'))
    .map(name => {
      const fullPath = path.join(dir, name);
      const stat = fs.statSync(fullPath);
      const basic = {
        name,
        fullPath,
        mtimeMs: stat.mtimeMs,
        bytes: stat.size
      };
      return inspect ? { ...basic, ...inspectBackupFile(fullPath) } : basic;
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);
}

function pruneBackups(db, keep = DEFAULT_KEEP) {
  const normalizedKeep = clampInt(keep, 1, 100, DEFAULT_KEEP);
  const backups = listBackups(db);
  for (const old of backups.slice(normalizedKeep)) {
    try {
      fs.unlinkSync(old.fullPath);
      logger.info('database', 'Old backup removed by retention', { backup_name: old.name });
    } catch (err) {
      console.warn(`⚠️ Kunde inte radera gammal backup ${old.name}: ${err.message}`);
      logger.warn('database', 'Could not remove old backup', { backup_name: old.name, error: err.message });
    }
  }
}

async function createBackup(db, { keep, force = false, reason = 'manual' } = {}) {
  const settings = getBackupSettings(db);
  const normalizedKeep = clampInt(keep, 1, 100, settings.keep);
  const dir = backupDirectory(db);
  fs.mkdirSync(dir, { recursive: true });

  const existing = listBackups(db);
  if (!force && existing[0] && Date.now() - existing[0].mtimeMs < 20 * 60 * 60 * 1000) {
    return { skipped: true, path: existing[0].fullPath, reason: 'recent_backup_exists' };
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const suffix = backupReason(reason);
  const destination = path.join(dir, `mtg_tracker_${stamp}_${suffix}.db`);
  await db.backup(destination);
  try { fs.chmodSync(destination, 0o600); } catch (_) {}

  let verification;
  try {
    verification = verifyDatabaseFile(destination, {
      schema_version: db.schemaVersion,
      instance_uid: db.instanceUid || null
    });
  } catch (err) {
    try { fs.unlinkSync(destination); } catch (_) {}
    logger.error('database', 'Database backup verification failed', {
      backup_name: path.basename(destination),
      reason: suffix,
      error: err.message,
      code: err.code || null
    });
    throw err;
  }

  logger.info('database', 'Database backup created and verified', {
    backup_name: path.basename(destination),
    forced: !!force,
    reason: suffix,
    schema_version: verification.schema_version,
    sha256: verification.sha256
  });

  pruneBackups(db, normalizedKeep);
  return {
    skipped: false,
    path: destination,
    reason: suffix,
    verification: {
      schema_version: verification.schema_version,
      instance_uid: verification.instance_uid,
      integrity_check: verification.integrity_check,
      foreign_key_issues: verification.foreign_key_issues,
      sha256: verification.sha256
    }
  };
}

function nextRunAt(settings, now = new Date()) {
  if (!settings.enabled) return null;
  const next = new Date(now);
  next.setHours(settings.hour, settings.minute, 0, 0);
  if (next.getTime() <= now.getTime()) next.setDate(next.getDate() + 1);
  return next;
}

function scheduleDailyBackups(db) {
  let timer = null;
  let stopped = false;
  let nextRun = null;

  const clear = () => {
    if (timer) clearTimeout(timer);
    timer = null;
    nextRun = null;
  };

  const arm = () => {
    clear();
    if (stopped) return;
    const settings = getBackupSettings(db);
    if (!settings.enabled) {
      console.log('ℹ️ Automatiska databasbackuper är avstängda.');
      return;
    }

    const next = nextRunAt(settings);
    nextRun = next;
    const delay = Math.max(1000, next.getTime() - Date.now());
    console.log(`💾 Nästa automatiska backup: ${next.toISOString()} (serverns lokala klocka ${String(settings.hour).padStart(2,'0')}:${String(settings.minute).padStart(2,'0')})`);

    timer = setTimeout(async () => {
      try {
        const current = getBackupSettings(db);
        const result = await createBackup(db, { keep: current.keep, force: true, reason: 'automatic' });
        console.log(`💾 Automatisk databasbackup skapad: ${result.path}`);
      } catch (err) {
        console.error('❌ Automatisk databasbackup misslyckades:', err);
        logger.error('database', 'Automatic database backup failed', { error: err.message });
      } finally {
        arm();
      }
    }, delay);
    timer.unref();
  };

  const scheduler = {
    reschedule() {
      stopped = false;
      arm();
    },
    stop() {
      stopped = true;
      clear();
    },
    state() {
      return {
        ...getBackupSettings(db),
        next_run_at: nextRun ? nextRun.toISOString() : null
      };
    }
  };

  activeScheduler = scheduler;
  arm();
  return scheduler;
}

function rescheduleDailyBackups() {
  activeScheduler?.reschedule();
  return activeScheduler?.state() || null;
}

function schedulerState(db) {
  return activeScheduler?.state() || {
    ...getBackupSettings(db),
    next_run_at: nextRunAt(getBackupSettings(db))?.toISOString() || null
  };
}

function validateBackupForRestore(db, name) {
  const fullPath = backupPathByName(db, name);
  if (!fs.existsSync(fullPath)) {
    const err = new Error('Backupfilen finns inte.');
    err.status = 404;
    err.code = 'BACKUP_NOT_FOUND';
    err.expose = true;
    throw err;
  }
  const info = inspectBackupFile(fullPath, { full: true, includeHash: true });
  if (info.health !== 'ok' || info.integrity_check !== 'ok' || Number(info.foreign_key_issues || 0) !== 0 || !info.required_tables_ok) {
    const err = new Error(`Backupfilen klarade inte full SQLite/recovery-verifiering (${info.health}).`);
    err.status = 422;
    err.code = 'BACKUP_INVALID';
    err.expose = true;
    throw err;
  }
  return { fullPath, info };
}

function buildRestorePlan(db, name) {
  const selectedName = safeBackupName(name);
  const { fullPath, info } = validateBackupForRestore(db, selectedName);
  const sourceSchema = Number(info.schema_version || 0);
  const targetSchema = Number(db.schemaVersion || 0);
  const sameInstance = info.instance_uid && db.instanceUid
    ? info.instance_uid === db.instanceUid
    : null;
  return {
    backup: selectedName,
    source_schema_version: sourceSchema,
    target_schema_version: targetSchema,
    source_instance_uid: info.instance_uid || null,
    current_instance_uid: db.instanceUid || null,
    same_instance: sameInstance,
    cross_instance_restore: sameInstance === false,
    migration_after_restore_required: sourceSchema < targetSchema,
    compatible: sourceSchema <= targetSchema,
    verification: {
      quick_check: info.health,
      integrity_check: info.integrity_check,
      foreign_key_issues: info.foreign_key_issues,
      required_tables_ok: info.required_tables_ok,
      sha256: info.sha256
    },
    counts: {
      players: info.players,
      decks: info.decks,
      matches: info.matches
    },
    fullPath
  };
}

async function stageRestore(db, name, { keep, allowCrossInstance = false } = {}) {
  const plan = buildRestorePlan(db, name);
  const selectedName = plan.backup;
  const fullPath = plan.fullPath;
  const info = {
    schema_version: plan.source_schema_version,
    instance_uid: plan.source_instance_uid,
    health: plan.verification.quick_check,
    integrity_check: plan.verification.integrity_check,
    foreign_key_issues: plan.verification.foreign_key_issues,
    required_tables_ok: plan.verification.required_tables_ok,
    sha256: plan.verification.sha256,
    players: plan.counts.players,
    decks: plan.counts.decks,
    matches: plan.counts.matches
  };
  if (plan.cross_instance_restore && !allowCrossInstance) {
    const err = new Error('Backupen tillhör en annan serveridentitet. Cross-instance restore kräver explicit godkännande.');
    err.status = 409;
    err.code = 'CROSS_INSTANCE_RESTORE_CONFIRMATION_REQUIRED';
    err.expose = true;
    err.details = { source_instance_uid: plan.source_instance_uid, current_instance_uid: plan.current_instance_uid };
    throw err;
  }
  if (Number(info.schema_version || 0) > Number(db.schemaVersion || 0)) {
    const err = new Error(`Backupen använder schema v${info.schema_version}, men servern stödjer endast v${db.schemaVersion}. Uppgradera servern innan restore.`);
    err.status = 409;
    err.code = 'BACKUP_SCHEMA_TOO_NEW';
    err.expose = true;
    throw err;
  }
  const dir = dataDirectory(db);
  const pending = path.join(dir, PENDING_RESTORE_FILENAME);
  const pendingTmp = `${pending}.tmp`;
  const manifestPath = path.join(dir, PENDING_RESTORE_MANIFEST);
  const manifestTmp = `${manifestPath}.tmp`;

  if (fs.existsSync(pending) || fs.existsSync(manifestPath)) {
    const err = new Error('En restore är redan staged. Starta om servern eller slutför recovery innan en ny restore startas.');
    err.status = 409;
    err.code = 'RESTORE_ALREADY_PENDING';
    err.expose = true;
    throw err;
  }
  for (const stale of [pendingTmp, manifestTmp]) {
    try { if (fs.existsSync(stale)) fs.unlinkSync(stale); } catch (_) {}
  }

  // Kopiera vald backup först. En pre-restore-backup kan trigga retention och
  // får därför inte kunna radera källfilen innan den är staged.
  fs.copyFileSync(fullPath, pendingTmp);
  try { fs.chmodSync(pendingTmp, 0o600); } catch (_) {}
  const stagedVerification = verifyDatabaseFile(pendingTmp, {
    schema_version: info.schema_version,
    instance_uid: info.instance_uid || null,
    sha256: info.sha256
  });

  const settings = getBackupSettings(db);
  const safety = await createBackup(db, {
    keep: clampInt(keep, 1, 100, settings.keep),
    force: true,
    reason: 'pre-restore'
  });

  const safetyVerification = safety.verification || verifyDatabaseFile(safety.path, {
    schema_version: db.schemaVersion,
    instance_uid: db.instanceUid || null
  });

  const manifest = {
    format_version: 2,
    requested_at: new Date().toISOString(),
    source_backup: selectedName,
    source_schema_version: info.schema_version,
    source_instance_uid: info.instance_uid,
    current_instance_uid_before_restore: db.instanceUid || null,
    cross_instance_restore: plan.cross_instance_restore,
    staged_sha256: stagedVerification.sha256,
    pre_restore_backup: path.basename(safety.path),
    pre_restore_backup_sha256: safetyVerification.sha256 || sha256File(safety.path)
  };
  fs.writeFileSync(manifestTmp, `${JSON.stringify(manifest, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(manifestTmp, 0o600); } catch (_) {}
  fs.renameSync(pendingTmp, pending);
  fs.renameSync(manifestTmp, manifestPath);
  try { fs.chmodSync(pending, 0o600); fs.chmodSync(manifestPath, 0o600); } catch (_) {}

  logger.warn('database', 'Database restore staged', {
    backup_name: selectedName,
    source_schema_version: info.schema_version,
    source_instance_uid: info.instance_uid,
    pre_restore_backup: manifest.pre_restore_backup
  });

  return {
    restore_staged: true,
    backup: selectedName,
    source: info,
    pre_restore_backup: manifest.pre_restore_backup,
    cross_instance_restore: plan.cross_instance_restore,
    restart_required: true
  };
}

module.exports = {
  createBackup,
  scheduleDailyBackups,
  rescheduleDailyBackups,
  schedulerState,
  listBackups,
  inspectBackupFile,
  backupDirectory,
  backupPathByName,
  getBackupSettings,
  updateBackupSettings,
  pruneBackups,
  stageRestore,
  buildRestorePlan,
  safeBackupName,
  PENDING_RESTORE_FILENAME,
  PENDING_RESTORE_MANIFEST
};
