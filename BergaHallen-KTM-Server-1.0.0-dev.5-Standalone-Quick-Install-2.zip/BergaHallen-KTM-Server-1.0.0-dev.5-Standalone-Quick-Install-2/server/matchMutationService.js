'use strict';

function httpError(status, code, message) {
  const err = new Error(message);
  err.status = status;
  err.code = code;
  return err;
}

function deriveNextTurnPlan(match, players) {
  const activePlayers = players.filter(p => !p.is_eliminated);
  if (activePlayers.length <= 1) return null;

  const groups = [];
  for (const p of players) {
    const group = Number(p.turn_group ?? p.seat_index + 1);
    if (!groups.includes(group) && players.some(x => !x.is_eliminated && Number(x.turn_group ?? x.seat_index + 1) === group)) groups.push(group);
  }
  if (groups.length <= 1) return null;

  const currentGroup = Number(match.active_turn_group ?? players[Number(match.active_player_index)]?.turn_group ?? groups[0]);
  let groupIndex = groups.indexOf(currentGroup);
  if (groupIndex < 0) groupIndex = 0;
  const nextGroupIndex = (groupIndex + 1) % groups.length;
  const nextGroup = groups[nextGroupIndex];
  const nextIndex = players.findIndex(p => !p.is_eliminated && Number(p.turn_group ?? p.seat_index + 1) === nextGroup);
  if (nextIndex < 0) return null;

  return {
    currentGroup,
    nextGroup,
    nextIndex,
    newRound: nextGroupIndex <= groupIndex ? Number(match.current_round || 1) + 1 : Number(match.current_round || 1),
    groupMembers: players.filter(p => !p.is_eliminated && Number(p.turn_group ?? p.seat_index + 1) === nextGroup)
  };
}

function createMatchMutationService({
  db,
  fetchMatch,
  mutationMatchState,
  refreshPlayerElimination,
  refreshMatchWinner,
  setTeamEliminated,
  closeCurrentTurn,
  logTurnStart
}) {
  if (!db || typeof db.prepare !== 'function' || typeof db.transaction !== 'function') {
    throw new TypeError('createMatchMutationService kräver en db-adapter.');
  }

  function requireActiveMatchPlayer(matchId, playerId) {
    const match = fetchMatch(matchId, true);
    const player = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(matchId, playerId);
    if (!match || !player) {
      throw httpError(404, 'MATCH_PLAYER_NOT_FOUND', 'Aktiv match eller spelare saknas.');
    }
    return { match, player };
  }

  function changeLife(matchId, playerId, change) {
    const { match, player } = requireActiveMatchPlayer(matchId, playerId);
    const rules = match.rules || {};
    let newLife;

    db.transaction(() => {
      if (rules.life_scope === 'team') {
        const team = db.prepare('SELECT * FROM match_teams WHERE match_id=? AND team_number=?').get(matchId, player.team_number);
        const previous = Number(team?.current_life ?? player.current_life);
        newLife = previous + change;
        db.prepare('UPDATE match_teams SET current_life=? WHERE match_id=? AND team_number=?').run(newLife, matchId, player.team_number);
        db.prepare('UPDATE match_players SET current_life=? WHERE match_id=? AND team_number=?').run(newLife, matchId, player.team_number);
        db.prepare(`INSERT INTO match_events (match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json) VALUES (?,?,'LIFE_CHANGE',?,?,?,?,?)`)
          .run(matchId, playerId, change, previous, newLife, match.current_round, JSON.stringify({ scope:'team', team_number:Number(player.team_number) }));
        refreshPlayerElimination(matchId, playerId);
      } else {
        newLife = Number(player.current_life) + change;
        db.prepare('UPDATE match_players SET current_life=? WHERE match_id=? AND player_id=?').run(newLife, matchId, playerId);
        db.prepare(`INSERT INTO match_events (match_id,player_id,event_type,change_value,prev_value,new_value,round_number) VALUES (?,?,'LIFE_CHANGE',?,?,?,?)`)
          .run(matchId, playerId, change, player.current_life, newLife, match.current_round);
        refreshPlayerElimination(matchId, playerId);
      }
      refreshMatchWinner(matchId);
    })();

    const updated = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(matchId, playerId);
    return { success:true, newLife, isEliminated:!!updated.is_eliminated, eliminated_reason:updated.eliminated_reason, ...mutationMatchState(matchId) };
  }

  function changePoison(matchId, playerId, change) {
    const { match, player } = requireActiveMatchPlayer(matchId, playerId);
    const rules = match.rules || {};
    let newPoison;

    db.transaction(() => {
      if (rules.poison_scope === 'team') {
        const team = db.prepare('SELECT * FROM match_teams WHERE match_id=? AND team_number=?').get(matchId, player.team_number);
        const previous = Number(team?.poison_counters ?? player.poison_counters ?? 0);
        newPoison = Math.max(0, previous + change);
        db.prepare('UPDATE match_teams SET poison_counters=? WHERE match_id=? AND team_number=?').run(newPoison, matchId, player.team_number);
        db.prepare('UPDATE match_players SET poison_counters=? WHERE match_id=? AND team_number=?').run(newPoison, matchId, player.team_number);
        db.prepare(`INSERT INTO match_events (match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json) VALUES (?,?,'POISON_CHANGE',?,?,?,?,?)`)
          .run(matchId, playerId, change, previous, newPoison, match.current_round, JSON.stringify({ scope:'team', team_number:Number(player.team_number), threshold:Number(rules.poison_loss_threshold || 10) }));
      } else {
        const previous = Number(player.poison_counters || 0);
        newPoison = Math.max(0, previous + change);
        db.prepare('UPDATE match_players SET poison_counters=? WHERE match_id=? AND player_id=?').run(newPoison, matchId, playerId);
        db.prepare(`INSERT INTO match_events (match_id,player_id,event_type,change_value,prev_value,new_value,round_number) VALUES (?,?,'POISON_CHANGE',?,?,?,?)`)
          .run(matchId, playerId, change, previous, newPoison, match.current_round);
      }
      refreshPlayerElimination(matchId, playerId);
      refreshMatchWinner(matchId);
    })();

    const updated = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(matchId, playerId);
    return { success:true, poison_counters:newPoison, isEliminated:!!updated.is_eliminated, eliminated_reason:updated.eliminated_reason, ...mutationMatchState(matchId) };
  }

  function changeTax(matchId, playerId, change) {
    const { match, player } = requireActiveMatchPlayer(matchId, playerId);
    const previous = Number(player.commander_tax || 0);
    const newTax = Math.max(0, previous + change);
    db.transaction(() => {
      db.prepare('UPDATE match_players SET commander_tax=? WHERE match_id=? AND player_id=?').run(newTax, matchId, playerId);
      db.prepare(`INSERT INTO match_events (match_id,player_id,event_type,change_value,prev_value,new_value,round_number) VALUES (?,?,'TAX_CHANGE',?,?,?,?)`)
        .run(matchId, playerId, change, previous, newTax, match.current_round);
    })();
    return { success:true, commander_tax:newTax, ...mutationMatchState(matchId) };
  }

  function concede(matchId, playerId) {
    const { match, player } = requireActiveMatchPlayer(matchId, playerId);
    db.transaction(() => {
      if (match.rules?.play_mode === 'two_headed_giant') {
        setTeamEliminated(matchId, Number(player.team_number), true, 'Conceded');
      } else {
        db.prepare("UPDATE match_players SET is_eliminated=1, eliminated_reason='Conceded' WHERE match_id=? AND player_id=?").run(matchId, playerId);
      }
      db.prepare(`INSERT INTO match_events (match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json) VALUES (?,?,'CONCEDE',0,0,1,?,?)`)
        .run(matchId, playerId, match.current_round, JSON.stringify({ scope:match.rules?.play_mode === 'two_headed_giant' ? 'team' : 'player', team_number:Number(player.team_number) }));
      refreshMatchWinner(matchId);
    })();
    return { success:true, ...mutationMatchState(matchId) };
  }

  function nextTurn(matchId) {
    const match = fetchMatch(matchId, true);
    if (!match) throw httpError(404, 'MATCH_NOT_FOUND', 'Aktiv match saknas.');
    const players = match.players;
    const plan = deriveNextTurnPlan(match, players);
    if (!plan) return { success:true, match };
    const { currentGroup, nextGroup, nextIndex, newRound, groupMembers } = plan;
    const now = db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;

    db.transaction(() => {
      closeCurrentTurn(matchId, now, { reason:'next_turn', turn_group:currentGroup });
      db.prepare(`
        UPDATE matches
        SET active_player_index=?, active_turn_group=?, current_round=?, turn_started_at=?,
            timer_remaining_seconds=timer_seconds,
            timer_is_running=CASE WHEN timer_seconds > 0 THEN 1 ELSE 0 END,
            timer_anchor_at=?
        WHERE id=?
      `).run(nextIndex, nextGroup, newRound, now, now, matchId);
      logTurnStart(matchId, players[nextIndex].player_id, newRound, now, {
        reason:'next_turn', turn_group:nextGroup, team_number:Number(players[nextIndex].team_number),
        player_ids:groupMembers.map(p=>Number(p.player_id))
      });
    })();

    return { success:true, match:fetchMatch(matchId, true) };
  }

  return Object.freeze({ changeLife, changePoison, changeTax, concede, nextTurn });
}

module.exports = { createMatchMutationService, deriveNextTurnPlan };
