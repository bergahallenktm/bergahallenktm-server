const fs = require('fs');
const path = require('path');

const dataDir = process.env.BERGAHALLEN_DATA_DIR ? path.resolve(process.env.BERGAHALLEN_DATA_DIR) : path.join(__dirname, '../data');
const logDir = path.join(dataDir, 'logs');
const logPath = path.join(logDir, 'system.log');
const MAX_BYTES = Math.max(256 * 1024, Number(process.env.LOG_MAX_BYTES || 2 * 1024 * 1024));
const KEEP_FILES = Math.max(1, Math.min(10, Number(process.env.LOG_KEEP_FILES || 3)));
const VALID_LEVELS = new Set(['debug', 'info', 'warn', 'error']);
const VALID_CATEGORIES = new Set(['auth', 'match', 'sync', 'database', 'admin', 'api', 'system']);

function ensureDir() {
  fs.mkdirSync(logDir, { recursive: true });
}

function rotateIfNeeded() {
  ensureDir();
  let size = 0;
  try { size = fs.statSync(logPath).size; } catch (_) { return; }
  if (size < MAX_BYTES) return;

  for (let i = KEEP_FILES - 1; i >= 1; i -= 1) {
    const from = `${logPath}.${i}`;
    const to = `${logPath}.${i + 1}`;
    if (fs.existsSync(from)) {
      try { fs.renameSync(from, to); } catch (_) {}
    }
  }
  try { fs.renameSync(logPath, `${logPath}.1`); } catch (_) {}
}

function normalizeMeta(meta) {
  if (!meta || typeof meta !== 'object' || Array.isArray(meta)) return {};
  const safe = { ...meta };
  // Ingen request-body loggas. Dessa nycklar ska ändå aldrig kunna råka hamna här.
  for (const key of ['password', 'current_password', 'password_hash', 'session', 'cookie', 'authorization', 'token', 'reveal_token', 'session_secret']) {
    if (key in safe) safe[key] = '[REDACTED]';
  }
  return safe;
}

function write(level, category, message, meta = {}) {
  const normalizedLevel = VALID_LEVELS.has(level) ? level : 'info';
  const normalizedCategory = VALID_CATEGORIES.has(category) ? category : 'system';
  const entry = {
    ts: new Date().toISOString(),
    level: normalizedLevel,
    category: normalizedCategory,
    message: String(message || ''),
    ...normalizeMeta(meta)
  };
  try {
    rotateIfNeeded();
    fs.appendFileSync(logPath, `${JSON.stringify(entry)}\n`, 'utf8');
  } catch (err) {
    // Logging får aldrig fälla servern.
    console.warn(`⚠️ Kunde inte skriva lokal systemlogg: ${err.message}`);
  }
  return entry;
}

function categoryForRequest(req) {
  // req.path kan vara reducerad till t.ex. /login efter router-mount.
  // originalUrl behåller /api/v1/auth/login och är därför rätt signal.
  const pathname = String(req.originalUrl || req.path || '').split('?')[0].toLowerCase();
  if (pathname.includes('/auth/')) return 'auth';
  if (pathname.includes('/admin/')) return 'admin';
  if (pathname.includes('/sync') || pathname.includes('offline-sync')) return 'sync';
  if (pathname.includes('/matches')) return 'match';
  return 'api';
}

function requestMiddleware(req, res, next) {
  if (!req.path.startsWith('/api/')) return next();
  const startedAt = Date.now();
  res.on('finish', () => {
    // Loggläsning i sig ska inte fylla loggen med brus.
    if (req.path.endsWith('/admin/system/logs')) return;
    const status = Number(res.statusCode || 0);
    const level = status >= 500 ? 'error' : status >= 400 ? 'warn' : 'info';
    write(level, categoryForRequest(req), `${req.method} ${req.originalUrl}`, {
      request_id: req.requestId || null,
      status,
      duration_ms: Date.now() - startedAt,
      actor_id: req.session?.user?.id || null,
      actor_name: req.session?.user?.name || null
    });
  });
  next();
}

function parseFile(filePath) {
  if (!fs.existsSync(filePath)) return [];
  const text = fs.readFileSync(filePath, 'utf8');
  return text.split(/\r?\n/).filter(Boolean).map(line => {
    try { return JSON.parse(line); }
    catch (_) { return { ts: null, level: 'warn', category: 'system', message: line }; }
  });
}

function readRecent({ limit = 100, category = null, level = null } = {}) {
  const safeLimit = Math.max(1, Math.min(500, Number(limit) || 100));
  const files = [];
  for (let i = KEEP_FILES; i >= 1; i -= 1) files.push(`${logPath}.${i}`);
  files.push(logPath);
  let rows = files.flatMap(parseFile);
  if (category && VALID_CATEGORIES.has(category)) rows = rows.filter(row => row.category === category);
  if (level && VALID_LEVELS.has(level)) rows = rows.filter(row => row.level === level);
  return rows.slice(-safeLimit).reverse();
}

function info() {
  ensureDir();
  const files = [];
  for (let i = 0; i <= KEEP_FILES; i += 1) {
    const filePath = i === 0 ? logPath : `${logPath}.${i}`;
    if (!fs.existsSync(filePath)) continue;
    const stat = fs.statSync(filePath);
    files.push({ name: path.basename(filePath), bytes: stat.size, modified_at: stat.mtime.toISOString() });
  }
  return {
    directory: logDir,
    current_file: logPath,
    max_bytes: MAX_BYTES,
    keep_files: KEEP_FILES,
    files,
    categories: [...VALID_CATEGORIES],
    levels: [...VALID_LEVELS]
  };
}

module.exports = {
  debug: (category, message, meta) => write('debug', category, message, meta),
  info: (category, message, meta) => write('info', category, message, meta),
  warn: (category, message, meta) => write('warn', category, message, meta),
  error: (category, message, meta) => write('error', category, message, meta),
  requestMiddleware,
  readRecent,
  getInfo: info,
  logPath
};
