const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const MIN_SECRET_LENGTH = 32;

function defaultDataDir(env = process.env) {
  return env.BERGAHALLEN_DATA_DIR
    ? path.resolve(env.BERGAHALLEN_DATA_DIR)
    : path.join(__dirname, '../data');
}

function readPersistedSecret(secretPath) {
  try {
    const value = fs.readFileSync(secretPath, 'utf8').trim();
    if (value.length < MIN_SECRET_LENGTH) {
      const err = new Error(`Den persistenta sessionshemligheten i ${secretPath} är ogiltig eller för kort.`);
      err.code = 'INVALID_PERSISTED_SESSION_SECRET';
      throw err;
    }
    return value;
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
}

function persistGeneratedSecret(secretPath, secret) {
  fs.mkdirSync(path.dirname(secretPath), { recursive: true });
  try {
    fs.writeFileSync(secretPath, `${secret}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  } catch (err) {
    // Två samtidiga starter ska återanvända samma hemlighet, aldrig rotera den.
    if (err.code !== 'EEXIST') throw err;
    return readPersistedSecret(secretPath);
  }
  try { fs.chmodSync(secretPath, 0o600); } catch (_) {}
  return secret;
}

function validateConfiguredSecret(configured, env = process.env) {
  if (!configured) return null;
  const knownPlaceholders = new Set([
    'skriv-in-ditt-hemliga-session-losenord-har',
    'bergahallen-ktm-dev-3010-secret-key-2026',
    'change-me',
    'changeme'
  ]);
  const production = String(env.NODE_ENV || '').trim().toLowerCase() === 'production';
  if (production && (configured.length < MIN_SECRET_LENGTH || knownPlaceholders.has(configured.toLowerCase()))) {
    const err = new Error(`SESSION_SECRET måste vara minst ${MIN_SECRET_LENGTH} tecken och får inte vara ett känt exempel-/standardvärde.`);
    err.code = 'WEAK_SESSION_SECRET';
    throw err;
  }
  return configured;
}

function resolveSessionSecret({ env = process.env, dataDir } = {}) {
  const configured = validateConfiguredSecret(String(env.SESSION_SECRET || '').trim(), env);
  if (configured) return { secret: configured, source: 'environment', path: null };

  const resolvedDataDir = dataDir ? path.resolve(dataDir) : defaultDataDir(env);
  const secretPath = path.join(resolvedDataDir, '.session-secret');
  const existing = readPersistedSecret(secretPath);
  if (existing) return { secret: existing, source: 'persistent_generated', path: secretPath };

  const generated = crypto.randomBytes(48).toString('base64url');
  const persisted = persistGeneratedSecret(secretPath, generated);
  return { secret: persisted, source: 'persistent_generated', path: secretPath };
}

module.exports = { MIN_SECRET_LENGTH, validateConfiguredSecret, resolveSessionSecret };
