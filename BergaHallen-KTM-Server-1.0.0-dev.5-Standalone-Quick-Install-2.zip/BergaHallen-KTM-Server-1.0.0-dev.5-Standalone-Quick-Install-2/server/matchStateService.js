const {
  parseMatchRules, parseStringArray, sqliteTimestampToMs
} = require('./matchRouteUtils');

function buildTeams(players, teamStates = []) {
  const byTeam = new Map();
  for (const player of players || []) {
    const teamNumber = Number(player.team_number);
    if (!byTeam.has(teamNumber)) byTeam.set(teamNumber, []);
    byTeam.get(teamNumber).push(player);
  }
  const stateByTeam = new Map((teamStates || []).map(t => [Number(t.team_number), t]));

  return [...byTeam.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([teamNumber, members]) => {
      const state = stateByTeam.get(teamNumber) || null;
      return {
        team_number: teamNumber,
        label: `Lag ${teamNumber}`,
        label_key: 'team.team',
        role_key: state?.role_key || (members.some(p => p.role_key === 'archenemy') ? 'archenemy' : members.some(p => p.role_key === 'hero') ? 'heroes' : null),
        life_scope: state?.life_scope || 'player',
        initial_life: state?.initial_life ?? null,
        current_life: state?.current_life ?? null,
        poison_scope: state?.poison_scope || 'player',
        poison_counters: state?.poison_counters ?? null,
        poison_loss_threshold: Number(state?.poison_loss_threshold || 10),
        player_count: members.length,
        alive_count: members.filter(p => !p.is_eliminated).length,
        is_eliminated: state ? !!state.is_eliminated : members.every(p => !!p.is_eliminated),
        is_winner: state ? !!state.is_winner : members.some(p => !!p.is_winner),
        players: members.map(p => ({
          player_id: p.player_id == null ? null : Number(p.player_id),
          player_uid: p.player_uid || null,
          player_name: p.player_name,
          deck_id: p.deck_id == null ? null : Number(p.deck_id),
          deck_uid: p.deck_uid || null,
          deck_name: p.deck_name,
          role_key: p.role_key || null,
          turn_group: p.turn_group == null ? null : Number(p.turn_group),
          range_of_influence: p.range_of_influence == null ? null : Number(p.range_of_influence),
          attack_rule: p.attack_rule || null,
          is_eliminated: !!p.is_eliminated,
          is_winner: !!p.is_winner
        }))
      };
    });
}

function getTimerState(match, nowMs = Date.now()) {
  const configuredSeconds = Math.max(0, Number(match.timer_seconds || 0));
  if (configuredSeconds <= 0) {
    return {
      enabled: false,
      configured_seconds: 0,
      remaining_seconds: 0,
      is_running: false,
      is_paused: false,
      is_expired: false,
      server_time: new Date(nowMs).toISOString()
    };
  }

  let remaining = Math.max(0, Number(match.timer_remaining_seconds ?? configuredSeconds));
  const running = !!Number(match.timer_is_running);
  const anchorMs = sqliteTimestampToMs(match.timer_anchor_at);
  if (running && anchorMs !== null) {
    remaining = Math.max(0, remaining - Math.floor(Math.max(0, nowMs - anchorMs) / 1000));
  }

  const effectiveRunning = running && remaining > 0;
  return {
    enabled: true,
    configured_seconds: configuredSeconds,
    remaining_seconds: remaining,
    is_running: effectiveRunning,
    is_paused: !effectiveRunning && remaining > 0,
    is_expired: remaining <= 0,
    anchor_at: match.timer_anchor_at || null,
    turn_started_at: match.turn_started_at || null,
    server_time: new Date(nowMs).toISOString()
  };
}

function createMatchStateService({ db, sanitizePublicMatch }) {
  if (!db || typeof db.prepare !== 'function') throw new TypeError('db med prepare() krävs.');
  if (typeof sanitizePublicMatch !== 'function') throw new TypeError('sanitizePublicMatch() krävs.');

  function fetchTeamStates(matchId) {
    try {
      return db.prepare('SELECT * FROM match_teams WHERE match_id=? ORDER BY team_number').all(matchId);
    } catch (_) {
      return [];
    }
  }

  function withTeamMetadata(match, players) {
    const teamMode = match.team_mode === 'teams' ? 'teams' : 'ffa';
    const rules = parseMatchRules(match);
    const teamStates = fetchTeamStates(match.id);
    const teams = buildTeams(players, teamStates);
    const activeIndex = Number(match.active_player_index || 0);
    const activePlayer = players?.[activeIndex] || players?.[0] || null;
    const activeTurnGroup = Number(match.active_turn_group ?? activePlayer?.turn_group ?? activeIndex + 1);
    const activeTurnPlayers = (players || []).filter(p => !p.is_eliminated && Number(p.turn_group ?? p.seat_index + 1) === activeTurnGroup);
    return {
      ...match,
      rules,
      limited_format: match.limited_format || rules.limited_format || null,
      modifiers: parseStringArray(match.modifiers_json || rules.modifiers || []),
      team_mode: teamMode,
      is_team_match: teamMode === 'teams',
      team_count: new Set((players || []).map(p => Number(p.team_number))).size,
      teams,
      active_turn_group: activeTurnGroup,
      active_turn_players: activeTurnPlayers.map(p => ({
        player_id: Number(p.player_id), player_uid: p.player_uid || null, player_name: p.player_name,
        team_number: Number(p.team_number), role_key: p.role_key || null
      })),
      active_team_number: activeTurnPlayers.length ? Number(activeTurnPlayers[0].team_number) : null,
      players
    };
  }

  function snapshotTimer(matchId) {
    const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
    if (!match) return null;
    const timer = getTimerState(match);
    if (!timer.enabled) return timer;
    const now = db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;
    db.prepare('UPDATE matches SET timer_remaining_seconds=?, timer_anchor_at=? WHERE id=?')
      .run(timer.remaining_seconds, now, matchId);
    return { ...timer, anchor_at: now };
  }

  function fetchMatch(matchId, requireActive = false, { includeSecrets = false } = {}) {
    const statusClause = requireActive ? "AND m.status = 'active'" : '';
    const match = db.prepare(`SELECT m.* FROM matches m WHERE m.id = ? ${statusClause}`).get(matchId);
    if (!match) return null;
    const players = db.prepare(`
      SELECT mp.*,
             COALESCE(p.entity_uid,mp.player_uid) AS player_uid,
             COALESCE(p.name,mp.player_name_snapshot,'Raderad spelare') AS player_name,
             CASE WHEN p.id IS NULL THEN 1 ELSE 0 END AS player_deleted,
             COALESCE(d.entity_uid,mp.deck_uid) AS deck_uid,
             CASE WHEN mp.deck_id IS NULL AND mp.deck_uid IS NULL THEN NULL ELSE COALESCE(d.name,mp.deck_name_snapshot,'Raderad kortlek') END AS deck_name,
             COALESCE(d.color_identity,mp.deck_color_identity_snapshot) AS deck_color_identity,
             CASE WHEN mp.deck_id IS NULL AND mp.deck_uid IS NULL THEN NULL ELSE COALESCE(owner.entity_uid,mp.deck_owner_uid) END AS deck_owner_uid,
             CASE WHEN mp.deck_id IS NULL AND mp.deck_uid IS NULL THEN NULL ELSE COALESCE(owner.name,mp.deck_owner_name_snapshot,'Raderad spelare') END AS deck_owner_name,
             CASE WHEN mp.deck_id IS NULL AND mp.deck_uid IS NULL THEN 0 WHEN d.id IS NULL THEN 1 ELSE 0 END AS deck_deleted
      FROM match_players mp
      LEFT JOIN players p ON p.id = mp.player_id
      LEFT JOIN decks d ON d.id = mp.deck_id
      LEFT JOIN players owner ON owner.id = d.owner_id
      WHERE mp.match_id = ?
      ORDER BY mp.seat_index ASC
    `).all(matchId);
    const dto = withTeamMetadata({ ...match, table_display_name: match.table_name || `Bord ${match.id}`, timer: getTimerState(match) }, players);
    return includeSecrets ? dto : sanitizePublicMatch(dto);
  }

  function listActiveMatches() {
    const matches = db.prepare(`SELECT * FROM matches WHERE status = 'active' ORDER BY started_at ASC, id ASC`).all();
    return matches.map(m => fetchMatch(m.id, true));
  }

  function mutationMatchState(matchId) {
    const match = fetchMatch(matchId, false);
    const winningTeam = match?.teams?.find(team => team.is_winner)?.team_number ?? null;
    return {
      match,
      match_completed: match?.status === 'completed',
      winning_team_number: winningTeam
    };
  }

  return {
    fetchTeamStates,
    buildTeams,
    withTeamMetadata,
    getTimerState,
    snapshotTimer,
    fetchMatch,
    listActiveMatches,
    mutationMatchState
  };
}

module.exports = {
  buildTeams,
  getTimerState,
  createMatchStateService
};
