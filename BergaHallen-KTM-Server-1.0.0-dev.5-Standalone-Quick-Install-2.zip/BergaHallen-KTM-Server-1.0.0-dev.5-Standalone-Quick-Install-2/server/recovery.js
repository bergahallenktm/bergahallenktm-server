const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const { getUpgradeStatus, dataDirectory: upgradeDataDirectory } = require('./upgradeSafety');

const BACKUP_RESTORE_REPAIR_VERSION = 2;
const REQUIRED_DOMAIN_TABLES = Object.freeze(['players', 'decks', 'matches']);

function dataDirectory() {
  return process.env.BERGAHALLEN_DATA_DIR
    ? path.resolve(process.env.BERGAHALLEN_DATA_DIR)
    : upgradeDataDirectory();
}

function activeDbPath(dataDir = dataDirectory()) {
  return path.join(dataDir, 'mtg_tracker_v7.db');
}

function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  const fd = fs.openSync(filePath, 'r');
  const buffer = Buffer.allocUnsafe(1024 * 1024);
  try {
    let bytesRead;
    do {
      bytesRead = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (bytesRead > 0) hash.update(buffer.subarray(0, bytesRead));
    } while (bytesRead > 0);
  } finally {
    fs.closeSync(fd);
  }
  return hash.digest('hex');
}

function safeStat(filePath) {
  try {
    const stat = fs.statSync(filePath);
    return { exists: true, bytes: stat.size, mtime_ms: stat.mtimeMs, mode: stat.mode & 0o777 };
  } catch (_) {
    return { exists: false, bytes: 0, mtime_ms: null, mode: null };
  }
}

function inspectDatabaseFile(filePath, { full = false, includeHash = false } = {}) {
  const stat = safeStat(filePath);
  if (!stat.exists) {
    return {
      exists: false,
      file_bytes: 0,
      quick_check: null,
      integrity_check: null,
      foreign_key_issues: null,
      schema_version: 0,
      instance_uid: null,
      required_tables_ok: false,
      missing_required_tables: [...REQUIRED_DOMAIN_TABLES],
      sha256: null
    };
  }

  let db;
  try {
    db = new Database(filePath, { readonly: true, fileMustExist: true });
    const quick = String(db.pragma('quick_check', { simple: true }) || 'unknown');
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name);
    const tableSet = new Set(tables);
    const missing = REQUIRED_DOMAIN_TABLES.filter(name => !tableSet.has(name));
    const schemaVersion = tableSet.has('schema_migrations')
      ? Number(db.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migrations').get()?.version || 0)
      : 0;
    const instanceUid = tableSet.has('system_settings')
      ? db.prepare("SELECT value FROM system_settings WHERE key='instance_uid'").get()?.value || null
      : null;

    let integrity = null;
    let foreignKeys = null;
    if (full) {
      const rows = db.pragma('integrity_check');
      integrity = rows.length === 1 && rows[0].integrity_check === 'ok' ? 'ok' : rows.map(row => row.integrity_check || String(row)).join('; ');
      foreignKeys = db.pragma('foreign_key_check');
    }

    const counts = {};
    for (const table of REQUIRED_DOMAIN_TABLES) {
      counts[table] = tableSet.has(table)
        ? Number(db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get()?.n || 0)
        : null;
    }

    return {
      exists: true,
      file_bytes: stat.bytes,
      file_mode: stat.mode,
      quick_check: quick,
      integrity_check: integrity,
      foreign_key_issues: foreignKeys == null ? null : foreignKeys.length,
      schema_version: schemaVersion,
      instance_uid: instanceUid,
      tables,
      required_tables_ok: missing.length === 0,
      missing_required_tables: missing,
      counts,
      sha256: includeHash ? sha256File(filePath) : null
    };
  } catch (err) {
    return {
      exists: true,
      file_bytes: stat.bytes,
      file_mode: stat.mode,
      quick_check: `error: ${err.message}`,
      integrity_check: full ? `error: ${err.message}` : null,
      foreign_key_issues: full ? -1 : null,
      schema_version: 0,
      instance_uid: null,
      required_tables_ok: false,
      missing_required_tables: [...REQUIRED_DOMAIN_TABLES],
      counts: { players: null, decks: null, matches: null },
      sha256: includeHash ? (() => { try { return sha256File(filePath); } catch (_) { return null; } })() : null
    };
  } finally {
    try { db?.close(); } catch (_) {}
  }
}

function databaseInspectionOk(info, { requireFull = false } = {}) {
  if (!info?.exists || info.quick_check !== 'ok' || !info.required_tables_ok) return false;
  if (!requireFull) return true;
  return info.integrity_check === 'ok' && Number(info.foreign_key_issues || 0) === 0;
}

function verifyDatabaseFile(filePath, expected = {}) {
  const info = inspectDatabaseFile(filePath, { full: true, includeHash: true });
  if (!databaseInspectionOk(info, { requireFull: true })) {
    const err = new Error('Databasfilen klarade inte full recovery-verifiering.');
    err.code = 'DATABASE_RECOVERY_VALIDATION_FAILED';
    err.details = info;
    throw err;
  }
  if (expected.schema_version != null && Number(info.schema_version) !== Number(expected.schema_version)) {
    const err = new Error(`Databasfilen har schema ${info.schema_version}, förväntat ${expected.schema_version}.`);
    err.code = 'DATABASE_RECOVERY_SCHEMA_MISMATCH';
    err.details = info;
    throw err;
  }
  if (Object.prototype.hasOwnProperty.call(expected, 'instance_uid') && (info.instance_uid || null) !== (expected.instance_uid || null)) {
    const err = new Error('Databasfilens instance_uid matchar inte den förväntade identiteten.');
    err.code = 'DATABASE_RECOVERY_IDENTITY_MISMATCH';
    err.details = info;
    throw err;
  }
  if (expected.sha256 && info.sha256 !== expected.sha256) {
    const err = new Error('Databasfilens SHA256 matchar inte staged manifest.');
    err.code = 'DATABASE_RECOVERY_HASH_MISMATCH';
    err.details = info;
    throw err;
  }
  return info;
}

function readJson(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); }
  catch (_) { return null; }
}

function publicPendingRestore(dataDir = dataDirectory()) {
  const dbFile = path.join(dataDir, 'restore_pending.db');
  const manifestFile = path.join(dataDir, 'restore_pending.json');
  const dbStat = safeStat(dbFile);
  const manifestStat = safeStat(manifestFile);
  const manifest = manifestStat.exists ? readJson(manifestFile) : null;
  return {
    staged_database: dbStat.exists,
    staged_manifest: manifestStat.exists,
    consistent_pair: dbStat.exists === manifestStat.exists,
    source_backup: manifest?.source_backup || null,
    source_schema_version: manifest?.source_schema_version ?? null,
    source_instance_uid: manifest?.source_instance_uid || null,
    staged_at: manifest?.requested_at || null,
    format_version: manifest?.format_version ?? null
  };
}

function buildStandaloneRecoveryDiagnostics({ dataDir = dataDirectory() } = {}) {
  const activePath = activeDbPath(dataDir);
  const active = inspectDatabaseFile(activePath, { full: true, includeHash: false });
  const pendingRestore = publicPendingRestore(dataDir);
  const backupsDir = path.join(dataDir, 'backups');
  const backups = fs.existsSync(backupsDir)
    ? fs.readdirSync(backupsDir)
      .filter(name => /^mtg_tracker_[A-Za-z0-9_.-]+\.db$/.test(name))
      .map(name => {
        const filePath = path.join(backupsDir, name);
        const info = inspectDatabaseFile(filePath, { full: false, includeHash: false });
        return { name, ...info };
      })
    : [];
  const healthyBackups = backups.filter(info => databaseInspectionOk(info)).length;
  const upgrade = getUpgradeStatus({ dataDir });
  const recommendations = [];

  if (!databaseInspectionOk(active, { requireFull: true })) {
    recommendations.push({ severity: 'critical', code: 'RESTORE_VERIFIED_BACKUP', action: 'Restore from a fully verified backup; automatic data repair is intentionally not attempted.' });
  }
  if (!pendingRestore.consistent_pair) {
    recommendations.push({ severity: 'warning', code: 'INCOMPLETE_STAGED_RESTORE', action: 'Restart the Server to let restore recovery quarantine the incomplete staged state.' });
  }
  if (!backups.length) {
    recommendations.push({ severity: 'warning', code: 'CREATE_BACKUP', action: 'Create a verified backup.' });
  } else if (!healthyBackups) {
    recommendations.push({ severity: 'critical', code: 'NO_HEALTHY_BACKUP', action: 'No backup passes the quick recovery gate; create a new verified backup if the active database is healthy.' });
  }
  if (upgrade.pending) {
    recommendations.push({ severity: 'warning', code: 'UPGRADE_RECOVERY_PENDING', action: 'Resolve the pending Server upgrade before starting a restore or other recovery mutation.' });
  }
  if (!recommendations.length) {
    recommendations.push({ severity: 'info', code: 'NO_REPAIR_REQUIRED', action: 'Database and recovery state are healthy; no repair action is required.' });
  }

  return {
    ok: databaseInspectionOk(active, { requireFull: true }) && pendingRestore.consistent_pair,
    backup_restore_repair_version: BACKUP_RESTORE_REPAIR_VERSION,
    generated_at: new Date().toISOString(),
    active_database: active,
    backups: {
      count: backups.length,
      quick_healthy: healthyBackups,
      quick_unhealthy: backups.length - healthyBackups
    },
    pending_restore: pendingRestore,
    upgrade: {
      pending: upgrade.pending ? {
        status: upgrade.pending.status || null,
        source_schema: upgrade.pending.source_schema ?? null,
        target_schema: upgrade.pending.target_schema ?? null,
        error_code: upgrade.pending.error_code || null
      } : null,
      last: upgrade.last ? {
        status: upgrade.last.status || null,
        source_schema: upgrade.last.source_schema ?? null,
        target_schema: upgrade.last.target_schema ?? null,
        completed_at: upgrade.last.completed_at || null
      } : null
    },
    recommendations
  };
}

function runSafeMaintenance(db) {
  const before = {
    integrity: db.pragma('integrity_check'),
    foreign_keys: db.pragma('foreign_key_check')
  };
  const beforeOk = before.integrity.length === 1 && before.integrity[0].integrity_check === 'ok' && before.foreign_keys.length === 0;
  if (!beforeOk) {
    const err = new Error('Säker repair avbryts eftersom databasen redan har integritetsfel. Använd en verifierad backup i stället.');
    err.status = 409;
    err.code = 'SAFE_REPAIR_REFUSED_RESTORE_REQUIRED';
    err.expose = true;
    throw err;
  }

  const checkpoint = db.pragma('wal_checkpoint(PASSIVE)');
  db.pragma('optimize');

  const afterIntegrity = db.pragma('integrity_check');
  const afterForeignKeys = db.pragma('foreign_key_check');
  const afterOk = afterIntegrity.length === 1 && afterIntegrity[0].integrity_check === 'ok' && afterForeignKeys.length === 0;
  if (!afterOk) {
    const err = new Error('Databaskontrollen efter säker maintenance misslyckades.');
    err.status = 500;
    err.code = 'SAFE_REPAIR_POSTCHECK_FAILED';
    throw err;
  }

  return {
    success: true,
    action: 'safe_maintenance',
    checkpoint,
    optimize: 'completed',
    integrity_check: 'ok',
    foreign_key_issues: 0,
    note: 'No destructive or heuristic data repair was performed.'
  };
}

module.exports = {
  BACKUP_RESTORE_REPAIR_VERSION,
  REQUIRED_DOMAIN_TABLES,
  dataDirectory,
  activeDbPath,
  sha256File,
  inspectDatabaseFile,
  databaseInspectionOk,
  verifyDatabaseFile,
  publicPendingRestore,
  buildStandaloneRecoveryDiagnostics,
  runSafeMaintenance
};
