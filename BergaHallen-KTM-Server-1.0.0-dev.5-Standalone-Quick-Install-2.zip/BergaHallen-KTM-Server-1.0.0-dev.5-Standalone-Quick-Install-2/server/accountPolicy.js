const ACCOUNT_CONTRACT_VERSION = 1;
const AUTHORIZATION_CONTRACT_VERSION = 1;
const ACCOUNT_MODEL = 'account_player_1to1';

const PLAYER_PERMISSIONS = Object.freeze([
  'account.read_self',
  'account.update_self_preferences',
  'decks.manage_own',
  'matches.manage'
]);

const ADMIN_PERMISSIONS = Object.freeze([
  ...PLAYER_PERMISSIONS,
  'admin.access',
  'admin.manage_players',
  'admin.manage_decks',
  'admin.manage_matches',
  'admin.backup_restore',
  'admin.system'
]);

const OFFLINE_QUEUEABLE_PERMISSIONS = Object.freeze([
  'decks.manage_own',
  'matches.manage'
]);

const ONLINE_ONLY_PERMISSIONS = Object.freeze([
  'account.update_self_preferences',
  'admin.access',
  'admin.manage_players',
  'admin.manage_decks',
  'admin.manage_matches',
  'admin.backup_restore',
  'admin.system'
]);

function roleForPlayer(player) {
  return player?.is_admin ? 'admin' : 'player';
}

function permissionsForRole(role) {
  return role === 'admin' ? [...ADMIN_PERMISSIONS] : [...PLAYER_PERMISSIONS];
}

function permissionRevisionForPlayer(player) {
  // auth_revision is incremented when credentials are administratively reset.
  // The role bit is included so a future role change always changes the cached
  // authorization snapshot even if it happens without a password revision.
  const authRevision = Math.max(0, Number(player?.auth_revision || 0));
  return authRevision * 2 + (player?.is_admin ? 1 : 0);
}

function hasPermission(player, permission) {
  return permissionsForRole(roleForPlayer(player)).includes(String(permission));
}

function authorizationForPlayer(player) {
  if (!player) return null;
  const role = roleForPlayer(player);
  return {
    contract_version: AUTHORIZATION_CONTRACT_VERSION,
    role,
    permissions: permissionsForRole(role),
    revision: permissionRevisionForPlayer(player),
    server_authoritative_online: true,
    cached_snapshot_is_authority: false,
    offline_queueable_permissions: [...OFFLINE_QUEUEABLE_PERMISSIONS].filter(permission => hasPermission(player, permission)),
    online_only_permissions: [...ONLINE_ONLY_PERMISSIONS].filter(permission => hasPermission(player, permission))
  };
}

function accountIdentityForPlayer(player) {
  if (!player) return null;
  const id = Number(player.id);
  const uid = player.entity_uid || null;
  return {
    model: ACCOUNT_MODEL,
    account_id: id,
    account_uid: uid,
    player_id: id,
    player_uid: uid
  };
}

function publicAccountPolicy() {
  return {
    account_contract_version: ACCOUNT_CONTRACT_VERSION,
    authorization_contract_version: AUTHORIZATION_CONTRACT_VERSION,
    account_model: ACCOUNT_MODEL,
    registration: {
      enabled: true,
      requires_online: true,
      verify_server_via: '/api/v1/meta',
      creates_player_identity: true,
      username_max_length: 40,
      password_min_length: 4,
      password_max_length: 200
    },
    roles: {
      player: { permissions: [...PLAYER_PERMISSIONS] },
      admin: { permissions: [...ADMIN_PERMISSIONS] }
    },
    semantics: {
      instance_scoped_identity: true,
      cached_user_snapshot_allowed: true,
      cached_permission_snapshot_allowed: true,
      cached_permission_snapshot_is_authority: false,
      offline_queueable_permissions: [...OFFLINE_QUEUEABLE_PERMISSIONS],
      online_only_permissions: [...ONLINE_ONLY_PERMISSIONS],
      unauthorized_status: 401,
      forbidden_status: 403
    }
  };
}

module.exports = {
  ACCOUNT_CONTRACT_VERSION,
  AUTHORIZATION_CONTRACT_VERSION,
  ACCOUNT_MODEL,
  PLAYER_PERMISSIONS,
  ADMIN_PERMISSIONS,
  OFFLINE_QUEUEABLE_PERMISSIONS,
  ONLINE_ONLY_PERMISSIONS,
  roleForPlayer,
  permissionsForRole,
  permissionRevisionForPlayer,
  hasPermission,
  authorizationForPlayer,
  accountIdentityForPlayer,
  publicAccountPolicy
};
