const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const session = require('express-session');

/**
 * Persistent SQLite-backed session store for express-session.
 *
 * Kept in a separate SQLite file from the MTG application database so auth
 * lifecycle/cleanup cannot interfere with match data. Both files live in the
 * same Docker volume and therefore survive container rebuilds/restarts.
 *
 * Android note: the HTTP cookie/session contract is unchanged. Android only
 * needs to persist and resend the connect.sid cookie; the server-side session
 * now survives server restarts as well.
 */
class SqliteSessionStore extends session.Store {
  constructor(options = {}) {
    super();

    const dataDir = options.dataDir || path.join(__dirname, '../data');
    fs.mkdirSync(dataDir, { recursive: true });

    this.dbPath = options.dbPath || path.join(dataDir, 'sessions.db');
    this.ttlMs = Number(options.ttlMs || 1000 * 60 * 60 * 24 * 7);
    this.cleanupIntervalMs = Number(options.cleanupIntervalMs || 1000 * 60 * 30);
    this.closed = false;

    this.db = new Database(this.dbPath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('busy_timeout = 5000');

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS sessions (
        sid TEXT PRIMARY KEY,
        sess TEXT NOT NULL,
        expires_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
    `);

    this.getStmt = this.db.prepare('SELECT sess, expires_at FROM sessions WHERE sid = ?');
    this.setStmt = this.db.prepare(`
      INSERT INTO sessions (sid, sess, expires_at, updated_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(sid) DO UPDATE SET
        sess = excluded.sess,
        expires_at = excluded.expires_at,
        updated_at = excluded.updated_at
    `);
    this.destroyStmt = this.db.prepare('DELETE FROM sessions WHERE sid = ?');
    this.clearStmt = this.db.prepare('DELETE FROM sessions');
    this.lengthStmt = this.db.prepare('SELECT COUNT(*) AS count FROM sessions WHERE expires_at > ?');
    this.cleanupStmt = this.db.prepare('DELETE FROM sessions WHERE expires_at <= ?');
    this.allSessionsStmt = this.db.prepare('SELECT sid, sess FROM sessions');

    this.cleanupExpired();
    this.cleanupTimer = setInterval(() => this.cleanupExpired(), this.cleanupIntervalMs);
    this.cleanupTimer.unref?.();
  }

  expiryFor(sess) {
    const expires = sess?.cookie?.expires;
    if (expires) {
      const timestamp = new Date(expires).getTime();
      if (Number.isFinite(timestamp)) return timestamp;
    }

    const maxAge = Number(sess?.cookie?.maxAge);
    if (Number.isFinite(maxAge) && maxAge > 0) {
      return Date.now() + maxAge;
    }

    return Date.now() + this.ttlMs;
  }

  cleanupExpired() {
    if (this.closed) return 0;
    try {
      return this.cleanupStmt.run(Date.now()).changes;
    } catch (err) {
      console.warn('⚠️ Kunde inte rensa utgångna sessioner:', err.message);
      return 0;
    }
  }

  get(sid, callback = () => {}) {
    try {
      const row = this.getStmt.get(sid);
      if (!row) return callback(null, null);

      if (row.expires_at <= Date.now()) {
        this.destroyStmt.run(sid);
        return callback(null, null);
      }

      return callback(null, JSON.parse(row.sess));
    } catch (err) {
      return callback(err);
    }
  }

  set(sid, sess, callback = () => {}) {
    try {
      const now = Date.now();
      this.setStmt.run(sid, JSON.stringify(sess), this.expiryFor(sess), now);
      return callback(null);
    } catch (err) {
      return callback(err);
    }
  }

  // express-session uses touch() to extend an active session. Persist the full
  // object as well so cookie expiry in JSON cannot drift from expires_at.
  touch(sid, sess, callback = () => {}) {
    return this.set(sid, sess, callback);
  }

  destroy(sid, callback = () => {}) {
    try {
      this.destroyStmt.run(sid);
      return callback(null);
    } catch (err) {
      return callback(err);
    }
  }

  clear(callback = () => {}) {
    try {
      this.clearStmt.run();
      return callback(null);
    } catch (err) {
      return callback(err);
    }
  }

  destroyUserSessions(userId, callback = () => {}) {
    try {
      const target = Number(userId);
      let removed = 0;
      for (const row of this.allSessionsStmt.all()) {
        let parsed;
        try { parsed = JSON.parse(row.sess); } catch (_) { continue; }
        if (Number(parsed?.user?.id || 0) !== target) continue;
        removed += this.destroyStmt.run(row.sid).changes;
      }
      return callback(null, removed);
    } catch (err) {
      return callback(err);
    }
  }

  length(callback = () => {}) {
    try {
      const row = this.lengthStmt.get(Date.now());
      return callback(null, row.count);
    } catch (err) {
      return callback(err);
    }
  }

  ping() {
    if (this.closed) throw new Error('Sessionsdatabasen är stängd.');
    this.db.prepare('SELECT 1 AS ok').get();
    return true;
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    clearInterval(this.cleanupTimer);
    try {
      this.db.pragma('wal_checkpoint(TRUNCATE)');
    } catch (err) {
      console.warn('⚠️ Kunde inte checkpointa sessions-WAL:', err.message);
    }
    this.db.close();
  }
}

module.exports = SqliteSessionStore;
