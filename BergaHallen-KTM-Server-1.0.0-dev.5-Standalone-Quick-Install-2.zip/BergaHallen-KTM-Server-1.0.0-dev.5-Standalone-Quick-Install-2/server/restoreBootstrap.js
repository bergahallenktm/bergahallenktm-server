const fs = require('fs');
const path = require('path');
const { verifyDatabaseFile, inspectDatabaseFile, databaseInspectionOk } = require('./recovery');
const { releaseProfile } = require('./upgradeSafety');

const DATA_DIR = process.env.BERGAHALLEN_DATA_DIR ? path.resolve(process.env.BERGAHALLEN_DATA_DIR) : path.join(__dirname, '../data');
const ACTIVE_DB = path.join(DATA_DIR, 'mtg_tracker_v7.db');
const PENDING_DB = path.join(DATA_DIR, 'restore_pending.db');
const PENDING_MANIFEST = path.join(DATA_DIR, 'restore_pending.json');
const LAST_RESTORE = path.join(DATA_DIR, 'last_restore.json');
const TEMP_ACTIVE = `${ACTIVE_DB}.restore_tmp`;
const PREVIOUS_ACTIVE = `${ACTIVE_DB}.pre_restore_swap`;

function readJson(filePath) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); }
  catch (_) { return null; }
}

function atomicWriteJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(tmp, 0o600); } catch (_) {}
  fs.renameSync(tmp, filePath);
  try { fs.chmodSync(filePath, 0o600); } catch (_) {}
}

function removeIfExists(filePath) {
  try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
}

function quarantineFile(filePath, prefix) {
  if (!fs.existsSync(filePath)) return null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const destination = path.join(DATA_DIR, `${prefix}_${stamp}.db`);
  try {
    fs.renameSync(filePath, destination);
    try { fs.chmodSync(destination, 0o600); } catch (_) {}
    return path.basename(destination);
  } catch (_) {
    return null;
  }
}

function recordFailure(error, extra = {}) {
  const failure = {
    applied: false,
    failed: true,
    failed_at: new Date().toISOString(),
    error_code: error?.code || null,
    error: error?.message || String(error),
    ...extra
  };
  atomicWriteJson(LAST_RESTORE, failure);
  return failure;
}

function clearSessions() {
  for (const name of ['sessions.db', 'sessions.db-wal', 'sessions.db-shm']) {
    removeIfExists(path.join(DATA_DIR, name));
  }
}

function expectedFromManifest(manifest = {}) {
  const expected = {};
  if (manifest.source_schema_version != null) expected.schema_version = Number(manifest.source_schema_version);
  if (Object.prototype.hasOwnProperty.call(manifest, 'source_instance_uid')) expected.instance_uid = manifest.source_instance_uid || null;
  if (manifest.staged_sha256) expected.sha256 = manifest.staged_sha256;
  return expected;
}

function validatePendingBackup(filePath, manifest = {}) {
  const info = verifyDatabaseFile(filePath, expectedFromManifest(manifest));
  const targetSchema = Number(releaseProfile().target_schema);
  if (Number(info.schema_version) > targetSchema) {
    const err = new Error(`Staged restore använder schema ${info.schema_version}, men Servern stödjer endast schema ${targetSchema}.`);
    err.code = 'RESTORE_SCHEMA_NEWER_THAN_SERVER';
    throw err;
  }
  return info;
}

function successfulResult(manifest, info, extra = {}) {
  return {
    applied: true,
    applied_at: new Date().toISOString(),
    source_backup: manifest.source_backup || null,
    source_schema_version: info?.schema_version ?? manifest.source_schema_version ?? null,
    source_instance_uid: info?.instance_uid || manifest.source_instance_uid || null,
    pre_restore_backup: manifest.pre_restore_backup || null,
    cross_instance_restore: !!manifest.cross_instance_restore,
    integrity_check: 'ok',
    foreign_key_issues: 0,
    ...extra
  };
}

function commitSuccessfulRestore(manifest, info, extra = {}) {
  clearSessions();
  const result = successfulResult(manifest, info, extra);
  atomicWriteJson(LAST_RESTORE, result);
  removeIfExists(PENDING_DB);
  removeIfExists(PENDING_MANIFEST);
  removeIfExists(PREVIOUS_ACTIVE);
  removeIfExists(TEMP_ACTIVE);
  console.log(`♻️ Databasrestore genomförd${result.source_backup ? ` från ${result.source_backup}` : ''}.`);
  return result;
}

function handleIncompleteStagedPair() {
  const hasDb = fs.existsSync(PENDING_DB);
  const hasManifest = fs.existsSync(PENDING_MANIFEST);
  if (hasDb === hasManifest) return null;

  const err = new Error('Staged restore är ofullständig: databas och manifest måste finnas tillsammans.');
  err.code = 'RESTORE_STAGED_PAIR_INCOMPLETE';
  const quarantined = hasDb ? quarantineFile(PENDING_DB, 'restore_incomplete') : null;
  removeIfExists(PENDING_MANIFEST);
  const failure = recordFailure(err, { quarantined_file: quarantined });
  console.error(`❌ ${err.message} Nuvarande databas behålls.`);
  return failure;
}

function recoverInterruptedSwap(manifest) {
  if (!fs.existsSync(PREVIOUS_ACTIVE)) return null;

  // Om active redan är den verifierade staged-filen dog processen efter swap men
  // före commit. Då kan vi slutföra commit utan att göra om bytet.
  if (fs.existsSync(ACTIVE_DB)) {
    try {
      const activeInfo = verifyDatabaseFile(ACTIVE_DB, expectedFromManifest(manifest));
      return commitSuccessfulRestore(manifest, activeInfo, { recovered_interrupted_swap: true });
    } catch (_) {
      const quarantined = quarantineFile(ACTIVE_DB, 'restore_interrupted_active');
      if (!fs.existsSync(PREVIOUS_ACTIVE)) {
        const err = new Error('Restore recovery saknar föregående aktiv databas efter avbrutet swap.');
        err.code = 'RESTORE_ROLLBACK_SOURCE_MISSING';
        throw Object.assign(err, { quarantined_file: quarantined });
      }
      fs.renameSync(PREVIOUS_ACTIVE, ACTIVE_DB);
      try { fs.chmodSync(ACTIVE_DB, 0o600); } catch (_) {}
    }
  } else {
    fs.renameSync(PREVIOUS_ACTIVE, ACTIVE_DB);
    try { fs.chmodSync(ACTIVE_DB, 0o600); } catch (_) {}
  }

  removeIfExists(TEMP_ACTIVE);
  return null;
}

function reconcileOrphanSwapWithoutPending() {
  if (!fs.existsSync(PREVIOUS_ACTIVE)) return null;
  if (!fs.existsSync(ACTIVE_DB)) {
    fs.renameSync(PREVIOUS_ACTIVE, ACTIVE_DB);
    try { fs.chmodSync(ACTIVE_DB, 0o600); } catch (_) {}
    return { recovered: true, action: 'restored_previous_active_database' };
  }

  const active = inspectDatabaseFile(ACTIVE_DB, { full: true });
  if (databaseInspectionOk(active, { requireFull: true })) {
    removeIfExists(PREVIOUS_ACTIVE);
    return { recovered: true, action: 'removed_stale_previous_database' };
  }

  const quarantined = quarantineFile(ACTIVE_DB, 'restore_orphan_invalid_active');
  fs.renameSync(PREVIOUS_ACTIVE, ACTIVE_DB);
  try { fs.chmodSync(ACTIVE_DB, 0o600); } catch (_) {}
  return { recovered: true, action: 'rolled_back_invalid_active_database', quarantined_file: quarantined };
}

function applyPendingRestore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });

  const incomplete = handleIncompleteStagedPair();
  if (incomplete) return incomplete;

  if (!fs.existsSync(PENDING_DB)) {
    const recovery = reconcileOrphanSwapWithoutPending();
    return recovery ? { applied: false, recovery } : { applied: false };
  }

  const manifest = readJson(PENDING_MANIFEST);
  if (!manifest || typeof manifest !== 'object') {
    const quarantined = quarantineFile(PENDING_DB, 'restore_invalid_manifest');
    removeIfExists(PENDING_MANIFEST);
    const err = new Error('Staged restore-manifest kan inte läsas.');
    err.code = 'RESTORE_MANIFEST_INVALID';
    return recordFailure(err, { quarantined_file: quarantined });
  }

  try {
    const recovered = recoverInterruptedSwap(manifest);
    if (recovered) return recovered;
  } catch (err) {
    const failure = recordFailure(err, { quarantined_file: err.quarantined_file || null });
    console.error(`❌ Restore recovery misslyckades: ${err.message}`);
    return failure;
  }

  let pendingInfo;
  try {
    pendingInfo = validatePendingBackup(PENDING_DB, manifest);
  } catch (err) {
    const quarantined = quarantineFile(PENDING_DB, 'restore_failed_validation');
    removeIfExists(PENDING_MANIFEST);
    const failure = recordFailure(err, { quarantined_file: quarantined });
    console.error(`❌ Staged restore avvisades: ${err.message}. Nuvarande databas behålls.`);
    return failure;
  }

  removeIfExists(TEMP_ACTIVE);
  fs.copyFileSync(PENDING_DB, TEMP_ACTIVE);
  try { fs.chmodSync(TEMP_ACTIVE, 0o600); } catch (_) {}

  try {
    validatePendingBackup(TEMP_ACTIVE, manifest);
  } catch (err) {
    removeIfExists(TEMP_ACTIVE);
    const failure = recordFailure(err, { source_backup: manifest.source_backup || null });
    console.error(`❌ Restore-copy verifierades inte: ${err.message}. Nuvarande databas behålls.`);
    return failure;
  }

  // SQLite-backupfilen är fristående. Gamla WAL/SHM får inte följa med över swap.
  removeIfExists(`${ACTIVE_DB}-wal`);
  removeIfExists(`${ACTIVE_DB}-shm`);
  removeIfExists(PREVIOUS_ACTIVE);

  try {
    if (fs.existsSync(ACTIVE_DB)) fs.renameSync(ACTIVE_DB, PREVIOUS_ACTIVE);
    fs.renameSync(TEMP_ACTIVE, ACTIVE_DB);
    try { fs.chmodSync(ACTIVE_DB, 0o600); } catch (_) {}

    // 2.0: commit först efter full verifiering av den faktiska ACTIVE_DB.
    const activeInfo = validatePendingBackup(ACTIVE_DB, manifest);
    removeIfExists(PREVIOUS_ACTIVE);
    return commitSuccessfulRestore(manifest, activeInfo);
  } catch (err) {
    const quarantined = fs.existsSync(ACTIVE_DB) ? quarantineFile(ACTIVE_DB, 'restore_failed_postswap') : null;
    try {
      if (fs.existsSync(PREVIOUS_ACTIVE)) {
        fs.renameSync(PREVIOUS_ACTIVE, ACTIVE_DB);
        try { fs.chmodSync(ACTIVE_DB, 0o600); } catch (_) {}
        const rollbackInfo = inspectDatabaseFile(ACTIVE_DB, { full: true });
        if (!databaseInspectionOk(rollbackInfo, { requireFull: true })) {
          const rollbackErr = new Error('Restore misslyckades och rollback-databasen klarade inte integritetskontroll.');
          rollbackErr.code = 'RESTORE_ROLLBACK_VALIDATION_FAILED';
          throw rollbackErr;
        }
      }
    } catch (rollbackErr) {
      const failure = recordFailure(rollbackErr, {
        original_error: err.message,
        quarantined_file: quarantined
      });
      console.error(`❌ Kritisk restore/rollback-failure: ${rollbackErr.message}`);
      throw Object.assign(rollbackErr, { restore_failure: failure });
    }

    const stagedQuarantine = quarantineFile(PENDING_DB, 'restore_failed_staged');
    removeIfExists(PENDING_MANIFEST);
    const failure = recordFailure(err, {
      source_backup: manifest.source_backup || null,
      quarantined_file: quarantined || stagedQuarantine,
      rollback_applied: true
    });
    console.error(`❌ Restore misslyckades efter swap och rullades tillbaka: ${err.message}`);
    return failure;
  }
}

function getLastRestoreInfo() {
  return readJson(LAST_RESTORE);
}

module.exports = {
  applyPendingRestore,
  getLastRestoreInfo,
  validatePendingBackup,
  reconcileOrphanSwapWithoutPending,
  LAST_RESTORE
};
