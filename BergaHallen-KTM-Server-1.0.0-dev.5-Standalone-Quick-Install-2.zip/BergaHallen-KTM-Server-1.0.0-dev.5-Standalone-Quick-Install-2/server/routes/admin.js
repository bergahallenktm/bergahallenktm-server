const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const db = require('../db');
const asyncHandler = require('../asyncHandler');
const { requireAdmin } = require('../authz');
const {
  createBackup, listBackups, backupPathByName, getBackupSettings,
  updateBackupSettings, rescheduleDailyBackups, stageRestore, buildRestorePlan
} = require('../backup');
const { buildSystemStatus } = require('../systemStatus');
const localLogger = require('../localLogger');
const { buildStandaloneRecoveryDiagnostics, runSafeMaintenance, BACKUP_RESTORE_REPAIR_VERSION } = require('../recovery');

const router = express.Router();
router.use(requireAdmin);

function positiveId(value, label='id') {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) {
    const err = new Error(`${label} måste vara ett positivt heltal.`);
    err.status = 400; err.code = 'INVALID_ID'; err.expose = true;
    throw err;
  }
  return n;
}

function audit(actorId, action, targetType, targetId, details={}) {
  db.prepare(`
    INSERT INTO admin_audit_log (actor_player_id, action, target_type, target_id, details_json)
    VALUES (?,?,?,?,?)
  `).run(actorId, action, targetType, targetId == null ? null : String(targetId), JSON.stringify(details));
  localLogger.info('admin', action, { actor_id: actorId, target_type: targetType, target_id: targetId == null ? null : String(targetId) });
}

function requireConfirmation(req, expected) {
  const accepted = Array.isArray(expected) ? expected : [expected];
  const actual = String(req.body?.confirmation || '').trim();
  if (!accepted.includes(actual)) {
    const err = new Error(`Bekräftelsen måste vara exakt: ${accepted[0]}`);
    err.status = 422;
    err.code = 'CONFIRMATION_REQUIRED';
    err.expose = true;
    throw err;
  }
}

function activeMatchExists() {
  return db.prepare("SELECT id FROM matches WHERE status='active' ORDER BY id LIMIT 1").get();
}

function activeMatchForDeck(deckId) {
  return db.prepare(`
    SELECT m.id
    FROM matches m
    JOIN match_players mp ON mp.match_id=m.id
    WHERE m.status='active' AND mp.deck_id=?
    LIMIT 1
  `).get(deckId);
}

function recordPlayerTombstone(player) {
  const revision = db.nextSyncRevision('players');
  db.prepare(`
    INSERT INTO sync_tombstones
      (resource,legacy_id,entity_uid,owner_id,client_uid,deleted_at,sync_revision)
    VALUES ('players',?,?,NULL,NULL,CURRENT_TIMESTAMP,?)
    ON CONFLICT(resource,legacy_id) DO UPDATE SET
      entity_uid=excluded.entity_uid,
      deleted_at=CURRENT_TIMESTAMP,
      sync_revision=excluded.sync_revision
  `).run(player.id, player.entity_uid || null, revision);
  return revision;
}

function recordDeckTombstone(deck) {
  const revision = db.nextSyncRevision('decks');
  db.prepare(`
    INSERT INTO sync_tombstones
      (resource,legacy_id,entity_uid,owner_id,client_uid,deleted_at,sync_revision)
    VALUES ('decks',?,?,?,?,CURRENT_TIMESTAMP,?)
    ON CONFLICT(resource,legacy_id) DO UPDATE SET
      entity_uid=excluded.entity_uid,
      owner_id=excluded.owner_id,
      client_uid=excluded.client_uid,
      deleted_at=CURRENT_TIMESTAMP,
      sync_revision=excluded.sync_revision
  `).run(deck.id, deck.entity_uid || null, deck.owner_id || null, deck.client_uid || null, revision);
  return revision;
}

async function forcedBackup(reason = 'pre-destructive-operation') {
  const settings = getBackupSettings(db);
  const result = await createBackup(db, { keep: settings.keep, force: true, reason });
  return result?.path || null;
}


// Steg 3.9.5: lokal systemstatus/diagnostik. Endpoints är admin-only via router.use(requireAdmin).
router.get('/system/status', (req, res) => {
  try {
    res.json(buildSystemStatus(db));
  } catch (err) {
    localLogger.error('database', 'System status collection failed', { error: err.message });
    res.status(500).json({ error: 'Kunde inte läsa systemstatus.', code: 'SYSTEM_STATUS_FAILED' });
  }
});

router.get('/system/logs', (req, res) => {
  const limit = Math.max(1, Math.min(500, Number(req.query.limit || 100) || 100));
  const category = String(req.query.category || '').trim().toLowerCase() || null;
  const level = String(req.query.level || '').trim().toLowerCase() || null;
  res.json({
    logs: localLogger.readRecent({ limit, category, level }),
    info: localLogger.getInfo()
  });
});

router.get('/system/recovery-diagnostics', (req, res) => {
  try {
    res.json(buildStandaloneRecoveryDiagnostics());
  } catch (err) {
    localLogger.error('database', 'Recovery diagnostics failed', { error: err.message });
    res.status(500).json({ error: 'Kunde inte köra recovery-diagnostik.', code: 'RECOVERY_DIAGNOSTICS_FAILED' });
  }
});

router.post('/system/repair-safe', asyncHandler(async (req, res) => {
  requireConfirmation(req, ['KÖR SÄKER REPAIR', 'RUN SAFE REPAIR']);
  const active = activeMatchExists();
  if (active) {
    return res.status(409).json({
      error: `Aktiv match #${active.id} måste avslutas eller avbrytas före database maintenance.`,
      code: 'ACTIVE_MATCH_BLOCKS_SAFE_REPAIR'
    });
  }

  const backupPath = await forcedBackup('pre-safe-repair');
  const result = runSafeMaintenance(db);
  audit(req.authPlayer.id, 'DATABASE_SAFE_REPAIR', 'database', null, {
    backup_name: backupPath ? path.basename(backupPath) : null,
    integrity_check: result.integrity_check,
    foreign_key_issues: result.foreign_key_issues
  });
  res.json({
    success: true,
    backup_restore_repair_version: BACKUP_RESTORE_REPAIR_VERSION,
    pre_repair_backup: backupPath ? path.basename(backupPath) : null,
    ...result
  });
}));

router.post('/system/backup', asyncHandler(async (req, res) => {
  const settings = getBackupSettings(db);
  const result = await createBackup(db, { keep: settings.keep, force: true, reason: 'manual' });
  const backupName = path.basename(result.path);
  audit(req.authPlayer.id, 'MANUAL_BACKUP_CREATED', 'database', null, { backup_name: backupName });
  res.json({
    success: true,
    backup: {
      name: backupName,
      created_at: new Date().toISOString()
    }
  });
}));

router.get('/system/backups', (req, res) => {
  const settings = getBackupSettings(db);
  const backups = listBackups(db, { inspect: true }).map(item => ({
    name: item.name,
    created_at: new Date(item.mtimeMs).toISOString(),
    bytes: item.bytes,
    health: item.health,
    schema_version: item.schema_version,
    instance_uid: item.instance_uid,
    players: item.players,
    decks: item.decks,
    matches: item.matches,
    required_tables_ok: item.required_tables_ok
  }));
  res.json({
    backups,
    settings,
    current_instance_uid: db.instanceUid
  });
});

router.get('/system/backups/:name/restore-plan', (req, res, next) => {
  try {
    const plan = buildRestorePlan(db, req.params.name);
    res.json({
      success: true,
      backup_restore_repair_version: BACKUP_RESTORE_REPAIR_VERSION,
      backup: plan.backup,
      source_schema_version: plan.source_schema_version,
      target_schema_version: plan.target_schema_version,
      source_instance_uid: plan.source_instance_uid,
      current_instance_uid: plan.current_instance_uid,
      same_instance: plan.same_instance,
      cross_instance_restore: plan.cross_instance_restore,
      migration_after_restore_required: plan.migration_after_restore_required,
      compatible: plan.compatible,
      verification: plan.verification,
      counts: plan.counts
    });
  } catch (err) {
    next(err);
  }
});

router.get('/system/backups/:name/download', (req, res, next) => {
  try {
    const fullPath = backupPathByName(db, req.params.name);
    if (!require('fs').existsSync(fullPath)) {
      return res.status(404).json({ error: 'Backupfilen finns inte.', code: 'BACKUP_NOT_FOUND' });
    }
    res.download(fullPath, path.basename(fullPath));
  } catch (err) {
    next(err);
  }
});

router.put('/system/backup-settings', (req, res) => {
  const raw = req.body || {};
  const keep = Number(raw.keep);
  const hour = Number(raw.hour);
  const minute = Number(raw.minute);

  if (!Number.isInteger(keep) || keep < 1 || keep > 100) {
    return res.status(422).json({ error: 'Antal backuper att behålla måste vara 1–100.', code: 'INVALID_BACKUP_KEEP' });
  }
  if (!Number.isInteger(hour) || hour < 0 || hour > 23 || !Number.isInteger(minute) || minute < 0 || minute > 59) {
    return res.status(422).json({ error: 'Backuptiden är ogiltig.', code: 'INVALID_BACKUP_TIME' });
  }

  const settings = updateBackupSettings(db, {
    enabled: !!raw.enabled,
    keep,
    hour,
    minute
  });
  const schedule = rescheduleDailyBackups();
  audit(req.authPlayer.id, 'BACKUP_SETTINGS_UPDATED', 'database', null, settings);
  res.json({ success: true, settings, schedule });
});

router.post('/system/backups/:name/restore', asyncHandler(async (req, res) => {
  const restorePlan = buildRestorePlan(db, req.params.name);
  if (restorePlan.cross_instance_restore) {
    requireConfirmation(req, ['ÅTERSTÄLL ANNAN SERVER', 'RESTORE OTHER SERVER']);
  } else {
    requireConfirmation(req, ['ÅTERSTÄLL BACKUP', 'RESTORE BACKUP']);
  }
  const password = String(req.body?.password || '');
  const admin = db.prepare('SELECT * FROM players WHERE id=? AND is_admin=1').get(Number(req.authPlayer.id));
  if (!admin || !admin.password_hash || !(await bcrypt.compare(password, admin.password_hash))) {
    return res.status(403).json({ error: 'Adminlösenordet är fel.', code: 'ADMIN_PASSWORD_REQUIRED' });
  }

  const active = activeMatchExists();
  if (active) {
    return res.status(409).json({
      error: `Aktiv match #${active.id} måste avslutas eller avbrytas före restore.`,
      code: 'ACTIVE_MATCH_BLOCKS_RESTORE'
    });
  }

  const settings = getBackupSettings(db);
  const result = await stageRestore(db, req.params.name, {
    keep: settings.keep,
    allowCrossInstance: restorePlan.cross_instance_restore
  });
  audit(req.authPlayer.id, 'DATABASE_RESTORE_STAGED', 'database', null, {
    backup_name: result.backup,
    source_schema_version: result.source?.schema_version || 0,
    source_instance_uid: result.source?.instance_uid || null,
    pre_restore_backup: result.pre_restore_backup,
    cross_instance_restore: !!result.cross_instance_restore
  });

  const restartAfterRestore = req.body?.restart_after_restore !== false;
  res.json({
    success: true,
    ...result,
    restart_scheduled: restartAfterRestore,
    note: restartAfterRestore
      ? 'Servern startar om för att applicera backupen.'
      : 'Backupen är staged och appliceras vid nästa serverstart.'
  });

  if (restartAfterRestore) {
    const timer = setTimeout(() => {
      try { process.kill(process.pid, 'SIGTERM'); }
      catch (_) { process.exit(0); }
    }, 750);
    timer.unref();
  }
}));

router.get('/summary', (req, res) => {
  const players = db.prepare(`
    SELECT p.id,p.entity_uid,p.name,p.is_admin,p.archived,p.archived_at,p.created_at,p.updated_at,
           COUNT(DISTINCT d.id) AS deck_count,
           COUNT(DISTINCT mp.match_id) AS match_count
    FROM players p
    LEFT JOIN decks d ON d.owner_id=p.id AND d.archived=0
    LEFT JOIN match_players mp ON mp.player_id=p.id
    GROUP BY p.id
    ORDER BY p.archived ASC,p.is_admin DESC,p.name COLLATE NOCASE
  `).all();

  const decks = db.prepare(`
    SELECT d.id,d.entity_uid,d.name,d.format,d.owner_id,p.name AS owner_name,d.archived,d.archived_at,d.updated_at,
           COUNT(DISTINCT mp.match_id) AS match_count,
           EXISTS(
             SELECT 1 FROM match_players amp
             JOIN matches am ON am.id=amp.match_id
             WHERE amp.deck_id=d.id AND am.status='active'
           ) AS in_active_match
    FROM decks d
    JOIN players p ON p.id=d.owner_id
    LEFT JOIN match_players mp ON mp.deck_id=d.id
    GROUP BY d.id
    ORDER BY d.archived ASC,p.name COLLATE NOCASE,d.name COLLATE NOCASE
  `).all();

  const matches = db.prepare(`
    SELECT m.id,m.match_type,m.match_profile,m.deck_format,m.play_mode,m.team_mode,m.table_name,m.status,m.started_at,m.ended_at,
           GROUP_CONCAT(COALESCE(p.name,mp.player_name_snapshot,'Raderad spelare'), ', ') AS player_names,
           COUNT(mp.id) AS player_count
    FROM matches m
    LEFT JOIN match_players mp ON mp.match_id=m.id
    LEFT JOIN players p ON p.id=mp.player_id
    GROUP BY m.id
    ORDER BY m.started_at DESC,m.id DESC
    LIMIT 200
  `).all();

  const counts = {
    players: db.prepare('SELECT COUNT(*) AS n FROM players WHERE is_admin=0').get().n,
    decks: db.prepare('SELECT COUNT(*) AS n FROM decks').get().n,
    matches: db.prepare('SELECT COUNT(*) AS n FROM matches').get().n,
    completed_matches: db.prepare("SELECT COUNT(*) AS n FROM matches WHERE status='completed'").get().n,
    active_matches: db.prepare("SELECT COUNT(*) AS n FROM matches WHERE status='active'").get().n
  };

  res.json({ players, decks, matches, counts });
});

router.post('/players/:id/password', asyncHandler(async (req, res) => {
  const id = positiveId(req.params.id, 'player_id');
  const password = String(req.body?.password || '');
  if (password.length < 4) return res.status(400).json({ error: 'Lösenordet måste vara minst 4 tecken.', code: 'PASSWORD_TOO_SHORT' });
  if (password.length > 200) return res.status(400).json({ error: 'Lösenordet är för långt.', code: 'PASSWORD_TOO_LONG' });
  const player = db.prepare('SELECT id,name,archived FROM players WHERE id=?').get(id);
  if (!player) return res.status(404).json({ error: 'Spelaren hittades inte.', code: 'PLAYER_NOT_FOUND' });
  if (player.archived) return res.status(409).json({ error: 'Återställ spelaren innan lösenordet ändras.', code: 'PLAYER_ARCHIVED' });

  const hash = await bcrypt.hash(password, 12);
  db.prepare('UPDATE players SET password_hash=?,auth_revision=auth_revision+1,updated_at=CURRENT_TIMESTAMP,sync_revision=? WHERE id=?')
    .run(hash, db.nextSyncRevision('players'), id);
  audit(req.authPlayer.id, 'PLAYER_PASSWORD_RESET', 'player', id, { player_name: player.name });
  res.json({ success: true, player_id: id, sessions_invalidated: true });
}));

// Soft-delete/arkivering finns kvar som första, reversibla steg.
router.delete('/players/:id', (req, res) => {
  const id = positiveId(req.params.id, 'player_id');
  const player = db.prepare('SELECT * FROM players WHERE id=?').get(id);
  if (!player) return res.status(404).json({ error: 'Spelaren hittades inte.', code: 'PLAYER_NOT_FOUND' });
  if (player.is_admin) return res.status(409).json({ error: 'Superuser-kontot kan inte tas bort här.', code: 'ADMIN_DELETE_BLOCKED' });
  const active = db.prepare(`
    SELECT m.id FROM matches m
    JOIN match_players mp ON mp.match_id=m.id
    WHERE m.status='active' AND mp.player_id=?
    LIMIT 1
  `).get(id);
  if (active) return res.status(409).json({ error: `Spelaren deltar i aktiv match #${active.id}. Avsluta eller avbryt matchen först.`, code: 'PLAYER_IN_ACTIVE_MATCH' });

  db.transaction(() => {
    const ownedDecks = db.prepare('SELECT id FROM decks WHERE owner_id=? AND archived=0').all(id);
    for (const deck of ownedDecks) {
      db.prepare('UPDATE decks SET archived=1,archived_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP,sync_revision=? WHERE id=?')
        .run(db.nextSyncRevision('decks'), deck.id);
    }
    db.prepare(`
      UPDATE players
      SET archived=1,archived_at=CURRENT_TIMESTAMP,auth_revision=auth_revision+1,
          updated_at=CURRENT_TIMESTAMP,sync_revision=?
      WHERE id=?
    `).run(db.nextSyncRevision('players'), id);
    audit(req.authPlayer.id, 'PLAYER_ARCHIVED', 'player', id, { player_name: player.name, archived_decks: ownedDecks.length });
  })();
  res.json({ success: true, archived: true, player_id: id });
});

router.post('/players/:id/restore', (req, res) => {
  const id = positiveId(req.params.id, 'player_id');
  const player = db.prepare('SELECT * FROM players WHERE id=?').get(id);
  if (!player) return res.status(404).json({ error: 'Spelaren hittades inte.', code: 'PLAYER_NOT_FOUND' });
  db.prepare('UPDATE players SET archived=0,archived_at=NULL,updated_at=CURRENT_TIMESTAMP,sync_revision=? WHERE id=?')
    .run(db.nextSyncRevision('players'), id);
  audit(req.authPlayer.id, 'PLAYER_RESTORED', 'player', id, { player_name: player.name });
  res.json({ success: true, player_id: id });
});

// Permanent player delete: tillåts först efter arkivering. Matchhistorik och
// statistik använder snapshots/UID och finns kvar, men konto/password försvinner.
router.delete('/players/:id/permanent', asyncHandler(async (req, res) => {
  const id = positiveId(req.params.id, 'player_id');
  const player = db.prepare('SELECT * FROM players WHERE id=?').get(id);
  if (!player) return res.status(404).json({ error: 'Spelaren hittades inte.', code: 'PLAYER_NOT_FOUND' });
  if (player.is_admin) return res.status(409).json({ error: 'Det aktiva superuser-kontot kan inte raderas permanent.', code: 'ADMIN_DELETE_BLOCKED' });
  if (!player.archived) return res.status(409).json({ error: 'Arkivera spelaren först. Permanent radering är steg två.', code: 'PLAYER_NOT_ARCHIVED' });
  requireConfirmation(req, [`RADERA SPELARE ${player.name}`, `DELETE PLAYER ${player.name}`]);

  const activePlayer = db.prepare(`
    SELECT m.id FROM matches m JOIN match_players mp ON mp.match_id=m.id
    WHERE m.status='active' AND mp.player_id=? LIMIT 1
  `).get(id);
  if (activePlayer) return res.status(409).json({ error: `Spelaren deltar i aktiv match #${activePlayer.id}.`, code: 'PLAYER_IN_ACTIVE_MATCH' });

  const activeOwnedDeck = db.prepare(`
    SELECT m.id,d.id AS deck_id,d.name AS deck_name
    FROM decks d
    JOIN match_players mp ON mp.deck_id=d.id
    JOIN matches m ON m.id=mp.match_id
    WHERE d.owner_id=? AND m.status='active'
    LIMIT 1
  `).get(id);
  if (activeOwnedDeck) {
    return res.status(409).json({
      error: `Spelarens kortlek "${activeOwnedDeck.deck_name}" används i aktiv match #${activeOwnedDeck.id}.`,
      code: 'OWNED_DECK_IN_ACTIVE_MATCH'
    });
  }

  const backupPath = await forcedBackup();
  const ownedDecks = db.prepare('SELECT * FROM decks WHERE owner_id=? ORDER BY id').all(id);

  db.transaction(() => {
    for (const deck of ownedDecks) recordDeckTombstone(deck);
    recordPlayerTombstone(player);
    db.prepare('DELETE FROM decks WHERE owner_id=?').run(id);
    db.prepare('DELETE FROM players WHERE id=?').run(id);
    audit(req.authPlayer.id, 'PLAYER_PERMANENTLY_DELETED', 'player', id, {
      player_uid: player.entity_uid,
      player_name_snapshot: player.name,
      deleted_decks: ownedDecks.length
    });
  })();

  res.json({
    success: true,
    permanently_deleted: true,
    player_id: id,
    player_uid: player.entity_uid,
    deleted_decks: ownedDecks.length,
    backup_path: backupPath
  });
}));

router.delete('/decks/:id', (req, res) => {
  const id = positiveId(req.params.id, 'deck_id');
  const deck = db.prepare('SELECT d.*,p.name AS owner_name FROM decks d JOIN players p ON p.id=d.owner_id WHERE d.id=?').get(id);
  if (!deck) return res.status(404).json({ error: 'Kortleken hittades inte.', code: 'DECK_NOT_FOUND' });
  const active = activeMatchForDeck(id);
  if (active) return res.status(409).json({ error: `Kortleken används i aktiv match #${active.id}.`, code: 'DECK_IN_ACTIVE_MATCH' });
  if (!deck.archived) {
    db.prepare('UPDATE decks SET archived=1,archived_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP,sync_revision=? WHERE id=?')
      .run(db.nextSyncRevision('decks'), id);
    audit(req.authPlayer.id, 'DECK_ARCHIVED', 'deck', id, { deck_name: deck.name, owner_name: deck.owner_name });
  }
  res.json({ success: true, archived: true, deck_id: id });
});

router.post('/decks/:id/restore', (req, res) => {
  const id = positiveId(req.params.id, 'deck_id');
  const deck = db.prepare('SELECT d.*,p.archived AS owner_archived FROM decks d JOIN players p ON p.id=d.owner_id WHERE d.id=?').get(id);
  if (!deck) return res.status(404).json({ error: 'Kortleken hittades inte.', code: 'DECK_NOT_FOUND' });
  if (deck.owner_archived) return res.status(409).json({ error: 'Spelaren som äger kortleken är borttagen. Återställ spelaren först.', code: 'OWNER_ARCHIVED' });
  const activeNameConflict = db.prepare(`
    SELECT id FROM decks
    WHERE owner_id=? AND name=? COLLATE NOCASE AND archived=0 AND id<>?
  `).get(deck.owner_id, deck.name, id);
  if (activeNameConflict) {
    return res.status(409).json({
      error: 'En aktiv kortlek med detta namn finns redan under spelaren.',
      code: 'DECK_NAME_CONFLICT',
      retryable: false
    });
  }
  db.prepare('UPDATE decks SET archived=0,archived_at=NULL,updated_at=CURRENT_TIMESTAMP,sync_revision=? WHERE id=?')
    .run(db.nextSyncRevision('decks'), id);
  audit(req.authPlayer.id, 'DECK_RESTORED', 'deck', id, { deck_name: deck.name });
  res.json({ success: true, restored: true, deck_id: id });
});

router.delete('/decks/:id/permanent', asyncHandler(async (req, res) => {
  const id = positiveId(req.params.id, 'deck_id');
  const deck = db.prepare(`
    SELECT d.*,p.name AS owner_name
    FROM decks d JOIN players p ON p.id=d.owner_id
    WHERE d.id=?
  `).get(id);
  if (!deck) return res.status(404).json({ error: 'Kortleken hittades inte.', code: 'DECK_NOT_FOUND' });
  if (!deck.archived) return res.status(409).json({ error: 'Arkivera kortleken först. Permanent radering är steg två.', code: 'DECK_NOT_ARCHIVED' });
  requireConfirmation(req, [`RADERA KORTLEK ${deck.name}`, `DELETE DECK ${deck.name}`]);

  const active = activeMatchForDeck(id);
  if (active) return res.status(409).json({ error: `Kortleken används i aktiv match #${active.id}.`, code: 'DECK_IN_ACTIVE_MATCH' });

  const backupPath = await forcedBackup();
  db.transaction(() => {
    recordDeckTombstone(deck);
    db.prepare('DELETE FROM decks WHERE id=?').run(id);
    audit(req.authPlayer.id, 'DECK_PERMANENTLY_DELETED', 'deck', id, {
      deck_uid: deck.entity_uid,
      deck_name_snapshot: deck.name,
      owner_name_snapshot: deck.owner_name
    });
  })();

  res.json({
    success: true,
    permanently_deleted: true,
    deck_id: id,
    deck_uid: deck.entity_uid,
    backup_path: backupPath
  });
}));

router.delete('/matches/:id', asyncHandler(async (req, res) => {
  const id = positiveId(req.params.id, 'match_id');
  const match = db.prepare('SELECT * FROM matches WHERE id=?').get(id);
  if (!match) return res.status(404).json({ error: 'Matchen hittades inte.', code: 'MATCH_NOT_FOUND' });
  if (match.status === 'active') return res.status(409).json({ error: 'En aktiv match kan inte raderas ur statistiken. Avsluta eller avbryt den först.', code: 'ACTIVE_MATCH_DELETE_BLOCKED' });
  requireConfirmation(req, [`RADERA MATCH ${id}`, `DELETE MATCH ${id}`]);

  const snapshot = db.prepare(`
    SELECT
      COALESCE(p.name,mp.player_name_snapshot,'Raderad spelare') AS player_name,
      COALESCE(d.name,mp.deck_name_snapshot,'Raderad kortlek') AS deck_name,
      mp.is_winner
    FROM match_players mp
    LEFT JOIN players p ON p.id=mp.player_id
    LEFT JOIN decks d ON d.id=mp.deck_id
    WHERE mp.match_id=?
    ORDER BY mp.seat_index
  `).all(id);

  const backupPath = await forcedBackup();
  db.transaction(() => {
    db.prepare('DELETE FROM matches WHERE id=?').run(id);
    audit(req.authPlayer.id, 'MATCH_DELETED', 'match', id, { status: match.status, players: snapshot });
  })();

  res.json({ success: true, deleted: true, match_id: id, backup_path: backupPath });
}));

// Statistik är dynamiskt beräknad från completed matcher. Därför är
// "nollställ statistik" samma destruktiva operation som att radera matcherna.
router.post('/reset/matches', asyncHandler(async (req, res) => {
  requireConfirmation(req, ['NOLLSTÄLL MATCHER', 'RESET MATCHES']);
  const active = activeMatchExists();
  if (active) return res.status(409).json({ error: `Aktiv match #${active.id} finns. Avsluta/avbryt den först.`, code: 'ACTIVE_MATCHES_PRESENT' });

  const backupPath = await forcedBackup();
  const count = db.prepare('SELECT COUNT(*) AS n FROM matches').get().n;
  db.transaction(() => {
    db.prepare('DELETE FROM matches').run();
    audit(req.authPlayer.id, 'ALL_MATCHES_RESET', 'database', null, { deleted_matches: count });
  })();

  res.json({ success: true, deleted_matches: count, statistics_reset: true, backup_path: backupPath });
}));

router.post('/reset/decks', asyncHandler(async (req, res) => {
  requireConfirmation(req, ['RADERA ALLA KORTLEKAR', 'DELETE ALL DECKS']);
  const active = activeMatchExists();
  if (active) return res.status(409).json({ error: `Aktiv match #${active.id} finns. Avsluta/avbryt den först.`, code: 'ACTIVE_MATCHES_PRESENT' });

  const backupPath = await forcedBackup();
  const decks = db.prepare('SELECT * FROM decks ORDER BY id').all();

  db.transaction(() => {
    for (const deck of decks) recordDeckTombstone(deck);
    db.prepare('DELETE FROM decks').run();
    audit(req.authPlayer.id, 'ALL_DECKS_RESET', 'database', null, { deleted_decks: decks.length });
  })();

  res.json({ success: true, deleted_decks: decks.length, backup_path: backupPath });
}));

router.post('/reset/players', asyncHandler(async (req, res) => {
  requireConfirmation(req, ['RADERA ALLA SPELARE', 'DELETE ALL PLAYERS']);
  const active = activeMatchExists();
  if (active) return res.status(409).json({ error: `Aktiv match #${active.id} finns. Avsluta/avbryt den först.`, code: 'ACTIVE_MATCHES_PRESENT' });

  const adminId = Number(req.authPlayer.id);
  const backupPath = await forcedBackup();
  const players = db.prepare('SELECT * FROM players WHERE id<>? ORDER BY id').all(adminId);
  const decks = db.prepare('SELECT * FROM decks WHERE owner_id<>? ORDER BY id').all(adminId);

  db.transaction(() => {
    for (const deck of decks) recordDeckTombstone(deck);
    for (const player of players) recordPlayerTombstone(player);

    db.prepare('DELETE FROM decks WHERE owner_id<>?').run(adminId);
    // Om någon annan admin har skrivit auditposter måste de tas bort/nullas innan kontot raderas.
    db.prepare('UPDATE admin_audit_log SET actor_player_id=NULL WHERE actor_player_id<>?').run(adminId);
    db.prepare('DELETE FROM players WHERE id<>?').run(adminId);
    audit(adminId, 'ALL_PLAYERS_RESET', 'database', null, {
      deleted_players: players.length,
      deleted_decks: decks.length
    });
  })();

  res.json({
    success: true,
    deleted_players: players.length,
    deleted_decks: decks.length,
    backup_path: backupPath
  });
}));

router.post('/reset/factory', asyncHandler(async (req, res) => {
  requireConfirmation(req, ['FABRIKSÅTERSTÄLL', 'FACTORY RESET']);
  const password = String(req.body?.password || '');
  const adminId = Number(req.authPlayer.id);
  const admin = db.prepare('SELECT * FROM players WHERE id=? AND is_admin=1').get(adminId);
  if (!admin || !admin.password_hash || !(await bcrypt.compare(password, admin.password_hash))) {
    return res.status(403).json({ error: 'Adminlösenordet är fel.', code: 'ADMIN_PASSWORD_REQUIRED' });
  }

  const backupPath = await forcedBackup();
  const counts = {
    matches: db.prepare('SELECT COUNT(*) AS n FROM matches').get().n,
    decks: db.prepare('SELECT COUNT(*) AS n FROM decks').get().n,
    players: db.prepare('SELECT COUNT(*) AS n FROM players WHERE id<>?').get(adminId).n
  };

  const decks = db.prepare('SELECT * FROM decks ORDER BY id').all();
  const players = db.prepare('SELECT * FROM players WHERE id<>? ORDER BY id').all(adminId);

  db.transaction(() => {
    for (const deck of decks) recordDeckTombstone(deck);
    for (const player of players) recordPlayerTombstone(player);

    db.prepare('DELETE FROM matches').run();
    db.prepare('DELETE FROM decks').run();

    // Rensa gammal adminlogg innan andra konton tas bort; logga sedan endast själva reseten.
    db.prepare('DELETE FROM admin_audit_log').run();
    db.prepare('DELETE FROM players WHERE id<>?').run(adminId);
    db.prepare(`
      UPDATE players
      SET is_admin=1,archived=0,archived_at=NULL,updated_at=CURRENT_TIMESTAMP
      WHERE id=?
    `).run(adminId);

    const previousInstanceUid = db.instanceUid;
    const newInstanceUid = db.rotateInstanceUid();
    audit(adminId, 'DATABASE_FACTORY_RESET', 'database', null, {
      ...counts,
      previous_instance_uid: previousInstanceUid,
      new_instance_uid: newInstanceUid
    });
  })();

  res.json({
    success: true,
    factory_reset: true,
    admin_player_id: adminId,
    deleted: counts,
    backup_path: backupPath,
    instance_uid: db.instanceUid,
    note: 'Endast aktuellt admin-konto finns kvar som användare. Sync-tombstones behålls internt för gamla Androidklienter. Installationens instance_uid har roterats.'
  });
}));

router.get('/audit-log', (req, res) => {
  const rows = db.prepare(`
    SELECT a.id,a.action,a.target_type,a.target_id,a.details_json,a.created_at,p.name AS actor_name
    FROM admin_audit_log a
    LEFT JOIN players p ON p.id=a.actor_player_id
    ORDER BY a.id DESC
    LIMIT 100
  `).all().map(row => ({
    ...row,
    details: (() => { try { return JSON.parse(row.details_json || '{}'); } catch (_) { return {}; } })()
  }));
  res.json(rows);
});

module.exports = router;
