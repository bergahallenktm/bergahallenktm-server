'use strict';

const express = require('express');
const db = require('../db');
const asyncHandler = require('../asyncHandler');
const { requireAuth } = require('../authz');
const localLogger = require('../localLogger');
const {
  ACCOUNT_DELETION_CONTRACT_VERSION,
  preview,
  deleteAuthenticatedAccount
} = require('../accountDeletionService');

function createAccountDeletionRouter({ sessionStore } = {}) {
  const router = express.Router();
  router.use(requireAuth);

  router.get('/deletion', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json(preview(db, req.authPlayer.id));
  });

  router.post('/deletion', asyncHandler(async (req, res) => {
    const playerId = Number(req.authPlayer.id);
    const result = await deleteAuthenticatedAccount({
      db,
      playerId,
      currentPassword: req.body?.current_password,
      confirm: req.body?.confirm === true
    });

    // Remove every persisted web/Android session for the deleted account. The
    // current request session is destroyed separately so express-session cannot
    // save it again while sending the success response.
    if (sessionStore?.destroyUserSessions) {
      await new Promise((resolve, reject) => sessionStore.destroyUserSessions(playerId, err => err ? reject(err) : resolve()));
    }

    await new Promise((resolve, reject) => {
      if (!req.session) return resolve();
      req.session.destroy(err => err ? reject(err) : resolve());
    });

    res.clearCookie('connect.sid');
    localLogger.info('auth', 'Account self-deletion completed', {
      request_id: req.requestId || null,
      contract_version: ACCOUNT_DELETION_CONTRACT_VERSION,
      deletion_receipt_id: result.deletion_receipt_id
    });
    res.status(200).json({
      deleted: true,
      contract_version: ACCOUNT_DELETION_CONTRACT_VERSION,
      deletion_receipt_id: result.deletion_receipt_id,
      deleted_at: result.deleted_at
    });
  }));

  return router;
}

module.exports = { createAccountDeletionRouter };
