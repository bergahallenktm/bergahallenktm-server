const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { requirePermission } = require('../authz');
const { ENGINE_VERSION, RULES_VERSION, resolveMatchSetup, rulesSnapshot, publicMatchOptions, validateAndDecorateParticipants, buildTeamStates } = require('../matchFormatEngine');
const {
  isHiddenRoleMode, assignServerHiddenState, applyOfflineHiddenSnapshot,
  generateRevealToken, hashRevealToken, safeTokenEqual, sanitizePublicMatch,
  privateSecretPayload
} = require('../hiddenRoleEngine');
const {
  asPositiveInt, asInteger, requestFingerprint, formatDuration, parseCommanderDamage,
  normalizeTeamMode, parseMatchRules, normalizeDayNightState, dayNightStateFromCode,
  sqliteTimestampToMs, sqliteTimestampToIso, sqliteTimestampMs, isCanonicalUuid, firstDefined,
  parseJsonObject, normalizeOfflineTimestamp, canonicalOfflineEventType, parseHistoryFilters, buildHistoryWhere
} = require('../matchRouteUtils');
const { createMatchStateService } = require('../matchStateService');
const { createMatchMutationService } = require('../matchMutationService');

const router = express.Router();
const requireMatchManage = requirePermission('matches.manage');
const {
  fetchTeamStates, buildTeams, withTeamMetadata, getTimerState, snapshotTimer,
  fetchMatch, listActiveMatches, mutationMatchState
} = createMatchStateService({ db, sanitizePublicMatch });

// 3.9.12.1: only /matches mutation paths are Server Mode persistent actions and
// require an authenticated player/admin. The router is mounted both at /api and
// /api/v1, so an unscoped router.use() would also intercept unrelated POSTs such
// as /api/v1/auth/login and /api/v1/auth/register before the v1 auth router.
// Read-only match/history paths stay backward-compatible.
router.use('/matches', (req, res, next) => req.method === 'GET' ? next() : requireMatchManage(req, res, next));


const MATCH_FORMATS = {
  'Commander': { name: 'Commander (40 Liv, 2-6 spelare)', name_key: 'format.Commander', life: 40, minPlayers: 2, maxPlayers: 6 },
  'KTM': { name: 'KTM - Kitchen Table Magic (20 Liv, 2-6 spelare)', name_key: 'format.KTM', life: 20, minPlayers: 2, maxPlayers: 6 },
  '1v1': { name: '1v1 Constructed (20 Liv, exakt 2 spelare)', name_key: 'format.1v1', life: 20, minPlayers: 2, maxPlayers: 2 },
  'Casual 4+': { name: 'Casual 4+ (20 Liv, minst 4 spelare)', name_key: 'format.Casual4', life: 20, minPlayers: 4, maxPlayers: 6 },
  'Oathbreaker': { name: 'Oathbreaker (20 Liv, 2-6 spelare)', name_key: 'format.Oathbreaker', life: 20, minPlayers: 2, maxPlayers: 6 }
};

function routeError(res, err, defaultStatus = 400, defaultCode = 'INVALID_REQUEST') {
  const status = Number(err?.status || defaultStatus);
  return res.status(Number.isInteger(status) ? status : defaultStatus).json({
    error: err?.message || 'Ogiltig begäran.',
    code: err?.code || defaultCode
  });
}



function canonicalMatchUid(matchId) {
  return db.prepare('SELECT client_match_uid FROM matches WHERE id=?').get(matchId)?.client_match_uid || null;
}
function expectedMatchUidGuard(req, res, matchId) {
  const expected = String(req.get('X-BergaHallen-Expected-Match-Uid') || '').trim();
  if (!expected) return true; // API v1 legacy compatibility.
  const actual = canonicalMatchUid(matchId);
  if (!actual) return true;
  if (expected !== actual) {
    res.status(409).json({ success:false, error:'Matchens stabila identitet matchar inte längre route-ID:t.', code:'MATCH_IDENTITY_MISMATCH', retryable:false, expected_match_uid:expected, actual_match_uid:actual });
    return false;
  }
  return true;
}
function actorUid(req) {
  return String(req.session?.user?.entity_uid || req.session?.user?.id || '');
}
function reliableMatchMutation(operationKind, handler) {
  return (req, res) => {
    let matchId;
    try { matchId = asPositiveInt(req.params.id, 'match_id'); }
    catch (err) { return routeError(res, err); }
    if (!expectedMatchUidGuard(req, res, matchId)) return;
    const operationUid = String(req.get('X-BergaHallen-Client-Operation-Uid') || '').trim();
    if (!operationUid) return handler(req, res); // old API v1 client: accepted, not replay-safe.
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(operationUid)) return res.status(400).json({ success:false,error:'client_operation_uid måste vara ett giltigt UUID.',code:'INVALID_IDEMPOTENCY_KEY',retryable:false });
    const targetUid = canonicalMatchUid(matchId);
    const fingerprint = requestFingerprint({ method:req.method, operation_kind:operationKind, match_id:matchId, match_uid:targetUid, body:req.body || {}, actor:actorUid(req) });
    const existing = db.prepare("SELECT * FROM idempotency_operations WHERE key_type='client_operation_uid' AND idempotency_key=?").get(operationUid);
    if (existing) {
      if (existing.operation_kind !== operationKind || Number(existing.target_id) !== matchId || String(existing.target_uid || '') !== String(targetUid || '') || existing.request_fingerprint !== fingerprint) {
        return res.status(409).json({ success:false,error:'Samma idempotency key har redan använts för en annan operation.',code:'IDEMPOTENCY_KEY_REUSE',retryable:false });
      }
      return res.status(Number(existing.result_status || 200)).json({ success:true,idempotent_replay:true,...mutationMatchState(matchId) });
    }
    let capturedStatus=200, capturedBody=null, capturedHeaders={};
    const originalStatus=res.status.bind(res), originalJson=res.json.bind(res), originalSet=res.set.bind(res);
    const proxy=Object.create(res);
    proxy.status=(code)=>{ capturedStatus=Number(code)||200; return proxy; };
    proxy.json=(body)=>{ capturedBody=body; return proxy; };
    proxy.set=(key,value)=>{ if (typeof key==='string') capturedHeaders[key]=value; else if (key && typeof key==='object') Object.assign(capturedHeaders,key); return proxy; };
    try {
      db.transaction(() => {
        handler(req, proxy);
        if (capturedBody === null) throw Object.assign(new Error('Mutation returnerade inget synkront JSON-svar.'),{code:'RELIABILITY_RESPONSE_CAPTURE_FAILED',status:500});
        if (capturedStatus >= 200 && capturedStatus < 300) {
          db.prepare(`INSERT INTO idempotency_operations
            (key_type,idempotency_key,operation_kind,target_type,target_id,target_uid,actor_uid,request_fingerprint,result_status)
            VALUES ('client_operation_uid',?,?,?,?,?,?,?,?)`)
            .run(operationUid,operationKind,'match',matchId,targetUid,actorUid(req),fingerprint,capturedStatus);
        }
      })();
    } catch (err) { return routeError(res,err,err.status||500,err.code||'INTERNAL_SERVER_ERROR'); }
    for (const [k,v] of Object.entries(capturedHeaders)) originalSet(k,v);
    originalStatus(capturedStatus);
    return originalJson(capturedBody);
  };
}
function reliableAbort(handler) {
  return (req,res) => {
    let matchId; try { matchId=asPositiveInt(req.params.id,'match_id'); } catch(err){ return routeError(res,err); }
    if (!expectedMatchUidGuard(req,res,matchId)) return;
    return handler(req,res);
  };
}



const DAY_NIGHT_CODES = Object.freeze({ none: 0, day: 1, night: 2 });

function orderedOfflineEvents(events, fallbackTimestamp = null) {
  return [...(Array.isArray(events) ? events : [])].sort((a, b) => {
    const aSeq = Number(firstDefined(a?.sequence, a?.sequence_number, a?.sequenceNumber, a?.seq));
    const bSeq = Number(firstDefined(b?.sequence, b?.sequence_number, b?.sequenceNumber, b?.seq));
    const aHasSeq = Number.isFinite(aSeq);
    const bHasSeq = Number.isFinite(bSeq);
    if (aHasSeq && bHasSeq && aSeq !== bSeq) return aSeq - bSeq;
    if (aHasSeq !== bHasSeq) return aHasSeq ? -1 : 1;
    return String(offlineEventTimestamp(a || {}, fallbackTimestamp) || '')
      .localeCompare(String(offlineEventTimestamp(b || {}, fallbackTimestamp) || ''));
  });
}

function validateOfflineDayNightJournal(events, explicitFinalState, fallbackTimestamp = null) {
  let current = 'none';
  let seen = 0;
  for (const event of orderedOfflineEvents(events, fallbackTimestamp)) {
    if (canonicalOfflineEventType(firstDefined(event?.event_type, event?.eventType, event?.type)) !== 'DAY_NIGHT_CHANGE') continue;
    const prevCode = Number(firstDefined(event.prev_value, event.prevValue));
    const newCode = Number(firstDefined(event.new_value, event.newValue, event.change_value, event.changeValue));
    if (![0, 1, 2].includes(prevCode) || ![1, 2].includes(newCode) || prevCode === newCode) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'DAY_NIGHT_CHANGE innehåller ogiltiga prev/new-värden.');
    }
    const expectedPrev = DAY_NIGHT_CODES[current];
    if (prevCode !== expectedPrev) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'DAY_NIGHT_CHANGE-journalen är inte deterministisk från föregående state.');
    }
    current = dayNightStateFromCode(newCode);
    seen++;
  }

  if (explicitFinalState !== undefined && explicitFinalState !== null && explicitFinalState !== '') {
    const normalized = normalizeDayNightState(explicitFinalState, { allowNone: true });
    if (normalized !== current) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'match.day_night_state matchar inte den importerade DAY_NIGHT_CHANGE-journalen.');
    }
    return normalized;
  }
  return seen > 0 ? current : 'none';
}

function logTurnStart(matchId, playerId, roundNumber, createdAt = null, metadata = null) {
  db.prepare(`
    INSERT INTO match_events
      (match_id, player_id, event_type, change_value, prev_value, new_value, round_number, created_at, metadata_json)
    VALUES (?, ?, 'TURN_START', 0, 0, 0, ?, COALESCE(?, CURRENT_TIMESTAMP), ?)
  `).run(matchId, playerId, roundNumber, createdAt, metadata ? JSON.stringify(metadata) : null);
}

function closeCurrentTurn(matchId, endedAt = null, metadata = null) {
  const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
  if (!match) return null;
  const players = db.prepare('SELECT player_id FROM match_players WHERE match_id=? ORDER BY seat_index').all(matchId);
  const activePlayer = players[Number(match.active_player_index)] || players[0];
  if (!activePlayer) return null;

  const latestStart = db.prepare("SELECT * FROM match_events WHERE match_id=? AND event_type='TURN_START' ORDER BY id DESC LIMIT 1").get(matchId);
  const latestEnd = db.prepare("SELECT * FROM match_events WHERE match_id=? AND event_type='TURN_END' ORDER BY id DESC LIMIT 1").get(matchId);
  if (latestStart && latestEnd && latestEnd.id > latestStart.id) return latestEnd;

  const endValue = endedAt || db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;
  const startValue = latestStart?.created_at || match.turn_started_at || match.started_at || endValue;
  const startMs = sqliteTimestampToMs(startValue) || Date.now();
  const endMs = sqliteTimestampToMs(endValue) || Date.now();
  const duration = Math.max(0, Math.round((endMs - startMs) / 1000));

  const info = db.prepare(`
    INSERT INTO match_events
      (match_id, player_id, event_type, change_value, prev_value, new_value, round_number, created_at, duration_seconds, metadata_json)
    VALUES (?, ?, 'TURN_END', ?, 0, 0, ?, ?, ?, ?)
  `).run(matchId, activePlayer.player_id, duration, match.current_round || 1, endValue, duration, metadata ? JSON.stringify(metadata) : null);
  return db.prepare('SELECT * FROM match_events WHERE id=?').get(info.lastInsertRowid);
}

function validateParticipants(participants, matchType, teamMode = 'ffa', resolvedSetup = null) {
  if (!Array.isArray(participants)) throw new Error('Ogiltigt format på deltagare.');
  const legacy = MATCH_FORMATS[matchType] || { minPlayers: 2, maxPlayers: 6 };
  const config = resolvedSetup
    ? { minPlayers: resolvedSetup.min_players, maxPlayers: resolvedSetup.max_players }
    : legacy;
  if (participants.length < config.minPlayers || participants.length > config.maxPlayers) {
    throw new Error(`${matchType} kräver mellan ${config.minPlayers} och ${config.maxPlayers} spelare för valt spelsätt.`);
  }

  const seenPlayers = new Set();
  const seenDecks = new Set();
  const deckSelectionMode = resolvedSetup?.deck_selection_mode || 'required';
  const validated = participants.map((p, index) => {
    const playerId = asPositiveInt(p.player_id, 'player_id');
    const rawDeckId = Number(p.deck_id);
    const hasDeck = Number.isInteger(rawDeckId) && rawDeckId > 0;
    if (!hasDeck && deckSelectionMode === 'required') {
      const err = new Error('Vald matchtyp kräver en registrerad kortlek för varje spelare.');
      err.code = 'DECK_REQUIRED';
      throw err;
    }
    const deckId = hasDeck ? rawDeckId : null;
    const teamNumber = teamMode === 'teams'
      ? asPositiveInt(p.team_number, 'team_number')
      : index + 1;

    if (seenPlayers.has(playerId)) throw new Error('En spelare kan inte delta mer än en gång i samma match.');
    if (deckId && seenDecks.has(deckId)) throw new Error('Samma kortlek kan inte spelas av fler än en spelare i samma match.');
    seenPlayers.add(playerId);
    if (deckId) seenDecks.add(deckId);

    const player = db.prepare('SELECT id, entity_uid, name FROM players WHERE id = ? AND archived=0 AND is_admin=0').get(playerId);
    const deck = deckId ? db.prepare('SELECT d.id, d.entity_uid, d.name, d.owner_id, d.color_identity, p.name AS owner_name, p.entity_uid AS owner_uid FROM decks d JOIN players p ON p.id = d.owner_id WHERE d.id = ? AND d.archived = 0 AND p.archived=0').get(deckId) : null;
    if (!player || (deckId && !deck)) throw new Error('Vald spelare eller kortlek finns inte i databasen.');

    // Avsiktligt ingen kontroll av deckägare: familjen får låna varandras kortlekar.
    // Limited kan dessutom använda deck_id=null så en draft/sealed-match inte
    // tvingar fram permanenta serverdecks bara för matchspårning.
    return { player_id: playerId, player_uid: player.entity_uid || null, player_name: player.name, deck_id: deckId, deck_uid: deck?.entity_uid || null, deck_name: deck?.name || null, deck_color_identity: deck?.color_identity || null, deck_owner_uid: deck?.owner_uid || null, deck_owner_name: deck?.owner_name || null, team_number: teamNumber };
  });

  if (teamMode === 'teams') {
    const teamNumbers = [...new Set(validated.map(p => p.team_number))];
    if (teamNumbers.length < 2) throw new Error('En lagmatch måste innehålla minst två lag.');
    if (teamNumbers.length >= validated.length) {
      throw new Error('Lagmatch kräver att minst två spelare tillhör samma lag. Välj Alla mot alla för FFA.');
    }
  }

  return resolvedSetup ? validateAndDecorateParticipants(validated, resolvedSetup) : validated;
}

function assertParticipantsAvailable(participants) {
  for (const p of participants) {
    const playerConflict = db.prepare(`
      SELECT m.id, m.table_name
      FROM matches m JOIN match_players mp ON mp.match_id = m.id
      WHERE m.status = 'active' AND mp.player_id = ? LIMIT 1
    `).get(p.player_id);
    if (playerConflict) {
      throw new Error(`${p.player_name} deltar redan i ${playerConflict.table_name || `Bord ${playerConflict.id}`}.`);
    }

    if (p.deck_id) {
      const deckConflict = db.prepare(`
        SELECT m.id, m.table_name, d.name
        FROM matches m JOIN match_players mp ON mp.match_id = m.id JOIN decks d ON d.id = mp.deck_id
        WHERE m.status = 'active' AND mp.deck_id = ? LIMIT 1
      `).get(p.deck_id);
      if (deckConflict) {
        throw new Error(`Kortleken "${deckConflict.name}" används redan i ${deckConflict.table_name || `Bord ${deckConflict.id}`}.`);
      }
    }
  }
}

function getEliminationState(player, rules = {}) {
  if (player.eliminated_reason === 'Conceded') return { eliminated: 1, reason: 'Conceded' };
  if (Number(player.current_life) <= 0) return { eliminated: 1, reason: '0 HP' };
  const poisonThreshold = Math.max(1, Number(rules.poison_loss_threshold || 10));
  if ((Number(player.poison_counters) || 0) >= poisonThreshold) return { eliminated: 1, reason: `Poison (${poisonThreshold}+)` };

  const commanderDamageScope = rules.commander_damage_scope || (rules.match_profile === 'commander' ? 'player' : 'none');
  if (commanderDamageScope !== 'none') {
    const damage = parseCommanderDamage(player.commander_damage);
    for (const [sourceId, value] of Object.entries(damage)) {
      if (Number(value) >= 21) {
        const source = db.prepare('SELECT name FROM players WHERE id = ?').get(Number(sourceId));
        return { eliminated: 1, reason: `Cmdr Dmg (${source?.name || 'Motståndare'})` };
      }
    }
  }
  return { eliminated: 0, reason: null };
}

function setTeamEliminated(matchId, teamNumber, eliminated, reason = null) {
  db.prepare('UPDATE match_players SET is_eliminated=?, eliminated_reason=? WHERE match_id=? AND team_number=?')
    .run(eliminated ? 1 : 0, eliminated ? reason : null, matchId, teamNumber);
  db.prepare('UPDATE match_teams SET is_eliminated=? WHERE match_id=? AND team_number=?')
    .run(eliminated ? 1 : 0, matchId, teamNumber);
}

function refreshPlayerElimination(matchId, playerId) {
  const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
  const player = db.prepare('SELECT * FROM match_players WHERE match_id = ? AND player_id = ?').get(matchId, playerId);
  if (!player) throw new Error('Spelaren deltar inte i matchen.');
  const rules = parseMatchRules(match);
  const state = getEliminationState(player, rules);

  // Two-Headed Giant använder lagbaserade förlustvillkor för delat liv,
  // delat poison och commander-damage-scope. En träffad tröskel slår därför
  // ut hela laget, inte bara kortet som råkade användas för registreringen.
  if (rules.life_scope === 'team' && Number(player.current_life) <= 0) {
    setTeamEliminated(matchId, Number(player.team_number), true, '0 HP');
    return { eliminated: 1, reason: '0 HP', team_eliminated: true };
  }
  if (rules.poison_scope === 'team' && Number(player.poison_counters || 0) >= Number(rules.poison_loss_threshold || 10)) {
    const reason = `Poison (${Number(rules.poison_loss_threshold || 10)}+)`;
    setTeamEliminated(matchId, Number(player.team_number), true, reason);
    return { eliminated: 1, reason, team_eliminated: true };
  }
  if (rules.commander_damage_scope === 'team' && state.eliminated && String(state.reason || '').startsWith('Cmdr Dmg')) {
    setTeamEliminated(matchId, Number(player.team_number), true, state.reason);
    return { ...state, team_eliminated: true };
  }

  db.prepare('UPDATE match_players SET is_eliminated = ?, eliminated_reason = ? WHERE match_id = ? AND player_id = ?')
    .run(state.eliminated, state.reason, matchId, playerId);
  return state;
}

function updateTeamWinnerFlags(matchId, winningTeam = null) {
  db.prepare('UPDATE match_players SET is_winner=0 WHERE match_id=?').run(matchId);
  db.prepare('UPDATE match_teams SET is_winner=0 WHERE match_id=?').run(matchId);
  if (winningTeam != null) {
    db.prepare('UPDATE match_players SET is_winner=1 WHERE match_id=? AND team_number=?').run(matchId, winningTeam);
    db.prepare('UPDATE match_teams SET is_winner=1 WHERE match_id=? AND team_number=?').run(matchId, winningTeam);
  }
}

function completeMatchForTeam(matchId, winningTeam) {
  const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
  if (match?.status === 'active') {
    snapshotTimer(matchId);
    closeCurrentTurn(matchId, null, { reason: 'match_completed' });
  }
  db.prepare("UPDATE matches SET status='completed', ended_at=COALESCE(ended_at,CURRENT_TIMESTAMP), timer_is_running=0 WHERE id=?").run(matchId);
  updateTeamWinnerFlags(matchId, winningTeam);
}


function parseVariantState(match) {
  return parseJsonObject(match?.variant_state_json, {}) || {};
}

function writeVariantState(matchId, state) {
  db.prepare("UPDATE matches SET variant_state_json=? WHERE id=?").run(JSON.stringify(state || {}), matchId);
}

function completeMatchForPlayers(matchId, playerIds) {
  const winnerIds = [...new Set((playerIds || []).map(Number).filter(n => Number.isInteger(n) && n > 0))];
  const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
  if (match?.status === 'active') {
    snapshotTimer(matchId);
    closeCurrentTurn(matchId, null, { reason:'hidden_role_match_completed' });
  }
  db.prepare("UPDATE matches SET status='completed', ended_at=COALESCE(ended_at,CURRENT_TIMESTAMP), timer_is_running=0 WHERE id=?").run(matchId);
  db.prepare('UPDATE match_players SET is_winner=0 WHERE match_id=?').run(matchId);
  db.prepare('UPDATE match_teams SET is_winner=0 WHERE match_id=?').run(matchId);
  for (const playerId of winnerIds) {
    db.prepare('UPDATE match_players SET is_winner=1 WHERE match_id=? AND player_id=?').run(matchId, playerId);
    db.prepare(`UPDATE match_teams SET is_winner=1 WHERE match_id=? AND team_number=(
      SELECT team_number FROM match_players WHERE match_id=? AND player_id=?
    )`).run(matchId, matchId, playerId);
  }
}

function refreshHiddenRoleWinner(matchId, match, rules, players) {
  if (!isHiddenRoleMode(rules.play_mode || match.play_mode)) return false;
  const alive = players.filter(p => !p.is_eliminated);

  if ((rules.play_mode || match.play_mode) === 'assassin') {
    if (alive.length === 1) completeMatchForPlayers(matchId, [alive[0].player_id]);
    else if (match.status === 'completed') {
      db.prepare("UPDATE matches SET status='active', ended_at=NULL WHERE id=? AND status!='aborted'").run(matchId);
      db.prepare('UPDATE match_players SET is_winner=0 WHERE match_id=?').run(matchId);
      db.prepare('UPDATE match_teams SET is_winner=0 WHERE match_id=?').run(matchId);
    }
    return true;
  }

  // Kingdoms / Treachery.
  const state = parseVariantState(match);
  const king = players.find(p => p.role_key === 'king');
  const assassin = players.find(p => p.role_key === 'assassin');
  const bandits = players.filter(p => p.role_key === 'bandit');
  const knights = players.filter(p => p.role_key === 'knight');
  const usurper = players.find(p => p.role_key === 'usurper');

  // Assassin vinner ensam även om King föll på samma mutation.
  if (alive.length === 1 && assassin && Number(alive[0].player_id) === Number(assassin.player_id)) {
    state.throne_claim_pending = false;
    writeVariantState(matchId, state);
    completeMatchForPlayers(matchId, [assassin.player_id]);
    return true;
  }

  if (king && !king.is_eliminated) {
    if (state.throne_claim_pending) {
      state.throne_claim_pending = false;
      state.fallen_king_player_id = null;
      writeVariantState(matchId, state);
    }
    if (bandits.every(p => !!p.is_eliminated) && (!assassin || assassin.is_eliminated)) {
      completeMatchForPlayers(matchId, [king.player_id, ...knights.map(p => p.player_id)]);
      return true;
    }
    if (match.status === 'completed') {
      db.prepare("UPDATE matches SET status='active', ended_at=NULL WHERE id=? AND status!='aborted'").run(matchId);
      db.prepare('UPDATE match_players SET is_winner=0 WHERE match_id=?').run(matchId);
      db.prepare('UPDATE match_teams SET is_winner=0 WHERE match_id=?').run(matchId);
    }
    return true;
  }

  if (king?.is_eliminated) {
    if (usurper && !usurper.is_eliminated) {
      if (!state.throne_claim_pending) {
        state.throne_claim_pending = true;
        state.fallen_king_player_id = Number(king.player_id);
        state.pending_since = new Date().toISOString();
        writeVariantState(matchId, state);
      }
      // Vinst avgörs först när Usurper privat bekräftar eller avstår anspråket.
      return true;
    }
    completeMatchForPlayers(matchId, bandits.map(p => p.player_id));
    return true;
  }

  return true;
}

function refreshMatchWinner(matchId) {
  const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId);
  if (!match || match.status === 'aborted') return;
  const rules = parseMatchRules(match);
  const players = db.prepare('SELECT * FROM match_players WHERE match_id = ? ORDER BY seat_index').all(matchId);
  if (refreshHiddenRoleWinner(matchId, match, rules, players)) return;
  for (const teamNumber of [...new Set(players.map(p => Number(p.team_number)))]) {
    const members = players.filter(p => Number(p.team_number) === teamNumber);
    db.prepare('UPDATE match_teams SET is_eliminated=? WHERE match_id=? AND team_number=?')
      .run(members.length > 0 && members.every(p => !!p.is_eliminated) ? 1 : 0, matchId, teamNumber);
  }

  // Emperor avgörs omedelbart när en Emperor lämnar spelet. Generalerna kan
  // alltså fortfarande leva när det andra laget vinner.
  if (rules.winner_scope === 'emperor_team') {
    const deadEmperor = players.find(p => p.role_key === 'emperor' && p.is_eliminated);
    if (deadEmperor) {
      const winningTeam = [...new Set(players.map(p => Number(p.team_number)))].find(t => t !== Number(deadEmperor.team_number));
      if (winningTeam != null) completeMatchForTeam(matchId, winningTeam);
      return;
    }
  }

  const alive = players.filter(p => !p.is_eliminated);
  const aliveTeams = [...new Set(alive.map(p => Number(p.team_number)))];
  const allTeams = [...new Set(players.map(p => Number(p.team_number)))];
  updateTeamWinnerFlags(matchId, null);

  if (allTeams.length >= 2 && alive.length > 0 && aliveTeams.length === 1) {
    completeMatchForTeam(matchId, aliveTeams[0]);
    return;
  }

  if (match.status === 'completed') {
    const now = db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;
    const timer = getTimerState(match);
    db.prepare(`
      UPDATE matches
      SET status='active', ended_at=NULL, turn_started_at=?, timer_anchor_at=?,
          timer_remaining_seconds=?, timer_is_running=?
      WHERE id=? AND status!='aborted'
    `).run(now, now, timer.remaining_seconds, timer.enabled && timer.remaining_seconds > 0 ? 1 : 0, matchId);
    const active = players[Number(match.active_player_index)] || players[0];
    if (active) logTurnStart(matchId, active.player_id, match.current_round || 1, now, { reason: 'undo_reopened_match', turn_group: active.turn_group });
  } else {
    db.prepare("UPDATE matches SET status='active', ended_at=NULL WHERE id=? AND status!='aborted'").run(matchId);
  }
}


const matchMutations = createMatchMutationService({
  db,
  fetchMatch,
  mutationMatchState,
  refreshPlayerElimination,
  refreshMatchWinner,
  setTeamEliminated,
  closeCurrentTurn,
  logTurnStart
});


class OfflineSyncError extends Error {
  constructor(status, code, message) {
    super(message || code);
    this.name = 'OfflineSyncError';
    this.status = status;
    this.code = code;
  }
}

function offlineSyncError(status, code, message) {
  return new OfflineSyncError(status, code, message);
}


function validateOfflineImport(snapshot, participants, matchType, teamMode, startedAt, endedAt, events, resolvedSetup = null) {
  const legacyConfig = MATCH_FORMATS[matchType];
  const config = resolvedSetup
    ? { minPlayers: resolvedSetup.min_players, maxPlayers: resolvedSetup.max_players }
    : legacyConfig;
  if (!config) {
    throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', `Okänt matchformat: ${matchType}`);
  }

  if (participants.length < config.minPlayers || participants.length > config.maxPlayers) {
    throw offlineSyncError(
      422,
      'INVALID_OFFLINE_MATCH',
      `${matchType} kräver mellan ${config.minPlayers} och ${config.maxPlayers} spelare.`
    );
  }

  const startMs = sqliteTimestampMs(startedAt);
  const endMs = sqliteTimestampMs(endedAt);
  if (!startMs || !endMs || endMs < startMs) {
    throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'ended_at måste vara samma tid eller senare än started_at.');
  }

  // Rimlighetsgräns: en importerad match får inte ligga orimligt långt i framtiden.
  if (startMs > Date.now() + 24 * 60 * 60 * 1000 || endMs > Date.now() + 24 * 60 * 60 * 1000) {
    throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Matchens timestamps ligger orimligt långt i framtiden.');
  }

  const winnerPlayers = participants.filter(p => p.is_winner);
  const status = String(snapshot.status || 'completed').toLowerCase();

  if (status === 'completed') {
    if (teamMode === 'ffa') {
      if (resolvedSetup?.winner_scope === 'role_condition') {
        if (winnerPlayers.length < 1) {
          throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'En completed hidden-role-match måste ha minst en vinnare.');
        }
      } else if (winnerPlayers.length !== 1) {
        throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'En completed FFA-match måste ha exakt en vinnare.');
      }
    } else {
      const winningTeams = [...new Set(winnerPlayers.map(p => Number(p.team_number)))];
      if (winningTeams.length !== 1 || winnerPlayers.length < 1) {
        throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'En completed lagmatch måste ha exakt ett vinnande lag.');
      }
      const winningTeam = winningTeams[0];
      if (!participants.some(p => Number(p.team_number) === winningTeam)) {
        throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Vinnande lag finns inte i matchen.');
      }
    }
  }

  if (teamMode === 'teams') {
    const teams = new Map();
    for (const p of participants) {
      const n = Number(p.team_number);
      if (!Number.isInteger(n) || n <= 0) {
        throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Ogiltigt team_number i lagmatch.');
      }
      teams.set(n, (teams.get(n) || 0) + 1);
    }
    if (teams.size < 2) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Lagmatch måste innehålla minst två lag.');
    }
  }

  // Counter-rimlighet. Liv får vara negativt; övriga räknare ska inte vara det.
  for (const p of participants) {
    if (!Number.isFinite(Number(p.current_life))) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Ogiltig current_life.');
    }
    if (Number(p.poison_counters) < 0 || Number(p.commander_tax) < 0) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Poison och commander tax får inte vara negativa.');
    }
  }

  // Journalen måste ha monoton sekvens om sekvensnummer skickas.
  let lastSequence = null;
  for (const event of events || []) {
    const raw = firstDefined(event.sequence, event.sequence_number, event.sequenceNumber, event.seq);
    if (raw === undefined || raw === null || raw === '') continue;
    const seq = Number(raw);
    if (!Number.isInteger(seq) || seq < 0 || (lastSequence !== null && seq <= lastSequence)) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Eventjournalens sequence måste vara strikt stigande.');
    }
    lastSequence = seq;
  }
}


function extractOfflineRulesSnapshot(body, snapshot) {
  const raw = firstDefined(
    snapshot?.rules_snapshot, snapshot?.rulesSnapshot,
    snapshot?.rules, snapshot?.rules_json, snapshot?.rulesJson,
    body?.rules_snapshot, body?.rulesSnapshot,
    body?.rules, body?.rules_json, body?.rulesJson
  );
  const parsed = parseJsonObject(raw, null);
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
}

function normalizeImportedRulesSnapshot(body, snapshot, setup) {
  const supplied = extractOfflineRulesSnapshot(body, snapshot);
  if (!supplied) return { rules: rulesSnapshot(setup), preserved: false };

  const rules = { ...supplied };
  const explicitEngineVersion = firstDefined(
    rules.engine_version,
    snapshot?.engine_version, snapshot?.engineVersion,
    body?.engine_version, body?.engineVersion,
    setup.engine_version
  );
  const explicitRulesVersion = firstDefined(
    rules.rules_version,
    snapshot?.rules_version, snapshot?.rulesVersion,
    body?.rules_version, body?.rulesVersion,
    explicitEngineVersion
  );

  const engineVersion = Number(explicitEngineVersion);
  const rulesVersion = Number(explicitRulesVersion);
  if (!Number.isInteger(engineVersion) || engineVersion <= 0 || engineVersion > ENGINE_VERSION) {
    throw offlineSyncError(409, 'MATCH_ENGINE_VERSION_UNSUPPORTED', `Offline-matchens engine_version ${explicitEngineVersion} stöds inte av servern.`);
  }
  if (!Number.isInteger(rulesVersion) || rulesVersion <= 0 || rulesVersion > RULES_VERSION) {
    throw offlineSyncError(409, 'RULES_VERSION_UNSUPPORTED', `Offline-matchens rules_version ${explicitRulesVersion} stöds inte av servern.`);
  }

  const identity = {
    match_profile: setup.match_profile,
    deck_format: setup.deck_format,
    play_mode: setup.play_mode,
    team_mode: setup.team_mode,
    limited_format: setup.limited_format
  };
  for (const [key, expected] of Object.entries(identity)) {
    if (rules[key] != null && String(rules[key] ?? '') !== String(expected ?? '')) {
      throw offlineSyncError(422, 'OFFLINE_RULES_IDENTITY_MISMATCH', `rules.${key} matchar inte offline-matchens normaliserade identitet.`);
    }
  }
  if (rules.modifiers != null) {
    const suppliedModifiers = Array.isArray(rules.modifiers) ? [...new Set(rules.modifiers.map(String))].sort() : [];
    const expectedModifiers = [...new Set((setup.modifiers || []).map(String))].sort();
    if (JSON.stringify(suppliedModifiers) !== JSON.stringify(expectedModifiers)) {
      throw offlineSyncError(422, 'OFFLINE_RULES_IDENTITY_MISMATCH', 'rules.modifiers matchar inte offline-matchens normaliserade identitet.');
    }
  }

  // Om snapshoten påstår sig vara exakt dagens engine/rules-version måste de
  // formatkritiska fälten också matcha dagens serverdefinition. Äldre rules-
  // versioner får däremot behålla sin historiska semantik utan omskrivning.
  if (engineVersion === Number(setup.engine_version) && rulesVersion === Number(setup.rules_version)) {
    const criticalKeys = [
      'life_scope','turn_scope','winner_scope','poison_scope','poison_loss_threshold',
      'commander_damage_scope','starting_policy','starting_life_mode','team_shape',
      'fixed_team_sizes','role_assignment','role_visibility','role_assignment_algorithm_version',
      'role_assignment_algorithm','hidden_information','target_assignment','target_visibility',
      'objective_tracking','reveal_policy','history_reveal_policy','attack_restriction','defend_from',
      'range_restriction','positional','shared_blocking','seat_order_locked','deck_selection_mode',
      'limited_rules','modifier_rules'
    ];
    for (const key of criticalKeys) {
      if (!Object.prototype.hasOwnProperty.call(rules, key)) continue;
      const actual = JSON.stringify(rules[key] ?? null);
      const expected = JSON.stringify(setup[key] ?? null);
      if (actual !== expected) {
        throw offlineSyncError(422, 'OFFLINE_RULES_MISMATCH', `rules.${key} stämmer inte med angiven engine/rules-version.`);
      }
    }
  }

  // Äldre klienter kan ha skickat versions-/identitetsfält utanför rules.
  // Endast dessa metadatafält kompletteras; övrig historisk rules-data bevaras.
  if (rules.engine_version == null) rules.engine_version = engineVersion;
  if (rules.rules_version == null) rules.rules_version = rulesVersion;
  if (rules.rules_profile == null) rules.rules_profile = setup.rules_profile;
  for (const [key, expected] of Object.entries(identity)) {
    if (rules[key] == null) rules[key] = expected;
  }
  if (rules.modifiers == null) rules.modifiers = [...(setup.modifiers || [])];

  return { rules, preserved: true };
}

function extractOfflineTeams(body, snapshot) {
  const raw = firstDefined(snapshot?.teams, body?.teams, []);
  const parsed = parseJsonObject(raw, raw);
  return Array.isArray(parsed) ? parsed : [];
}

function buildImportedTeamStates(participants, setup, rawTeams = []) {
  const base = buildTeamStates(participants, setup);
  if (!rawTeams.length) {
    return base.map(team => {
      const members = participants.filter(p => Number(p.team_number) === Number(team.team_number));
      return {
        ...team,
        current_life: team.life_scope === 'team' ? Number(members[0]?.current_life ?? team.current_life) : team.current_life,
        poison_counters: team.poison_scope === 'team' ? Number(members[0]?.poison_counters ?? team.poison_counters ?? 0) : team.poison_counters,
        is_eliminated: members.length > 0 && members.every(p => !!p.is_eliminated) ? 1 : 0,
        is_winner: members.some(p => !!p.is_winner) ? 1 : 0
      };
    });
  }

  const byTeam = new Map();
  for (const raw of rawTeams) {
    const n = Number(firstDefined(raw?.team_number, raw?.teamNumber));
    if (!Number.isInteger(n) || n <= 0 || byTeam.has(n)) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Offline-matchens teams[] innehåller ogiltigt eller duplicerat team_number.');
    }
    if (!participants.some(p => Number(p.team_number) === n)) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', `Offline-matchens teams[] refererar okänt lag ${n}.`);
    }
    byTeam.set(n, raw);
  }

  return base.map(team => {
    const members = participants.filter(p => Number(p.team_number) === Number(team.team_number));
    const raw = byTeam.get(Number(team.team_number)) || {};
    const rawInitialLife = Number(firstDefined(raw.initial_life, raw.initialLife));
    const rawCurrentLife = Number(firstDefined(raw.current_life, raw.currentLife));
    const rawPoison = Number(firstDefined(raw.poison_counters, raw.poisonCounters));
    const initialLife = Number.isFinite(rawInitialLife) ? rawInitialLife : team.initial_life;
    const currentLife = Number.isFinite(rawCurrentLife)
      ? rawCurrentLife
      : (team.life_scope === 'team' ? Number(members[0]?.current_life ?? team.current_life) : team.current_life);
    const poisonCounters = Number.isFinite(rawPoison) && rawPoison >= 0
      ? Math.trunc(rawPoison)
      : (team.poison_scope === 'team' ? Number(members[0]?.poison_counters ?? team.poison_counters ?? 0) : team.poison_counters);

    if (team.life_scope === 'team' && Number.isFinite(currentLife)) {
      for (const p of members) p.current_life = currentLife;
    }
    if (team.poison_scope === 'team' && Number.isFinite(poisonCounters)) {
      for (const p of members) p.poison_counters = poisonCounters;
    }
    if (firstDefined(raw.is_winner, raw.isWinner, false)) {
      for (const p of members) p.is_winner = 1;
    }

    return {
      ...team,
      role_key: firstDefined(raw.role_key, raw.roleKey, team.role_key),
      initial_life: initialLife,
      current_life: currentLife,
      poison_counters: poisonCounters,
      is_eliminated: firstDefined(raw.is_eliminated, raw.isEliminated, members.length > 0 && members.every(p => !!p.is_eliminated)) ? 1 : 0,
      is_winner: firstDefined(raw.is_winner, raw.isWinner, members.some(p => !!p.is_winner)) ? 1 : 0
    };
  });
}


function extractOfflineSnapshot(raw) {
  const parsed = parseJsonObject(raw, null);
  if (!parsed || typeof parsed !== 'object') return null;
  return parsed.match && typeof parsed.match === 'object' ? parsed.match : parsed;
}

function extractOfflineParticipants(body, snapshot) {
  const refsRaw = firstDefined(
    body.participant_refs,
    body.participantRefs,
    body.participants,
    body.participant_refs_json,
    body.participantRefsJson
  );
  const refsParsed = parseJsonObject(refsRaw, refsRaw);
  const refs = Array.isArray(refsParsed)
    ? refsParsed
    : Array.isArray(refsParsed?.participants)
      ? refsParsed.participants
      : [];

  const players = Array.isArray(snapshot?.players) ? snapshot.players : [];
  if (refs.length > 0) {
    return refs.map(ref => {
      const playerId = Number(firstDefined(ref.player_id, ref.playerId));
      const matching = players.find(p => Number(firstDefined(p.player_id, p.playerId)) === playerId) || {};
      return { ...matching, ...ref };
    });
  }
  return players;
}

function resolveOfflineDeck(ref) {
  const rawDeckId = Number(firstDefined(ref.deck_id, ref.deckId));
  if (Number.isInteger(rawDeckId) && rawDeckId > 0) {
    const direct = db.prepare(`
      SELECT d.*, owner.name AS owner_name
      FROM decks d
      JOIN players owner ON owner.id=d.owner_id
      WHERE d.id=?
    `).get(rawDeckId);
    if (direct) return direct;
  }

  const clientUid = String(firstDefined(
    ref.deck_client_uid,
    ref.deckClientUid,
    ref.client_uid,
    ref.deck?.client_uid,
    ref.deck?.clientUid,
    ''
  ) || '').trim();

  if (!clientUid) return null;

  const ownerId = Number(firstDefined(
    ref.deck_owner_id,
    ref.deckOwnerId,
    ref.owner_id,
    ref.ownerId
  ));

  if (Number.isInteger(ownerId) && ownerId > 0) {
    return db.prepare(`
      SELECT d.*, owner.name AS owner_name
      FROM decks d
      JOIN players owner ON owner.id=d.owner_id
      WHERE d.owner_id=? AND d.client_uid=?
    `).get(ownerId, clientUid) || null;
  }

  const candidates = db.prepare(`
    SELECT d.*, owner.name AS owner_name
    FROM decks d
    JOIN players owner ON owner.id=d.owner_id
    WHERE d.client_uid=?
    ORDER BY d.id
  `).all(clientUid);

  if (candidates.length === 1) return candidates[0];
  if (candidates.length > 1) {
    throw offlineSyncError(409, 'DECK_NOT_SYNCED', `deck_client_uid "${clientUid}" är inte unik utan deck_owner_id.`);
  }
  return null;
}

function normalizeImportedCommanderDamage(value) {
  const parsed = parseJsonObject(value, {});
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return '{}';
  const normalized = {};
  for (const [key, amount] of Object.entries(parsed)) {
    const playerId = Number(key);
    const damage = Number(amount);
    if (Number.isInteger(playerId) && playerId > 0 && Number.isFinite(damage) && damage >= 0) {
      normalized[String(playerId)] = Math.trunc(damage);
    }
  }
  return JSON.stringify(normalized);
}

function resolveOfflineParticipants(body, snapshot, { deckSelectionMode = 'required', maxPlayers = 8 } = {}) {
  const raw = extractOfflineParticipants(body, snapshot);
  if (!Array.isArray(raw) || raw.length < 2 || raw.length > Math.max(2, Number(maxPlayers || 8))) {
    throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', `Offline-matchen måste innehålla 2–${Math.max(2, Number(maxPlayers || 8))} deltagare.`);
  }

  const seenPlayers = new Set();
  const seenDecks = new Set();

  return raw.map((ref, index) => {
    const rawPlayerId = Number(firstDefined(ref.player_id, ref.playerId));
    if (!Number.isInteger(rawPlayerId) || rawPlayerId <= 0) {
      throw offlineSyncError(409, 'PLAYER_NOT_FOUND', 'Offline-matchen innehåller ett ogiltigt player_id.');
    }
    const playerId = rawPlayerId;

    if (seenPlayers.has(playerId)) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Samma spelare förekommer mer än en gång i offline-matchen.');
    }
    seenPlayers.add(playerId);

    const player = db.prepare('SELECT id,entity_uid,name,is_admin,archived FROM players WHERE id=?').get(playerId);
    if (!player || player.archived || player.is_admin) {
      throw offlineSyncError(409, 'PLAYER_NOT_FOUND', `Spelare ${playerId} saknas eller kan inte användas.`);
    }

    const deck = resolveOfflineDeck(ref);
    if (!deck && deckSelectionMode === 'required') {
      const clientUid = firstDefined(ref.deck_client_uid, ref.deckClientUid, ref.client_uid);
      throw offlineSyncError(
        409,
        'DECK_NOT_SYNCED',
        `Kortlek för ${player.name} finns ännu inte på servern${clientUid ? ` (client_uid ${clientUid})` : ''}.`
      );
    }

    if (deck && seenDecks.has(Number(deck.id))) {
      throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', 'Samma kortlek förekommer mer än en gång i offline-matchen.');
    }
    if (deck) seenDecks.add(Number(deck.id));

    const teamNumberRaw = Number(firstDefined(ref.team_number, ref.teamNumber, index + 1));
    const teamNumber = Number.isInteger(teamNumberRaw) && teamNumberRaw > 0 ? teamNumberRaw : index + 1;

    return {
      source_player_id: playerId,
      player_id: playerId,
      player_uid: player.entity_uid || null,
      player_name: player.name,
      deck_id: deck ? Number(deck.id) : null,
      deck_uid: deck?.entity_uid || null,
      deck_name: deck?.name || null,
      deck_color_identity: deck?.color_identity || null,
      team_number: teamNumber,
      seat_index: Number.isInteger(Number(firstDefined(ref.seat_index, ref.seatIndex)))
        ? Number(firstDefined(ref.seat_index, ref.seatIndex))
        : index,
      initial_life: Math.max(1, Number(firstDefined(ref.initial_life, ref.initialLife, 40)) || 40),
      current_life: Number(firstDefined(ref.current_life, ref.currentLife, ref.life, 40)) || 0,
      poison_counters: Math.max(0, Number(firstDefined(ref.poison_counters, ref.poisonCounters, ref.poison, 0)) || 0),
      commander_tax: Math.max(0, Number(firstDefined(ref.commander_tax, ref.commanderTax, ref.tax, 0)) || 0),
      commander_damage: normalizeImportedCommanderDamage(firstDefined(ref.commander_damage, ref.commanderDamage, {})),
      is_eliminated: firstDefined(ref.is_eliminated, ref.isEliminated, false) ? 1 : 0,
      eliminated_reason: firstDefined(ref.eliminated_reason, ref.eliminatedReason, null),
      is_winner: firstDefined(ref.is_winner, ref.isWinner, false) ? 1 : 0,
      role_key: firstDefined(ref.role_key, ref.roleKey, null),
      role_visibility: firstDefined(ref.role_visibility, ref.roleVisibility, null),
      secret_target_player_id: firstDefined(ref.secret_target_player_id, ref.secretTargetPlayerId, null),
      secret_target_player_uid: firstDefined(ref.secret_target_player_uid, ref.secretTargetPlayerUid, null),
      secret_target_name_snapshot: firstDefined(ref.secret_target_name_snapshot, ref.secretTargetNameSnapshot, null),
      victory_condition_key: firstDefined(ref.victory_condition_key, ref.victoryConditionKey, null),
      objective_score: Math.max(0, Number(firstDefined(ref.objective_score, ref.objectiveScore, 0)) || 0),
      secret_state_json: JSON.stringify(parseJsonObject(firstDefined(ref.secret_state, ref.secretState, ref.secret_state_json, ref.secretStateJson), {})),
      turn_group: firstDefined(ref.turn_group, ref.turnGroup, null),
      range_of_influence: firstDefined(ref.range_of_influence, ref.rangeOfInfluence, null),
      attack_rule: firstDefined(ref.attack_rule, ref.attackRule, null)
    };
  }).sort((a, b) => a.seat_index - b.seat_index);
}

function offlineEventTimestamp(event, fallback) {
  return normalizeOfflineTimestamp(firstDefined(
    event.created_at,
    event.createdAt,
    event.created_at_ms,
    event.createdAtMs,
    event.timestamp,
    event.timestamp_ms,
    event.timestampMs,
    event.local_timestamp,
    event.localTimestamp
  ), fallback);
}

function offlineEventPlayerId(event, fieldNames, fallback = null) {
  for (const field of fieldNames) {
    const value = event[field];
    const n = Number(value);
    if (Number.isInteger(n) && n > 0) return n;
  }
  return fallback;
}

function insertImportedEvent(matchId, event, fallbackTimestamp) {
  const type = canonicalOfflineEventType(firstDefined(event.event_type, event.eventType, event.type));
  const playerId = offlineEventPlayerId(event, ['player_id', 'playerId'], null);
  if (playerId && !db.prepare('SELECT 1 FROM match_players WHERE match_id=? AND player_id=?').get(matchId, playerId)) {
    throw offlineSyncError(422, 'INVALID_OFFLINE_MATCH', `Event ${type} refererar en spelare som inte deltar i matchen.`);
  }

  const relatedId = offlineEventPlayerId(
    event,
    ['related_player_id', 'relatedPlayerId', 'source_player_id', 'sourcePlayerId', 'commander_player_id', 'commanderPlayerId'],
    null
  );

  const changeValue = Number(firstDefined(event.change_value, event.changeValue, event.delta, event.amount, 0));
  const prevValue = Number(firstDefined(event.prev_value, event.prevValue, event.previous_value, event.previousValue, 0));
  const newValue = Number(firstDefined(event.new_value, event.newValue, event.value, prevValue + (Number.isFinite(changeValue) ? changeValue : 0)));
  const roundNumber = Math.max(1, Number(firstDefined(event.round_number, event.roundNumber, 1)) || 1);
  const duration = Number(firstDefined(event.duration_seconds, event.durationSeconds));
  const timestamp = offlineEventTimestamp(event, fallbackTimestamp);

  const metadata = {
    imported_offline: true,
    local_sequence: firstDefined(event.sequence, event.sequence_number, event.sequenceNumber, event.seq, null),
    local_event_id: firstDefined(event.id, event.local_id, event.localId, null),
    source: 'android_offline',
    payload: parseJsonObject(firstDefined(event.payload, event.payload_json, event.payloadJson), null)
  };

  db.prepare(`
    INSERT INTO match_events
      (match_id, player_id, related_player_id, event_type, change_value, prev_value, new_value,
       round_number, created_at, duration_seconds, metadata_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP), ?, ?)
  `).run(
    matchId,
    playerId,
    relatedId && db.prepare('SELECT 1 FROM players WHERE id=?').get(relatedId) ? relatedId : null,
    type,
    Number.isFinite(changeValue) ? Math.trunc(changeValue) : 0,
    Number.isFinite(prevValue) ? Math.trunc(prevValue) : 0,
    Number.isFinite(newValue) ? Math.trunc(newValue) : 0,
    roundNumber,
    timestamp,
    Number.isFinite(duration) ? Math.max(0, Math.trunc(duration)) : null,
    JSON.stringify(metadata)
  );

  return { type, timestamp, playerId, roundNumber };
}

function importOfflineTurnHistory(matchId, snapshot, events, participants, startedAt, endedAt) {
  const ordered = orderedOfflineEvents(events, startedAt);

  const firstBefore = extractOfflineSnapshot(firstDefined(
    ordered[0]?.before_match_json,
    ordered[0]?.beforeMatchJson,
    ordered[0]?.before_snapshot,
    ordered[0]?.beforeSnapshot
  ));

  let activeIndex = Number(firstDefined(
    firstBefore?.active_player_index,
    firstBefore?.activePlayerIndex,
    snapshot?.starting_player_index,
    snapshot?.startingPlayerIndex,
    0
  ));
  if (!Number.isInteger(activeIndex) || activeIndex < 0 || activeIndex >= participants.length) activeIndex = 0;

  let currentRound = Math.max(1, Number(firstDefined(firstBefore?.current_round, firstBefore?.currentRound, 1)) || 1);
  let turnStartedAt = startedAt;
  let activePlayerId = participants[activeIndex]?.player_id;

  if (activePlayerId) {
    logTurnStart(matchId, activePlayerId, currentRound, startedAt, { imported_offline: true, reason: 'offline_match_started' });
  }

  for (const event of ordered) {
    const type = canonicalOfflineEventType(firstDefined(event.event_type, event.eventType, event.type));
    if (type !== 'NEXT_TURN') continue;

    const timestamp = offlineEventTimestamp(event, turnStartedAt || startedAt);
    if (activePlayerId) {
      const startMs = sqliteTimestampToMs(turnStartedAt) || sqliteTimestampToMs(startedAt) || Date.now();
      const endMs = sqliteTimestampToMs(timestamp) || startMs;
      const duration = Math.max(0, Math.floor((endMs - startMs) / 1000));
      db.prepare(`
        INSERT INTO match_events
          (match_id, player_id, event_type, change_value, prev_value, new_value,
           round_number, created_at, duration_seconds, metadata_json)
        VALUES (?, ?, 'TURN_END', ?, 0, 0, ?, ?, ?, ?)
      `).run(matchId, activePlayerId, duration, currentRound, timestamp, duration,
        JSON.stringify({ imported_offline: true, reason: 'next_turn' }));
    }

    const after = extractOfflineSnapshot(firstDefined(
      event.after_match_json,
      event.afterMatchJson,
      event.after_snapshot,
      event.afterSnapshot
    ));
    let nextIndex = Number(firstDefined(after?.active_player_index, after?.activePlayerIndex));
    if (!Number.isInteger(nextIndex) || nextIndex < 0 || nextIndex >= participants.length) {
      nextIndex = (activeIndex + 1) % participants.length;
    }
    activeIndex = nextIndex;
    currentRound = Math.max(1, Number(firstDefined(after?.current_round, after?.currentRound, currentRound)) || currentRound);
    activePlayerId = participants[activeIndex]?.player_id;
    turnStartedAt = timestamp;

    if (activePlayerId) {
      logTurnStart(matchId, activePlayerId, currentRound, timestamp, { imported_offline: true, reason: 'next_turn' });
    }
  }

  if (activePlayerId && endedAt) {
    const startMs = sqliteTimestampToMs(turnStartedAt) || sqliteTimestampToMs(startedAt) || Date.now();
    const endMs = sqliteTimestampToMs(endedAt) || startMs;
    const duration = Math.max(0, Math.floor((endMs - startMs) / 1000));
    db.prepare(`
      INSERT INTO match_events
        (match_id, player_id, event_type, change_value, prev_value, new_value,
         round_number, created_at, duration_seconds, metadata_json)
      VALUES (?, ?, 'TURN_END', ?, 0, 0, ?, ?, ?, ?)
    `).run(matchId, activePlayerId, duration, currentRound, endedAt, duration,
      JSON.stringify({ imported_offline: true, reason: 'offline_match_ended' }));
  }
}

// Bakåtkompatibelt kontrakt för befintliga Androidklienter.
router.get('/formats', (req, res) => res.json(MATCH_FORMATS));

// Ny normaliserad formatmodell för webb 3.9.8.1+ och framtida Android.
// Den gamla /formats-routen ligger kvar oförändrad till API v1 freeze.
router.get('/match-options', (req, res) => res.json(publicMatchOptions()));

// Används av matchbyggaren INNAN D20-rullningen. Serverkontrollen finns kvar
// även vid själva matchstarten, men denna route gör att användaren får besked
// innan tärningsmomentet om någon hunnit bli upptagen på ett annat bord.
router.post('/matches/check-availability', (req, res) => {
  try {
    const { participants } = req.body;
    const setup = resolveMatchSetup({ ...req.body, participants });
    const matchType = setup.legacy_match_type;
    const teamMode = setup.team_mode;
    const validated = validateParticipants(participants, matchType, teamMode, setup);
    assertParticipantsAvailable(validated);
    res.json({
      success: true,
      match_profile: setup.match_profile,
      deck_format: setup.deck_format,
      play_mode: setup.play_mode,
      team_mode: teamMode,
      limited_format: setup.limited_format,
      modifiers: setup.modifiers,
      deck_selection_mode: setup.deck_selection_mode,
      starting_life: setup.starting_life,
      teams: buildTeams(validated)
    });
  } catch (err) {
    routeError(res, err, 409, 'MATCH_AVAILABILITY_CONFLICT');
  }
});

router.post('/matches/start', (req, res) => {
  try {
    const { participants, timer_minutes, starting_player_id, table_name } = req.body;
    const suppliedMatchUid = String(req.body?.client_match_uid || '').trim();
    const clientMatchUid = suppliedMatchUid || crypto.randomUUID();
    if (suppliedMatchUid && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(suppliedMatchUid)) {
      return res.status(400).json({ success:false,error:'client_match_uid måste vara ett giltigt UUID.',code:'INVALID_CLIENT_MATCH_UID',retryable:false });
    }
    const createFingerprint = requestFingerprint({ ...req.body, client_match_uid:undefined });
    const existingByUid = db.prepare('SELECT id FROM matches WHERE client_match_uid=?').get(clientMatchUid);
    if (existingByUid) {
      const op = db.prepare("SELECT request_fingerprint FROM idempotency_operations WHERE key_type='client_match_uid' AND idempotency_key=?").get(clientMatchUid);
      if (op && op.request_fingerprint !== createFingerprint) return res.status(409).json({success:false,error:'client_match_uid har redan använts med en annan match-start.',code:'IDEMPOTENCY_KEY_REUSE',retryable:false});
      const existingMatch = fetchMatch(existingByUid.id,false,{includeSecrets:true});
      let hiddenRoleSetup=null;
      if (existingMatch && isHiddenRoleMode(existingMatch.play_mode)) {
        const revealTokens=[];
        db.transaction(() => {
          for (const player of existingMatch.players) {
            const token=generateRevealToken();
            db.prepare('UPDATE match_players SET reveal_token_hash=? WHERE match_id=? AND player_id=?').run(hashRevealToken(token),existingByUid.id,player.player_id);
            revealTokens.push({player_id:player.player_id,player_uid:player.player_uid||null,player_name:player.player_name,reveal_token:token});
          }
        })();
        hiddenRoleSetup={contract_version:1,play_mode:existingMatch.play_mode,rules_version:Number(existingMatch.rules_version||RULES_VERSION),role_assignment_algorithm_version:1,reveal_tokens:revealTokens,assignment_snapshot:{version:1,play_mode:existingMatch.play_mode,algorithm_version:1,assignments:existingMatch.players.map(p=>({player_id:p.player_id,player_uid:p.player_uid||null,role_key:p.role_key||null,role_visibility:p.role_visibility||null,victory_condition_key:p.victory_condition_key||null,objective_score:Number(p.objective_score||0),secret_target_player_id:p.secret_target_player_id||null,secret_target_player_uid:p.secret_target_player_uid||null,secret_target_name_snapshot:p.secret_target_name_snapshot||null}))},assignment_snapshot_present:true};
        res.set('Cache-Control','no-store');
      }
      return res.json({success:true,idempotent_replay:true,matchId:Number(existingByUid.id),client_match_uid:clientMatchUid,match:fetchMatch(existingByUid.id,false),hidden_role_setup:hiddenRoleSetup});
    }
    const setup = resolveMatchSetup({ ...req.body, participants });
    const match_type = setup.legacy_match_type;
    const teamMode = setup.team_mode;
    let validated = validateParticipants(participants, match_type, teamMode, setup);
    let hiddenRoleSnapshot = null;
    const revealTokens = [];
    if (isHiddenRoleMode(setup.play_mode)) {
      const assigned = assignServerHiddenState(validated, setup);
      validated = assigned.participants;
      hiddenRoleSnapshot = assigned.snapshot;
      for (const participant of validated) {
        const token = generateRevealToken();
        participant.reveal_token_hash = hashRevealToken(token);
        revealTokens.push({
          player_id: participant.player_id,
          player_uid: participant.player_uid || null,
          player_name: participant.player_name,
          reveal_token: token
        });
      }
    }
    const initialLife = setup.starting_life;
    const timerMinutes = Number(timer_minutes || 0);
    if (!Number.isFinite(timerMinutes) || timerMinutes < 0) throw new Error('Ogiltig timer.');
    const timerSeconds = Math.round(timerMinutes * 60);
    const cleanTableName = typeof table_name === 'string' && table_name.trim() ? table_name.trim().slice(0, 80) : null;

    let startIndex = 0;
    if (starting_player_id) {
      const startId = asPositiveInt(starting_player_id, 'starting_player_id');
      const idx = validated.findIndex(p => p.player_id === startId);
      if (idx >= 0) startIndex = idx;
    }

    // Specialformat kan ha lagvis tur eller tvingad startroll. D20-vinnaren
    // avgör då startande lag, medan servern väljer korrekt representant/grupp.
    if (setup.starting_policy === 'king') {
      const idx = validated.findIndex(p => p.role_key === 'king');
      if (idx >= 0) startIndex = idx;
    } else if (setup.starting_policy === 'archenemy') {
      const idx = validated.findIndex(p => p.role_key === 'archenemy');
      if (idx >= 0) startIndex = idx;
    } else if (setup.starting_policy === 'random_emperor') {
      const chosenTeam = validated[startIndex]?.team_number;
      const idx = validated.findIndex(p => Number(p.team_number) === Number(chosenTeam) && p.role_key === 'emperor');
      if (idx >= 0) startIndex = idx;
    } else if (setup.turn_scope === 'team') {
      const chosenGroup = validated[startIndex]?.turn_group;
      const idx = validated.findIndex(p => Number(p.turn_group) === Number(chosenGroup));
      if (idx >= 0) startIndex = idx;
    }
    const startTurnGroup = Number(validated[startIndex]?.turn_group ?? startIndex + 1);

    const matchId = db.transaction(() => {
      // Kontrollen ligger i samma transaktion som INSERT så två samtidiga starter
      // inte kan boka samma spelare/deck innan den första hunnit sparas.
      assertParticipantsAvailable(validated);

      const info = db.prepare(`
        INSERT INTO matches
          (match_type, match_profile, deck_format, play_mode, team_mode, limited_format, modifiers_json,
           rules_profile, rules_version, rules_json, variant_state_json,
           table_name, status, current_round, active_player_index, active_turn_group, timer_seconds,
           timer_remaining_seconds, timer_is_running, timer_anchor_at, turn_started_at, client_match_uid)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 1, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?)
      `).run(
        match_type,
        setup.match_profile,
        setup.deck_format,
        setup.play_mode,
        teamMode,
        setup.limited_format,
        JSON.stringify(setup.modifiers || []),
        setup.rules_profile,
        setup.rules_version,
        JSON.stringify(rulesSnapshot(setup)),
        JSON.stringify(isHiddenRoleMode(setup.play_mode) ? {
          hidden_role_contract_version: 1,
          assignment_algorithm_version: setup.role_assignment_algorithm_version || 1,
          throne_claim_pending: false
        } : {}),
        cleanTableName,
        startIndex,
        startTurnGroup,
        timerSeconds,
        timerSeconds,
        timerSeconds > 0 ? 1 : 0,
        clientMatchUid
      );
      const id = Number(info.lastInsertRowid);

      validated.forEach((p, seatIndex) => {
        const participantLife = Number(p.initial_life ?? initialLife);
        db.prepare(`
          INSERT INTO match_players
          (match_id, player_id, deck_id, seat_index, team_number, initial_life, current_life,
           role_key, role_visibility, secret_target_player_id, secret_target_player_uid, secret_target_name_snapshot,
           victory_condition_key, objective_score, secret_state_json, reveal_token_hash,
           turn_group, range_of_influence, attack_rule)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(id, p.player_id, p.deck_id, seatIndex, p.team_number, participantLife, participantLife,
          p.role_key || null, p.role_visibility || 'public', p.secret_target_player_id || null, p.secret_target_player_uid || null,
          p.secret_target_name_snapshot || null, p.victory_condition_key || null, Number(p.objective_score || 0),
          p.secret_state_json || '{}', p.reveal_token_hash || null, p.turn_group ?? seatIndex + 1,
          p.range_of_influence ?? null, p.attack_rule || null);
        db.prepare(`
          INSERT INTO match_events
          (match_id, player_id, event_type, change_value, prev_value, new_value, round_number, metadata_json)
          VALUES (?, ?, 'INIT_LIFE', 0, ?, ?, 1, ?)
        `).run(id, p.player_id, participantLife, participantLife, JSON.stringify(
          isHiddenRoleMode(setup.play_mode)
            ? { team_number:p.team_number, hidden_information:true, role_key:p.role_visibility === 'public' ? p.role_key : null }
            : { team_number:p.team_number, role_key:p.role_key || null }
        ));
      });

      for (const team of buildTeamStates(validated, setup)) {
        db.prepare(`
          INSERT INTO match_teams
            (match_id,team_number,role_key,life_scope,initial_life,current_life,poison_scope,poison_counters,poison_loss_threshold)
          VALUES (?,?,?,?,?,?,?,?,?)
        `).run(id, team.team_number, team.role_key, team.life_scope, team.initial_life, team.current_life,
          team.poison_scope, team.poison_counters, team.poison_loss_threshold);
      }
      const startMembers = validated.filter(p => Number(p.turn_group) === startTurnGroup);
      logTurnStart(id, validated[startIndex].player_id, 1, null, {
        reason: 'match_started', turn_group:startTurnGroup, team_number:validated[startIndex].team_number,
        player_ids:startMembers.map(p=>p.player_id)
      });
      db.prepare(`INSERT INTO idempotency_operations
        (key_type,idempotency_key,operation_kind,target_type,target_id,target_uid,actor_uid,request_fingerprint,result_status)
        VALUES ('client_match_uid',?,'MATCH_START','match',?,?,?,?,200)`)
        .run(clientMatchUid,id,clientMatchUid,actorUid(req),createFingerprint);
      return id;
    })();

    if (isHiddenRoleMode(setup.play_mode)) res.set('Cache-Control', 'no-store');
    res.json({
      success: true,
      matchId,
      client_match_uid: clientMatchUid,
      match: fetchMatch(matchId, true),
      hidden_role_setup: isHiddenRoleMode(setup.play_mode) ? {
        contract_version: 1,
        play_mode: setup.play_mode,
        rules_version: Number(setup.rules_version || RULES_VERSION),
        role_assignment_algorithm_version: Number(setup.role_assignment_algorithm_version || 1),
        reveal_tokens: revealTokens,
        // Confidential bootstrap payload. It is deliberately separated from
        // public MatchDto and returned only once on successful online start.
        // Android may persist it in secure/private storage so the same match can
        // continue offline without regenerating roles or secret targets. The web
        // client intentionally stores only reveal tokens in sessionStorage.
        assignment_snapshot: hiddenRoleSnapshot,
        assignment_snapshot_present: !!hiddenRoleSnapshot
      } : null
    });
  } catch (err) {
    console.error('❌ Fel vid matchstart:', err);
    routeError(res, err, 400, 'INVALID_MATCH_START');
  }
});


// Android 3.9.0: importera en match som skapats helt offline och redan är
// avslutad. client_match_uid gör endpointen idempotent: samma UUID returnerar
// alltid samma servermatch i stället för att skapa en dubblett.
router.post('/matches/offline-sync', (req, res) => {
  try {
    if (!req.session?.user?.id) {
      return res.status(401).json({
        success: false,
        error: 'AUTH_REQUIRED',
        code: 'AUTH_REQUIRED',
        message: 'Serverinloggning krävs för att synka en offline-match.'
      });
    }

    const body = req.body || {};
    const clientMatchUid = String(firstDefined(
      body.client_match_uid,
      body.clientMatchUid,
      body.client_uid,
      body.clientUid,
      body.match?.client_match_uid,
      body.match?.clientMatchUid,
      ''
    ) || '').trim();

    if (!isCanonicalUuid(clientMatchUid)) {
      return res.status(422).json({
        success: false,
        error: 'INVALID_OFFLINE_MATCH',
        code: 'INVALID_OFFLINE_MATCH',
        message: 'client_match_uid måste vara ett giltigt UUID.'
      });
    }

    const existing = db.prepare('SELECT id FROM matches WHERE client_match_uid=?').get(clientMatchUid);
    if (existing) {
      const match = fetchMatch(existing.id, false);
      return res.json({
        success: true,
        already_synced: true,
        client_match_uid: clientMatchUid,
        match_id: Number(existing.id),
        matchId: Number(existing.id),
        server_id: Number(existing.id),
        server_match_id: Number(existing.id),
        match
      });
    }

    const snapshot = extractOfflineSnapshot(firstDefined(
      body.final_match,
      body.finalMatch,
      body.match_snapshot,
      body.matchSnapshot,
      body.snapshot,
      body.match,
      body.match_json,
      body.matchJson
    )) || {};

    // 3.9.1 använder endpointen bara för helt offline-skapade matcher.
    // source_server_match_id är reserverat för framtida reconciliation.
    const sourceServerMatchId = firstDefined(body.source_server_match_id, body.sourceServerMatchId, null);
    if (sourceServerMatchId !== null && sourceServerMatchId !== undefined) {
      const sourceId = Number(sourceServerMatchId);
      if (!Number.isInteger(sourceId) || sourceId <= 0) {
        return res.status(422).json({
          success: false,
          error: 'INVALID_OFFLINE_MATCH',
          code: 'INVALID_OFFLINE_MATCH',
          message: 'source_server_match_id måste vara null eller ett positivt server-id.'
        });
      }
    }

    const status = String(firstDefined(snapshot.status, body.status, 'completed')).toLowerCase();
    if (status === 'active') {
      return res.status(422).json({
        success: false,
        error: 'INVALID_OFFLINE_MATCH',
        code: 'INVALID_OFFLINE_MATCH',
        message: 'En helt offline-skapad match måste vara avslutad innan den importeras.'
      });
    }
    if (!['completed', 'aborted'].includes(status)) {
      return res.status(422).json({
        success: false,
        error: 'INVALID_OFFLINE_MATCH',
        code: 'INVALID_OFFLINE_MATCH',
        message: 'Offline-matchens status måste vara completed eller aborted.'
      });
    }

    const rawOfflineParticipants = extractOfflineParticipants(body, snapshot);
    const setupIdentity = {
      match_profile: firstDefined(snapshot.match_profile, snapshot.matchProfile, body.match_profile, body.matchProfile),
      match_type: firstDefined(snapshot.match_type, snapshot.matchType, body.match_type, body.matchType, 'Commander'),
      deck_format: firstDefined(snapshot.deck_format, snapshot.deckFormat, body.deck_format, body.deckFormat),
      play_mode: firstDefined(snapshot.play_mode, snapshot.playMode, body.play_mode, body.playMode),
      team_mode: firstDefined(snapshot.team_mode, snapshot.teamMode, body.team_mode, body.teamMode),
      limited_format: firstDefined(snapshot.limited_format, snapshot.limitedFormat, body.limited_format, body.limitedFormat),
      modifiers: firstDefined(snapshot.modifiers, body.modifiers, []),
      participants: rawOfflineParticipants
    };
    const preliminarySetup = resolveMatchSetup(setupIdentity);
    let participants = resolveOfflineParticipants(body, snapshot, {
      deckSelectionMode: preliminarySetup.deck_selection_mode,
      maxPlayers: preliminarySetup.max_players
    });
    const offlineStartingLife = firstDefined(
      snapshot.starting_life, snapshot.startingLife,
      body.starting_life, body.startingLife,
      participants[0]?.initial_life, participants[0]?.initialLife
    );
    const setup = resolveMatchSetup({ ...setupIdentity, starting_life: offlineStartingLife, participants });
    const matchType = setup.legacy_match_type;
    const teamMode = setup.team_mode;

    // 3.9.8.2.1: om Android skickar snapshoten som matchen faktiskt spelades
    // med ska servern bevara den som historisk sanning. Dagens engine används
    // fortfarande för identitets-/säkerhetsvalidering, inte för att skriva över
    // den spelade rules-versionen.
    const importedRulesInfo = normalizeImportedRulesSnapshot(body, snapshot, setup);
    const importedRules = importedRulesInfo.rules;
    const historicalSetup = {
      ...setup,
      ...importedRules,
      modifiers: Array.isArray(importedRules.modifiers) ? importedRules.modifiers : setup.modifiers
    };

    const decoratedOffline = validateAndDecorateParticipants(participants, historicalSetup);
    participants = participants.map((p, index) => {
      const suppliedTurnGroup = Number(p.turn_group);
      const suppliedRange = Number(p.range_of_influence);
      return {
        ...p,
        role_key: p.role_key || decoratedOffline[index]?.role_key || null,
        turn_group: Number.isInteger(suppliedTurnGroup) && suppliedTurnGroup > 0
          ? suppliedTurnGroup
          : (decoratedOffline[index]?.turn_group ?? p.seat_index + 1),
        range_of_influence: Number.isInteger(suppliedRange) && suppliedRange > 0
          ? suppliedRange
          : (decoratedOffline[index]?.range_of_influence ?? null),
        attack_rule: p.attack_rule || decoratedOffline[index]?.attack_rule || null
      };
    });

    // Hidden-role-matcher måste bära den privata assignment-snapshot som faktiskt
    // användes offline. Servern validerar den mot aktuell Engine men lottar aldrig om.
    let hiddenRoleSnapshotPreserved = false;
    if (isHiddenRoleMode(historicalSetup.play_mode)) {
      const rawHiddenSnapshot = firstDefined(
        snapshot.hidden_role_snapshot, snapshot.hiddenRoleSnapshot,
        body.hidden_role_snapshot, body.hiddenRoleSnapshot,
        parseJsonObject(snapshot.variant_state_json, null)?.hidden_role_snapshot,
        snapshot.variant_state?.hidden_role_snapshot
      );
      const hidden = applyOfflineHiddenSnapshot(participants, historicalSetup, rawHiddenSnapshot);
      participants = hidden.participants;
      hiddenRoleSnapshotPreserved = true;
    }

    const offlineTeams = extractOfflineTeams(body, snapshot);
    const importedTeamStates = buildImportedTeamStates(participants, historicalSetup, offlineTeams);

    const startedAt = normalizeOfflineTimestamp(firstDefined(
      snapshot.started_at,
      snapshot.startedAt,
      snapshot.started_at_ms,
      snapshot.startedAtMs,
      body.started_at,
      body.startedAt,
      body.started_at_ms,
      body.startedAtMs
    ), db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now);

    const endedAt = normalizeOfflineTimestamp(firstDefined(
      snapshot.ended_at,
      snapshot.endedAt,
      snapshot.ended_at_ms,
      snapshot.endedAtMs,
      body.ended_at,
      body.endedAt,
      body.ended_at_ms,
      body.endedAtMs
    ), startedAt);

    const tableNameRaw = firstDefined(snapshot.table_name, snapshot.tableName, body.table_name, body.tableName);
    const tableName = typeof tableNameRaw === 'string' && tableNameRaw.trim()
      ? tableNameRaw.trim().slice(0, 80)
      : null;

    const currentRound = Math.max(1, Number(firstDefined(snapshot.current_round, snapshot.currentRound, 1)) || 1);
    let activePlayerIndex = Number(firstDefined(snapshot.active_player_index, snapshot.activePlayerIndex, 0));
    if (!Number.isInteger(activePlayerIndex) || activePlayerIndex < 0 || activePlayerIndex >= participants.length) {
      activePlayerIndex = 0;
    }
    let activeTurnGroup = Number(firstDefined(
      snapshot.active_turn_group, snapshot.activeTurnGroup,
      body.active_turn_group, body.activeTurnGroup,
      participants[activePlayerIndex]?.turn_group,
      activePlayerIndex + 1
    ));
    const knownTurnGroups = new Set(participants.map(p => Number(p.turn_group)).filter(Number.isInteger));
    if (!Number.isInteger(activeTurnGroup) || !knownTurnGroups.has(activeTurnGroup)) {
      activeTurnGroup = Number(participants[activePlayerIndex]?.turn_group ?? activePlayerIndex + 1);
    }

    const timerSeconds = Math.max(0, Math.trunc(Number(firstDefined(
      snapshot.timer_seconds,
      snapshot.timerSeconds,
      snapshot.timer_configured_seconds,
      snapshot.timerConfiguredSeconds,
      body.timer_configured_seconds,
      body.timerConfiguredSeconds,
      0
    )) || 0));

    const timerRemaining = Math.max(0, Math.trunc(Number(firstDefined(
      snapshot.timer_remaining_seconds,
      snapshot.timerRemainingSeconds,
      body.timer_remaining_seconds,
      body.timerRemainingSeconds,
      0
    )) || 0));

    const eventsRaw = firstDefined(
      body.events,
      body.local_events,
      body.localEvents,
      body.event_journal,
      body.eventJournal,
      []
    );
    const eventsParsed = parseJsonObject(eventsRaw, eventsRaw);
    const events = Array.isArray(eventsParsed) ? eventsParsed : [];
    const orderedEvents = orderedOfflineEvents(events, startedAt);
    const explicitDayNightState = firstDefined(
      snapshot.day_night_state, snapshot.dayNightState,
      body.day_night_state, body.dayNightState
    );
    const dayNightState = validateOfflineDayNightJournal(orderedEvents, explicitDayNightState, startedAt);

    validateOfflineImport(
      { ...snapshot, status },
      participants,
      matchType,
      teamMode,
      startedAt,
      endedAt,
      events,
      historicalSetup
    );

    const matchId = db.transaction(() => {
      // Kontrollera igen inne i transaktionen så parallella WorkManager-försök
      // inte kan passera första SELECT samtidigt.
      const duplicate = db.prepare('SELECT id FROM matches WHERE client_match_uid=?').get(clientMatchUid);
      if (duplicate) return Number(duplicate.id);

      const info = db.prepare(`
        INSERT INTO matches
          (match_type, match_profile, deck_format, play_mode, team_mode, limited_format, modifiers_json,
           rules_profile, rules_version, rules_json, variant_state_json, day_night_state,
           table_name, status, current_round, active_player_index, active_turn_group,
           timer_seconds, timer_remaining_seconds, timer_is_running, timer_anchor_at,
           turn_started_at, started_at, ended_at,
           client_match_uid, imported_offline, imported_at,
           imported_by_player_id, imported_by_user_id, import_source)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, NULL, ?, ?, ?,
                ?, 1, CURRENT_TIMESTAMP, ?, ?, 'android_offline')
      `).run(
        matchType,
        setup.match_profile,
        setup.deck_format,
        setup.play_mode,
        teamMode,
        setup.limited_format,
        JSON.stringify(historicalSetup.modifiers || []),
        importedRules.rules_profile || setup.rules_profile,
        Number(importedRules.rules_version || setup.rules_version),
        JSON.stringify(importedRules),
        JSON.stringify(isHiddenRoleMode(historicalSetup.play_mode) ? {
          hidden_role_contract_version: 1,
          assignment_algorithm_version: historicalSetup.role_assignment_algorithm_version || 1,
          imported_hidden_snapshot: true,
          throne_claim_pending: false
        } : {}),
        dayNightState,
        tableName,
        status,
        currentRound,
        activePlayerIndex,
        activeTurnGroup,
        timerSeconds,
        timerRemaining,
        startedAt,
        startedAt,
        endedAt,
        clientMatchUid,
        Number(req.session.user.id),
        Number(req.session.user.id)
      );
      const id = Number(info.lastInsertRowid);

      for (const p of participants) {
        db.prepare(`
          INSERT INTO match_players
            (match_id, player_id, deck_id, seat_index, team_number,
             initial_life, current_life, poison_counters, commander_tax,
             is_eliminated, eliminated_reason, is_winner, commander_damage,
             role_key,role_visibility,secret_target_player_id,secret_target_player_uid,secret_target_name_snapshot,
             victory_condition_key,objective_score,secret_state_json,reveal_token_hash,
             turn_group,range_of_influence,attack_rule)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          id,
          p.player_id,
          p.deck_id,
          p.seat_index,
          p.team_number,
          p.initial_life,
          p.current_life,
          p.poison_counters,
          p.commander_tax,
          p.is_eliminated,
          p.eliminated_reason,
          p.is_winner,
          p.commander_damage,
          p.role_key || null,
          p.role_visibility || 'public',
          p.secret_target_player_id || null,
          p.secret_target_player_uid || null,
          p.secret_target_name_snapshot || null,
          p.victory_condition_key || null,
          Number(p.objective_score || 0),
          p.secret_state_json || '{}',
          null,
          p.turn_group ?? p.seat_index + 1,
          p.range_of_influence ?? null,
          p.attack_rule || null
        );

        db.prepare(`
          INSERT INTO match_events
            (match_id, player_id, event_type, change_value, prev_value, new_value,
             round_number, created_at, metadata_json)
          VALUES (?, ?, 'INIT_LIFE', 0, ?, ?, 1, ?, ?)
        `).run(
          id,
          p.player_id,
          p.initial_life,
          p.initial_life,
          startedAt,
          JSON.stringify({ imported_offline: true })
        );
      }

      for (const team of importedTeamStates) {
        db.prepare(`
          INSERT INTO match_teams
            (match_id,team_number,role_key,life_scope,initial_life,current_life,poison_scope,poison_counters,poison_loss_threshold,is_eliminated,is_winner)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)
        `).run(id, team.team_number, team.role_key, team.life_scope, team.initial_life, team.current_life,
          team.poison_scope, team.poison_counters, team.poison_loss_threshold, team.is_eliminated || 0, team.is_winner || 0);
      }

      // Serverns historik använder TURN_START/TURN_END. Härled dem från Androids
      // lokala NEXT_TURN-journal så turdurationerna överlever offline-import.
      importOfflineTurnHistory(id, snapshot, orderedEvents, participants, startedAt, endedAt);

      // Importera även den råa mutationsjournalen med lokala timestamps.
      for (const event of orderedEvents) {
        insertImportedEvent(id, event, startedAt);
      }

      return id;
    })();

    const importedMatch = fetchMatch(matchId, false);
    res.json({
      success: true,
      already_synced: false,
      imported_offline: true,
      rules_snapshot_preserved: importedRulesInfo.preserved,
      hidden_role_snapshot_preserved: hiddenRoleSnapshotPreserved,
      rules_version: Number(importedRules.rules_version || setup.rules_version),
      client_match_uid: clientMatchUid,
      match_id: matchId,
      matchId,
      server_id: matchId,
      server_match_id: matchId,
      match: importedMatch
    });
  } catch (err) {
    // UNIQUE-indexet är sista skyddet om två identiska uppladdningar kommer
    // exakt samtidigt.
    if (String(err?.message || '').includes('UNIQUE constraint failed: matches.client_match_uid')) {
      const uid = String(firstDefined(
        req.body?.client_match_uid,
        req.body?.clientMatchUid,
        req.body?.client_uid,
        req.body?.clientUid,
        ''
      ) || '').trim();
      const existing = uid ? db.prepare('SELECT id FROM matches WHERE client_match_uid=?').get(uid) : null;
      if (existing) {
        const match = fetchMatch(existing.id, false);
        return res.json({
          success: true,
          already_synced: true,
          client_match_uid: uid,
          match_id: Number(existing.id),
          matchId: Number(existing.id),
          server_id: Number(existing.id),
          server_match_id: Number(existing.id),
          match
        });
      }
    }

    if (err instanceof OfflineSyncError) {
      return res.status(err.status).json({
        success: false,
        error: err.code,
        code: err.code,
        client_match_uid: firstDefined(
          req.body?.client_match_uid,
          req.body?.clientMatchUid,
          null
        ),
        message: err.message
      });
    }

    console.error('❌ Offline-matchsynk:', err);
    res.status(500).json({
      success: false,
      error: 'INTERNAL_SERVER_ERROR',
      code: 'INTERNAL_SERVER_ERROR',
      client_match_uid: firstDefined(
        req.body?.client_match_uid,
        req.body?.clientMatchUid,
        null
      ),
      message: 'Servern kunde inte importera offline-matchen just nu. Försök igen senare.'
    });
  }
});


function privateParticipantRow(matchId, playerId) {
  return db.prepare(`
    SELECT mp.*,
           COALESCE(p.entity_uid,mp.player_uid) AS player_uid,
           COALESCE(p.name,mp.player_name_snapshot,'Raderad spelare') AS player_name
      FROM match_players mp
      LEFT JOIN players p ON p.id=mp.player_id
     WHERE mp.match_id=? AND mp.player_id=?
  `).get(matchId, playerId) || null;
}

function resolveHiddenRolePrivateAccess(req, matchId) {
  const requestedId = Number(firstDefined(req.body?.player_id, req.body?.playerId, req.session?.user?.id));
  if (!Number.isInteger(requestedId) || requestedId <= 0) {
    throw Object.assign(new Error('player_id krävs för privat reveal.'), { code:'HIDDEN_ROLE_PLAYER_REQUIRED', status:400 });
  }
  const player = privateParticipantRow(matchId, requestedId);
  if (!player) throw Object.assign(new Error('Spelaren deltar inte i matchen.'), { code:'MATCH_PLAYER_NOT_FOUND', status:404 });

  const sessionOwns = Number(req.session?.user?.id) === requestedId;
  const token = String(firstDefined(req.body?.reveal_token, req.body?.revealToken, '') || '');
  const tokenValid = !!token && safeTokenEqual(token, player.reveal_token_hash);
  if (!sessionOwns && !tokenValid) {
    throw Object.assign(new Error('Privat reveal kräver spelarens session eller giltig reveal-token.'), { code:'HIDDEN_ROLE_PRIVATE_ACCESS_DENIED', status:403 });
  }
  return player;
}

function getHiddenSecretPayload(matchId, player) {
  const match = fetchMatch(matchId, false, { includeSecrets:true });
  if (!match) throw Object.assign(new Error('Matchen hittades inte.'), { code:'MATCH_NOT_FOUND', status:404 });
  if (!match.rules?.hidden_information) {
    throw Object.assign(new Error('Matchen använder inte privat hidden-role-state.'), { code:'HIDDEN_ROLE_NOT_ACTIVE', status:409 });
  }
  const fullPlayer = match.players.find(p => Number(p.player_id) === Number(player.player_id));
  if (!fullPlayer) throw Object.assign(new Error('Spelaren deltar inte i matchen.'), { code:'MATCH_PLAYER_NOT_FOUND', status:404 });
  const target = fullPlayer.secret_target_player_id
    ? match.players.find(p => Number(p.player_id) === Number(fullPlayer.secret_target_player_id)) || null
    : null;
  const variant = parseVariantState(match);
  const actions = {
    claim_throne: match.status === 'active' && match.play_mode === 'kingdoms' && fullPlayer.role_key === 'usurper' && !fullPlayer.is_eliminated && !!variant.throne_claim_pending,
    decline_throne_claim: match.status === 'active' && match.play_mode === 'kingdoms' && fullPlayer.role_key === 'usurper' && !fullPlayer.is_eliminated && !!variant.throne_claim_pending,
    claim_target: match.status === 'active' && match.play_mode === 'assassin' && !!target && !!target.is_eliminated
  };
  return privateSecretPayload(match, fullPlayer, target, actions);
}

// Spelarspecifik privat state. Den här routen använder endast inloggad spelares
// identitet och är därför lämplig för Android med personlig session.
router.get('/matches/:id/my-secret', (req, res) => {
  try {
    if (!req.session?.user?.id) return res.status(401).json({ error:'Inloggning krävs.', code:'AUTH_REQUIRED' });
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const player = privateParticipantRow(matchId, Number(req.session.user.id));
    if (!player) return res.status(403).json({ error:'Du deltar inte i matchen.', code:'HIDDEN_ROLE_PRIVATE_ACCESS_DENIED' });
    res.set('Cache-Control', 'no-store');
    res.json(getHiddenSecretPayload(matchId, player));
  } catch (err) { routeError(res, err, err.status || 400, err.code || 'HIDDEN_ROLE_REVEAL_FAILED'); }
});

// Gemensam webb-/bordsenhet kan reveala en deltagares hemlighet med token som
// endast returneras i startresponsens separata hidden_role_setup. Token skickas
// i POST-body så den inte hamnar i URL/access-logg.
router.post('/matches/:id/hidden-role/reveal', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const player = resolveHiddenRolePrivateAccess(req, matchId);
    res.set('Cache-Control', 'no-store');
    res.json(getHiddenSecretPayload(matchId, player));
  } catch (err) { routeError(res, err, err.status || 400, err.code || 'HIDDEN_ROLE_REVEAL_FAILED'); }
});

router.post('/matches/:id/hidden-role/claim-target', reliableMatchMutation('HIDDEN_TARGET_CLAIM', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const actor = resolveHiddenRolePrivateAccess(req, matchId);
    const match = fetchMatch(matchId, true, { includeSecrets:true });
    if (!match || match.play_mode !== 'assassin') {
      return res.status(409).json({ error:'Åtgärden gäller endast Assassin / Secret Target.', code:'HIDDEN_ROLE_ACTION_NOT_ALLOWED' });
    }
    const self = match.players.find(p => Number(p.player_id) === Number(actor.player_id));
    const target = self?.secret_target_player_id
      ? match.players.find(p => Number(p.player_id) === Number(self.secret_target_player_id))
      : null;
    if (!target || !target.is_eliminated) {
      return res.status(409).json({ error:'Ditt nuvarande mål är inte utslaget.', code:'ASSASSIN_TARGET_NOT_ELIMINATED' });
    }

    let nextTarget = target.secret_target_player_id
      ? match.players.find(p => Number(p.player_id) === Number(target.secret_target_player_id)) || null
      : null;
    if (nextTarget && Number(nextTarget.player_id) === Number(self.player_id)) nextTarget = null;

    const state = parseJsonObject(self.secret_state_json, {}) || {};
    const claims = Array.isArray(state.claimed_targets) ? [...state.claimed_targets] : [];
    claims.push({
      player_id:Number(target.player_id),
      player_uid:target.player_uid || null,
      player_name:target.player_name,
      claimed_at:new Date().toISOString()
    });
    state.claimed_targets = claims;

    db.prepare(`
      UPDATE match_players
         SET objective_score=objective_score+1,
             secret_target_player_id=?, secret_target_player_uid=?, secret_target_name_snapshot=?, secret_state_json=?
       WHERE match_id=? AND player_id=?
    `).run(
      nextTarget?.player_id || null,
      nextTarget?.player_uid || null,
      nextTarget?.player_name || null,
      JSON.stringify(state),
      matchId,
      self.player_id
    );
    db.prepare(`
      INSERT INTO match_events(match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json)
      VALUES (?,?,'HIDDEN_TARGET_CLAIM',1,?,?,?,?)
    `).run(matchId, self.player_id, Number(self.objective_score || 0), Number(self.objective_score || 0) + 1,
      Number(match.current_round || 1), JSON.stringify({ hidden_information:true }));

    const updatedPlayer = privateParticipantRow(matchId, self.player_id);
    res.set('Cache-Control', 'no-store');
    res.json({ success:true, secret:getHiddenSecretPayload(matchId, updatedPlayer), match:fetchMatch(matchId, false) });
  } catch (err) { routeError(res, err, err.status || 400, err.code || 'HIDDEN_ROLE_ACTION_FAILED'); }
}));

router.post('/matches/:id/hidden-role/claim-throne', reliableMatchMutation('HIDDEN_THRONE_CLAIM', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const actor = resolveHiddenRolePrivateAccess(req, matchId);
    const match = fetchMatch(matchId, true, { includeSecrets:true });
    if (!match || match.play_mode !== 'kingdoms') {
      return res.status(409).json({ error:'Åtgärden gäller endast Kingdoms / Treachery.', code:'HIDDEN_ROLE_ACTION_NOT_ALLOWED' });
    }
    const usurper = match.players.find(p => Number(p.player_id) === Number(actor.player_id));
    const state = parseVariantState(match);
    const fallenKing = state.fallen_king_player_id
      ? match.players.find(p => Number(p.player_id) === Number(state.fallen_king_player_id))
      : match.players.find(p => p.role_key === 'king' && p.is_eliminated);
    if (!state.throne_claim_pending || usurper?.role_key !== 'usurper' || usurper?.is_eliminated || !fallenKing) {
      return res.status(409).json({ error:'Det finns inget giltigt tronanspråk för spelaren.', code:'KINGDOMS_THRONE_CLAIM_NOT_AVAILABLE' });
    }

    db.transaction(() => {
      db.prepare(`UPDATE match_players SET role_key='king', role_visibility='public', victory_condition_key='protect_kingdom',
                   current_life=50, is_eliminated=0, eliminated_reason=NULL WHERE match_id=? AND player_id=?`)
        .run(matchId, usurper.player_id);
      db.prepare(`UPDATE match_players SET role_key='usurper', role_visibility='secret', victory_condition_key='seize_throne',
                   current_life=5, is_eliminated=0, eliminated_reason=NULL WHERE match_id=? AND player_id=?`)
        .run(matchId, fallenKing.player_id);
      state.throne_claim_pending = false;
      state.fallen_king_player_id = null;
      state.throne_swaps = Number(state.throne_swaps || 0) + 1;
      writeVariantState(matchId, state);
      db.prepare(`INSERT INTO match_events(match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json)
                  VALUES (?,NULL,'HIDDEN_THRONE_RESOLVED',0,0,0,?,?)`)
        .run(matchId, Number(match.current_round || 1), JSON.stringify({ hidden_information:true, result:'claimed' }));
    })();
    refreshMatchWinner(matchId);
    const updatedPlayer = privateParticipantRow(matchId, usurper.player_id);
    res.set('Cache-Control', 'no-store');
    res.json({ success:true, secret:getHiddenSecretPayload(matchId, updatedPlayer), match:fetchMatch(matchId, false) });
  } catch (err) { routeError(res, err, err.status || 400, err.code || 'HIDDEN_ROLE_ACTION_FAILED'); }
}));

router.post('/matches/:id/hidden-role/decline-throne', reliableMatchMutation('HIDDEN_THRONE_DECLINE', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const actor = resolveHiddenRolePrivateAccess(req, matchId);
    const match = fetchMatch(matchId, true, { includeSecrets:true });
    if (!match || match.play_mode !== 'kingdoms') {
      return res.status(409).json({ error:'Åtgärden gäller endast Kingdoms / Treachery.', code:'HIDDEN_ROLE_ACTION_NOT_ALLOWED' });
    }
    const usurper = match.players.find(p => Number(p.player_id) === Number(actor.player_id));
    const state = parseVariantState(match);
    if (!state.throne_claim_pending || usurper?.role_key !== 'usurper' || usurper?.is_eliminated) {
      return res.status(409).json({ error:'Det finns inget giltigt tronanspråk att avstå.', code:'KINGDOMS_THRONE_CLAIM_NOT_AVAILABLE' });
    }
    state.throne_claim_pending = false;
    state.throne_claim_declined = true;
    writeVariantState(matchId, state);
    db.prepare(`INSERT INTO match_events(match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json)
                VALUES (?,NULL,'HIDDEN_THRONE_RESOLVED',0,0,0,?,?)`)
      .run(matchId, Number(match.current_round || 1), JSON.stringify({ hidden_information:true, result:'declined' }));
    const bandits = match.players.filter(p => p.role_key === 'bandit').map(p => p.player_id);
    completeMatchForPlayers(matchId, bandits);
    res.json({ success:true, match:fetchMatch(matchId, false) });
  } catch (err) { routeError(res, err, err.status || 400, err.code || 'HIDDEN_ROLE_ACTION_FAILED'); }
}));

router.get('/matches/active-list', (req, res) => res.json(listActiveMatches()));

router.get('/matches/my-active', (req, res) => {
  if (!req.session.user) return res.json(null);
  const row = db.prepare(`
    SELECT m.id FROM matches m JOIN match_players mp ON mp.match_id = m.id
    WHERE m.status = 'active' AND mp.player_id = ? ORDER BY m.started_at DESC LIMIT 1
  `).get(req.session.user.id);
  res.json(row ? fetchMatch(row.id, true) : null);
});

// Bakåtkompatibel route. För inloggad spelare returneras alltid dennes match.
// För anonym klient returneras match bara när exakt en aktiv match finns.
router.get('/matches/active', (req, res) => {
  if (req.session.user) {
    const own = db.prepare(`SELECT m.id FROM matches m JOIN match_players mp ON mp.match_id=m.id WHERE m.status='active' AND mp.player_id=? LIMIT 1`).get(req.session.user.id);
    if (own) return res.json(fetchMatch(own.id, true));
  }
  const active = db.prepare("SELECT id FROM matches WHERE status='active' ORDER BY started_at ASC").all();
  if (active.length === 1) return res.json(fetchMatch(active[0].id, true));
  return res.json(null);
});

router.get('/matches/active/:id', (req, res) => {
  try {
    const id = asPositiveInt(req.params.id, 'match_id');
    const match = fetchMatch(id, true);
    if (!match) return res.status(404).json({ error: 'Aktiv match hittades inte.', code: 'MATCH_NOT_FOUND' });
    res.json(match);
  } catch (err) { routeError(res, err); }
});

router.delete('/matches/:id/abort', reliableAbort((req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = db.prepare('SELECT id, status FROM matches WHERE id=?').get(matchId);
    if (!match) return res.status(404).json({ error: 'Matchen hittades inte.', code: 'MATCH_NOT_FOUND' });

    // Idempotent endpoint: om samma klientanrop råkar skickas två gånger är
    // matchen redan i önskat tillstånd och det ska fortfarande räknas som lyckat.
    if (match.status === 'aborted') return res.json({ success: true, already_aborted: true, match: fetchMatch(matchId, false) });
    if (match.status !== 'active') return res.status(409).json({ error: 'Matchen är inte aktiv och kan därför inte avbrytas.', code: 'MATCH_NOT_ACTIVE' });

    const now = db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;
    db.transaction(() => {
      snapshotTimer(matchId);
      closeCurrentTurn(matchId, now, { reason: 'abort' });
      db.prepare("UPDATE matches SET status='aborted', ended_at=?, timer_is_running=0 WHERE id=?").run(now, matchId);
      db.prepare(`
        INSERT INTO match_events
          (match_id, player_id, event_type, change_value, prev_value, new_value, round_number, created_at, metadata_json)
        VALUES (?, NULL, 'ABORT', 0, 0, 0, ?, ?, ?)
      `).run(matchId, match.current_round || 1, now, JSON.stringify({ source: 'server', reason: 'manual_abort' }));
    })();
    res.json({ success: true, match: fetchMatch(matchId, false) });
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/life', reliableMatchMutation('LIFE_CHANGE', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const playerId = asPositiveInt(req.body.player_id, 'player_id');
    const change = asInteger(req.body.change, 'change');
    res.json(matchMutations.changeLife(matchId, playerId, change));
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/poison', reliableMatchMutation('POISON_CHANGE', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const playerId = asPositiveInt(req.body.player_id, 'player_id');
    const change = asInteger(req.body.change, 'change');
    res.json(matchMutations.changePoison(matchId, playerId, change));
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/tax', reliableMatchMutation('TAX_CHANGE', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const playerId = asPositiveInt(req.body.player_id, 'player_id');
    const change = asInteger(req.body.change, 'change');
    res.json(matchMutations.changeTax(matchId, playerId, change));
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/concede', reliableMatchMutation('CONCEDE', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const playerId = asPositiveInt(req.body.player_id, 'player_id');
    res.json(matchMutations.concede(matchId, playerId));
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/cmdr-dmg', reliableMatchMutation('CMDR_DMG', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const targetId = asPositiveInt(req.body.target_player_id, 'target_player_id');
    const sourceId = asPositiveInt(req.body.source_player_id, 'source_player_id');
    const change = asInteger(req.body.change, 'change');
    if (targetId === sourceId) throw new Error('En spelare kan inte ge commander damage till sig själv.');

    const match = fetchMatch(matchId, true);
    if (!match) return res.status(404).json({ error: 'Aktiv match saknas.', code: 'MATCH_NOT_FOUND' });
    const target = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(matchId, targetId);
    const source = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(matchId, sourceId);
    if (!target || !source) return res.status(400).json({ error: 'Både källa och mål måste delta i samma match.', code: 'MATCH_PLAYER_NOT_FOUND' });
    if ((match.rules?.commander_damage_scope || 'none') === 'none') {
      return res.status(409).json({ error: 'Commander damage används inte i denna matchprofil.', code: 'COMMANDER_DAMAGE_NOT_ENABLED' });
    }
    if (match.team_mode === 'teams' && Number(target.team_number) === Number(source.team_number)) {
      return res.status(400).json({ error: 'Commander damage kan bara registreras från en motståndare i en lagmatch.', code: 'TEAMMATE_NOT_OPPONENT' });
    }

    const damage = parseCommanderDamage(target.commander_damage);
    const current = Number(damage[sourceId] || 0);
    const next = Math.max(0, current + change);
    const appliedDamageChange = next - current;
    let newLife;
    damage[sourceId] = next;

    db.transaction(() => {
      // Commander damage sänker den livstotal som matchens rules snapshot anger.
      // I 2HG/Archenemy Commander är det lagets delade liv, medan själva
      // commander-damage-spåret fortfarande hör till den attackerade spelaren.
      if (match.rules?.life_scope === 'team') {
        const team = db.prepare('SELECT * FROM match_teams WHERE match_id=? AND team_number=?').get(matchId, target.team_number);
        const previousTeamLife = Number(team?.current_life ?? target.current_life);
        newLife = previousTeamLife - appliedDamageChange;
        db.prepare('UPDATE match_teams SET current_life=? WHERE match_id=? AND team_number=?').run(newLife, matchId, target.team_number);
        db.prepare('UPDATE match_players SET current_life=? WHERE match_id=? AND team_number=?').run(newLife, matchId, target.team_number);
        db.prepare('UPDATE match_players SET commander_damage=? WHERE match_id=? AND player_id=?')
          .run(JSON.stringify(damage), matchId, targetId);
      } else {
        newLife = Number(target.current_life) - appliedDamageChange;
        db.prepare('UPDATE match_players SET commander_damage=?, current_life=? WHERE match_id=? AND player_id=?')
          .run(JSON.stringify(damage), newLife, matchId, targetId);
      }
      db.prepare(`INSERT INTO match_events (match_id,player_id,related_player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json) VALUES (?,?,?,'CMDR_DMG',?,?,?,?,?)`)
        .run(matchId, targetId, sourceId, appliedDamageChange, current, next, match.current_round,
          JSON.stringify({ life_scope:match.rules?.life_scope || 'player', team_number:Number(target.team_number) }));
      refreshPlayerElimination(matchId, targetId);
      refreshMatchWinner(matchId);
    })();
    const updated = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(matchId, targetId);
    res.json({
      success: true,
      commander_damage: damage,
      current_life: updated.current_life,
      isEliminated: !!updated.is_eliminated,
      eliminated_reason: updated.eliminated_reason,
      ...mutationMatchState(matchId)
    });
  } catch (err) { routeError(res, err); }
}));

// Day/Night Contract v1 – global matchstate. V1 är helt user-driven:
 // NEXT_TURN ändrar aldrig state automatiskt.
router.post('/matches/:id/day-night', reliableMatchMutation('DAY_NIGHT_CHANGE', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = db.prepare("SELECT * FROM matches WHERE id=? AND status='active'").get(matchId);
    if (!match) return res.status(404).json({ error: 'Aktiv match saknas.', code: 'MATCH_NOT_FOUND' });

    const nextState = normalizeDayNightState(req.body?.state, { allowNone: false });
    const previousState = normalizeDayNightState(match.day_night_state, { allowNone: true, fallback: 'none' });

    // Idempotens: samma state igen är en lyckad no-op och får inte skapa event.
    if (previousState === nextState) {
      return res.json({ success: true, changed: false, ...mutationMatchState(matchId) });
    }

    db.transaction(() => {
      db.prepare('UPDATE matches SET day_night_state=? WHERE id=?').run(nextState, matchId);
      db.prepare(`
        INSERT INTO match_events
          (match_id, player_id, related_player_id, event_type, change_value, prev_value, new_value, round_number, metadata_json)
        VALUES (?, NULL, NULL, 'DAY_NIGHT_CHANGE', ?, ?, ?, ?, ?)
      `).run(
        matchId,
        DAY_NIGHT_CODES[nextState],
        DAY_NIGHT_CODES[previousState],
        DAY_NIGHT_CODES[nextState],
        Math.max(1, Number(match.current_round || 1)),
        JSON.stringify({ contract_version: 1, source: 'user' })
      );
    })();

    res.json({
      success: true,
      changed: true,
      previous_state: previousState,
      day_night_state: nextState,
      ...mutationMatchState(matchId)
    });
  } catch (err) {
    routeError(res, err, err?.status || 400, err?.code || 'INVALID_DAY_NIGHT_STATE');
  }
}));

router.post('/matches/:id/undo', reliableMatchMutation('UNDO', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = db.prepare("SELECT * FROM matches WHERE id=? AND status IN ('active','completed')").get(matchId);
    if (!match) return res.status(404).json({ error: 'Match hittades inte.', code: 'MATCH_NOT_FOUND' });
    const ev = db.prepare("SELECT * FROM match_events WHERE match_id=? AND event_type IN ('LIFE_CHANGE','POISON_CHANGE','TAX_CHANGE','CONCEDE','CMDR_DMG','DAY_NIGHT_CHANGE','HIDDEN_TARGET_CLAIM','HIDDEN_THRONE_RESOLVED') ORDER BY id DESC LIMIT 1").get(matchId);
    if (!ev) return res.status(400).json({ error: 'Inga tidigare ändringar att ångra.' });
    if (['HIDDEN_TARGET_CLAIM','HIDDEN_THRONE_RESOLVED'].includes(ev.event_type)) {
      return res.status(409).json({ error:'Ångra kan inte passera en bekräftad hidden-role-åtgärd.', code:'UNDO_BLOCKED_BY_HIDDEN_ROLE_ACTION' });
    }
    if (ev.event_type === 'CMDR_DMG' && !ev.related_player_id) {
      return res.status(400).json({ error: 'Detta äldre commander-damage-event saknar källspelare och kan inte ångras säkert.' });
    }

    db.transaction(() => {
      let metadata = {};
      try { metadata = ev.metadata_json ? JSON.parse(ev.metadata_json) : {}; } catch (_) { metadata = {}; }
      const teamNumber = Number(metadata.team_number || 0);
      if (ev.event_type === 'LIFE_CHANGE') {
        if (metadata.scope === 'team' && teamNumber > 0) {
          db.prepare('UPDATE match_teams SET current_life=?,is_eliminated=0 WHERE match_id=? AND team_number=?').run(ev.prev_value, matchId, teamNumber);
          db.prepare('UPDATE match_players SET current_life=?,is_eliminated=0,eliminated_reason=NULL WHERE match_id=? AND team_number=?').run(ev.prev_value, matchId, teamNumber);
        } else {
          db.prepare('UPDATE match_players SET current_life=? WHERE match_id=? AND player_id=?').run(ev.prev_value, matchId, ev.player_id);
        }
        refreshPlayerElimination(matchId, ev.player_id);
      } else if (ev.event_type === 'POISON_CHANGE') {
        if (metadata.scope === 'team' && teamNumber > 0) {
          db.prepare('UPDATE match_teams SET poison_counters=?,is_eliminated=0 WHERE match_id=? AND team_number=?').run(ev.prev_value, matchId, teamNumber);
          db.prepare('UPDATE match_players SET poison_counters=?,is_eliminated=0,eliminated_reason=NULL WHERE match_id=? AND team_number=?').run(ev.prev_value, matchId, teamNumber);
        } else {
          db.prepare('UPDATE match_players SET poison_counters=? WHERE match_id=? AND player_id=?').run(ev.prev_value, matchId, ev.player_id);
        }
        refreshPlayerElimination(matchId, ev.player_id);
      } else if (ev.event_type === 'TAX_CHANGE') {
        db.prepare('UPDATE match_players SET commander_tax=? WHERE match_id=? AND player_id=?').run(ev.prev_value, matchId, ev.player_id);
      } else if (ev.event_type === 'CONCEDE') {
        if (metadata.scope === 'team' && teamNumber > 0) {
          db.prepare('UPDATE match_teams SET is_eliminated=0 WHERE match_id=? AND team_number=?').run(matchId, teamNumber);
          db.prepare('UPDATE match_players SET is_eliminated=0, eliminated_reason=NULL WHERE match_id=? AND team_number=?').run(matchId, teamNumber);
        } else {
          db.prepare('UPDATE match_players SET is_eliminated=0, eliminated_reason=NULL WHERE match_id=? AND player_id=?').run(matchId, ev.player_id);
        }
        refreshPlayerElimination(matchId, ev.player_id);
      } else if (ev.event_type === 'DAY_NIGHT_CHANGE') {
        const restoredState = dayNightStateFromCode(ev.prev_value);
        db.prepare('UPDATE matches SET day_night_state=? WHERE id=?').run(restoredState, matchId);
      } else if (ev.event_type === 'CMDR_DMG') {
        const player = db.prepare('SELECT commander_damage,current_life,team_number FROM match_players WHERE match_id=? AND player_id=?').get(matchId, ev.player_id);
        const damage = parseCommanderDamage(player.commander_damage);
        damage[ev.related_player_id] = ev.prev_value;
        if (metadata.life_scope === 'team') {
          const team = db.prepare('SELECT current_life FROM match_teams WHERE match_id=? AND team_number=?').get(matchId, player.team_number);
          const restoredLife = Number(team?.current_life ?? player.current_life) + ev.change_value;
          db.prepare('UPDATE match_teams SET current_life=?,is_eliminated=0 WHERE match_id=? AND team_number=?').run(restoredLife, matchId, player.team_number);
          db.prepare('UPDATE match_players SET current_life=?,is_eliminated=0,eliminated_reason=NULL WHERE match_id=? AND team_number=?').run(restoredLife, matchId, player.team_number);
          db.prepare('UPDATE match_players SET commander_damage=? WHERE match_id=? AND player_id=?').run(JSON.stringify(damage), matchId, ev.player_id);
        } else {
          const restoredLife = Number(player.current_life) + ev.change_value;
          db.prepare('UPDATE match_players SET commander_damage=?, current_life=? WHERE match_id=? AND player_id=?')
            .run(JSON.stringify(damage), restoredLife, matchId, ev.player_id);
        }
        refreshPlayerElimination(matchId, ev.player_id);
      }
      db.prepare('DELETE FROM match_events WHERE id=?').run(ev.id);
      refreshMatchWinner(matchId);
    })();
    res.json({ success: true, match: fetchMatch(matchId, false) });
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/reorder-seats', reliableMatchMutation('REORDER_SEATS', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = fetchMatch(matchId, true);
    if (!match) return res.status(404).json({ error: 'Aktiv match saknas.', code: 'MATCH_NOT_FOUND' });
    if (match.rules?.seat_order_locked || match.rules?.positional || match.rules?.play_mode === 'emperor') {
      return res.status(409).json({ error: 'Sittordningen är en del av reglerna för detta spelsätt och kan inte ändras efter matchstart.', code: 'SEAT_ORDER_LOCKED_BY_RULES' });
    }

    const requested = Array.isArray(req.body?.player_ids)
      ? req.body.player_ids.map((id) => asPositiveInt(id, 'player_id'))
      : [];
    const currentIds = match.players.map((p) => Number(p.player_id));

    if (requested.length !== currentIds.length || new Set(requested).size !== requested.length) {
      return res.status(400).json({ error: 'Turordningen måste innehålla varje spelare exakt en gång.', code: 'INVALID_TURN_ORDER' });
    }
    if (requested.some((id) => !currentIds.includes(id))) {
      return res.status(400).json({ error: 'Turordningen innehåller en spelare som inte deltar i matchen.', code: 'INVALID_TURN_ORDER' });
    }

    const activePlayer = match.players[match.active_player_index];
    const activePlayerId = activePlayer ? Number(activePlayer.player_id) : requested[0];
    const newActiveIndex = requested.indexOf(activePlayerId);

    const tx = db.transaction(() => {
      requested.forEach((playerId, index) => {
        db.prepare('UPDATE match_players SET seat_index=? WHERE match_id=? AND player_id=?')
          .run(-(index + 1), matchId, playerId);
      });
      requested.forEach((playerId, index) => {
        db.prepare('UPDATE match_players SET seat_index=? WHERE match_id=? AND player_id=?')
          .run(index, matchId, playerId);
      });
      db.prepare('UPDATE matches SET active_player_index=? WHERE id=?').run(newActiveIndex, matchId);
    });
    tx();

    res.json({ success: true, match: fetchMatch(matchId, true) });
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/next-turn', reliableMatchMutation('NEXT_TURN', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    res.json(matchMutations.nextTurn(matchId));
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/timer/pause', reliableMatchMutation('PAUSE_TIMER', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = db.prepare("SELECT * FROM matches WHERE id=? AND status='active'").get(matchId);
    if (!match) return res.status(404).json({ error: 'Aktiv match saknas.', code: 'MATCH_NOT_FOUND' });
    const timer = getTimerState(match);
    if (!timer.enabled) return res.json({ success: true, match: fetchMatch(matchId, true) });

    const now = db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;
    db.prepare('UPDATE matches SET timer_remaining_seconds=?, timer_is_running=0, timer_anchor_at=? WHERE id=?')
      .run(timer.remaining_seconds, now, matchId);
    res.json({ success: true, match: fetchMatch(matchId, true) });
  } catch (err) { routeError(res, err); }
}));

router.post('/matches/:id/timer/resume', reliableMatchMutation('RESUME_TIMER', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = db.prepare("SELECT * FROM matches WHERE id=? AND status='active'").get(matchId);
    if (!match) return res.status(404).json({ error: 'Aktiv match saknas.', code: 'MATCH_NOT_FOUND' });
    const timer = getTimerState(match);
    if (!timer.enabled) return res.json({ success: true, match: fetchMatch(matchId, true) });
    if (timer.remaining_seconds <= 0) return res.status(409).json({ error: 'Timern har redan gått ut.', code: 'TIMER_EXPIRED' });

    const now = db.prepare('SELECT CURRENT_TIMESTAMP AS now').get().now;
    db.prepare('UPDATE matches SET timer_remaining_seconds=?, timer_is_running=1, timer_anchor_at=? WHERE id=?')
      .run(timer.remaining_seconds, now, matchId);
    res.json({ success: true, match: fetchMatch(matchId, true) });
  } catch (err) { routeError(res, err); }
}));

router.get('/matches/:id/timer', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
    if (!match) return res.status(404).json({ error: 'Matchen hittades inte.', code: 'MATCH_NOT_FOUND' });
    res.json(getTimerState(match));
  } catch (err) { routeError(res, err); }
});

router.post('/matches/:id/finish', reliableMatchMutation('FINISH', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const match = fetchMatch(matchId, true);
    if (!match) return res.status(404).json({ error: 'Aktiv match saknas.', code: 'MATCH_NOT_FOUND' });
    if (isHiddenRoleMode(match.play_mode)) {
      return res.status(409).json({
        error: 'Hidden-role-matcher avslutas av rollernas vinstvillkor och kan inte tilldelas en manuell vinnare.',
        code: 'HIDDEN_ROLE_MANUAL_FINISH_NOT_ALLOWED'
      });
    }

    let winningTeam = null;
    if (req.body.winner_team_number !== undefined && req.body.winner_team_number !== null && req.body.winner_team_number !== '') {
      winningTeam = asPositiveInt(req.body.winner_team_number, 'winner_team_number');
      if (!match.players.some(p => Number(p.team_number) === winningTeam)) {
        return res.status(400).json({ error: 'Det valda laget deltar inte i matchen.', code: 'WINNER_TEAM_INVALID' });
      }
    } else {
      const winnerId = asPositiveInt(req.body.winner_player_id, 'winner_player_id');
      const winner = match.players.find(p => p.player_id === winnerId);
      if (!winner) return res.status(400).json({ error: 'Vinnaren deltar inte i matchen.', code: 'WINNER_PLAYER_INVALID' });
      winningTeam = Number(winner.team_number);
    }

    db.transaction(() => {
      snapshotTimer(matchId);
      closeCurrentTurn(matchId, null, { reason: 'manual_finish' });
      db.prepare("UPDATE matches SET status='completed', ended_at=CURRENT_TIMESTAMP, timer_is_running=0 WHERE id=?").run(matchId);
      updateTeamWinnerFlags(matchId, winningTeam);
    })();
    res.json({ success: true, winning_team_number: winningTeam, match: fetchMatch(matchId, false) });
  } catch (err) { routeError(res, err); }
}));


const historyPlayersStatement = db.prepare(`
  SELECT mp.*,
         COALESCE(p.entity_uid,mp.player_uid) AS player_uid,
         COALESCE(p.name,mp.player_name_snapshot,'Raderad spelare') AS player_name,
         CASE WHEN p.id IS NULL THEN 1 ELSE 0 END AS player_deleted,
         COALESCE(d.entity_uid,mp.deck_uid) AS deck_uid,
         CASE WHEN mp.deck_id IS NULL AND mp.deck_uid IS NULL THEN NULL ELSE COALESCE(d.name,mp.deck_name_snapshot,'Raderad kortlek') END AS deck_name,
         CASE WHEN mp.deck_id IS NULL AND mp.deck_uid IS NULL THEN 0 WHEN d.id IS NULL THEN 1 ELSE 0 END AS deck_deleted,
         COALESCE(d.color_identity,mp.deck_color_identity_snapshot) AS deck_color_identity
  FROM match_players mp
  LEFT JOIN players p ON mp.player_id=p.id
  LEFT JOIN decks d ON mp.deck_id=d.id
  WHERE mp.match_id=?
  ORDER BY mp.seat_index ASC
`);

function historyDto(row) {
  const players = historyPlayersStatement.all(row.id);
  return sanitizePublicMatch(withTeamMetadata({
    ...row,
    client_match_uid: row.client_match_uid || null,
    imported_offline: !!row.imported_offline,
    imported_at: row.imported_at || null,
    import_source: row.import_source || null,
    table_display_name: row.table_name || `Bord ${row.id}`,
    duration_formatted: formatDuration(row.duration_seconds)
  }, players));
}

function selectHistoryRows(filters, { limit = null, offset = 0 } = {}) {
  const { sql, params } = buildHistoryWhere(filters);
  let query = `
    SELECT m.*,
      CAST((julianday(COALESCE(m.ended_at,CURRENT_TIMESTAMP))-julianday(m.started_at))*86400 AS INTEGER) AS duration_seconds
    FROM matches m
    WHERE ${sql}
    ORDER BY m.started_at DESC,m.id DESC`;
  const values = [...params];
  if (limit !== null) { query += ' LIMIT ? OFFSET ?'; values.push(limit, offset); }
  return db.prepare(query).all(...values).map(historyDto);
}

// Auktoritativ full snapshot för Android/äldre klienter. Till skillnad från den
// tidigare hårdkodade LIMIT 50 returnerar GET /matches hela matchhistoriken.
router.get('/matches', (req, res) => {
  try {
    const filters = parseHistoryFilters(req.query);
    res.json(selectHistoryRows(filters));
  } catch (err) { routeError(res, err); }
});

// 3.9.9 – paginerad historik för webbappen och framtida klienter. Samma filter
// som statistik 2.0 används så historik och statistik alltid kan visa samma urval.
router.get('/matches/history-page', (req, res) => {
  try {
    const filters = parseHistoryFilters(req.query);
    const limit = Math.max(1, Math.min(100, Number.parseInt(req.query.limit,10) || 25));
    const offset = Math.max(0, Number.parseInt(req.query.offset,10) || 0);
    const { sql, params } = buildHistoryWhere(filters);
    const total = Number(db.prepare(`SELECT COUNT(*) AS count FROM matches m WHERE ${sql}`).get(...params)?.count || 0);
    const items = selectHistoryRows(filters,{limit,offset});
    res.json({
      contract_version: 6,
      items,
      total,
      limit,
      offset,
      has_more: offset + items.length < total,
      filters: Object.fromEntries(Object.entries(filters).filter(([,value]) => value !== null))
    });
  } catch (err) { routeError(res, err); }
});

function fetchMatchEvents(matchId) {
  return db.prepare(`
    SELECT e.id, e.match_id, e.player_id,
           COALESCE(p.entity_uid,e.player_uid) AS player_uid,
           COALESCE(p.name,e.player_name_snapshot) AS player_name,
           e.related_player_id,
           COALESCE(rp.entity_uid,e.related_player_uid) AS related_player_uid,
           COALESCE(rp.name,e.related_player_name_snapshot) AS related_player_name,
           e.event_type, e.change_value, e.prev_value, e.new_value,
           e.round_number, e.duration_seconds, e.metadata_json, e.created_at,
           strftime('%H:%M:%S', e.created_at) AS time_formatted
    FROM match_events e
    LEFT JOIN players p ON p.id=e.player_id
    LEFT JOIN players rp ON rp.id=e.related_player_id
    WHERE e.match_id=?
    ORDER BY e.id ASC
  `).all(matchId).map(ev => ({
    ...ev,
    created_at_utc: sqliteTimestampToIso(ev.created_at),
    metadata: (() => { try { return ev.metadata_json ? JSON.parse(ev.metadata_json) : null; } catch (_) { return null; } })()
  }));
}

function buildMatchHistory(matchId) {
  const match = fetchMatch(matchId, false);
  if (!match) return null;
  const events = fetchMatchEvents(matchId);
  const rounds = new Map();

  for (const ev of events) {
    const roundNumber = Number(ev.round_number || 1);
    if (!rounds.has(roundNumber)) rounds.set(roundNumber, { round_number: roundNumber, turns: [], events: [] });
    const round = rounds.get(roundNumber);

    if (ev.event_type === 'TURN_START') {
      round.turns.push({
        player_id: ev.player_id,
        player_name: ev.player_name,
        started_at: ev.created_at,
        started_at_utc: ev.created_at_utc,
        started_time: ev.time_formatted,
        ended_at: null,
        duration_seconds: null,
        duration_formatted: null
      });
      continue;
    }
    if (ev.event_type === 'TURN_END') {
      const turn = [...round.turns].reverse().find(t => t.player_id === ev.player_id && !t.ended_at);
      if (turn) {
        turn.ended_at = ev.created_at;
        turn.ended_at_utc = ev.created_at_utc;
        turn.ended_time = ev.time_formatted;
        turn.duration_seconds = Number(ev.duration_seconds ?? ev.change_value ?? 0);
        turn.duration_formatted = formatDuration(turn.duration_seconds);
      }
      continue;
    }
    if (ev.event_type === 'INIT_LIFE') continue;

    round.events.push({
      id: ev.id,
      event_type: ev.event_type,
      player_id: ev.player_id,
      player_name: ev.player_name,
      related_player_id: ev.related_player_id,
      related_player_name: ev.related_player_name,
      change_value: ev.change_value,
      prev_value: ev.prev_value,
      new_value: ev.new_value,
      time: ev.time_formatted,
      created_at: ev.created_at,
      created_at_utc: ev.created_at_utc
    });
  }

  const nowMs = Date.now();
  for (const round of rounds.values()) {
    for (const turn of round.turns) {
      if (!turn.ended_at && match.status === 'active' && Number(match.current_round) === Number(round.round_number)) {
        const startMs = sqliteTimestampToMs(turn.started_at) || nowMs;
        turn.duration_seconds = Math.max(0, Math.floor((nowMs - startMs) / 1000));
        turn.duration_formatted = formatDuration(turn.duration_seconds);
        turn.is_active = true;
      }
    }
    const completedDurations = round.turns.map(t => Number(t.duration_seconds || 0));
    round.duration_seconds = completedDurations.reduce((a, b) => a + b, 0);
    round.duration_formatted = formatDuration(round.duration_seconds);
  }

  return {
    match_id: matchId,
    status: match.status,
    current_round: match.current_round,
    day_night_state: normalizeDayNightState(match.day_night_state, { allowNone: true, fallback: 'none' }),
    match_profile: match.match_profile,
    deck_format: match.deck_format,
    play_mode: match.play_mode,
    rules_profile: match.rules_profile,
    rules_version: match.rules_version,
    rules: match.rules,
    team_mode: match.team_mode,
    is_team_match: match.is_team_match,
    teams: match.teams,
    timer: match.timer,
    rounds: [...rounds.values()].sort((a, b) => a.round_number - b.round_number),
    events
  };
}

// Android-/API-vänlig rå eventström. TURN_START/TURN_END är förstaklass-events.
router.get('/matches/:id/events', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    if (!db.prepare('SELECT 1 FROM matches WHERE id=?').get(matchId)) return res.status(404).json({ error: 'Matchen hittades inte.', code: 'MATCH_NOT_FOUND' });
    res.json({ match_id: matchId, events: fetchMatchEvents(matchId) });
  } catch (err) { routeError(res, err); }
});

router.get('/matches/:id/history', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const history = buildMatchHistory(matchId);
    if (!history) return res.status(404).json({ error: 'Matchen hittades inte.', code: 'MATCH_NOT_FOUND' });
    res.json(history);
  } catch (err) { routeError(res, err); }
});

// Legacy-route för befintlig webb/äldre klienter. Nu bygger den på riktiga
// TURN_START/TURN_END i stället för tiden mellan första/sista livsändringen.
router.get('/matches/:id/life-history', (req, res) => {
  try {
    const matchId = asPositiveInt(req.params.id, 'match_id');
    const history = buildMatchHistory(matchId);
    if (!history) return res.status(404).json({ error: 'Matchen hittades inte.', code: 'MATCH_NOT_FOUND' });
    const result = {};
    for (const round of history.rounds) {
      result[round.round_number] = {
        round_duration_formatted: round.duration_formatted,
        turns: round.turns,
        events: round.events.filter(e => e.event_type === 'LIFE_CHANGE').map(e => ({
          player_name: e.player_name,
          from_life: e.prev_value,
          to_life: e.new_value,
          diff: e.change_value,
          time: e.time
        }))
      };
    }
    res.json(result);
  } catch (err) { routeError(res, err); }
});

module.exports = router;
