const express = require('express');
const QRCode = require('qrcode');
const db = require('../db');
const packageInfo = require('../../package.json');
const { DISCOVERY_CONTRACT_VERSION } = require('../apiContract');
const { API_VERSION } = require('../apiCompatibility');
const { getActiveTlsRuntime, publicTlsMetadata, CANONICAL_HTTPS_PORT } = require('../tlsRuntime');
const {
  PRODUCT,
  QR_TYPE,
  QR_VERSION,
  normalizeBaseUrl,
  buildProvisioning,
  buildQrPayload,
  preferredUrlFromEnv
} = require('../discovery');

const router = express.Router();
const DEFAULT_PORT = 3010;

function requestOrigin(req) {
  return normalizeBaseUrl(`${req.protocol}://${req.get('host')}`);
}

function queryEndpoints(req) {
  const values = [];
  const endpoint = req.query.endpoint;
  if (Array.isArray(endpoint)) values.push(...endpoint);
  else if (endpoint) values.push(endpoint);

  // Legacy query compatibility from the first 3.9.11 candidate.
  if (req.query.url) values.push(req.query.url);
  if (req.query.base_url) values.push(req.query.base_url);
  return values;
}

function provisioningForRequest(req) {
  const activeTls = getActiveTlsRuntime();
  return buildProvisioning({
    preferredUrl: activeTls?.httpsRequired ? activeTls.canonicalHttpsUrl : preferredUrlFromEnv(),
    endpoints: queryEndpoints(req),
    requestOrigin: requestOrigin(req),
    instanceUid: db.instanceUid,
    serverName: 'Bergahallen KTM',
    appVersion: packageInfo.version,
    apiVersion: API_VERSION,
    discoveryContractVersion: DISCOVERY_CONTRACT_VERSION
  });
}

function discoveryDocument() {
  const tls = publicTlsMetadata(getActiveTlsRuntime());
  return {
    status: 'ok',
    product: PRODUCT,
    server_name: 'Bergahallen KTM',
    app_version: packageInfo.version,
    api_version: API_VERSION,
    discovery_contract_version: DISCOVERY_CONTRACT_VERSION,
    instance_uid: db.instanceUid,
    ...tls,
    api_base_path: '/api/v1',
    verification_path: '/api/v1/meta',
    discovery_path: '/api/v1/discovery',
    default_port: tls.https_required ? CANONICAL_HTTPS_PORT : DEFAULT_PORT,
    identity: {
      server_identity: 'instance_uid',
      endpoint_semantics: 'replaceable_hints',
      numeric_id_scope: 'instance_uid'
    },
    connection: {
      discovery_is_optional_probe: true,
      qr_supported: true,
      qr_format: 'json',
      qr_type: QR_TYPE,
      qr_version: QR_VERSION,
      qr_endpoints: true,
      legacy_url_shorthand: true,
      final_verification: '/api/v1/meta',
      credentials_in_qr: false,
      https_required: !!tls.https_required,
      tls_ca_spki_sha256: tls.tls_ca_spki_sha256 || null
    },
    server_time: new Date().toISOString()
  };
}

// Public and intentionally lightweight. This is an OPTIONAL candidate probe.
// /api/v1/meta is the authoritative final verify-before-bind endpoint.
router.get('/discovery', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(discoveryDocument());
});

router.get('/discovery/provision', (req, res, next) => {
  try {
    const provisioning = provisioningForRequest(req);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ...provisioning, qr_payload: buildQrPayload(provisioning) });
  } catch (err) { next(err); }
});

router.get('/discovery/qr.svg', async (req, res, next) => {
  try {
    const provisioning = provisioningForRequest(req);
    const payload = buildQrPayload(provisioning);
    const svg = await QRCode.toString(payload, {
      type: 'svg',
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 320
    });
    res.setHeader('Cache-Control', 'no-store');
    res.type('image/svg+xml').send(svg);
  } catch (err) { next(err); }
});

module.exports = router;
