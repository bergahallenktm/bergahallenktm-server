const express = require('express');
const db = require('../db');
const { requirePermission } = require('../authz');
const requireDeckManage = requirePermission('decks.manage_own');
const { normalizeColorIdentity } = require('../colorIdentity');

const router = express.Router();

function countDeckCards(decklist) {
  if (!decklist) return 0;

  return String(decklist).split(/\r?\n/).reduce((total, rawLine) => {
    const line = rawLine.trim();
    if (!line || line.startsWith('//') || line.startsWith('#')) return total;

    const quantityMatch = line.match(/^(\d+)\s*(?:x\s+)?(.+)$/i);
    if (quantityMatch) {
      const quantity = Number.parseInt(quantityMatch[1], 10);
      return total + (Number.isFinite(quantity) && quantity > 0 ? quantity : 0);
    }

    return total + 1;
  }, 0);
}

function withCardCount(rows) {
  return rows.map(deck => ({ ...deck, card_count: countDeckCards(deck.decklist) }));
}


function deckDto(deck) {
  return {
    ...deck,
    archived: Number(deck.archived || 0),
    status: Number(deck.archived || 0) ? 'archived' : 'active',
    card_count: countDeckCards(deck.decklist),
    sync_revision: Number(deck.sync_revision || 0)
  };
}

function expectedRevisionFrom(req) {
  const raw = req.body?.expected_revision ?? req.query?.expected_revision;
  if (raw === undefined || raw === null || raw === '') return null;
  const revision = Number(raw);
  if (!Number.isInteger(revision) || revision < 0) {
    const err = new Error('expected_revision måste vara ett heltal >= 0.');
    err.code = 'INVALID_SYNC_REVISION';
    err.status = 400;
    throw err;
  }
  return revision;
}


function expectedEntityUidFrom(req) {
  const raw = req.body?.expected_entity_uid ?? req.body?.entity_uid ?? req.query?.expected_entity_uid ?? req.get('X-BergaHallen-Expected-Deck-Uid');
  const value = raw == null ? '' : String(raw).trim();
  if (value.length > 128) throw Object.assign(new Error('expected_entity_uid är för långt.'),{code:'INVALID_DECK_ENTITY_UID',status:400});
  return value || null;
}
function ensureDeckIdentity(res, deck, expectedEntityUid) {
  if (!expectedEntityUid || String(deck.entity_uid || '') === expectedEntityUid) return true;
  res.status(409).json({success:false,error:'Kortlekens stabila identitet matchar inte route-ID:t.',code:'DECK_IDENTITY_MISMATCH',retryable:false,expected_entity_uid:expectedEntityUid,actual_entity_uid:deck.entity_uid||null});
  return false;
}
function tombstoneMatchesExpected(tombstone, expectedEntityUid) {
  return !expectedEntityUid || String(tombstone?.entity_uid || '') === String(expectedEntityUid);
}
function ambiguousDeckNotFound(res) {
  return res.status(404).json({error:'Kortleken hittades inte. Efter restore är frånvaro utan matchande tombstone inte bevis för permanent radering.',code:'DECK_NOT_FOUND',retryable:false,reconciliation_required:true,deletion_proven:false});
}

function revisionConflict(deck, expectedRevision) {
  return expectedRevision !== null && Number(deck.sync_revision || 0) !== expectedRevision;
}

function sendRevisionConflict(res, deck) {
  return res.status(409).json({
    success: false,
    error: 'Kortleken har ändrats på en annan klient. Ladda om och försök igen.',
    code: 'DECK_REVISION_CONFLICT',
    retryable: false,
    current_deck: deckDto(deck)
  });
}

function normalizeCatalogQuery(query = {}) {
  const clean = value => String(value ?? '').trim();
  const limitRaw = Number(query.limit ?? 100);
  const offsetRaw = Number(query.offset ?? 0);
  const limit = Number.isInteger(limitRaw) ? Math.min(Math.max(limitRaw, 1), 500) : 100;
  const offset = Number.isInteger(offsetRaw) ? Math.max(offsetRaw, 0) : 0;
  const sort = ['name','owner','format','updated','cards'].includes(clean(query.sort)) ? clean(query.sort) : 'name';
  const direction = clean(query.direction).toLowerCase() === 'desc' ? 'desc' : 'asc';
  return {
    scope: clean(query.scope).toLowerCase() === 'mine' ? 'mine' : 'all',
    include_archived: ['1','true','yes'].includes(clean(query.include_archived).toLowerCase()),
    status: ['active','archived'].includes(clean(query.status).toLowerCase()) ? clean(query.status).toLowerCase() : '',
    q: clean(query.q).toLocaleLowerCase('sv'),
    format: clean(query.format),
    owner_id: clean(query.owner_id),
    color_identity: clean(query.color_identity).toUpperCase(),
    sort,
    direction,
    limit,
    offset
  };
}

function applyCatalogFilters(rows, filters) {
  let items = rows.map(deckDto);
  if (filters.q) {
    items = items.filter(deck => [deck.name, deck.owner_name, deck.format]
      .some(value => String(value || '').toLocaleLowerCase('sv').includes(filters.q)));
  }
  if (filters.format) items = items.filter(deck => String(deck.format || '').toLowerCase() === filters.format.toLowerCase());
  if (filters.owner_id) items = items.filter(deck => String(deck.owner_id) === filters.owner_id);
  if (filters.color_identity) items = items.filter(deck => String(deck.color_identity || '').toUpperCase() === filters.color_identity);
  if (filters.status) items = items.filter(deck => deck.status === filters.status);

  const compare = (a, b) => {
    let av; let bv;
    if (filters.sort === 'owner') { av = a.owner_name || ''; bv = b.owner_name || ''; }
    else if (filters.sort === 'format') { av = a.format || ''; bv = b.format || ''; }
    else if (filters.sort === 'updated') { av = a.updated_at || ''; bv = b.updated_at || ''; }
    else if (filters.sort === 'cards') { av = Number(a.card_count || 0); bv = Number(b.card_count || 0); }
    else { av = a.name || ''; bv = b.name || ''; }
    let result;
    if (typeof av === 'number' && typeof bv === 'number') result = av - bv;
    else result = String(av).localeCompare(String(bv), 'sv', { sensitivity:'base', numeric:true });
    if (result === 0) result = String(a.name || '').localeCompare(String(b.name || ''), 'sv', { sensitivity:'base', numeric:true });
    return filters.direction === 'desc' ? -result : result;
  };
  items.sort(compare);
  return items;
}

function normalizeDeckInput(body) {
  const name = String(body?.name || '').trim();
  const format = String(body?.format || 'Commander').trim() || 'Commander';
  const decklist = String(body?.decklist || '');
  const clientUid = body?.client_uid == null ? null : String(body.client_uid).trim();
  const colorIdentityPresent = Object.prototype.hasOwnProperty.call(body || {}, 'color_identity');
  const colorIdentity = colorIdentityPresent
    ? normalizeColorIdentity(body?.color_identity, { strict: body?.color_identity != null && body?.color_identity !== '' })
    : undefined;

  if (!name) throw new Error('Deck-namn krävs.');
  if (name.length > 100) throw new Error('Deck-namnet får vara högst 100 tecken.');
  if (format.length > 60) throw new Error('Formatnamnet är för långt.');
  if (clientUid && clientUid.length > 100) throw new Error('client_uid är för långt.');

  return { name, format, decklist, client_uid: clientUid || null, color_identity: colorIdentity, color_identity_present: colorIdentityPresent };
}

const deckSelect = `
  SELECT d.id, d.name, d.format, d.decklist, d.owner_id, p.name AS owner_name,
         d.archived, d.archived_at, d.client_uid, d.created_at, d.updated_at, d.sync_revision,
         d.color_identity, d.entity_uid
  FROM decks d JOIN players p ON p.id = d.owner_id
`;

function deckTombstoneDto(row) {
  return {
    id: Number(row.legacy_id),
    name: `Raderad kortlek #${row.legacy_id}`,
    format: 'Commander',
    decklist: '',
    owner_id: row.owner_id == null ? null : Number(row.owner_id),
    owner_name: 'Raderad spelare',
    archived: 1,
    archived_at: row.deleted_at,
    client_uid: row.client_uid || null,
    created_at: null,
    updated_at: row.deleted_at,
    sync_revision: Number(row.sync_revision || 0),
    color_identity: null,
    entity_uid: row.entity_uid || null,
    card_count: 0,
    permanently_deleted: true
  };
}

function deckTombstoneById(id) {
  return db.prepare(`
    SELECT * FROM sync_tombstones
    WHERE resource='decks' AND legacy_id=?
  `).get(id);
}

function deckTombstoneByClientUid(ownerId, clientUid) {
  if (!clientUid) return null;
  return db.prepare(`
    SELECT * FROM sync_tombstones
    WHERE resource='decks' AND owner_id=? AND client_uid=?
    ORDER BY sync_revision DESC LIMIT 1
  `).get(ownerId, clientUid);
}

function getDeckById(id) {
  return db.prepare(`${deckSelect} WHERE d.id = ?`).get(id);
}

function sendDeck(res, deck, extra = {}) {
  res.json({ ...deckDto(deck), ...extra });
}

router.get('/players', (req, res) => {
  res.json(db.prepare('SELECT id, name, entity_uid FROM players WHERE archived=0 AND is_admin=0 ORDER BY name COLLATE NOCASE').all());
});

// Android/offline: spelarsynk använder samma revisionsprincip som decks och
// returnerar tombstones för administrativt borttagna spelare.
router.get('/players/sync', (req, res) => {
  const rawRevision = req.query?.since_revision;
  const hasRevision = rawRevision !== undefined && rawRevision !== null && rawRevision !== '';
  const sinceRevision = hasRevision ? Number(rawRevision) : null;
  if (hasRevision && (!Number.isInteger(sinceRevision) || sinceRevision < 0)) {
    return res.status(400).json({ error: 'since_revision måste vara ett heltal >= 0.', code: 'INVALID_SYNC_REVISION' });
  }

  const liveSql = `
    SELECT id,name,archived,archived_at,created_at,updated_at,sync_revision,entity_uid
    FROM players
    ${hasRevision ? 'WHERE sync_revision > ?' : ''}
  `;
  const live = hasRevision ? db.prepare(liveSql).all(sinceRevision) : db.prepare(liveSql).all();

  const tombSql = `
    SELECT legacy_id AS id,
           ('Raderad spelare #' || legacy_id) AS name,
           1 AS archived,
           deleted_at AS archived_at,
           NULL AS created_at,
           deleted_at AS updated_at,
           sync_revision,
           entity_uid,
           1 AS permanently_deleted
    FROM sync_tombstones
    WHERE resource='players'
    ${hasRevision ? 'AND sync_revision > ?' : ''}
  `;
  const tombstones = hasRevision ? db.prepare(tombSql).all(sinceRevision) : db.prepare(tombSql).all();

  const players = [...live, ...tombstones]
    .sort((a, b) => Number(a.sync_revision) - Number(b.sync_revision) || Number(a.id) - Number(b.id));

  res.json({ players, sync_revision: db.currentSyncRevision('players'), server_time: new Date().toISOString() });
});

router.get('/all-decks', (req, res) => {
  const decks = db.prepare(`
    ${deckSelect}
    WHERE d.archived = 0 AND p.archived = 0 AND p.is_admin=0
    ORDER BY p.name COLLATE NOCASE, d.name COLLATE NOCASE
  `).all();
  res.json(withCardCount(decks));
});


// Deck UX 2.0: filterable/paginated catalog without breaking legacy list endpoints.
// `scope=mine` may include archived decks and therefore requires authentication.
router.get('/decks/catalog', (req, res) => {
  const filters = normalizeCatalogQuery(req.query);
  const userId = req.session?.user?.id == null ? null : Number(req.session.user.id);
  if (filters.scope === 'mine' && !userId) {
    return res.status(401).json({ error:'Inloggning krävs.', code:'AUTH_REQUIRED' });
  }

  const rows = filters.scope === 'mine'
    ? db.prepare(`${deckSelect} WHERE d.owner_id=? ${filters.include_archived ? '' : 'AND d.archived=0'} ORDER BY d.id`).all(userId)
    : db.prepare(`${deckSelect} WHERE d.archived=0 AND p.archived=0 AND p.is_admin=0 ORDER BY d.id`).all();

  const filtered = applyCatalogFilters(rows, filters);
  const total = filtered.length;
  const items = filtered.slice(filters.offset, filters.offset + filters.limit);
  res.json({
    contract_version: 2,
    items,
    total,
    limit: filters.limit,
    offset: filters.offset,
    has_more: filters.offset + items.length < total,
    sync_revision: db.currentSyncRevision('decks'),
    filters: {
      scope: filters.scope,
      include_archived: filters.scope === 'mine' ? filters.include_archived : false,
      status: filters.status || null,
      q: filters.q || null,
      format: filters.format || null,
      owner_id: filters.owner_id || null,
      color_identity: filters.color_identity || null,
      sort: filters.sort,
      direction: filters.direction
    }
  });
});

router.get('/players/:id/decks', (req, res) => {
  const decks = db.prepare(`
    ${deckSelect}
    WHERE d.owner_id = ? AND d.archived = 0 AND p.archived = 0 AND p.is_admin=0
    ORDER BY d.name COLLATE NOCASE
  `).all(req.params.id);
  res.json(withCardCount(decks));
});

// Mobil-/offlinevänlig synk-endpoint. Till skillnad från /all-decks returnerar
// den även arkiverade poster (tombstones), så Android kan ta bort lokala kopior.
// `since` är valfri ISO-/SQLite-tid från föregående sync_cursor.
router.get('/decks/sync', (req, res) => {
  const rawRevision = req.query?.since_revision;
  const hasRevision = rawRevision !== undefined && rawRevision !== null && rawRevision !== '';
  const sinceRevision = hasRevision ? Number(rawRevision) : null;

  if (hasRevision && (!Number.isInteger(sinceRevision) || sinceRevision < 0)) {
    return res.status(400).json({ error: 'since_revision måste vara ett heltal >= 0.', code: 'INVALID_SYNC_REVISION' });
  }

  const live = hasRevision
    ? db.prepare(`
        ${deckSelect}
        WHERE d.sync_revision > ?
      `).all(sinceRevision)
    : db.prepare(`${deckSelect}`).all();

  const tombSql = `
    SELECT * FROM sync_tombstones
    WHERE resource='decks'
    ${hasRevision ? 'AND sync_revision > ?' : ''}
  `;
  const tombRows = hasRevision ? db.prepare(tombSql).all(sinceRevision) : db.prepare(tombSql).all();
  const tombstones = tombRows.map(deckTombstoneDto);

  const decks = withCardCount(live)
    .concat(tombstones)
    .sort((a, b) => Number(a.sync_revision) - Number(b.sync_revision) || Number(a.id) - Number(b.id));

  res.json({
    decks,
    sync_revision: db.currentSyncRevision('decks'),
    server_time: new Date().toISOString()
  });
});

router.post('/decks', requireDeckManage, (req, res) => {
  try {
    const input = normalizeDeckInput(req.body);
    const ownerId = req.session.user.id;

    // Android kan senare skicka ett stabilt UUID för en lokalt skapad deck.
    // Om ett nätverksretry skickar samma POST igen blir anropet idempotent.
    if (input.client_uid) {
      const hardDeleted = deckTombstoneByClientUid(ownerId, input.client_uid);
      if (hardDeleted) {
        return res.json({
          success: true,
          idempotent_replay: true,
          permanently_deleted: true,
          ...deckTombstoneDto(hardDeleted)
        });
      }

      const existingByClientUid = db.prepare('SELECT id FROM decks WHERE owner_id = ? AND client_uid = ?').get(ownerId, input.client_uid);
      if (existingByClientUid) {
        // A retried create must never overwrite a newer edit made by another
        // client. The stable client_uid identifies the already-created entity;
        // mutations after creation belong on PUT with optional revision guard.
        return sendDeck(res, getDeckById(existingByClientUid.id), { success: true, idempotent_replay: true });
      }
    }

    const existingByName = db.prepare(`
      SELECT * FROM decks
      WHERE owner_id = ? AND name = ? COLLATE NOCASE
      ORDER BY archived ASC, updated_at DESC, id DESC
      LIMIT 1
    `).get(ownerId, input.name);
    if (existingByName) {
      if (existingByName.archived) {
        db.prepare(`
          UPDATE decks
          SET name=?, format=?, decklist=?,
              color_identity=CASE WHEN ?=1 THEN ? ELSE color_identity END,
              archived=0, archived_at=NULL, client_uid=COALESCE(?, client_uid),
              updated_at=CURRENT_TIMESTAMP, sync_revision=?
          WHERE id=?
        `).run(input.name, input.format, input.decklist, input.color_identity_present ? 1 : 0, input.color_identity ?? null, input.client_uid, db.nextSyncRevision('decks'), existingByName.id);
        return sendDeck(res, getDeckById(existingByName.id), { success: true, restored: true });
      }
      return res.status(409).json({ error: 'En kortlek med detta namn finns redan under ditt konto.', code: 'DECK_NAME_CONFLICT' });
    }

    const info = db.prepare(`
      INSERT INTO decks (owner_id, name, format, decklist, color_identity, archived, client_uid, created_at, updated_at, sync_revision)
      VALUES (?, ?, ?, ?, ?, 0, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?)
    `).run(ownerId, input.name, input.format, input.decklist, input.color_identity ?? null, input.client_uid, db.nextSyncRevision('decks'));

    sendDeck(res, getDeckById(Number(info.lastInsertRowid)), { success: true });
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE' || err.code === 'SQLITE_CONSTRAINT') {
      return res.status(409).json({ error: 'Kunde inte skapa deck eftersom den redan finns.', code: 'DECK_CONFLICT' });
    }
    res.status(400).json({ error: err.message || 'Kunde inte skapa deck.', code: 'INVALID_DECK' });
  }
});

router.post('/decks/import-csv', requireDeckManage, (req, res) => {
  try {
    const { fileName, csvContent, format, color_identity } = req.body || {};
    if (!csvContent || !fileName) {
      return res.status(400).json({ error: 'Filnamn och innehåll krävs.', code: 'IMPORT_CONTENT_REQUIRED' });
    }

    const importedColorIdentity = normalizeColorIdentity(color_identity, { strict: color_identity != null && color_identity !== '' });
    let deckName = String(fileName).replace(/\.[^/.]+$/, '').replace(/_/g, ' ').trim();
    if (!deckName) deckName = 'Importerad Kortlek';
    if (deckName.length > 100) {
      return res.status(400).json({ error: 'Deck-namnet får vara högst 100 tecken.', code: 'DECK_NAME_TOO_LONG' });
    }

    const normalizedFormat = String(format || 'Commander').trim() || 'Commander';
    if (normalizedFormat.length > 60) {
      return res.status(400).json({ error: 'Formatnamnet är för långt.', code: 'DECK_FORMAT_TOO_LONG' });
    }

    const lines = String(csvContent).split(/\r?\n/);
    const decklistLines = [];
    for (const rawLine of lines) {
      let line = rawLine.trim();
      if (!line || line.startsWith('//') || line.startsWith('#')) continue;
      if (line.startsWith('"') && line.endsWith('"')) line = line.substring(1, line.length - 1);

      const firstSpaceIndex = line.indexOf(' ');
      if (firstSpaceIndex === -1) continue;
      const qty = parseInt(line.substring(0, firstSpaceIndex).trim(), 10);
      if (Number.isNaN(qty) || qty <= 0) continue;

      let restOfLine = line.substring(firstSpaceIndex + 1).trim();
      restOfLine = restOfLine.replace(/\s*\([A-Z0-9]{3,4}\)\s*\d*$/i, '').trim();
      if (restOfLine) decklistLines.push(`${qty} ${restOfLine}`);
    }

    if (decklistLines.length === 0) {
      return res.status(400).json({ error: 'Kunde inte läsa några kort från filen.', code: 'IMPORT_EMPTY' });
    }

    const ownerId = req.session.user.id;
    const decklist = decklistLines.join('\n');
    const existing = db.prepare(`
      SELECT * FROM decks
      WHERE owner_id=? AND name=? COLLATE NOCASE
      ORDER BY archived ASC, updated_at DESC, id DESC
      LIMIT 1
    `).get(ownerId, deckName);

    let id;
    let restored = false;
    if (existing?.archived) {
      db.prepare(`
        UPDATE decks SET format=?, decklist=?, color_identity=?, archived=0, archived_at=NULL, updated_at=CURRENT_TIMESTAMP, sync_revision=?
        WHERE id=?
      `).run(normalizedFormat, decklist, importedColorIdentity, db.nextSyncRevision('decks'), existing.id);
      id = existing.id;
      restored = true;
    } else if (existing) {
      return res.status(409).json({ error: 'En kortlek med detta namn finns redan under ditt konto.', code: 'DECK_NAME_CONFLICT' });
    } else {
      const info = db.prepare(`
        INSERT INTO decks (owner_id, name, format, decklist, color_identity, archived, created_at, updated_at, sync_revision)
        VALUES (?, ?, ?, ?, ?, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?)
      `).run(ownerId, deckName, normalizedFormat, decklist, importedColorIdentity, db.nextSyncRevision('decks'));
      id = Number(info.lastInsertRowid);
    }

    return res.json({
      success: true,
      id,
      name: deckName,
      format: normalizedFormat,
      color_identity: importedColorIdentity,
      cardCount: countDeckCards(decklist),
      restored
    });
  } catch (err) {
    return res.status(Number(err?.status || 400)).json({
      error: err?.message || 'Kunde inte importera kortleken.',
      code: err?.code || 'DECK_IMPORT_FAILED'
    });
  }
});

router.put('/decks/:id', requireDeckManage, (req, res) => {
  try {
    const input = normalizeDeckInput(req.body);
    const expectedRevision = expectedRevisionFrom(req);
    const expectedEntityUid = expectedEntityUidFrom(req);
    const deck = db.prepare('SELECT * FROM decks WHERE id = ?').get(req.params.id);
    if (!deck) {
      const tombstone = deckTombstoneById(req.params.id);
      if (tombstone && Number(tombstone.owner_id) === Number(req.session.user.id) && tombstoneMatchesExpected(tombstone, expectedEntityUid)) {
        return res.json({ success: true, idempotent_replay: true, ...deckTombstoneDto(tombstone) });
      }
      return ambiguousDeckNotFound(res);
    }
    if (!ensureDeckIdentity(res, deck, expectedEntityUid)) return;
    if (deck.owner_id !== req.session.user.id) return res.status(403).json({ error: 'Obehörig.', code: 'DECK_FORBIDDEN' });
    if (deck.archived) return res.status(409).json({ error: 'Kortleken är arkiverad och kan inte redigeras.', code: 'DECK_ARCHIVED' });
    if (revisionConflict(deck, expectedRevision)) return sendRevisionConflict(res, deck);

    const duplicate = db.prepare(`
      SELECT id FROM decks
      WHERE owner_id=? AND name=? COLLATE NOCASE AND archived=0 AND id<>?
    `).get(deck.owner_id, input.name, deck.id);
    if (duplicate) return res.status(409).json({ error: 'En kortlek med detta namn finns redan under ditt konto.', code: 'DECK_NAME_CONFLICT' });

    db.prepare(`
      UPDATE decks SET name=?, format=?, decklist=?,
        color_identity=CASE WHEN ?=1 THEN ? ELSE color_identity END,
        client_uid=COALESCE(?, client_uid), updated_at=CURRENT_TIMESTAMP, sync_revision=?
      WHERE id=?
    `).run(input.name, input.format, input.decklist, input.color_identity_present ? 1 : 0, input.color_identity ?? null, input.client_uid, db.nextSyncRevision('decks'), deck.id);

    sendDeck(res, getDeckById(deck.id), { success: true });
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message || 'Kunde inte uppdatera deck.', code: err.code || 'INVALID_DECK' });
  }
});


router.post('/decks/:id/restore', requireDeckManage, (req, res) => {
  try {
    const expectedRevision = expectedRevisionFrom(req);
    const expectedEntityUid = expectedEntityUidFrom(req);
    const deck = db.prepare('SELECT * FROM decks WHERE id=?').get(req.params.id);
    if (!deck) {
      const tombstone = deckTombstoneById(req.params.id);
      if (tombstone && Number(tombstone.owner_id) === Number(req.session.user.id) && tombstoneMatchesExpected(tombstone, expectedEntityUid)) {
        return res.status(410).json({ error:'Kortleken är permanent raderad och kan inte återställas.', code:'DECK_PERMANENTLY_DELETED', retryable:false });
      }
      return ambiguousDeckNotFound(res);
    }
    if (!ensureDeckIdentity(res, deck, expectedEntityUid)) return;
    if (deck.owner_id !== req.session.user.id) return res.status(403).json({ error:'Obehörig.', code:'DECK_FORBIDDEN' });
    if (revisionConflict(deck, expectedRevision)) return sendRevisionConflict(res, deck);
    if (!deck.archived) return sendDeck(res, getDeckById(deck.id), { success:true, restored:true, already_active:true });

    const duplicate = db.prepare(`
      SELECT id FROM decks
      WHERE owner_id=? AND name=? COLLATE NOCASE AND archived=0 AND id<>?
    `).get(deck.owner_id, deck.name, deck.id);
    if (duplicate) {
      return res.status(409).json({
        error:'En aktiv kortlek med detta namn finns redan under ditt konto. Byt namn på den aktiva kortleken innan återställning.',
        code:'DECK_NAME_CONFLICT',
        retryable:false
      });
    }

    db.prepare(`
      UPDATE decks
      SET archived=0, archived_at=NULL, updated_at=CURRENT_TIMESTAMP, sync_revision=?
      WHERE id=?
    `).run(db.nextSyncRevision('decks'), deck.id);
    return sendDeck(res, getDeckById(deck.id), { success:true, restored:true });
  } catch (err) {
    return res.status(err.status || 400).json({ error:err.message || 'Kunde inte återställa kortleken.', code:err.code || 'DECK_RESTORE_FAILED' });
  }
});

router.delete('/decks/:id', requireDeckManage, (req, res) => {
  let expectedRevision; let expectedEntityUid;
  try { expectedRevision = expectedRevisionFrom(req); expectedEntityUid = expectedEntityUidFrom(req); }
  catch (err) { return res.status(err.status || 400).json({ error:err.message, code:err.code || 'INVALID_SYNC_REVISION' }); }
  const deck = db.prepare('SELECT * FROM decks WHERE id = ?').get(req.params.id);
  if (!deck) {
    const tombstone = deckTombstoneById(req.params.id);
    if (tombstone && Number(tombstone.owner_id) === Number(req.session.user.id) && tombstoneMatchesExpected(tombstone, expectedEntityUid)) {
      return res.json({ success: true, archived: true, already_archived: true, permanently_deleted: true, id: Number(tombstone.legacy_id) });
    }
    return res.status(404).json({ error:'Kortleken hittades inte.', code:'DECK_NOT_FOUND', retryable:false, reconciliation_required:true, deletion_proven:false });
  }
  if (!ensureDeckIdentity(res, deck, expectedEntityUid)) return;
  if (deck.owner_id !== req.session.user.id) return res.status(403).json({ error: 'Obehörig.', code: 'DECK_FORBIDDEN' });
  if (revisionConflict(deck, expectedRevision)) return sendRevisionConflict(res, deck);

  if (deck.archived) {
    return sendDeck(res, getDeckById(deck.id), { success:true, archived:true, already_archived:true });
  }

  // Soft delete/tombstone. Matchhistorik och statistik behåller därmed deck-id
  // och namn, samtidigt som webb/Android inte längre ser decken som aktiv.
  db.prepare(`
    UPDATE decks
    SET archived=1, archived_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP, sync_revision=?
    WHERE id=?
  `).run(db.nextSyncRevision('decks'), deck.id);

  return sendDeck(res, getDeckById(deck.id), { success:true, archived:true });
});

module.exports = router;
