const express = require('express');
const db = require('../db');
const statsV2 = require('../statsV2');

const router = express.Router();

function formatDuration(seconds) {
  if (seconds === null || seconds === undefined || seconds < 0) return '0s';
  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  if (hours > 0) return `${hours}h ${mins}m ${secs}s`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

function bestDeckForPlayerUid(playerUid) {
  const row = db.prepare(`
    SELECT
      mp.deck_uid,
      COALESCE(MAX(d.name), MAX(mp.deck_name_snapshot), 'Raderad kortlek') AS name,
      CASE WHEN MAX(d.id) IS NULL THEN 1 ELSE 0 END AS deleted,
      COUNT(*) AS games,
      SUM(mp.is_winner) AS wins,
      ROUND(CAST(SUM(mp.is_winner) AS FLOAT) / COUNT(*) * 100, 1) AS win_rate
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id AND m.status='completed'
    LEFT JOIN decks d ON d.entity_uid=mp.deck_uid
    WHERE mp.player_uid=? AND mp.deck_uid IS NOT NULL
    GROUP BY mp.deck_uid
    ORDER BY win_rate DESC,wins DESC,games DESC
    LIMIT 1
  `).get(playerUid);

  if (!row || row.games <= 0) return null;
  return {
    name: row.name,
    deleted: !!row.deleted,
    win_rate: Number(row.win_rate || 0),
    // Backward-compatible display value for older clients. New clients should
    // use the structured fields and translate their own presentation.
    legacy_label: `${row.name}${row.deleted ? ' · raderad' : ''} (${row.win_rate}%)`
  };
}

router.get('/stats', (req, res) => {
  try {
    // Historisk statistik grupperas på immutable UID, inte på namn eller nuvarande
    // foreign key. Därför kan "Spelare A" raderas och en ny "Spelare A" registreras
    // utan att deras statistik blandas ihop.
    const historicalPlayers = db.prepare(`
      SELECT
        mp.player_uid AS uid,
        MAX(p.id) AS id,
        COALESCE(MAX(p.name),MAX(mp.player_name_snapshot),'Raderad spelare') AS name,
        CASE WHEN MAX(p.id) IS NULL THEN 1 ELSE 0 END AS deleted,
        COALESCE(MAX(p.archived),0) AS archived,
        COUNT(*) AS total_games,
        COALESCE(SUM(mp.is_winner),0) AS wins,
        COUNT(*)-COALESCE(SUM(mp.is_winner),0) AS losses,
        ROUND(CAST(COALESCE(SUM(mp.is_winner),0) AS FLOAT)/MAX(COUNT(*),1)*100,1) AS win_rate
      FROM match_players mp
      JOIN matches m ON m.id=mp.match_id AND m.status='completed'
      LEFT JOIN players p ON p.entity_uid=mp.player_uid
      WHERE mp.player_uid IS NOT NULL
      GROUP BY mp.player_uid
    `).all();

    const playerMap = new Map(historicalPlayers.map(row => [row.uid, row]));
    const currentPlayers = db.prepare(`
      SELECT id,entity_uid AS uid,name,archived
      FROM players
      WHERE is_admin=0
      ORDER BY name COLLATE NOCASE
    `).all();

    for (const current of currentPlayers) {
      const existing = playerMap.get(current.uid);
      if (existing) {
        existing.id = current.id;
        existing.name = current.name;
        existing.deleted = 0;
        existing.archived = Number(current.archived || 0);
      } else {
        playerMap.set(current.uid, {
          uid: current.uid,
          id: current.id,
          name: current.name,
          deleted: 0,
          archived: Number(current.archived || 0),
          total_games: 0,
          wins: 0,
          losses: 0,
          win_rate: 0
        });
      }
    }

    const playerStats = [...playerMap.values()]
      .map(p => {
        const bestDeck = p.total_games > 0 ? bestDeckForPlayerUid(p.uid) : null;
        return {
          ...p,
          // Legacy string retained until API v1 freeze. Web 3.9.7+ uses the
          // structured fields below so deleted/no-match labels can be localized.
          best_deck: bestDeck?.legacy_label || 'Inga matcher',
          best_deck_name: bestDeck?.name || null,
          best_deck_deleted: !!bestDeck?.deleted,
          best_deck_win_rate: bestDeck?.win_rate ?? null
        };
      })
      .sort((a,b) => Number(b.wins)-Number(a.wins) || Number(b.total_games)-Number(a.total_games) || String(a.name).localeCompare(String(b.name)));

    const historicalDecks = db.prepare(`
      SELECT
        mp.deck_uid AS uid,
        MAX(d.id) AS id,
        COALESCE(MAX(d.name),MAX(mp.deck_name_snapshot),'Raderad kortlek') AS deck_name,
        COALESCE(MAX(owner.name),MAX(mp.deck_owner_name_snapshot),'Raderad spelare') AS owner_name,
        CASE WHEN MAX(d.id) IS NULL THEN 1 ELSE 0 END AS deleted,
        COALESCE(MAX(d.archived),0) AS archived,
        COUNT(*) AS total_games,
        COALESCE(SUM(mp.is_winner),0) AS wins,
        COUNT(*)-COALESCE(SUM(mp.is_winner),0) AS losses,
        ROUND(CAST(COALESCE(SUM(mp.is_winner),0) AS FLOAT)/MAX(COUNT(*),1)*100,1) AS win_rate,
        ROUND(AVG((julianday(m.ended_at)-julianday(m.started_at))*86400)) AS avg_seconds
      FROM match_players mp
      JOIN matches m ON m.id=mp.match_id AND m.status='completed'
      LEFT JOIN decks d ON d.entity_uid=mp.deck_uid
      LEFT JOIN players owner ON owner.id=d.owner_id
      WHERE mp.deck_uid IS NOT NULL
      GROUP BY mp.deck_uid
    `).all();

    const deckMap = new Map(historicalDecks.map(row => [row.uid, row]));
    const currentDecks = db.prepare(`
      SELECT d.id,d.entity_uid AS uid,d.name AS deck_name,d.archived,p.name AS owner_name
      FROM decks d
      JOIN players p ON p.id=d.owner_id
      WHERE p.is_admin=0
      ORDER BY p.name COLLATE NOCASE,d.name COLLATE NOCASE
    `).all();

    for (const current of currentDecks) {
      const existing = deckMap.get(current.uid);
      if (existing) {
        existing.id = current.id;
        existing.deck_name = current.deck_name;
        existing.owner_name = current.owner_name;
        existing.deleted = 0;
        existing.archived = Number(current.archived || 0);
      } else {
        deckMap.set(current.uid, {
          uid: current.uid,
          id: current.id,
          deck_name: current.deck_name,
          owner_name: current.owner_name,
          deleted: 0,
          archived: Number(current.archived || 0),
          total_games: 0,
          wins: 0,
          losses: 0,
          win_rate: 0,
          avg_seconds: null
        });
      }
    }

    const deckStats = [...deckMap.values()]
      .map(d => ({ ...d, avg_game_length: formatDuration(d.avg_seconds) }))
      .sort((a,b) => Number(b.wins)-Number(a.wins) || Number(b.total_games)-Number(a.total_games) || String(a.deck_name).localeCompare(String(b.deck_name)));

    const rawPlayModeStats = db.prepare(`
      SELECT
        COALESCE(NULLIF(TRIM(play_mode), ''), CASE WHEN team_mode='teams' THEN 'teams' ELSE 'ffa' END) AS play_mode,
        CASE WHEN team_mode='teams' THEN 'teams' ELSE 'ffa' END AS team_mode,
        COUNT(*) AS total_matches
      FROM matches
      WHERE status='completed'
      GROUP BY COALESCE(NULLIF(TRIM(play_mode), ''), CASE WHEN team_mode='teams' THEN 'teams' ELSE 'ffa' END)
      ORDER BY total_matches DESC, play_mode COLLATE NOCASE
    `).all();
    const completedMatchCount = rawPlayModeStats.reduce((sum, row) => sum + Number(row.total_matches || 0), 0);
    const playModeStats = rawPlayModeStats.map(row => ({
      play_mode: row.play_mode,
      team_mode: row.team_mode,
      total_matches: Number(row.total_matches || 0),
      share_percent: completedMatchCount > 0
        ? Math.round((Number(row.total_matches || 0) / completedMatchCount) * 1000) / 10
        : 0
    }));

    const formatIdentityRows = db.prepare(`
      SELECT limited_format, modifiers_json
      FROM matches
      WHERE status='completed'
    `).all();
    const limitedCounts = new Map();
    const modifierCounts = new Map();
    for (const row of formatIdentityRows) {
      const limited = String(row.limited_format || '').trim();
      if (limited) limitedCounts.set(limited, (limitedCounts.get(limited) || 0) + 1);
      let modifiers = [];
      try { modifiers = JSON.parse(row.modifiers_json || '[]'); } catch (_) { modifiers = []; }
      if (Array.isArray(modifiers)) {
        for (const modifier of new Set(modifiers.filter(Boolean).map(String))) {
          modifierCounts.set(modifier, (modifierCounts.get(modifier) || 0) + 1);
        }
      }
    }
    const totalCompletedMatches = formatIdentityRows.length;
    const limitedFormatStats = [...limitedCounts.entries()]
      .map(([limited_format,total_matches]) => ({
        limited_format, total_matches,
        share_percent: totalCompletedMatches > 0 ? Math.round((total_matches / totalCompletedMatches) * 1000) / 10 : 0
      }))
      .sort((a,b) => b.total_matches-a.total_matches || a.limited_format.localeCompare(b.limited_format));
    const modifierStats = [...modifierCounts.entries()]
      .map(([modifier,total_matches]) => ({
        modifier, total_matches,
        share_percent: totalCompletedMatches > 0 ? Math.round((total_matches / totalCompletedMatches) * 1000) / 10 : 0
      }))
      .sort((a,b) => b.total_matches-a.total_matches || a.modifier.localeCompare(b.modifier));

    const rawMatchups = db.prepare(`
      SELECT
        mp1.deck_uid AS deck1_uid,
        COALESCE(d1.name,mp1.deck_name_snapshot,'Raderad kortlek') AS deck1_name,
        CASE WHEN d1.id IS NULL THEN 1 ELSE 0 END AS deck1_deleted,
        mp2.deck_uid AS deck2_uid,
        COALESCE(d2.name,mp2.deck_name_snapshot,'Raderad kortlek') AS deck2_name,
        CASE WHEN d2.id IS NULL THEN 1 ELSE 0 END AS deck2_deleted,
        mp1.is_winner AS deck1_won,
        mp2.is_winner AS deck2_won,
        mp1.team_number AS deck1_team,
        mp2.team_number AS deck2_team
      FROM match_players mp1
      JOIN match_players mp2 ON mp1.match_id=mp2.match_id AND mp1.id<mp2.id
      JOIN matches m ON m.id=mp1.match_id AND m.status='completed'
      LEFT JOIN decks d1 ON d1.entity_uid=mp1.deck_uid
      LEFT JOIN decks d2 ON d2.entity_uid=mp2.deck_uid
      WHERE mp1.deck_uid IS NOT NULL AND mp2.deck_uid IS NOT NULL
    `).all();

    const matchupsMap = {};
    for (const row of rawMatchups) {
      if (Number(row.deck1_team) === Number(row.deck2_team)) continue;

      let left = {
        uid: row.deck1_uid, name: row.deck1_name, deleted: !!row.deck1_deleted,
        won: !!row.deck1_won
      };
      let right = {
        uid: row.deck2_uid, name: row.deck2_name, deleted: !!row.deck2_deleted,
        won: !!row.deck2_won
      };

      if (String(left.uid).localeCompare(String(right.uid)) > 0) {
        [left,right] = [right,left];
      }

      const key = `${left.uid}:${right.uid}`;
      if (!matchupsMap[key]) {
        matchupsMap[key] = {
          deck1_uid: left.uid,
          deck2_uid: right.uid,
          deck1: left.name,
          deck2: right.name,
          deck1_deleted: left.deleted,
          deck2_deleted: right.deleted,
          total: 0,
          deck1_wins: 0,
          deck2_wins: 0,
          neither_won: 0
        };
      }

      matchupsMap[key].total++;
      if (left.won && !right.won) matchupsMap[key].deck1_wins++;
      else if (right.won && !left.won) matchupsMap[key].deck2_wins++;
      else matchupsMap[key].neither_won++;
    }

    const dayNightStats = statsV2.dayNight(statsV2.parseStatsFilters({}));

    res.json({
      playerStats,
      deckStats,
      playModeStats,
      limitedFormatStats,
      modifierStats,
      dayNightStats,
      matchups: Object.values(matchupsMap)
    });
  } catch (err) {
    console.error('Stats Error:', err);
    res.status(500).json({ error: 'Kunde inte hämta statistik.', code: 'STATS_FAILED' });
  }
});


function sendStatsV2Error(res, err) {
  console.error('Stats v2 Error:', err);
  res.status(500).json({ success: false, error: 'Kunde inte hämta statistik.', code: 'STATS_V2_FAILED', retryable: true });
}

// 3.9.9 – Historik och statistik 2.0. Dessa endpoints är additiva och lämnar
// legacy GET /stats orörd för äldre webb-/Androidklienter. Filter avser vilka
// matcher som ingår i urvalet; därefter räknas statistik för hela det urvalet.
router.get('/stats/v2', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json(statsV2.buildStatsV2(filters));
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/summary', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), summary: statsV2.summary(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/players', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), playerStats: statsV2.players(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/decks', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), deckStats: statsV2.decks(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/player-decks', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), playerDeckStats: statsV2.playerDecks(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/formats', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), ...statsV2.formats(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/play-modes', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), playModeStats: statsV2.playModes(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/matchups', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), matchups: statsV2.matchups(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});


router.get('/stats/day-night', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), dayNightStats: statsV2.dayNight(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

router.get('/stats/trends', (req, res) => {
  try {
    const filters = statsV2.parseStatsFilters(req.query);
    res.json({ contract_version: 5, filters: statsV2.publicFilters(filters), trendStats: statsV2.trend(filters) });
  } catch (err) { sendStatsV2Error(res, err); }
});

module.exports = router;
