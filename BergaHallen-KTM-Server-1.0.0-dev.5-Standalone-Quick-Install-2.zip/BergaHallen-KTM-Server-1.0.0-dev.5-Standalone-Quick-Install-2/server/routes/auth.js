const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const asyncHandler = require('../asyncHandler');
const { requirePermission } = require('../authz');
const localLogger = require('../localLogger');
const {
  ACCOUNT_CONTRACT_VERSION, AUTHORIZATION_CONTRACT_VERSION, ACCOUNT_MODEL,
  roleForPlayer, authorizationForPlayer, accountIdentityForPlayer, publicAccountPolicy
} = require('../accountPolicy');
const {
  FALLBACK_LOCALE,
  normalizeSupportedLocale,
  localeSettingsForPlayer,
  legacyLocaleForPlayer,
  legacyLocaleForAccountPreference
} = require('../localeSettings');

const router = express.Router();

function regenerateSession(req) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((err) => err ? reject(err) : resolve());
  });
}

function publicUser(player) {
  const identity = accountIdentityForPlayer(player);
  const authorization = authorizationForPlayer(player);
  return {
    id: player.id,
    entity_uid: player.entity_uid || null,
    name: player.name,
    card_link_preference: player.card_link_preference || 'scryfall',
    preferred_locale: legacyLocaleForPlayer(player),
    locale_settings: localeSettingsForPlayer(player),
    is_admin: !!player.is_admin,
    role: roleForPlayer(player),
    permissions: authorization.permissions,
    authorization,
    account: identity
  };
}

function sessionUser(player) {
  return { ...publicUser(player), auth_revision: Number(player.auth_revision || 0) };
}

function readPlayer(id) {
  return db.prepare(`
    SELECT id,entity_uid,name,card_link_preference,preferred_locale,locale_mode,locale_preference,locale_revision,
           is_admin,archived,auth_revision
    FROM players WHERE id=?
  `).get(Number(id));
}

router.get('/policy', (req, res) => {
  res.json(publicAccountPolicy());
});

router.get('/me', (req, res) => {
  if (!req.session.user) {
    return res.json({
      user: null,
      auth_state: 'anonymous',
      account_contract_version: ACCOUNT_CONTRACT_VERSION,
      authorization_contract_version: AUTHORIZATION_CONTRACT_VERSION,
      account_model: ACCOUNT_MODEL
    });
  }
  const player = readPlayer(req.session.user.id);
  if (!player || player.archived) {
    return res.json({
      user: null,
      auth_state: 'anonymous',
      account_contract_version: ACCOUNT_CONTRACT_VERSION,
      authorization_contract_version: AUTHORIZATION_CONTRACT_VERSION,
      account_model: ACCOUNT_MODEL
    });
  }
  res.json({
    user: publicUser(player),
    auth_state: 'authenticated',
    account_contract_version: ACCOUNT_CONTRACT_VERSION,
    authorization_contract_version: AUTHORIZATION_CONTRACT_VERSION,
    account_model: ACCOUNT_MODEL
  });
});

router.post('/register', asyncHandler(async (req, res) => {
  const name = String(req.body?.name || '').trim();
  const password = String(req.body?.password || '');
  // A new Contract-v1 account always starts in Auto. preferred_locale is only a
  // concrete compatibility hint for old clients and never turns guest state into
  // an authenticated manual preference.
  const preferredLocale = legacyLocaleForAccountPreference(normalizeSupportedLocale(req.body?.preferred_locale) || FALLBACK_LOCALE);

  if (!name || !password) {
    localLogger.warn('auth', 'Registration rejected: required fields missing', { request_id: req.requestId || null });
    return res.status(400).json({ error: 'Namn och lösenord krävs.', code: 'REGISTER_FIELDS_REQUIRED' });
  }
  if (name.length > 40) return res.status(400).json({ error: 'Användarnamnet får vara högst 40 tecken.', code: 'USERNAME_TOO_LONG' });
  if (password.length < 4) return res.status(400).json({ error: 'Lösenordet måste vara minst 4 tecken.', code: 'PASSWORD_TOO_SHORT' });
  if (password.length > 200) return res.status(400).json({ error: 'Lösenordet är för långt.', code: 'PASSWORD_TOO_LONG' });

  const existing = db.prepare('SELECT * FROM players WHERE name=? COLLATE NOCASE').get(name);
  if (existing) {
    if (existing.archived) {
      localLogger.warn('auth', 'Registration rejected: archived account', { request_id: req.requestId || null, player_id: existing.id, player_name: existing.name });
      return res.status(409).json({ error: `Kontot "${existing.name}" är borttaget. En administratör kan återställa det.`, code: 'PLAYER_ARCHIVED' });
    }
    if (existing.password_hash && await bcrypt.compare(password, existing.password_hash)) {
      await regenerateSession(req);
      req.session.user = sessionUser(existing);
      localLogger.info('auth', 'Existing account authenticated during registration', { request_id: req.requestId || null, player_id: existing.id, player_name: existing.name });
      return res.json({ success: true, user: publicUser(existing), auth_state: 'authenticated', already_existed: true });
    }
    localLogger.warn('auth', 'Registration rejected: username taken', { request_id: req.requestId || null, player_name: name });
    return res.status(409).json({ error: `Användarnamnet "${name}" är redan upptaget.`, code: 'USERNAME_TAKEN' });
  }

  const hash = await bcrypt.hash(password, 10);
  try {
    const revision = db.nextSyncRevision('players');
    const info = db.prepare(`
      INSERT INTO players
        (name,password_hash,card_link_preference,preferred_locale,locale_mode,locale_preference,locale_revision,
         is_admin,archived,auth_revision,created_at,updated_at,sync_revision)
      VALUES (?,?,'scryfall',?,'auto',NULL,0,0,0,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?)
    `).run(name, hash, preferredLocale, revision);
    const player = db.prepare('SELECT * FROM players WHERE id=?').get(Number(info.lastInsertRowid));
    await regenerateSession(req);
    req.session.user = sessionUser(player);
    localLogger.info('auth', 'User registered and authenticated', { request_id: req.requestId || null, player_id: player.id, player_name: player.name });
    res.json({ success: true, user: publicUser(player), auth_state: 'authenticated' });
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE' || err.code === 'SQLITE_CONSTRAINT') {
      const raced = db.prepare('SELECT * FROM players WHERE name=? COLLATE NOCASE').get(name);
      if (raced && !raced.archived && raced.password_hash && await bcrypt.compare(password, raced.password_hash)) {
        await regenerateSession(req);
        req.session.user = sessionUser(raced);
        localLogger.info('auth', 'Existing account authenticated after registration race', { request_id: req.requestId || null, player_id: raced.id, player_name: raced.name });
        return res.json({ success: true, user: publicUser(raced), auth_state: 'authenticated', already_existed: true });
      }
      return res.status(409).json({ error: `Användarnamnet "${name}" är redan upptaget.`, code: 'USERNAME_TAKEN' });
    }
    throw err;
  }
}));

router.post('/login', asyncHandler(async (req, res) => {
  const name = String(req.body?.name || '').trim();
  const password = String(req.body?.password || '');
  const player = db.prepare('SELECT * FROM players WHERE name=? COLLATE NOCASE').get(name);
  if (!player || player.archived || !player.password_hash) {
    localLogger.warn('auth', 'Login failed', { request_id: req.requestId || null, player_name: name || null, reason: 'INVALID_CREDENTIALS' });
    return res.status(401).json({ error: 'Felaktiga uppgifter.', code: 'INVALID_CREDENTIALS', retryable: false, auth_state: 'anonymous' });
  }
  const match = await bcrypt.compare(password, player.password_hash);
  if (!match) {
    localLogger.warn('auth', 'Login failed', { request_id: req.requestId || null, player_id: player.id, player_name: player.name, reason: 'INVALID_CREDENTIALS' });
    return res.status(401).json({ error: 'Felaktiga uppgifter.', code: 'INVALID_CREDENTIALS', retryable: false, auth_state: 'anonymous' });
  }
  await regenerateSession(req);
  req.session.user = sessionUser(player);
  localLogger.info('auth', 'Login successful', { request_id: req.requestId || null, player_id: player.id, player_name: player.name, is_admin: !!player.is_admin });
  res.json({ success: true, user: publicUser(player), auth_state: 'authenticated' });
}));

router.post('/logout', (req, res, next) => {
  const actor = req.session?.user ? {
    player_id: req.session.user.id,
    player_name: req.session.user.name
  } : {};
  req.session.destroy((err) => {
    if (err) {
      localLogger.error('auth', 'Logout failed', { request_id: req.requestId || null, ...actor, error: err.message });
      return next(err);
    }
    localLogger.info('auth', 'Logout successful', { request_id: req.requestId || null, ...actor });
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

router.post('/locale', requirePermission('account.update_self_preferences'), (req, res) => {
  const legacyRequest = req.body?.mode == null && req.body?.locale != null;
  const mode = legacyRequest ? 'manual' : String(req.body?.mode || '').trim().toLowerCase();
  if (!['auto', 'manual'].includes(mode)) {
    return res.status(400).json({ error: 'Ogiltigt språkval.', code: 'INVALID_LOCALE' });
  }

  const current = readPlayer(req.authPlayer.id);
  if (!current || current.archived) {
    return res.status(401).json({ error: 'Du måste vara inloggad.', code: 'AUTH_REQUIRED' });
  }

  const expectedProvided = req.body?.expected_revision !== undefined && req.body?.expected_revision !== null;
  const expectedRevision = Number(req.body?.expected_revision);
  if (expectedProvided && (!Number.isInteger(expectedRevision) || expectedRevision < 0)) {
    return res.status(400).json({ error: 'Ogiltig revisionsnivå.', code: 'INVALID_LOCALE_REVISION' });
  }

  const currentSettings = localeSettingsForPlayer(current);
  if (expectedProvided && expectedRevision !== currentSettings.revision) {
    return res.status(409).json({
      success: false,
      error: 'Språkinställningen har ändrats på en annan klient.',
      code: 'LOCALE_PREFERENCE_CONFLICT',
      retryable: false,
      locale_settings: currentSettings,
      preferred_locale: legacyLocaleForPlayer(current)
    });
  }

  let accountPreference = null;
  let legacyLocale = legacyLocaleForPlayer(current);
  if (mode === 'manual') {
    accountPreference = normalizeSupportedLocale(req.body?.locale);
    if (!accountPreference) {
      return res.status(400).json({ error: 'Ogiltigt språkval.', code: 'INVALID_LOCALE' });
    }
    legacyLocale = legacyLocaleForAccountPreference(accountPreference);
  } else {
    // effective_locale is deliberately only a legacy compatibility hint. The
    // actual Auto preference stays device-specific and is never persisted here.
    const hinted = normalizeSupportedLocale(req.body?.effective_locale);
    if (hinted) legacyLocale = legacyLocaleForAccountPreference(hinted);
  }

  const desiredSame = currentSettings.mode === mode
    && (mode === 'auto' || currentSettings.preferred_locale === accountPreference)
    && legacyLocaleForPlayer(current) === legacyLocale;

  if (!desiredSame) {
    const info = db.prepare(`
      UPDATE players
         SET locale_mode=?,locale_preference=?,preferred_locale=?,locale_revision=locale_revision+1,
             updated_at=CURRENT_TIMESTAMP
       WHERE id=? AND locale_revision=?
    `).run(mode, accountPreference, legacyLocale, current.id, currentSettings.revision);
    if (info.changes !== 1) {
      const raced = readPlayer(current.id);
      return res.status(409).json({
        success: false,
        error: 'Språkinställningen har ändrats på en annan klient.',
        code: 'LOCALE_PREFERENCE_CONFLICT',
        retryable: false,
        locale_settings: localeSettingsForPlayer(raced),
        preferred_locale: legacyLocaleForPlayer(raced)
      });
    }
  }

  const updated = readPlayer(current.id);
  req.session.user = sessionUser(updated);
  res.json({
    success: true,
    locale_settings: localeSettingsForPlayer(updated),
    preferred_locale: legacyLocaleForPlayer(updated)
  });
});

router.post('/card-link-preference', requirePermission('account.update_self_preferences'), (req, res) => {
  const { preference } = req.body;
  if (!preference || !['scryfall', 'gatherer'].includes(preference)) {
    return res.status(400).json({ error: 'Ogiltig inställning. Välj scryfall eller gatherer.', code: 'INVALID_CARD_LINK_PREFERENCE' });
  }
  db.prepare('UPDATE players SET card_link_preference=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(preference, req.authPlayer.id);
  req.session.user.card_link_preference = preference;
  res.json({ success: true, preference });
});

module.exports = router;
