const ENGINE_VERSION = 4;
const OPTIONS_REVISION = 3;
const RULES_SCHEMA_VERSION = 3;
const RULES_VERSION = 4;

// Match Format Engine v4 – Limited + generiska modifiers + Offline First.
// Servern är regelkälla. Android/webb ska använda match-options och matchens
// rules snapshot. Hidden-role-snapshot får skapas offline av klient som stöder
// kontraktet och valideras av servern vid import utan att roller/targets lottas om.

const DECK_FORMATS = {
  freeform: { key:'freeform', stored_value:'Freeform / Kitchen Table', name_key:'deckFormat.freeform', category:'open', official:true, active_for_constructed:true },
  standard: { key:'standard', stored_value:'Standard', name_key:'deckFormat.standard', category:'constructed', official:true, active_for_constructed:true },
  pioneer: { key:'pioneer', stored_value:'Pioneer', name_key:'deckFormat.pioneer', category:'constructed', official:true, active_for_constructed:true },
  modern: { key:'modern', stored_value:'Modern', name_key:'deckFormat.modern', category:'constructed', official:true, active_for_constructed:true },
  legacy: { key:'legacy', stored_value:'Legacy', name_key:'deckFormat.legacy', category:'constructed', official:true, active_for_constructed:true },
  vintage: { key:'vintage', stored_value:'Vintage', name_key:'deckFormat.vintage', category:'constructed', official:true, active_for_constructed:true },
  pauper: { key:'pauper', stored_value:'Pauper', name_key:'deckFormat.pauper', category:'constructed', official:true, active_for_constructed:true },
  premodern: { key:'premodern', stored_value:'Premodern', name_key:'deckFormat.premodern', category:'community', official:false, active_for_constructed:true },
  old_school: { key:'old_school', stored_value:'Old School', name_key:'deckFormat.old_school', category:'community', official:false, active_for_constructed:true },
  commander: { key:'commander', stored_value:'Commander', name_key:'deckFormat.commander', category:'singleton', official:true, active_for_constructed:false },
  oathbreaker: { key:'oathbreaker', stored_value:'Oathbreaker', name_key:'deckFormat.oathbreaker', category:'singleton', official:true, active_for_constructed:false }
};

const PLAY_MODES = {
  duel: {
    key:'duel', name_key:'playMode.duel', team_mode:'ffa', min_players:2, max_players:2, recommended_players:2,
    life_scope:'player', turn_scope:'player', winner_scope:'player', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'random_player', starting_life_mode:'uniform'
  },
  ffa: {
    key:'ffa', name_key:'playMode.ffa', team_mode:'ffa', min_players:2, max_players:6, recommended_players:4,
    life_scope:'player', turn_scope:'player', winner_scope:'player', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'random_player', starting_life_mode:'uniform'
  },
  teams: {
    key:'teams', name_key:'playMode.teams', team_mode:'teams', min_players:3, max_players:6, recommended_players:4,
    life_scope:'player', turn_scope:'player', winner_scope:'team', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'random_player', starting_life_mode:'uniform', team_shape:'flexible'
  },
  two_headed_giant: {
    key:'two_headed_giant', name_key:'playMode.two_headed_giant', team_mode:'teams', min_players:4, max_players:4, recommended_players:4,
    life_scope:'team', turn_scope:'team', winner_scope:'team', poison_scope:'team', poison_loss_threshold:15,
    starting_policy:'random_team', starting_life_mode:'team', team_shape:'2v2', fixed_team_sizes:[2,2], official:true, default_team_life:30, commander_team_life:60,
    shared_blocking:true
  },
  emperor: {
    key:'emperor', name_key:'playMode.emperor', team_mode:'teams', min_players:6, max_players:6, recommended_players:6,
    life_scope:'player', turn_scope:'player', winner_scope:'emperor_team', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'random_emperor', starting_life_mode:'uniform', team_shape:'3v3', fixed_team_sizes:[3,3], official:true,
    role_assignment:'emperor_middle', attack_restriction:'adjacent_opponent', range_restriction:'emperor'
  },
  archenemy: {
    key:'archenemy', name_key:'playMode.archenemy', team_mode:'teams', min_players:4, max_players:6, recommended_players:4,
    life_scope:'player', turn_scope:'team', winner_scope:'team', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'archenemy', starting_life_mode:'role', team_shape:'1vN', official:true, role_life:{archenemy:40,hero:20},
    role_assignment:'archenemy_vs_heroes', schemes:'metadata_only'
  },
  archenemy_commander: {
    key:'archenemy_commander', name_key:'playMode.archenemy_commander', team_mode:'teams', min_players:4, max_players:6, recommended_players:4,
    life_scope:'team', turn_scope:'team', winner_scope:'team', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'archenemy', starting_life_mode:'team', team_shape:'1vN', official:true, default_team_life:60,
    role_assignment:'archenemy_vs_heroes', schemes:'metadata_only', commander_damage_scope:'player'
  },
  attack_left_defend_right: {
    key:'attack_left_defend_right', name_key:'playMode.attack_left_defend_right', team_mode:'ffa', min_players:3, max_players:6, recommended_players:4,
    life_scope:'player', turn_scope:'player', winner_scope:'player', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'random_player', starting_life_mode:'uniform', official:false,
    attack_restriction:'left_only', defend_from:'right', positional:true
  },
  kingdoms: {
    key:'kingdoms', name_key:'playMode.kingdoms', team_mode:'ffa', min_players:5, max_players:6, recommended_players:5,
    life_scope:'player', turn_scope:'player', winner_scope:'role_condition', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'king', starting_life_mode:'role', official:false,
    hidden_information:true, role_assignment:'random_role_pool', role_visibility:'mixed', public_roles:['king'],
    role_assignment_algorithm_version:1, role_assignment_algorithm:'fisher_yates_csprng_v1',
    role_life:{king:50,knight:40,bandit:40,assassin:40,usurper:40},
    role_sets:{
      '5':['king','knight','bandit','bandit','assassin'],
      '6':['king','knight','bandit','bandit','assassin','usurper']
    },
    variant_actions:['claim_throne','decline_throne_claim']
  },
  assassin: {
    key:'assassin', name_key:'playMode.assassin', team_mode:'ffa', min_players:3, max_players:6, recommended_players:4,
    life_scope:'player', turn_scope:'player', winner_scope:'player', poison_scope:'player', poison_loss_threshold:10,
    starting_policy:'random_player', starting_life_mode:'uniform', official:false,
    hidden_information:true, role_assignment:'uniform_role', role_visibility:'public', public_roles:['assassin'],
    role_assignment_algorithm_version:1, role_assignment_algorithm:'closed_cycle_csprng_v1',
    target_assignment:'closed_cycle', target_visibility:'owner_only', objective_tracking:'claimed_targets',
    variant_actions:['claim_target']
  }
};

const MATCH_PROFILES = {
  commander: {
    key:'commander', name_key:'matchProfile.commander', legacy_match_type:'Commander', rules_profile:'commander',
    default_deck_format:'commander', deck_format_selectable:false, default_play_mode:'ffa',
    allowed_play_modes:['duel','ffa','teams','two_headed_giant','emperor','archenemy_commander','attack_left_defend_right','kingdoms','assassin'],
    default_life:40, min_players:2, max_players:6, recommended_players:4, default_timer_minutes:3
  },
  oathbreaker: {
    key:'oathbreaker', name_key:'matchProfile.oathbreaker', legacy_match_type:'Oathbreaker', rules_profile:'oathbreaker',
    default_deck_format:'oathbreaker', deck_format_selectable:false, default_play_mode:'ffa',
    allowed_play_modes:['ffa','teams','assassin'], default_life:20, min_players:3, max_players:5, recommended_players:4,
    legacy_min_players:2, legacy_max_players:6, default_timer_minutes:3
  },
  constructed: {
    key:'constructed', name_key:'matchProfile.constructed', legacy_match_type:'Constructed', rules_profile:'constructed',
    default_deck_format:'freeform', deck_format_selectable:true, default_play_mode:'duel',
    allowed_play_modes:['duel','ffa','teams','two_headed_giant','emperor','archenemy','attack_left_defend_right','assassin'],
    default_life:20, min_players:2, max_players:6, recommended_players:2, default_timer_minutes:3
  },
  kitchen_table: {
    key:'kitchen_table', name_key:'matchProfile.kitchen_table', legacy_match_type:'KTM', rules_profile:'freeform',
    default_deck_format:'freeform', deck_format_selectable:false, default_play_mode:'ffa',
    allowed_play_modes:['duel','ffa','teams','two_headed_giant','emperor','archenemy','attack_left_defend_right','assassin'],
    default_life:20, min_players:2, max_players:6, recommended_players:4, default_timer_minutes:3
  }
};

const LIMITED_FORMATS = {
  booster_draft:{
    key:'booster_draft', name_key:'limitedFormat.booster_draft', min_players:4, max_players:8, recommended_players:8,
    allowed_profiles:['constructed','kitchen_table'], allowed_play_modes:['ffa','teams','two_headed_giant'],
    deck_selection_mode:'optional', team_shape:null, official:true, pool_type:'boosters', draft_type:'booster_draft'
  },
  sealed:{
    key:'sealed', name_key:'limitedFormat.sealed', min_players:2, max_players:8, recommended_players:4,
    allowed_profiles:['constructed','kitchen_table'], allowed_play_modes:['duel','ffa','teams','two_headed_giant'],
    deck_selection_mode:'optional', team_shape:null, official:true, pool_type:'sealed_pool', draft_type:'sealed'
  },
  cube_draft:{
    key:'cube_draft', name_key:'limitedFormat.cube_draft', min_players:2, max_players:8, recommended_players:8,
    allowed_profiles:['constructed','kitchen_table'], allowed_play_modes:['duel','ffa','teams','two_headed_giant'],
    deck_selection_mode:'optional', team_shape:null, official:false, pool_type:'cube', draft_type:'draft'
  },
  conspiracy_draft:{
    key:'conspiracy_draft', name_key:'limitedFormat.conspiracy_draft', min_players:4, max_players:8, recommended_players:4,
    allowed_profiles:['constructed','kitchen_table'], allowed_play_modes:['ffa'],
    deck_selection_mode:'optional', team_shape:null, official:false, pool_type:'boosters', draft_type:'multiplayer_draft'
  },
  team_draft:{
    key:'team_draft', name_key:'limitedFormat.team_draft', min_players:6, max_players:6, recommended_players:6,
    allowed_profiles:['constructed','kitchen_table'], allowed_play_modes:['teams'],
    deck_selection_mode:'optional', team_shape:'3v3', fixed_team_sizes:[3,3], official:true, pool_type:'boosters', draft_type:'team_draft'
  },
  team_sealed:{
    key:'team_sealed', name_key:'limitedFormat.team_sealed', min_players:4, max_players:8, recommended_players:6,
    allowed_profiles:['constructed','kitchen_table'], allowed_play_modes:['teams'],
    deck_selection_mode:'optional', team_shape:'equal_teams', official:true, pool_type:'team_sealed_pool', draft_type:'team_sealed'
  }
};

const MODIFIERS = {
  planechase:{
    key:'planechase', name_key:'modifier.planechase', official:true, offline_safe:true,
    rules:{
      mode:'metadata_only', planar_deck_required:false, plane_cards_tracked:false,
      phenomenon_cards_tracked:false, planar_die_tracked:false, planeswalk_history_tracked:false,
      implementation_phase:'metadata_before_4.0'
    }
  }
};

const PLANNED_PLAY_MODES = {};
const PLANNED_LIMITED_FORMATS = {};
const PLANNED_MODIFIERS = {};

function profileFromLegacyMatchType(matchType) {
  const raw=String(matchType||'').trim().toLowerCase();
  if(raw==='commander') return 'commander';
  if(raw==='oathbreaker') return 'oathbreaker';
  if(raw==='constructed'||raw==='1v1') return 'constructed';
  if(raw==='ktm'||raw==='casual 4+'||raw==='kitchen table') return 'kitchen_table';
  return null;
}
function normalizeDeckFormat(raw, profile){
  const requested=String(raw||'').trim().toLowerCase().replace(/[\s/-]+/g,'_');
  if(profile.deck_format_selectable&&requested&&DECK_FORMATS[requested]?.active_for_constructed) return requested;
  return profile.default_deck_format;
}
function inferPlayMode({rawPlayMode,rawTeamMode,participants,legacyMatchType,profile}){
  const explicit=String(rawPlayMode||'').trim().toLowerCase();
  if(explicit) return explicit;
  if(String(rawTeamMode||'').toLowerCase()==='teams') return 'teams';
  if(String(legacyMatchType||'').toLowerCase()==='1v1') return 'duel';
  if(profile.default_play_mode==='duel'&&Array.isArray(participants)&&participants.length>2) return 'ffa';
  return profile.default_play_mode;
}
function specialLifeDefaults(profileKey, playModeKey, profile){
  if(playModeKey==='two_headed_giant') return { starting_life: profileKey==='commander'?60:30, team_life:profileKey==='commander'?60:30, role_life:null };
  if(playModeKey==='archenemy') return { starting_life:20, team_life:null, role_life:{archenemy:40,hero:20} };
  if(playModeKey==='archenemy_commander') return { starting_life:60, team_life:60, role_life:{archenemy:60,hero:60} };
  if(playModeKey==='kingdoms') return { starting_life:40, team_life:null, role_life:{king:50,knight:40,bandit:40,assassin:40,usurper:40} };
  return { starting_life:profile.default_life, team_life:null, role_life:null };
}


function normalizeLimitedFormat(raw, profileKey){
  const key=String(raw||'').trim().toLowerCase();
  if(!key) return null;
  const limited=LIMITED_FORMATS[key];
  if(!limited){ const e=new Error(`Okänt Limited-format: ${key}.`); e.code='LIMITED_FORMAT_NOT_SUPPORTED'; throw e; }
  if(!limited.allowed_profiles.includes(profileKey)){
    const e=new Error('Valt Limited-format stöds bara för Constructed/Kitchen Table-profil.'); e.code='LIMITED_FORMAT_PROFILE_MISMATCH'; throw e;
  }
  return limited;
}

function normalizeModifiers(raw){
  const list=Array.isArray(raw)?raw:(raw==null||raw===''?[]:[raw]);
  const seen=new Set();
  const normalized=[];
  for(const item of list){
    const key=String(item||'').trim().toLowerCase();
    if(!key) continue;
    if(!MODIFIERS[key]){ const e=new Error(`Okänd modifier: ${key}.`); e.code='MODIFIER_NOT_SUPPORTED'; throw e; }
    if(seen.has(key)) continue;
    seen.add(key); normalized.push(key);
  }
  return normalized;
}

function modifierRulesFor(modifiers){
  const out={};
  for(const key of modifiers||[]) out[key]={...MODIFIERS[key].rules};
  return out;
}

function limitedRulesFor(limited){
  if(!limited) return null;
  return {
    format:limited.key,
    pool_type:limited.pool_type,
    draft_type:limited.draft_type,
    deck_selection_mode:limited.deck_selection_mode,
    participant_min:limited.min_players,
    participant_max:limited.max_players,
    recommended_players:limited.recommended_players,
    team_shape:limited.team_shape||null,
    fixed_team_sizes:limited.fixed_team_sizes||null,
    deck_registration_required:false,
    card_pool_tracking:false
  };
}

function victoryConditionsFor(setup){
  if(setup.play_mode==='kingdoms'){
    return [
      { type:'kingdoms_king_and_knight', winner_roles:['king','knight'], when:'all_bandits_and_assassin_eliminated' },
      { type:'kingdoms_bandits', winner_roles:['bandit'], when:'king_eliminated_without_valid_usurper_claim' },
      { type:'kingdoms_assassin', winner_roles:['assassin'], when:'assassin_last_survivor' },
      { type:'kingdoms_usurper', effect:'swap_with_king', when:'confirmed_usurper_killed_king' }
    ];
  }
  if(setup.play_mode==='assassin'){
    return [{ type:'last_player_standing', winner_scope:'player' }];
  }
  if(setup.winner_scope==='emperor_team'){
    return [
      { type:'enemy_emperor_eliminated', winner_scope:'team' },
      { type:'last_team_standing', winner_scope:'team' }
    ];
  }
  if(setup.winner_scope==='team') return [{ type:'last_team_standing', winner_scope:'team' }];
  return [{ type:'last_player_standing', winner_scope:'player' }];
}

function eliminationRulesFor(setup){
  const rules=[
    { type:'life', scope:setup.life_scope, comparator:'lte', threshold:0 },
    { type:'poison', scope:setup.poison_scope, comparator:'gte', threshold:setup.poison_loss_threshold },
    { type:'concede', scope:setup.play_mode==='two_headed_giant'?'team':'player' }
  ];
  if(setup.commander_damage_scope && setup.commander_damage_scope!=='none'){
    rules.push({ type:'commander_damage', scope:setup.commander_damage_scope, comparator:'gte', threshold:21, per_source:true });
  }
  return rules;
}

function turnRotationRulesFor(setup){
  return {
    scope:setup.turn_scope,
    group_field:'turn_group',
    advance:'next_alive_turn_group',
    skip_eliminated:true,
    round_increment:'when_turn_group_cycle_wraps',
    active_players_field:'active_turn_players'
  };
}

function resolveMatchSetup(input={}){
  const participants=Array.isArray(input.participants)?input.participants:[];
  const requestedProfile=String(input.match_profile||input.matchProfile||'').trim().toLowerCase();
  const legacyMatchType=input.match_type||input.matchType||null;
  const profileKey=MATCH_PROFILES[requestedProfile]?requestedProfile:(profileFromLegacyMatchType(legacyMatchType)||'kitchen_table');
  const profile=MATCH_PROFILES[profileKey];
  const playModeKey=inferPlayMode({rawPlayMode:input.play_mode||input.playMode,rawTeamMode:input.team_mode||input.teamMode,participants,legacyMatchType,profile});
  const playMode=PLAY_MODES[playModeKey];
  if(!playMode||!profile.allowed_play_modes.includes(playModeKey)){
    const err=new Error(`Spelsättet ${playModeKey||'?'} stöds inte för vald matchtyp.`); err.code='PLAY_MODE_NOT_SUPPORTED'; throw err;
  }
  if(playModeKey==='archenemy_commander'&&profileKey!=='commander'){
    const err=new Error('Archenemy Commander kräver Commander-profilen.'); err.code='PLAY_MODE_PROFILE_MISMATCH'; throw err;
  }
  if(playModeKey==='archenemy'&&profileKey==='commander'){
    const err=new Error('Använd Archenemy Commander tillsammans med Commander.'); err.code='PLAY_MODE_PROFILE_MISMATCH'; throw err;
  }
  if(playModeKey==='kingdoms'&&profileKey!=='commander'){
    const err=new Error('Kingdoms / Treachery kräver Commander-profilen.'); err.code='PLAY_MODE_PROFILE_MISMATCH'; throw err;
  }
  const limited=normalizeLimitedFormat(input.limited_format||input.limitedFormat,profileKey);
  if(limited && !limited.allowed_play_modes.includes(playModeKey)){
    const err=new Error(`Spelsättet ${playModeKey} stöds inte för ${limited.key}.`); err.code='LIMITED_PLAY_MODE_MISMATCH'; throw err;
  }
  const deckFormatKey=normalizeDeckFormat(input.deck_format||input.deckFormat,profile);
  const defaults=specialLifeDefaults(profileKey,playModeKey,profile);
  const lifeCandidate=Number(input.starting_life??input.startingLife);
  const startingLife=playMode.starting_life_mode==='uniform'&&Number.isInteger(lifeCandidate)&&lifeCandidate>0?lifeCandidate:defaults.starting_life;
  const legacyBounds=!requestedProfile&&legacyMatchType&&profile.legacy_min_players&&profile.legacy_max_players;
  const pmin=legacyBounds?profile.legacy_min_players:profile.min_players;
  const pmax=legacyBounds?profile.legacy_max_players:profile.max_players;
  let minPlayers=Math.max(pmin,playMode.min_players), maxPlayers=Math.min(pmax,playMode.max_players);
  let recommendedPlayers=Math.max(minPlayers,Math.min(maxPlayers,playModeKey===profile.default_play_mode?profile.recommended_players:playMode.recommended_players));
  if(limited){
    if(playModeKey==='duel'){ minPlayers=2; maxPlayers=2; recommendedPlayers=2; }
    else if(playModeKey==='two_headed_giant'){ minPlayers=4; maxPlayers=4; recommendedPlayers=4; }
    else { minPlayers=limited.min_players; maxPlayers=limited.max_players; recommendedPlayers=limited.recommended_players; }
  }
  const modifiers=normalizeModifiers(input.modifiers);
  const setup = {
    engine_version:ENGINE_VERSION, rules_schema_version:RULES_SCHEMA_VERSION,
    match_profile:profileKey, legacy_match_type:profile.legacy_match_type,
    deck_format:deckFormatKey, deck_format_stored_value:DECK_FORMATS[deckFormatKey]?.stored_value||null,
    play_mode:playModeKey, team_mode:playMode.team_mode, limited_format:limited?.key||null, modifiers,
    rules_profile:profile.rules_profile, rules_version:RULES_VERSION, starting_life:startingLife, team_life:defaults.team_life, role_life:defaults.role_life,
    min_players:minPlayers,max_players:maxPlayers,recommended_players:recommendedPlayers,default_timer_minutes:profile.default_timer_minutes,
    life_scope:playMode.life_scope,turn_scope:playMode.turn_scope,winner_scope:playMode.winner_scope,
    poison_scope:playMode.poison_scope,poison_loss_threshold:playMode.poison_loss_threshold,
    commander_damage_scope:(playModeKey==='two_headed_giant'&&profileKey==='commander')?'team':(playMode.commander_damage_scope||(profileKey==='commander'?'player':'none')),
    starting_policy:playMode.starting_policy,starting_life_mode:playMode.starting_life_mode,team_shape:limited?.team_shape||playMode.team_shape||null,
    fixed_team_sizes:limited?.fixed_team_sizes||playMode.fixed_team_sizes||null,role_assignment:playMode.role_assignment||null,
    attack_restriction:playMode.attack_restriction||null,defend_from:playMode.defend_from||null,range_restriction:playMode.range_restriction||null,
    schemes:playMode.schemes||null,positional:!!playMode.positional,shared_blocking:!!playMode.shared_blocking,
    seat_order_locked:!!playMode.positional || playModeKey==='emperor',
    deck_selection_mode:limited?.deck_selection_mode||'required',
    limited_rules:limitedRulesFor(limited),
    hidden_information:!!playMode.hidden_information,
    role_visibility:playMode.role_visibility || (playMode.role_assignment?'public':'none'),
    public_roles:Array.isArray(playMode.public_roles)?[...playMode.public_roles]:[],
    role_assignment_algorithm_version:playMode.role_assignment_algorithm_version || (playMode.role_assignment?1:null),
    role_assignment_algorithm:playMode.role_assignment_algorithm || null,
    role_sets:playMode.role_sets || null,
    target_assignment:playMode.target_assignment || null,
    target_visibility:playMode.target_visibility || 'none',
    objective_tracking:playMode.objective_tracking || null,
    variant_actions:Array.isArray(playMode.variant_actions)?[...playMode.variant_actions]:[],
    reveal_policy:playMode.hidden_information?'owner_or_match_reveal_token':'public',
    history_reveal_policy:playMode.hidden_information?'reveal_after_match':'public',
    secret_snapshot_contract:playMode.hidden_information?{
      version:1,
      assignments_field:'hidden_role_snapshot.assignments',
      validation:'structural_and_identity',
      server_must_not_regenerate_on_import:true
    }:null,
    modifier_rules:modifierRulesFor(modifiers)
  };
  setup.victory_conditions=victoryConditionsFor(setup);
  setup.elimination_rules=eliminationRulesFor(setup);
  setup.turn_rotation_rules=turnRotationRulesFor(setup);
  setup.offline_execution={
    sufficient:true,
    rules_schema_version:RULES_SCHEMA_VERSION,
    hidden_state_required:!!playMode.hidden_information,
    hidden_state_may_be_generated_client_side:!!playMode.hidden_information,
    hidden_state_validation:playMode.hidden_information?'structural_and_identity':'not_applicable',
    limited_state_required:false,
    modifiers_offline_safe:modifiers.every(key=>MODIFIERS[key]?.offline_safe!==false)
  };
  return setup;
}

function validateAndDecorateParticipants(participants, setup){
  const rows=(participants||[]).map((p,index)=>({...p,seat_index:index}));
  const counts=new Map(); for(const p of rows) counts.set(Number(p.team_number),(counts.get(Number(p.team_number))||0)+1);
  const teams=[...counts.entries()].sort((a,b)=>a[0]-b[0]);
  const requireTwoTeams=()=>{ if(teams.length!==2){const e=new Error('Detta spelsätt kräver exakt två lag.');e.code='SPECIAL_TEAM_SHAPE_INVALID';throw e;} };
  if(setup.play_mode==='two_headed_giant'){
    requireTwoTeams(); if(teams.some(([,n])=>n!==2)){const e=new Error('Two-Headed Giant kräver två lag med exakt två spelare i varje.');e.code='TWO_HEADED_GIANT_REQUIRES_2V2';throw e;}
  }
  if(setup.play_mode==='emperor'){
    requireTwoTeams(); if(teams.some(([,n])=>n!==3)){const e=new Error('Emperor kräver två lag med exakt tre spelare i varje.');e.code='EMPEROR_REQUIRES_3V3';throw e;}
  }
  let archenemyTeam=null;
  if(setup.play_mode==='archenemy'||setup.play_mode==='archenemy_commander'){
    requireTwoTeams(); const singleton=teams.filter(([,n])=>n===1); const heroes=teams.filter(([,n])=>n>=3);
    if(singleton.length!==1||heroes.length!==1){const e=new Error('Archenemy kräver ett lag med exakt en Archenemy och ett lag med minst tre hjältar.');e.code='ARCHENEMY_REQUIRES_1_VS_3_PLUS';throw e;}
    archenemyTeam=singleton[0][0];
  }
  if(setup.play_mode==='kingdoms' && ![5,6].includes(rows.length)){
    const e=new Error('Kingdoms / Treachery kräver exakt 5 eller 6 spelare.');e.code='KINGDOMS_REQUIRES_5_OR_6';throw e;
  }
  if(setup.play_mode==='assassin' && rows.length<3){
    const e=new Error('Assassin / Secret Target kräver minst 3 spelare.');e.code='ASSASSIN_REQUIRES_3_PLUS';throw e;
  }
  if(setup.limited_format==='team_draft'){
    requireTwoTeams();
    if(rows.length!==6 || teams.some(([,n])=>n!==3)){ const e=new Error('Team Draft kräver exakt två lag med tre spelare i varje.'); e.code='TEAM_DRAFT_REQUIRES_3V3'; throw e; }
  }
  if(setup.limited_format==='team_sealed'){
    requireTwoTeams();
    if(rows.length<4 || rows.length>8 || rows.length%2!==0 || teams[0]?.[1]!==teams[1]?.[1]){ const e=new Error('Team Sealed kräver två lika stora lag och totalt 4, 6 eller 8 spelare.'); e.code='TEAM_SEALED_REQUIRES_EQUAL_TEAMS'; throw e; }
  }
  const teamPositions=new Map();
  return rows.map((p,index)=>{
    const team=Number(p.team_number); const pos=teamPositions.get(team)||0; teamPositions.set(team,pos+1);
    let role_key=null, range_of_influence=null, attack_rule=setup.attack_restriction||null, turn_group=index+1, initial_life=setup.starting_life;
    if(setup.turn_scope==='team') turn_group=team;
    if(setup.play_mode==='two_headed_giant'){ role_key='head'; initial_life=setup.team_life; }
    if(setup.play_mode==='emperor'){ role_key=pos===1?'emperor':'general'; range_of_influence=role_key==='emperor'?2:1; attack_rule='adjacent_opponent'; }
    if(setup.play_mode==='archenemy'||setup.play_mode==='archenemy_commander'){
      role_key=team===archenemyTeam?'archenemy':'hero'; initial_life=setup.role_life?.[role_key]??setup.starting_life;
    }
    if(setup.play_mode==='attack_left_defend_right'){ attack_rule='left_only'; }
    if(setup.play_mode==='assassin'){ role_key='assassin'; }
    // Kingdoms hemliga roller tilldelas efter valideringen av hiddenRoleEngine.
    return {...p,role_key,range_of_influence,attack_rule,turn_group,initial_life};
  });
}

function buildTeamStates(participants, setup){
  const teams=[...new Set((participants||[]).map(p=>Number(p.team_number)))].sort((a,b)=>a-b);
  return teams.map(teamNumber=>{
    const members=participants.filter(p=>Number(p.team_number)===teamNumber);
    const role=members.some(p=>p.role_key==='archenemy')?'archenemy':(members.some(p=>p.role_key==='hero')?'heroes':null);
    const shared=setup.life_scope==='team';
    const life=shared?Number(members[0]?.initial_life??setup.team_life??setup.starting_life):null;
    return {team_number:teamNumber,role_key:role,life_scope:shared?'team':'player',initial_life:life,current_life:life,
      poison_scope:setup.poison_scope,poison_counters:setup.poison_scope==='team'?0:null,poison_loss_threshold:setup.poison_loss_threshold};
  });
}

function rulesSnapshot(setup){
  const keys=[
    'engine_version','rules_schema_version','rules_version','rules_profile',
    'match_profile','deck_format','play_mode','team_mode','limited_format','modifiers',
    'starting_life','team_life','role_life','min_players','max_players',
    'life_scope','turn_scope','winner_scope','poison_scope','poison_loss_threshold','commander_damage_scope',
    'starting_policy','starting_life_mode','team_shape','fixed_team_sizes','role_assignment','role_visibility',
    'role_assignment_algorithm_version','role_assignment_algorithm','role_sets','public_roles',
    'hidden_information','target_assignment','target_visibility','objective_tracking','variant_actions',
    'reveal_policy','history_reveal_policy','secret_snapshot_contract',
    'attack_restriction','defend_from','range_restriction','schemes',
    'positional','shared_blocking','seat_order_locked','deck_selection_mode','limited_rules','victory_conditions',
    'elimination_rules','turn_rotation_rules','modifier_rules','offline_execution'
  ];
  return Object.fromEntries(keys.map(k=>[k,setup[k]??null]));
}

function deckFormatsForProfile(profile){
  if(!profile.deck_format_selectable) return [profile.default_deck_format];
  return Object.values(DECK_FORMATS).filter(item=>item.active_for_constructed).map(item=>item.key);
}

function resolvedVariants(){
  const variants={};
  for(const [profileKey,profile] of Object.entries(MATCH_PROFILES)){
    for(const playModeKey of profile.allowed_play_modes){
      const setup=resolveMatchSetup({match_profile:profileKey,play_mode:playModeKey,participants:[]});
      variants[`${profileKey}:${playModeKey}`]={
        key:`${profileKey}:${playModeKey}`,
        match_profile:profileKey,
        play_mode:playModeKey,
        limited_format:null,
        team_mode:setup.team_mode,
        default_deck_format:profile.default_deck_format,
        deck_format_selectable:!!profile.deck_format_selectable,
        allowed_deck_formats:deckFormatsForProfile(profile),
        rules:rulesSnapshot(setup)
      };
    }
  }
  for(const [limitedKey,limited] of Object.entries(LIMITED_FORMATS)){
    for(const profileKey of limited.allowed_profiles){
      const profile=MATCH_PROFILES[profileKey];
      for(const playModeKey of limited.allowed_play_modes){
        if(!profile.allowed_play_modes.includes(playModeKey)) continue;
        const setup=resolveMatchSetup({match_profile:profileKey,play_mode:playModeKey,limited_format:limitedKey,participants:[]});
        const key=`${profileKey}:${playModeKey}:${limitedKey}`;
        variants[key]={
          key, match_profile:profileKey, play_mode:playModeKey, limited_format:limitedKey,
          team_mode:setup.team_mode, default_deck_format:profile.default_deck_format,
          deck_format_selectable:!!profile.deck_format_selectable,
          allowed_deck_formats:deckFormatsForProfile(profile), rules:rulesSnapshot(setup)
        };
      }
    }
  }
  return variants;
}

function publicMatchOptions(){
  return {
    engine_version:ENGINE_VERSION,
    options_revision:OPTIONS_REVISION,
    rules_schema_version:RULES_SCHEMA_VERSION,
    server_time:new Date().toISOString(),
    profiles:MATCH_PROFILES,
    deck_formats:DECK_FORMATS,
    play_modes:PLAY_MODES,
    limited_formats:LIMITED_FORMATS,
    modifiers:MODIFIERS,
    planned_play_modes:PLANNED_PLAY_MODES,
    planned_limited_formats:PLANNED_LIMITED_FORMATS,
    planned_modifiers:PLANNED_MODIFIERS,
    resolved_variants:resolvedVariants(),
    resolver_contract:{
      variant_key_fields:['match_profile','play_mode','limited_format'],
      server_authoritative:true,
      hidden_role_offline_contract_version:1,
      limited_contract_version:1,
      modifier_contract_version:1,
      client_overrides:{
        deck_format:'allowed only when profile.deck_format_selectable=true',
        starting_life:'allowed only when rules.starting_life_mode=uniform',
        hidden_role_snapshot:'required for offline-created hidden-role matches; server validates and preserves without regeneration',
        limited_format:'optional; use one of limited_formats and obey its participant/play-mode contract',
        modifiers:'optional array of active modifier IDs; each modifier exposes offline-safe metadata rules'
      }
    }
  };
}

module.exports={ENGINE_VERSION,OPTIONS_REVISION,RULES_SCHEMA_VERSION,RULES_VERSION,DECK_FORMATS,PLAY_MODES,MATCH_PROFILES,LIMITED_FORMATS,MODIFIERS,PLANNED_PLAY_MODES,PLANNED_LIMITED_FORMATS,PLANNED_MODIFIERS,profileFromLegacyMatchType,resolveMatchSetup,validateAndDecorateParticipants,buildTeamStates,rulesSnapshot,resolvedVariants,publicMatchOptions};
