const db = require('./db');
const { authorizationForPlayer, hasPermission } = require('./accountPolicy');

// Servern är alltid sanningskälla för behörighet. Vi litar inte enbart på
// is_admin/role-värdet som råkar ligga i en gammal cookie/session eller cache.
function currentPlayer(req) {
  const id = Number(req.session?.user?.id || 0);
  if (!id) return null;
  return db.prepare(`
    SELECT id, entity_uid, name, card_link_preference, preferred_locale, locale_mode, locale_preference, locale_revision, is_admin, archived, auth_revision
    FROM players WHERE id=?
  `).get(id) || null;
}

function authRequiredBody(req) {
  const expired = req.authFailureCode === 'SESSION_EXPIRED';
  return {
    error: expired ? 'Din serversession är inte längre giltig. Logga in igen.' : 'Du måste vara inloggad.',
    code: expired ? 'SESSION_EXPIRED' : 'AUTH_REQUIRED',
    retryable: false,
    auth_state: expired ? 'reauth_required' : 'anonymous',
    authentication_required: true,
    reauth_required: expired
  };
}

function requireAuth(req, res, next) {
  const player = currentPlayer(req);
  if (!player || player.archived) return res.status(401).json(authRequiredBody(req));
  req.authPlayer = player;
  req.authorization = authorizationForPlayer(player);
  next();
}

function requirePermission(permission, { legacyCode = 'PERMISSION_DENIED', message = 'Du saknar behörighet för åtgärden.' } = {}) {
  return (req, res, next) => {
    const player = currentPlayer(req);
    if (!player || player.archived) return res.status(401).json(authRequiredBody(req));
    const authorization = authorizationForPlayer(player);
    if (!hasPermission(player, permission)) {
      return res.status(403).json({
        error: message,
        code: legacyCode,
        retryable: false,
        auth_state: 'authenticated',
        required_permission: String(permission),
        role: authorization.role,
        authorization_revision: authorization.revision
      });
    }
    req.authPlayer = player;
    req.authorization = authorization;
    next();
  };
}

function requireAdmin(req, res, next) {
  return requirePermission('admin.access', {
    legacyCode: 'ADMIN_REQUIRED',
    message: 'Administratörsbehörighet krävs.'
  })(req, res, next);
}

module.exports = { currentPlayer, requireAuth, requirePermission, requireAdmin };
