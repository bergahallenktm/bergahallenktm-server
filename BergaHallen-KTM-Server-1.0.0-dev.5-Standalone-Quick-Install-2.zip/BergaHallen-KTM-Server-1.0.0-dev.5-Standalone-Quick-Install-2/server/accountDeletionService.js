'use strict';

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const {
  DELETION_TOMBSTONE_JOURNAL_SCHEMA,
  ensurePrivacyMaterial,
  accountMarker,
  appendRecord,
  activeTombstones
} = require('./privacyDeletionJournal');

const ACCOUNT_DELETION_CONTRACT_VERSION = 1;

function apiError(status, code, message) {
  const err = new Error(message);
  err.status = status;
  err.code = code;
  err.expose = true;
  return err;
}

function safeJson(text, fallback) {
  if (text == null || text === '') return fallback;
  try { return JSON.parse(text); } catch (_) { return fallback; }
}

function parseRules(match) {
  return safeJson(match?.rules_json, {}) || {};
}

function deletionLabels(receiptId, ownedDecks) {
  // Historical labels must not be derivable from the opaque deletion receipt.
  // Keep receipt IDs confined to the deletion response/journal boundary.
  const player = `Deleted player ${crypto.randomBytes(4).toString('hex')}`;
  const deckByUid = new Map();
  const deckByName = new Map();
  for (const deck of ownedDecks) {
    const label = `Deleted deck ${crypto.randomBytes(4).toString('hex')}`;
    if (deck.entity_uid) deckByUid.set(String(deck.entity_uid), label);
    if (deck.name) deckByName.set(String(deck.name), label);
  }
  return {
    player,
    playerUid: crypto.randomUUID(),
    deckByUid,
    deckByName,
    deckUidReplacement: new Map([...deckByUid.keys()].map(uid => [uid, crypto.randomUUID()]))
  };
}

function scrubJsonValue(value, ctx, keyHint = '') {
  if (Array.isArray(value)) {
    if (keyHint === 'player_ids') {
      return value.filter(item => Number(item) !== Number(ctx.playerId)).map(item => scrubJsonValue(item, ctx));
    }
    return value.map(item => scrubJsonValue(item, ctx));
  }
  if (!value || typeof value !== 'object') {
    if (typeof value === 'string') {
      if (value === ctx.playerName) return ctx.labels.player;
      if (value === ctx.playerUid) return ctx.labels.playerUid;
      if (ctx.labels.deckByName.has(value)) return ctx.labels.deckByName.get(value);
      if (ctx.labels.deckUidReplacement.has(value)) return ctx.labels.deckUidReplacement.get(value);
    }
    if (typeof value === 'number' && /(^|_)player_id$/.test(keyHint) && Number(value) === Number(ctx.playerId)) return null;
    return value;
  }

  const out = {};
  for (const [key, child] of Object.entries(value)) {
    if (/^(player_id|secret_target_player_id|actor_player_id|target_player_id|imported_by_player_id|imported_by_user_id)$/.test(key)
        && Number(child) === Number(ctx.playerId)) {
      out[key] = null;
      continue;
    }
    if (key === 'player_ids' && Array.isArray(child)) {
      out[key] = child.filter(item => Number(item) !== Number(ctx.playerId)).map(item => scrubJsonValue(item, ctx));
      continue;
    }
    out[key] = scrubJsonValue(child, ctx, key);
  }

  const uidKeys = ['player_uid', 'secret_target_player_uid', 'actor_player_uid', 'target_player_uid'];
  if (uidKeys.some(key => String(out[key] || '') === ctx.playerUid)) {
    for (const key of uidKeys) if (String(out[key] || '') === ctx.playerUid) out[key] = ctx.labels.playerUid;
    for (const nameKey of ['player_name', 'name', 'secret_target_name_snapshot', 'actor_name', 'target_name']) {
      if (nameKey in out) out[nameKey] = ctx.labels.player;
    }
  }
  for (const [deckUid, replacement] of ctx.labels.deckUidReplacement.entries()) {
    if (String(out.deck_uid || '') === deckUid) {
      out.deck_uid = replacement;
      if ('deck_name' in out) out.deck_name = ctx.labels.deckByUid.get(deckUid);
      if ('name' in out && String(out.name) === ctx.labels.deckByUid.get(deckUid)) out.name = ctx.labels.deckByUid.get(deckUid);
    }
  }
  return out;
}

function scrubJsonColumnRows(db, { table, idColumn = 'id', jsonColumn, ctx }) {
  const rows = db.prepare(`SELECT ${idColumn} AS row_id, ${jsonColumn} AS json_value FROM ${table} WHERE ${jsonColumn} IS NOT NULL AND ${jsonColumn}!=''`).all();
  const update = db.prepare(`UPDATE ${table} SET ${jsonColumn}=? WHERE ${idColumn}=?`);
  let changed = 0;
  for (const row of rows) {
    const parsed = safeJson(row.json_value, null);
    if (parsed == null) continue;
    const scrubbed = scrubJsonValue(parsed, ctx);
    const next = JSON.stringify(scrubbed);
    if (next !== row.json_value) {
      update.run(next, row.row_id);
      changed += 1;
    }
  }
  return changed;
}

function scrubCommanderDamage(db, ctx) {
  const rows = db.prepare("SELECT id,commander_damage FROM match_players WHERE commander_damage IS NOT NULL AND commander_damage!=''").all();
  const update = db.prepare('UPDATE match_players SET commander_damage=? WHERE id=?');
  let changed = 0;
  for (const row of rows) {
    const parsed = safeJson(row.commander_damage, {});
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) continue;
    const before = JSON.stringify(parsed);
    delete parsed[String(ctx.playerId)];
    const after = JSON.stringify(parsed);
    if (after !== before) {
      update.run(after, row.id);
      changed += 1;
    }
  }
  return changed;
}

function recordPlayerSyncTombstone(db, player) {
  const revision = db.nextSyncRevision('players');
  db.prepare(`
    INSERT INTO sync_tombstones
      (resource,legacy_id,entity_uid,owner_id,client_uid,deleted_at,sync_revision)
    VALUES ('players',?,?,NULL,NULL,CURRENT_TIMESTAMP,?)
    ON CONFLICT(resource,legacy_id) DO UPDATE SET
      entity_uid=excluded.entity_uid,deleted_at=CURRENT_TIMESTAMP,sync_revision=excluded.sync_revision
  `).run(player.id, player.entity_uid || null, revision);
}

function recordDeckSyncTombstone(db, deck) {
  const revision = db.nextSyncRevision('decks');
  db.prepare(`
    INSERT INTO sync_tombstones
      (resource,legacy_id,entity_uid,owner_id,client_uid,deleted_at,sync_revision)
    VALUES ('decks',?,?,?,?,CURRENT_TIMESTAMP,?)
    ON CONFLICT(resource,legacy_id) DO UPDATE SET
      entity_uid=excluded.entity_uid,owner_id=excluded.owner_id,client_uid=excluded.client_uid,
      deleted_at=CURRENT_TIMESTAMP,sync_revision=excluded.sync_revision
  `).run(deck.id, deck.entity_uid || null, deck.owner_id || null, deck.client_uid || null, revision);
}

function activeMatchRows(db, playerId) {
  return db.prepare(`
    SELECT DISTINCT m.*
      FROM matches m
      JOIN match_players mp ON mp.match_id=m.id
     WHERE m.status='active' AND mp.player_id=?
     ORDER BY m.id
  `).all(playerId);
}

function completeMatchForTeamAfterDeletion(db, matchId, winningTeam) {
  db.prepare("UPDATE matches SET status='completed',ended_at=COALESCE(ended_at,CURRENT_TIMESTAMP),timer_is_running=0 WHERE id=?").run(matchId);
  db.prepare('UPDATE match_players SET is_winner=CASE WHEN team_number=? THEN 1 ELSE 0 END WHERE match_id=?').run(winningTeam, matchId);
  db.prepare('UPDATE match_teams SET is_winner=CASE WHEN team_number=? THEN 1 ELSE 0 END WHERE match_id=?').run(winningTeam, matchId);
}

function completeMatchForPlayersAfterDeletion(db, matchId, playerIds) {
  const ids = [...new Set((playerIds || []).map(Number).filter(n => Number.isInteger(n) && n > 0))];
  db.prepare("UPDATE matches SET status='completed',ended_at=COALESCE(ended_at,CURRENT_TIMESTAMP),timer_is_running=0 WHERE id=?").run(matchId);
  db.prepare('UPDATE match_players SET is_winner=0 WHERE match_id=?').run(matchId);
  db.prepare('UPDATE match_teams SET is_winner=0 WHERE match_id=?').run(matchId);
  for (const id of ids) {
    db.prepare('UPDATE match_players SET is_winner=1 WHERE match_id=? AND player_id=?').run(matchId, id);
    db.prepare(`UPDATE match_teams SET is_winner=1 WHERE match_id=? AND team_number=(
      SELECT team_number FROM match_players WHERE match_id=? AND player_id=?
    )`).run(matchId, matchId, id);
  }
}

function refreshWinnerAfterDeletionConcede(db, match) {
  const matchId = Number(match.id);
  const rules = parseRules(match);
  const mode = String(rules.play_mode || match.play_mode || '');
  const players = db.prepare('SELECT * FROM match_players WHERE match_id=? ORDER BY seat_index,id').all(matchId);

  for (const teamNumber of [...new Set(players.map(p => Number(p.team_number)))]) {
    const members = players.filter(p => Number(p.team_number) === teamNumber);
    db.prepare('UPDATE match_teams SET is_eliminated=? WHERE match_id=? AND team_number=?')
      .run(members.length > 0 && members.every(p => !!p.is_eliminated) ? 1 : 0, matchId, teamNumber);
  }

  const alive = players.filter(p => !p.is_eliminated);
  if (mode === 'assassin') {
    if (alive.length === 1) completeMatchForPlayersAfterDeletion(db, matchId, [alive[0].player_id]);
    return;
  }

  if (mode === 'kingdoms' || mode === 'treachery') {
    const state = safeJson(match.variant_state_json, {}) || {};
    const king = players.find(p => p.role_key === 'king');
    const assassin = players.find(p => p.role_key === 'assassin');
    const bandits = players.filter(p => p.role_key === 'bandit');
    const knights = players.filter(p => p.role_key === 'knight');
    const usurper = players.find(p => p.role_key === 'usurper');
    if (alive.length === 1 && assassin && Number(alive[0].player_id) === Number(assassin.player_id)) {
      state.throne_claim_pending = false;
      db.prepare('UPDATE matches SET variant_state_json=? WHERE id=?').run(JSON.stringify(state), matchId);
      completeMatchForPlayersAfterDeletion(db, matchId, [assassin.player_id]);
      return;
    }
    if (king && !king.is_eliminated) {
      if (state.throne_claim_pending) {
        state.throne_claim_pending = false;
        state.fallen_king_player_id = null;
        db.prepare('UPDATE matches SET variant_state_json=? WHERE id=?').run(JSON.stringify(state), matchId);
      }
      if (bandits.every(p => !!p.is_eliminated) && (!assassin || assassin.is_eliminated)) {
        completeMatchForPlayersAfterDeletion(db, matchId, [king.player_id, ...knights.map(p => p.player_id)]);
      }
      return;
    }
    if (king?.is_eliminated) {
      if (usurper && !usurper.is_eliminated) {
        if (!state.throne_claim_pending) {
          state.throne_claim_pending = true;
          state.fallen_king_player_id = Number(king.player_id);
          state.pending_since = new Date().toISOString();
          db.prepare('UPDATE matches SET variant_state_json=? WHERE id=?').run(JSON.stringify(state), matchId);
        }
        return;
      }
      completeMatchForPlayersAfterDeletion(db, matchId, bandits.map(p => p.player_id));
      return;
    }
    return;
  }

  if (rules.winner_scope === 'emperor_team') {
    const deadEmperor = players.find(p => p.role_key === 'emperor' && p.is_eliminated);
    if (deadEmperor) {
      const winningTeam = [...new Set(players.map(p => Number(p.team_number)))].find(t => t !== Number(deadEmperor.team_number));
      if (winningTeam != null) completeMatchForTeamAfterDeletion(db, matchId, winningTeam);
      return;
    }
  }

  const aliveTeams = [...new Set(alive.map(p => Number(p.team_number)))];
  const allTeams = [...new Set(players.map(p => Number(p.team_number)))];
  db.prepare('UPDATE match_players SET is_winner=0 WHERE match_id=?').run(matchId);
  db.prepare('UPDATE match_teams SET is_winner=0 WHERE match_id=?').run(matchId);
  if (allTeams.length >= 2 && alive.length > 0 && aliveTeams.length === 1) {
    completeMatchForTeamAfterDeletion(db, matchId, aliveTeams[0]);
  }
}

function keepOrAdvanceActivePlayerAfterDeletion(db, match) {
  const current = db.prepare('SELECT * FROM match_players WHERE match_id=? ORDER BY seat_index,id').all(match.id);
  if (!current.length) return;
  const oldIndex = Math.max(0, Math.min(Number(match.active_player_index || 0), current.length - 1));
  const old = current[oldIndex];
  const group = Number(match.active_turn_group ?? old?.turn_group ?? old?.seat_index + 1);
  if (old && !old.is_eliminated && Number(old.turn_group ?? old.seat_index + 1) === group) return;
  for (let offset = 1; offset <= current.length; offset += 1) {
    const index = (oldIndex + offset) % current.length;
    const candidate = current[index];
    if (!candidate.is_eliminated) {
      db.prepare('UPDATE matches SET active_player_index=?,active_turn_group=? WHERE id=?')
        .run(index, Number(candidate.turn_group ?? candidate.seat_index + 1), match.id);
      return;
    }
  }
}

function concedeActiveParticipation(db, playerId) {
  const matches = activeMatchRows(db, playerId);
  for (const match of matches) {
    const participant = db.prepare('SELECT * FROM match_players WHERE match_id=? AND player_id=?').get(match.id, playerId);
    if (!participant) continue;
    const rules = parseRules(match);
    const teamScopedConcede = String(rules.play_mode || match.play_mode || '') === 'two_headed_giant';
    if (teamScopedConcede) {
      db.prepare("UPDATE match_players SET is_eliminated=1,eliminated_reason='Conceded' WHERE match_id=? AND team_number=?")
        .run(match.id, participant.team_number);
      db.prepare('UPDATE match_teams SET is_eliminated=1 WHERE match_id=? AND team_number=?')
        .run(match.id, participant.team_number);
    } else {
      db.prepare("UPDATE match_players SET is_eliminated=1,eliminated_reason='Conceded' WHERE match_id=? AND player_id=?")
        .run(match.id, playerId);
    }
    db.prepare(`
      INSERT INTO match_events(match_id,player_id,event_type,change_value,prev_value,new_value,round_number,metadata_json)
      VALUES (?,?,'CONCEDE',0,0,1,?,?)
    `).run(match.id, playerId, Number(match.current_round || 1), JSON.stringify({
      scope: teamScopedConcede ? 'team' : 'player',
      team_number: Number(participant.team_number),
      reason: 'account_deletion'
    }));

    refreshWinnerAfterDeletionConcede(db, match);
    const updatedMatch = db.prepare('SELECT * FROM matches WHERE id=?').get(match.id);
    if (updatedMatch?.status === 'active') keepOrAdvanceActivePlayerAfterDeletion(db, match);
  }
  return matches.length;
}

function databaseDeletion(db, player, receiptId) {
  const ownedDecks = db.prepare('SELECT * FROM decks WHERE owner_id=? ORDER BY id').all(player.id);
  const labels = deletionLabels(receiptId, ownedDecks);
  const ctx = {
    playerId: Number(player.id),
    playerUid: String(player.entity_uid || ''),
    playerName: String(player.name || ''),
    labels
  };

  const transaction = db.transaction(() => {
    const activeMatchCount = concedeActiveParticipation(db, player.id);

    for (const deck of ownedDecks) recordDeckSyncTombstone(db, deck);
    recordPlayerSyncTombstone(db, player);

    db.prepare('UPDATE match_players SET player_uid=?,player_name_snapshot=? WHERE player_uid=? OR player_id=?')
      .run(labels.playerUid, labels.player, player.entity_uid, player.id);
    db.prepare('UPDATE match_players SET deck_owner_uid=?,deck_owner_name_snapshot=? WHERE deck_owner_uid=?')
      .run(labels.playerUid, labels.player, player.entity_uid);
    db.prepare('UPDATE match_events SET player_uid=?,player_name_snapshot=? WHERE player_uid=? OR player_id=?')
      .run(labels.playerUid, labels.player, player.entity_uid, player.id);
    db.prepare('UPDATE match_events SET related_player_uid=?,related_player_name_snapshot=? WHERE related_player_uid=? OR related_player_id=?')
      .run(labels.playerUid, labels.player, player.entity_uid, player.id);
    db.prepare('UPDATE match_players SET secret_target_player_id=NULL,secret_target_player_uid=?,secret_target_name_snapshot=? WHERE secret_target_player_uid=? OR secret_target_player_id=?')
      .run(labels.playerUid, labels.player, player.entity_uid, player.id);

    for (const deck of ownedDecks) {
      const replacementUid = labels.deckUidReplacement.get(String(deck.entity_uid || '')) || crypto.randomUUID();
      const replacementName = labels.deckByUid.get(String(deck.entity_uid || '')) || `Deleted deck ${crypto.randomBytes(4).toString('hex')}`;
      if (deck.entity_uid) {
        db.prepare('UPDATE match_players SET deck_uid=?,deck_name_snapshot=?,deck_owner_uid=?,deck_owner_name_snapshot=? WHERE deck_uid=? OR deck_id=?')
          .run(replacementUid, replacementName, labels.playerUid, labels.player, deck.entity_uid, deck.id);
      } else {
        db.prepare('UPDATE match_players SET deck_uid=?,deck_name_snapshot=?,deck_owner_uid=?,deck_owner_name_snapshot=? WHERE deck_id=?')
          .run(replacementUid, replacementName, labels.playerUid, labels.player, deck.id);
      }
    }

    db.prepare('UPDATE matches SET imported_by_player_id=NULL WHERE imported_by_player_id=?').run(player.id);
    db.prepare('UPDATE matches SET imported_by_user_id=NULL WHERE imported_by_user_id=?').run(player.id);
    db.prepare('UPDATE admin_audit_log SET actor_player_id=NULL WHERE actor_player_id=?').run(player.id);
    db.prepare('DELETE FROM idempotency_operations WHERE actor_uid=? OR target_uid=?').run(player.entity_uid, player.entity_uid);
    for (const deck of ownedDecks) {
      if (deck.entity_uid) db.prepare('DELETE FROM idempotency_operations WHERE target_uid=?').run(deck.entity_uid);
    }

    const jsonRowsScrubbed =
      scrubJsonColumnRows(db, { table:'matches', jsonColumn:'variant_state_json', ctx })
      + scrubJsonColumnRows(db, { table:'match_players', jsonColumn:'secret_state_json', ctx })
      + scrubJsonColumnRows(db, { table:'match_events', jsonColumn:'metadata_json', ctx })
      + scrubJsonColumnRows(db, { table:'admin_audit_log', jsonColumn:'details_json', ctx });
    const commanderDamageRowsScrubbed = scrubCommanderDamage(db, ctx);

    db.prepare('DELETE FROM decks WHERE owner_id=?').run(player.id);
    const deletedPlayer = db.prepare('DELETE FROM players WHERE id=?').run(player.id);
    if (deletedPlayer.changes !== 1) throw apiError(500, 'ACCOUNT_DELETION_FAILED', 'Kontot kunde inte raderas atomärt.');

    return {
      active_match_count: activeMatchCount,
      owned_deck_count: ownedDecks.length,
      json_rows_scrubbed: jsonRowsScrubbed,
      commander_damage_rows_scrubbed: commanderDamageRowsScrubbed
    };
  });
  return transaction();
}

function preview(db, playerId) {
  const player = db.prepare('SELECT * FROM players WHERE id=?').get(Number(playerId));
  if (!player || player.archived || !player.password_hash) throw apiError(401, 'AUTH_REQUIRED', 'Du måste vara inloggad med ett aktivt serverkonto.');
  if (player.is_admin) throw apiError(403, 'SYSTEM_ACCOUNT_NOT_SELF_DELETABLE', 'Administrationskontot kan inte raderas med självbetjäning.');
  return {
    contract_version: ACCOUNT_DELETION_CONTRACT_VERSION,
    can_delete: true,
    requires_password: true,
    active_match_count: Number(db.prepare("SELECT COUNT(DISTINCT m.id) AS n FROM matches m JOIN match_players mp ON mp.match_id=m.id WHERE m.status='active' AND mp.player_id=?").get(player.id).n || 0),
    owned_deck_count: Number(db.prepare('SELECT COUNT(*) AS n FROM decks WHERE owner_id=?').get(player.id).n || 0),
    effects: {
      account_credentials_deleted: true,
      active_matches_conceded: true,
      player_identity_anonymised_if_history_requires_it: true,
      owned_decks_deleted_or_anonymised: true,
      shared_match_history_may_be_retained_anonymously: true
    }
  };
}

async function deleteAuthenticatedAccount({ db, playerId, currentPassword, confirm, env = process.env }) {
  if (confirm !== true) throw apiError(400, 'DELETION_CONFIRMATION_REQUIRED', 'Bekräftelse krävs för kontoradering.');
  const player = db.prepare('SELECT * FROM players WHERE id=?').get(Number(playerId));
  if (!player || player.archived || !player.password_hash) throw apiError(401, 'AUTH_REQUIRED', 'Du måste vara inloggad med ett aktivt serverkonto.');
  if (player.is_admin) throw apiError(403, 'SYSTEM_ACCOUNT_NOT_SELF_DELETABLE', 'Administrationskontot kan inte raderas med självbetjäning.');
  if (!String(currentPassword || '')) throw apiError(401, 'REAUTH_FAILED', 'Nuvarande lösenord kunde inte verifieras.');
  const passwordOk = await bcrypt.compare(String(currentPassword), player.password_hash);
  if (!passwordOk) throw apiError(401, 'REAUTH_FAILED', 'Nuvarande lösenord kunde inte verifieras.');

  let material;
  const receiptId = crypto.randomBytes(24).toString('base64url');
  const deletedAt = new Date().toISOString();
  let marker = null;
  let databaseCommitted = false;
  try {
    material = ensurePrivacyMaterial({ env });
    marker = accountMarker({ key: material.key, instanceUid: db.instanceUid, accountUid: player.entity_uid });
    appendRecord(material.journalPath, {
      account_marker: marker,
      deletion_receipt_id: receiptId,
      deleted_at: deletedAt,
      state: 'prepared'
    });
    const result = databaseDeletion(db, player, receiptId);
    databaseCommitted = true;
    appendRecord(material.journalPath, {
      account_marker: marker,
      deletion_receipt_id: receiptId,
      deleted_at: deletedAt,
      state: 'finalized'
    });
    return {
      deleted: true,
      contract_version: ACCOUNT_DELETION_CONTRACT_VERSION,
      deletion_receipt_id: receiptId,
      deleted_at: deletedAt,
      internal_result: result
    };
  } catch (err) {
    // Never cancel a prepared tombstone after the database deletion committed.
    // A surviving prepared record is intentionally active so a later restore
    // cannot resurrect the account if finalization itself failed.
    if (!databaseCommitted && material && marker) {
      try {
        appendRecord(material.journalPath, {
          account_marker: marker,
          deletion_receipt_id: receiptId,
          deleted_at: deletedAt,
          state: 'cancelled'
        });
      } catch (_) {}
    }
    if (['AUTH_REQUIRED','REAUTH_FAILED','DELETION_CONFIRMATION_REQUIRED','SYSTEM_ACCOUNT_NOT_SELF_DELETABLE','ACCOUNT_ALREADY_DELETED'].includes(err?.code)) throw err;
    const publicErr = apiError(500, 'ACCOUNT_DELETION_FAILED', 'Kontoraderingen kunde inte slutföras säkert.');
    publicErr.cause = err;
    throw publicErr;
  }
}

function reapplyDeletionJournal({ db, env = process.env }) {
  const material = ensurePrivacyMaterial({ env });
  const tombstones = activeTombstones(material.journalPath);
  if (!tombstones.length) return { contract_version: ACCOUNT_DELETION_CONTRACT_VERSION, journal_schema_version: DELETION_TOMBSTONE_JOURNAL_SCHEMA, scanned_accounts: 0, reapplied: 0 };

  const players = db.prepare('SELECT * FROM players WHERE entity_uid IS NOT NULL AND entity_uid!=\'\' ORDER BY id').all();
  const byMarker = new Map(tombstones.map(row => [row.account_marker, row]));
  let reapplied = 0;
  for (const player of players) {
    const marker = accountMarker({ key: material.key, instanceUid: db.instanceUid, accountUid: player.entity_uid });
    const tombstone = byMarker.get(marker);
    if (!tombstone) continue;
    if (player.is_admin) {
      const err = new Error('Deletion-journal matchar ett skyddat administrationskonto; restore stoppas fail-closed.');
      err.code = 'PRIVACY_REAPPLY_PROTECTED_ACCOUNT_CONFLICT';
      throw err;
    }
    databaseDeletion(db, player, tombstone.deletion_receipt_id);
    reapplied += 1;
  }

  const remaining = db.prepare('SELECT id,entity_uid,is_admin FROM players WHERE entity_uid IS NOT NULL AND entity_uid!=\'\'').all()
    .filter(player => byMarker.has(accountMarker({ key: material.key, instanceUid: db.instanceUid, accountUid: player.entity_uid })));
  if (remaining.length) {
    const err = new Error('Restore deletion reapply kunde inte verifiera att alla raderade identiteter är borta.');
    err.code = 'PRIVACY_REAPPLY_VERIFY_FAILED';
    throw err;
  }

  return {
    contract_version: ACCOUNT_DELETION_CONTRACT_VERSION,
    journal_schema_version: DELETION_TOMBSTONE_JOURNAL_SCHEMA,
    scanned_accounts: players.length,
    active_tombstones: tombstones.length,
    reapplied,
    verified: true
  };
}

module.exports = {
  ACCOUNT_DELETION_CONTRACT_VERSION,
  DELETION_TOMBSTONE_JOURNAL_SCHEMA,
  preview,
  deleteAuthenticatedAccount,
  reapplyDeletionJournal,
  _internal: {
    databaseDeletion,
    scrubJsonValue,
    concedeActiveParticipation,
    refreshWinnerAfterDeletionConcede,
    keepOrAdvanceActivePlayerAfterDeletion
  }
};
