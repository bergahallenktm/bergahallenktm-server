const crypto = require('crypto');

const HIDDEN_ROLE_CONTRACT_VERSION = 1;
const ASSIGNMENT_ALGORITHM_VERSION = 1;
const REVEAL_TOKEN_BYTES = 24;

function hiddenError(message, code, status = 422) {
  const err = new Error(message);
  err.code = code;
  err.status = status;
  return err;
}

function isHiddenRoleMode(playMode) {
  return playMode === 'kingdoms' || playMode === 'assassin';
}

function rolePoolForKingdoms(playerCount) {
  if (Number(playerCount) === 5) return ['king', 'knight', 'bandit', 'bandit', 'assassin'];
  if (Number(playerCount) === 6) return ['king', 'knight', 'bandit', 'bandit', 'assassin', 'usurper'];
  throw hiddenError('Kingdoms / Treachery kräver exakt 5 eller 6 spelare.', 'KINGDOMS_REQUIRES_5_OR_6');
}

function cryptoShuffle(values) {
  const out = [...values];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = crypto.randomInt(i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function playerIdentity(player) {
  const uid = String(player?.player_uid || player?.playerUid || '').trim();
  const id = Number(player?.player_id || player?.playerId || 0);
  return { uid: uid || null, id: Number.isInteger(id) && id > 0 ? id : null };
}

function samePlayerRef(assignment, player) {
  const aUid = String(assignment?.player_uid || assignment?.playerUid || '').trim();
  const pUid = String(player?.player_uid || player?.playerUid || '').trim();
  if (aUid && pUid) return aUid === pUid;
  const aId = Number(assignment?.player_id || assignment?.playerId || 0);
  const pId = Number(player?.player_id || player?.playerId || 0);
  return Number.isInteger(aId) && aId > 0 && aId === pId;
}

function victoryKeyForRole(role) {
  return ({
    king: 'protect_kingdom',
    knight: 'protect_king',
    bandit: 'kill_king',
    assassin: 'last_survivor',
    usurper: 'seize_throne'
  })[role] || null;
}

function roleVisibilityForKingdoms(role) {
  return role === 'king' ? 'public' : 'secret';
}

function normalizeSnapshot(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const assignments = Array.isArray(raw.assignments) ? raw.assignments : null;
  if (!assignments) return null;
  return {
    version: Number(raw.version || raw.contract_version || HIDDEN_ROLE_CONTRACT_VERSION),
    play_mode: String(raw.play_mode || raw.playMode || '').trim().toLowerCase(),
    algorithm_version: Number(raw.algorithm_version || raw.role_assignment_algorithm_version || ASSIGNMENT_ALGORITHM_VERSION),
    assignments
  };
}

function assertSnapshotHeader(snapshot, setup, participantCount) {
  if (!snapshot) throw hiddenError('Hidden-role snapshot saknas.', 'HIDDEN_ROLE_SNAPSHOT_REQUIRED');
  if (snapshot.version !== HIDDEN_ROLE_CONTRACT_VERSION) {
    throw hiddenError('Hidden-role snapshot-versionen stöds inte av servern.', 'HIDDEN_ROLE_SNAPSHOT_VERSION_UNSUPPORTED');
  }
  if (snapshot.algorithm_version !== Number(setup.role_assignment_algorithm_version || ASSIGNMENT_ALGORITHM_VERSION)) {
    throw hiddenError('Hidden-role assignment-algoritmen stöds inte av servern.', 'HIDDEN_ROLE_ALGORITHM_VERSION_UNSUPPORTED');
  }
  if (snapshot.play_mode && snapshot.play_mode !== setup.play_mode) {
    throw hiddenError('Hidden-role snapshot tillhör ett annat spelsätt.', 'HIDDEN_ROLE_SNAPSHOT_PLAY_MODE_MISMATCH');
  }
  if (snapshot.assignments.length !== participantCount) {
    throw hiddenError('Hidden-role snapshot har fel antal deltagare.', 'HIDDEN_ROLE_SNAPSHOT_PARTICIPANT_MISMATCH');
  }
}

function findAssignmentForPlayer(snapshot, player) {
  const matches = snapshot.assignments.filter(a => samePlayerRef(a, player));
  if (matches.length !== 1) {
    throw hiddenError('Hidden-role snapshot kan inte kopplas entydigt till deltagarna.', 'HIDDEN_ROLE_SNAPSHOT_IDENTITY_MISMATCH');
  }
  return matches[0];
}

function normalizeTargetRef(assignment) {
  const uid = String(assignment?.secret_target_player_uid || assignment?.target_player_uid || assignment?.targetPlayerUid || '').trim();
  const id = Number(assignment?.secret_target_player_id || assignment?.target_player_id || assignment?.targetPlayerId || 0);
  return { uid: uid || null, id: Number.isInteger(id) && id > 0 ? id : null };
}

function resolveTarget(targetRef, participants) {
  if (targetRef.uid) {
    const byUid = participants.filter(p => String(p.player_uid || '') === targetRef.uid);
    if (byUid.length === 1) return byUid[0];
  }
  if (targetRef.id) {
    const byId = participants.filter(p => Number(p.player_id) === targetRef.id);
    if (byId.length === 1) return byId[0];
  }
  return null;
}

function validateKingdomsSnapshot(participants, setup, snapshot) {
  assertSnapshotHeader(snapshot, setup, participants.length);
  const expected = rolePoolForKingdoms(participants.length).sort();
  const roles = [];
  const decorated = participants.map(player => {
    const assignment = findAssignmentForPlayer(snapshot, player);
    const role = String(assignment.role_key || assignment.roleKey || '').trim().toLowerCase();
    roles.push(role);
    return {
      ...player,
      role_key: role,
      role_visibility: roleVisibilityForKingdoms(role),
      victory_condition_key: victoryKeyForRole(role),
      objective_score: Math.max(0, Number(assignment.objective_score || assignment.objectiveScore || 0) || 0),
      initial_life: Number(setup.role_life?.[role] ?? setup.starting_life),
      secret_target_player_id: null,
      secret_target_player_uid: null,
      secret_target_name_snapshot: null,
      secret_state_json: JSON.stringify({ contract_version:HIDDEN_ROLE_CONTRACT_VERSION })
    };
  });
  if (JSON.stringify([...roles].sort()) !== JSON.stringify(expected)) {
    throw hiddenError('Kingdoms-snapshot har en ogiltig rolluppsättning.', 'KINGDOMS_ROLE_POOL_INVALID');
  }
  return decorated;
}

function validateAssassinSnapshot(participants, setup, snapshot) {
  assertSnapshotHeader(snapshot, setup, participants.length);
  const targetKeys = new Set();
  const decorated = participants.map(player => {
    const assignment = findAssignmentForPlayer(snapshot, player);
    const role = String(assignment.role_key || assignment.roleKey || 'assassin').trim().toLowerCase();
    if (role !== 'assassin') throw hiddenError('Assassin-snapshot innehåller en ogiltig roll.', 'ASSASSIN_ROLE_INVALID');
    const target = resolveTarget(normalizeTargetRef(assignment), participants);
    if (!target || Number(target.player_id) === Number(player.player_id)) {
      throw hiddenError('Assassin-snapshot innehåller ett ogiltigt hemligt mål.', 'ASSASSIN_TARGET_INVALID');
    }
    const key = target.player_uid || `id:${target.player_id}`;
    if (targetKeys.has(key)) throw hiddenError('Assassin-snapshot måste bilda en sluten målcykel.', 'ASSASSIN_TARGET_CYCLE_INVALID');
    targetKeys.add(key);
    return {
      ...player,
      role_key:'assassin',
      role_visibility:'public',
      victory_condition_key:'last_survivor',
      objective_score:Number(assignment.objective_score || assignment.objectiveScore || 0) || 0,
      secret_target_player_id:Number(target.player_id),
      secret_target_player_uid:target.player_uid || null,
      secret_target_name_snapshot:target.player_name || null,
      secret_state_json:JSON.stringify({ contract_version:HIDDEN_ROLE_CONTRACT_VERSION })
    };
  });
  if (targetKeys.size !== participants.length) {
    throw hiddenError('Assassin-snapshot måste ge varje deltagare exakt ett unikt mål.', 'ASSASSIN_TARGET_CYCLE_INVALID');
  }

  // En permutation med unika mål kan fortfarande bestå av flera separata
  // cykler (A→B→A och C→D→C). Assassin-kontraktet kräver EN sluten cykel som
  // omfattar samtliga deltagare, så verifiera reachability uttryckligen.
  const targetByPlayer = new Map(decorated.map(p => [Number(p.player_id), Number(p.secret_target_player_id)]));
  const startId = Number(decorated[0]?.player_id || 0);
  const visited = new Set();
  let cursor = startId;
  for (let i = 0; i < decorated.length; i += 1) {
    if (!cursor || visited.has(cursor)) {
      throw hiddenError('Assassin-snapshot måste bilda en enda sluten målcykel.', 'ASSASSIN_TARGET_CYCLE_INVALID');
    }
    visited.add(cursor);
    cursor = targetByPlayer.get(cursor);
  }
  if (cursor !== startId || visited.size !== decorated.length) {
    throw hiddenError('Assassin-snapshot måste bilda en enda sluten målcykel.', 'ASSASSIN_TARGET_CYCLE_INVALID');
  }
  return decorated;
}

function snapshotFromAssignments(playMode, assignments) {
  return {
    version:HIDDEN_ROLE_CONTRACT_VERSION,
    play_mode:playMode,
    algorithm_version:ASSIGNMENT_ALGORITHM_VERSION,
    assignments:assignments.map(p => ({
      player_id:p.player_id,
      player_uid:p.player_uid || null,
      role_key:p.role_key || null,
      role_visibility:p.role_visibility || null,
      victory_condition_key:p.victory_condition_key || null,
      objective_score:Number(p.objective_score || 0),
      secret_target_player_id:p.secret_target_player_id || null,
      secret_target_player_uid:p.secret_target_player_uid || null,
      secret_target_name_snapshot:p.secret_target_name_snapshot || null
    }))
  };
}

function assignServerHiddenState(participants, setup) {
  if (setup.play_mode === 'kingdoms') {
    const roles = cryptoShuffle(rolePoolForKingdoms(participants.length));
    const decorated = participants.map((player, index) => {
      const role = roles[index];
      return {
        ...player,
        role_key:role,
        role_visibility:roleVisibilityForKingdoms(role),
        victory_condition_key:victoryKeyForRole(role),
        objective_score:0,
        initial_life:Number(setup.role_life?.[role] ?? setup.starting_life),
        secret_target_player_id:null,
        secret_target_player_uid:null,
        secret_target_name_snapshot:null,
        secret_state_json:JSON.stringify({ contract_version:HIDDEN_ROLE_CONTRACT_VERSION })
      };
    });
    return { participants:decorated, snapshot:snapshotFromAssignments(setup.play_mode, decorated) };
  }

  if (setup.play_mode === 'assassin') {
    const cycle = cryptoShuffle(participants);
    const targetByPlayerId = new Map();
    cycle.forEach((player, index) => {
      const target = cycle[(index + 1) % cycle.length];
      targetByPlayerId.set(Number(player.player_id), target);
    });
    const decorated = participants.map(player => {
      const target = targetByPlayerId.get(Number(player.player_id));
      return {
        ...player,
        role_key:'assassin',
        role_visibility:'public',
        victory_condition_key:'last_survivor',
        objective_score:0,
        secret_target_player_id:Number(target.player_id),
        secret_target_player_uid:target.player_uid || null,
        secret_target_name_snapshot:target.player_name || null,
        secret_state_json:JSON.stringify({ contract_version:HIDDEN_ROLE_CONTRACT_VERSION })
      };
    });
    return { participants:decorated, snapshot:snapshotFromAssignments(setup.play_mode, decorated) };
  }

  return { participants, snapshot:null };
}

function applyOfflineHiddenSnapshot(participants, setup, rawSnapshot) {
  const snapshot = normalizeSnapshot(rawSnapshot);
  if (setup.play_mode === 'kingdoms') {
    const decorated = validateKingdomsSnapshot(participants, setup, snapshot);
    return { participants:decorated, snapshot:snapshotFromAssignments(setup.play_mode, decorated) };
  }
  if (setup.play_mode === 'assassin') {
    const decorated = validateAssassinSnapshot(participants, setup, snapshot);
    return { participants:decorated, snapshot:snapshotFromAssignments(setup.play_mode, decorated) };
  }
  return { participants, snapshot:null };
}

function generateRevealToken() {
  return crypto.randomBytes(REVEAL_TOKEN_BYTES).toString('base64url');
}

function hashRevealToken(token) {
  return crypto.createHash('sha256').update(String(token || ''), 'utf8').digest('hex');
}

function safeTokenEqual(token, storedHash) {
  const actual = Buffer.from(hashRevealToken(token), 'hex');
  const expectedText = String(storedHash || '');
  if (!/^[a-f0-9]{64}$/i.test(expectedText)) return false;
  const expected = Buffer.from(expectedText, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function isPublicRole(player) {
  return String(player?.role_visibility || '').toLowerCase() === 'public';
}

function sanitizePublicPlayer(player, revealAll = false) {
  if (!player || typeof player !== 'object') return player;
  const out = { ...player };
  delete out.reveal_token_hash;
  delete out.secret_state_json;
  if (!revealAll) {
    if (!isPublicRole(out)) {
      out.role_key = null;
      out.victory_condition_key = null;
    }
    out.secret_target_player_id = null;
    out.secret_target_player_uid = null;
    out.secret_target_name_snapshot = null;
  }
  return out;
}

function sanitizePublicMatch(match) {
  if (!match || typeof match !== 'object') return match;
  const hidden = !!match.rules?.hidden_information;
  if (!hidden) return match;
  const revealAll = match.status !== 'active' && match.rules?.history_reveal_policy === 'reveal_after_match';
  const players = (match.players || []).map(p => sanitizePublicPlayer(p, revealAll));
  const byId = new Map(players.map(p => [Number(p.player_id), p]));
  const teams = (match.teams || []).map(team => ({
    ...team,
    players:(team.players || []).map(p => sanitizePublicPlayer(byId.get(Number(p.player_id)) || p, revealAll))
  }));
  const activeTurnPlayers = (match.active_turn_players || []).map(p => {
    const canonical = byId.get(Number(p.player_id));
    return canonical ? {
      ...p,
      role_key: canonical.role_key || null,
      role_visibility: canonical.role_visibility || null
    } : sanitizePublicPlayer(p, revealAll);
  });
  const publicMatch = {
    ...match,
    hidden_information:true,
    private_state_separated:true,
    players,
    teams,
    active_turn_players:activeTurnPlayers
  };

  // variant_state_json is an internal server snapshot. Hidden-role variants may
  // contain private workflow state (and future contract versions may store
  // additional secret metadata there), so it must never travel in the public
  // MatchDto. Private endpoints use fetchMatch(..., { includeSecrets:true }).
  delete publicMatch.variant_state_json;
  return publicMatch;
}

function privateSecretPayload(match, player, target = null, actions = {}) {
  return {
    hidden_information:true,
    contract_version:HIDDEN_ROLE_CONTRACT_VERSION,
    match_id:Number(match.id),
    play_mode:match.play_mode,
    player_id:Number(player.player_id),
    player_uid:player.player_uid || null,
    player_name:player.player_name || null,
    role_key:player.role_key || null,
    role_visibility:player.role_visibility || null,
    victory_condition_key:player.victory_condition_key || null,
    objective_score:Number(player.objective_score || 0),
    target:target ? {
      player_id:Number(target.player_id),
      player_uid:target.player_uid || player.secret_target_player_uid || null,
      player_name:target.player_name || player.secret_target_name_snapshot || null,
      is_eliminated:!!target.is_eliminated
    } : null,
    actions:{
      claim_throne:!!actions.claim_throne,
      decline_throne_claim:!!actions.decline_throne_claim,
      claim_target:!!actions.claim_target
    }
  };
}

module.exports = {
  HIDDEN_ROLE_CONTRACT_VERSION,
  ASSIGNMENT_ALGORITHM_VERSION,
  isHiddenRoleMode,
  rolePoolForKingdoms,
  assignServerHiddenState,
  applyOfflineHiddenSnapshot,
  generateRevealToken,
  hashRevealToken,
  safeTokenEqual,
  sanitizePublicMatch,
  privateSecretPayload,
  hiddenError
};
