# BergaHallen KTM Server 1.0.0-dev.5 — Standalone Quick Install 2

**Suggested release title:** `BergaHallen KTM Server 1.0.0-dev.5 – Standalone Quick Install 2`  
**Suggested tag:** `server-public-1.0.0-dev.5-standalone.2`  
**GitHub release setting:** **Pre-release**

This release is for new users who want a self-contained BergaHallen KTM Server/Webapp installation without the separate Installer/Manager component.

## Install

```bash
unzip BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install-2.zip
cd BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install-2
sudo ./install.sh
```

After installation, open `https://<server-LAN-IP>/` and use `sudo bergahallen-ktm pairing` for Android pairing.

## Included standalone functionality

- Ubuntu 24.04 LTS amd64 bootstrap
- Docker + Compose provisioning when missing
- per-installation local CA
- IP-SAN HTTPS certificate
- TLS State schema v2
- Pairing & Trust Contract v2 terminal QR
- generated admin/session credentials
- health verification
- status/log/pairing/rebind/uninstall helper command

## Provenance

The application runtime is derived from the frozen BergaHallen KTM Server/Webapp `1.0.0-dev.5 / r2` baseline. `github-standalone.2` is a distribution wrapper only; it does not replace or mutate the canonical frozen project artifact.


## Standalone Quick Install 2 fix

- fixes `uninstall` → `install.sh`: preserved standalone data is now recognised as a valid reinstall state;
- reinstall reuses the existing database, local CA, secrets and `instance_uid`;
- if the LAN IP changed while uninstalled, a new leaf certificate is issued under the same CA;
- `uninstall --purge-data` still provides a fully clean removal.
