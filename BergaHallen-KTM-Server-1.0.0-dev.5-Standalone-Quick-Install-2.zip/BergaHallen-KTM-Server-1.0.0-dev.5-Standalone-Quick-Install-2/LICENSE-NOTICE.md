# License notice

This public source snapshot does not include an open-source license.

Public visibility of a Git repository is not the same as granting an open-source license. Until the repository owner explicitly adds a license, the code should be treated as copyrighted source made available for viewing.

If an open-source release is intended later, choose and add an explicit license as a separate project decision.
