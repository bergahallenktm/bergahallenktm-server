# Publish this package as a GitHub Release

Suggested repository: your public BergaHallen KTM Server repository.

## Release values

- **Tag:** `server-public-1.0.0-dev.5-standalone.2`
- **Title:** `BergaHallen KTM Server 1.0.0-dev.5 – Standalone Quick Install 2`
- **Mark as pre-release:** Yes
- **Release notes:** use `GITHUB-RELEASE-NOTES.md`

## Assets to upload

Upload the prepared assets delivered next to this package:

- `BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install-2.zip`
- `BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install-2.tar.gz`
- `BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install-2-SHA256SUMS.txt`

The ZIP is the simplest download for most users. The tar.gz preserves normal Unix executable permissions naturally and is convenient for Linux users.
