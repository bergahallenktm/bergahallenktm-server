const { buildStandaloneRecoveryDiagnostics } = require('../server/recovery');

try {
  const result = buildStandaloneRecoveryDiagnostics();
  console.log(JSON.stringify(result, null, 2));
  process.exitCode = result.ok ? 0 : 2;
} catch (err) {
  console.error(JSON.stringify({
    ok: false,
    code: err.code || 'RECOVERY_DIAGNOSTICS_FAILED',
    error: err.message || String(err)
  }, null, 2));
  process.exitCode = 1;
}
