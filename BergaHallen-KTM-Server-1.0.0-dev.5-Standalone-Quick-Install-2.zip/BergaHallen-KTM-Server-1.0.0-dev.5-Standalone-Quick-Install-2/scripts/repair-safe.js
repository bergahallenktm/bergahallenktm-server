const path = require('path');
const { inspectUpgradePlan } = require('../server/upgradeSafety');

(async () => {
  let db = null;
  try {
    const plan = inspectUpgradePlan();
    if (plan.pending_upgrade || plan.migration_required || plan.source_newer_than_server) {
      const err = new Error('Safe repair vägras medan en schema-uppgradering/recovery är pending. Slutför Installer/Server-upgrade först.');
      err.code = 'SAFE_REPAIR_BLOCKED_BY_UPGRADE_STATE';
      throw err;
    }

    db = require('../server/db');
    const { createBackup, getBackupSettings } = require('../server/backup');
    const { runSafeMaintenance, BACKUP_RESTORE_REPAIR_VERSION } = require('../server/recovery');

    const active = db.prepare("SELECT id FROM matches WHERE status='active' ORDER BY id LIMIT 1").get();
    if (active) {
      const err = new Error(`Aktiv match #${active.id} blockerar safe repair.`);
      err.code = 'ACTIVE_MATCH_BLOCKS_SAFE_REPAIR';
      throw err;
    }
    const settings = getBackupSettings(db);
    const backup = await createBackup(db, { keep: settings.keep, force: true, reason: 'pre-safe-repair' });
    const result = runSafeMaintenance(db);
    console.log(JSON.stringify({
      ok: true,
      backup_restore_repair_version: BACKUP_RESTORE_REPAIR_VERSION,
      pre_repair_backup: backup?.path ? path.basename(backup.path) : null,
      ...result
    }, null, 2));
    db.close();
  } catch (err) {
    console.error(JSON.stringify({
      ok: false,
      code: err.code || 'SAFE_REPAIR_FAILED',
      error: err.message || String(err)
    }, null, 2));
    try { db?.close(); } catch (_) {}
    process.exitCode = 1;
  }
})();
