#!/usr/bin/env node
'use strict';

const db = require('../server/db');
const { reapplyDeletionJournal } = require('../server/accountDeletionService');

function output(payload) {
  if (process.argv.includes('--json')) process.stdout.write(`${JSON.stringify(payload)}\n`);
  else process.stdout.write(`Deletion reapply: ${payload.reapplied || 0} account(s) reapplied; verified=${payload.verified !== false}\n`);
}

try {
  const result = reapplyDeletionJournal({ db });
  output({ status: 'ok', ...result });
  try { db.close(); } catch (_) {}
  process.exit(0);
} catch (err) {
  const payload = {
    status: 'error',
    code: err?.code || 'PRIVACY_REAPPLY_FAILED',
    message: 'Deletion reapply failed; service must remain unavailable until privacy protection is restored.'
  };
  process.stderr.write(`${JSON.stringify(payload)}\n`);
  try { db.close(); } catch (_) {}
  process.exit(2);
}
