const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const languages = ['sv', 'en'];

for (const language of languages) {
  const sourcePath = path.join(root, 'public', 'i18n', `${language}.json`);
  const targetPath = path.join(root, 'public', 'js', 'locales', `${language}.js`);
  const messages = JSON.parse(fs.readFileSync(sourcePath, 'utf8'));
  const output = [
    '// AUTO-GENERATED from public/i18n/' + language + '.json.',
    '// Edit the JSON source and run `npm run i18n:sync`.',
    'export default ' + JSON.stringify(messages, null, 2) + ';',
    ''
  ].join('\n');
  fs.writeFileSync(targetPath, output, 'utf8');
  console.log(`Synced ${language}: ${Object.keys(messages).length} translations`);
}
