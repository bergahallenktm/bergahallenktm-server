const db = require('../server/db');

try {
  const integrity = db.pragma('integrity_check');
  const foreignKeys = db.pragma('foreign_key_check');
  const ok = integrity.length === 1 && integrity[0].integrity_check === 'ok' && foreignKeys.length === 0;

  console.log(JSON.stringify({
    ok,
    schema_version: db.schemaVersion,
    integrity_check: integrity,
    foreign_key_issues: foreignKeys
  }, null, 2));

  db.close();
  if (!ok) process.exit(1);
} catch (err) {
  console.error(err);
  try { db.close(); } catch (_) {}
  process.exit(1);
}
