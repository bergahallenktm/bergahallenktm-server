const { inspectUpgradePlan, getUpgradeStatus } = require('../server/upgradeSafety');

try {
  const plan = inspectUpgradePlan();
  const status = getUpgradeStatus();
  const result = {
    ok: !plan.source_newer_than_server,
    database_exists: plan.database.exists,
    source_schema: plan.database.schema_version,
    target_schema: plan.target_schema,
    migration_required: plan.migration_required,
    pre_upgrade_backup_required: plan.pre_upgrade_backup_required,
    source_newer_than_server: plan.source_newer_than_server,
    support_level: plan.support_level,
    public_compatibility_root: plan.public_compatibility_root,
    instance_uid: plan.database.instance_uid,
    quick_check: plan.database.quick_check,
    pending_upgrade: status.pending,
    last_upgrade: status.last
  };
  console.log(JSON.stringify(result, null, 2));
  if (!result.ok) process.exit(1);
} catch (err) {
  console.error(JSON.stringify({
    ok: false,
    code: err?.code || 'UPGRADE_PREFLIGHT_FAILED',
    error: err?.message || String(err)
  }, null, 2));
  process.exit(1);
}
