const db = require('../server/db');
const { createBackup, getBackupSettings } = require('../server/backup');

(async () => {
  try {
    const settings = getBackupSettings(db);
    const result = await createBackup(db, {
      keep: settings.keep,
      force: true,
      reason: 'cli'
    });
    console.log(`Backup skapad: ${result.path}`);
    db.close();
  } catch (err) {
    console.error('Backup misslyckades:', err);
    try { db.close(); } catch (_) {}
    process.exit(1);
  }
})();
