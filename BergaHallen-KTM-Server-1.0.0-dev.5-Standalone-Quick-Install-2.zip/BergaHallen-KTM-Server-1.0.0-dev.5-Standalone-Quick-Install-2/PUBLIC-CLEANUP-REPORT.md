# Public cleanup report

## Purpose

Prepare a GitHub-public source snapshot without modifying or replacing the canonical frozen BergaHallen KTM Server/Webapp artifact.

## Source baseline

- Suite: `1.0.0-dev.5`
- Server: frozen `r2`
- Canonical frozen Full ZIP SHA256: `226eddadffe593af4bdba9f7e604691b3c0d33129e71380c575970acfd786633`
- Original extracted source files: 479

## Public snapshot policy

Kept:

- all current application runtime code;
- browser webapp/assets/localization;
- operational scripts;
- Dockerfile and production/development Compose definitions;
- environment example;
- package definition and frozen dependency lock;
- machine-readable Server release metadata;
- a small set of current integration contracts;
- new concise public documentation.

Excluded:

- historical development-step notes;
- verification/update instructions from old internal steps;
- Project Control and cross-chat handoffs;
- generated build logs and field-test output;
- changed-file/update-package manifests from historical builds;
- internal regression test corpus;
- static TLS test fixture certificates/private key.

## Hygiene-only derivative edits

- `.gitignore` replaced with a public-repository-safe version; notably `docker-compose.yml` is no longer ignored.
- `.dockerignore` added.
- internal test-only npm scripts removed because the internal test corpus is intentionally excluded.
- one user-specific example name in a source comment was replaced by `Spelare A`; executable behavior is unchanged.
- public README/security/deployment/privacy/provenance documentation added.

## Runtime identity check

73 current runtime/support files were compared against the frozen source baseline. All were byte-identical except `server/routes/stats.js`, whose only difference is the comment-only name anonymization described above.

## Validation performed on public snapshot

- no PEM/private-key marker found;
- no user home path or known personal server IP found;
- all JavaScript application files passed `node --check`;
- `package.json`, `package-lock.json`, release JSON and public snapshot manifest parse successfully;
- package name/version/dependency set matches the lockfile root;
- both Compose YAML files parse successfully;
- no database/runtime data is included.

## Governance

This package is a publication derivative only. It must not be used to redefine the canonical project baseline or the frozen dev.5 Server checksum/status.
