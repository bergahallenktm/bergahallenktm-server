#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="BergaHallen KTM Server"
APP_DIR="${BERGAHALLEN_APP_DIR:-/opt/bergahallen-ktm-server}"
ETC_DIR="${BERGAHALLEN_ETC_DIR:-/etc/bergahallen-ktm}"
TLS_DIR="$ETC_DIR/tls"
EXPORT_DIR="$ETC_DIR/export"
ENV_FILE="$ETC_DIR/server.env"
PAIRING_FILE="$ETC_DIR/pairing.json"
INSTALL_STATE="$ETC_DIR/standalone-install.json"
IMAGE_NAME="bergahallen-ktm-server:1.0.0-dev.5-standalone.2"
COMPOSE_BASE="$APP_DIR/docker-compose.yml"
COMPOSE_OVERRIDE="$APP_DIR/docker-compose.standalone.yml"

log() { printf '%s\n' "$*"; }
info() { printf '==> %s\n' "$*"; }
warn() { printf 'WARNING: %s\n' "$*" >&2; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

require_root() {
  [[ ${EUID:-$(id -u)} -eq 0 ]] || die "Run this command with sudo/root."
}

validate_ipv4() {
  local ip="$1" IFS=. octets=()
  [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || return 1
  read -r -a octets <<< "$ip"
  [[ ${#octets[@]} -eq 4 ]] || return 1
  local o
  for o in "${octets[@]}"; do
    [[ "$o" =~ ^[0-9]+$ ]] || return 1
    (( o >= 0 && o <= 255 )) || return 1
  done
  [[ "$ip" != 127.* && "$ip" != 0.* ]] || return 1
}

detect_default_ip() {
  local line ip
  line="$(ip -4 route get 1.1.1.1 2>/dev/null | head -n1 || true)"
  ip="$(awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}' <<< "$line")"
  if [[ -n "$ip" ]] && validate_ipv4 "$ip"; then
    printf '%s\n' "$ip"
    return 0
  fi
  ip="$(ip -o -4 addr show scope global 2>/dev/null | awk '!/ docker| br-| veth/ {split($4,a,"/"); print a[1]; exit}')"
  [[ -n "$ip" ]] && validate_ipv4 "$ip" || return 1
  printf '%s\n' "$ip"
}

detect_interface_for_ip() {
  local ip="$1"
  ip -o -4 addr show scope global 2>/dev/null | awk -v ip="$ip" '{split($4,a,"/"); if(a[1]==ip){print $2; exit}}'
}

compose() {
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_BASE" -f "$COMPOSE_OVERRIDE" "$@"
}

cert_der_sha256() {
  openssl x509 -in "$1" -outform DER | openssl dgst -sha256 -hex | awk '{print $2}'
}

ca_spki_sha256() {
  openssl x509 -in "$1" -pubkey -noout \
    | openssl pkey -pubin -outform DER 2>/dev/null \
    | openssl dgst -sha256 -hex | awk '{print $2}'
}

write_tls_state() {
  local instance_uid="$1" ip="$2" iface="$3"
  local ca_spki ca_sha leaf_sha tmp
  ca_spki="$(ca_spki_sha256 "$TLS_DIR/ca.crt")"
  ca_sha="$(cert_der_sha256 "$TLS_DIR/ca.crt")"
  leaf_sha="$(cert_der_sha256 "$TLS_DIR/server.crt")"
  tmp="$TLS_DIR/tls-state.json.tmp"
  jq -n \
    --arg instance_uid "$instance_uid" \
    --arg ip "$ip" \
    --arg iface "$iface" \
    --arg ca_spki "$ca_spki" \
    --arg ca_sha "$ca_sha" \
    --arg leaf_sha "$leaf_sha" \
    '{
      schema_version:2,
      instance_uid:$instance_uid,
      endpoint_mode:"simple_ip",
      canonical_https_url:("https://"+$ip),
      selected_ip:$ip,
      selected_interface:$iface,
      optional_mdns_name:null,
      optional_dns_name:null,
      tls_ca_spki_sha256:$ca_spki,
      ca_cert_sha256:$ca_sha,
      leaf_cert_sha256:$leaf_sha
    }' > "$tmp"
  chmod 0644 "$tmp"
  mv -f "$tmp" "$TLS_DIR/tls-state.json"
}

issue_leaf_for_ip() {
  local instance_uid="$1" ip="$2" iface="$3"
  local ext="$TLS_DIR/server.ext"
  [[ -s "$TLS_DIR/ca.key" && -s "$TLS_DIR/ca.crt" ]] || die "Local CA is missing."
  openssl ecparam -name prime256v1 -genkey -noout -out "$TLS_DIR/server.key"
  chmod 0600 "$TLS_DIR/server.key"
  openssl req -new -sha256 \
    -key "$TLS_DIR/server.key" \
    -subj "/CN=BergaHallen KTM Server" \
    -out "$TLS_DIR/server.csr"
  cat > "$ext" <<EOF_EXT
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyAgreement
extendedKeyUsage=serverAuth
subjectAltName=IP:$ip
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
EOF_EXT
  openssl x509 -req -sha256 \
    -in "$TLS_DIR/server.csr" \
    -CA "$TLS_DIR/ca.crt" \
    -CAkey "$TLS_DIR/ca.key" \
    -CAcreateserial \
    -days 825 \
    -extfile "$ext" \
    -out "$TLS_DIR/server.crt" >/dev/null 2>&1
  chmod 0644 "$TLS_DIR/server.crt"
  rm -f "$TLS_DIR/server.csr" "$TLS_DIR/server.ext" "$TLS_DIR/ca.srl"
  write_tls_state "$instance_uid" "$ip" "$iface"
}

write_pairing() {
  local state="$TLS_DIR/tls-state.json"
  [[ -s "$state" ]] || die "TLS state is missing."
  local instance_uid ip url ca_fp
  instance_uid="$(jq -r '.instance_uid' "$state")"
  ip="$(jq -r '.selected_ip' "$state")"
  url="$(jq -r '.canonical_https_url' "$state")"
  ca_fp="$(jq -r '.tls_ca_spki_sha256' "$state")"
  jq -c -n \
    --arg instance_uid "$instance_uid" \
    --arg url "$url" \
    --arg ca_fp "$ca_fp" \
    '{
      contract:"bergahallen-ktm-pairing",
      version:2,
      instance_uid:$instance_uid,
      preferred_url:$url,
      endpoint_mode:"simple_ip",
      endpoints:[{type:"ip",url:$url,priority:1}],
      tls_ca_spki_sha256:$ca_fp,
      server_api:1,
      tls_contract:2
    }' > "$PAIRING_FILE"
  chmod 0644 "$PAIRING_FILE"
  install -m 0644 "$TLS_DIR/ca.crt" "$EXPORT_DIR/bergahallen-ktm-ca.crt"
}

show_pairing() {
  [[ -s "$PAIRING_FILE" ]] || write_pairing
  local url fp uid
  url="$(jq -r '.preferred_url' "$PAIRING_FILE")"
  fp="$(jq -r '.tls_ca_spki_sha256' "$PAIRING_FILE")"
  uid="$(jq -r '.instance_uid' "$PAIRING_FILE")"
  printf '\nBergaHallen KTM Android pairing\n'
  printf 'Server:       %s\n' "$url"
  printf 'Instance UID: %s\n' "$uid"
  printf 'CA SPKI:      %s\n\n' "$fp"
  if command -v qrencode >/dev/null 2>&1; then
    qrencode -t ANSIUTF8 < "$PAIRING_FILE" || true
    printf '\n'
  fi
  printf 'Pairing JSON: %s\n' "$PAIRING_FILE"
  printf 'Browser CA:   %s\n' "$EXPORT_DIR/bergahallen-ktm-ca.crt"
}

healthcheck() {
  local url
  url="$(jq -r '.canonical_https_url' "$TLS_DIR/tls-state.json")"
  curl --fail --silent --show-error --cacert "$TLS_DIR/ca.crt" "$url/api/v1/health"
}
