#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${BERGAHALLEN_APP_DIR:-/opt/bergahallen-ktm-server}"
# shellcheck source=lib.sh
source "$APP_DIR/standalone/lib.sh"
require_root

PURGE=0
if [[ "${1:-}" == "--purge-data" ]]; then PURGE=1; fi

printf 'Stopping BergaHallen KTM Server...\n'
compose down || true
rm -f /usr/local/bin/bergahallen-ktm

if (( PURGE )); then
  printf 'PURGE requested: removing Docker volumes and local TLS identity.\n'
  docker volume rm bergahallen-ktm-data bergahallen-ktm-privacy-journal bergahallen-ktm-privacy-key 2>/dev/null || true
  rm -rf "$ETC_DIR"
else
  printf 'Persistent database/privacy volumes and /etc/bergahallen-ktm are preserved.\n'
  printf 'Reinstall is supported: unpack Standalone Quick Install 2 (or newer) and run sudo ./install.sh\n'
fi
rm -rf "$APP_DIR"
printf 'Standalone application files removed.\n'
