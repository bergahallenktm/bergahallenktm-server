# BergaHallen KTM Server — fristående snabbinstallation

Detta är ett **fristående publikt distributionspaket** för nya användare som vill köra BergaHallen KTM Server/Webbapp utan den separata Installer/Manager-komponenten.

Runtime bygger på den frysta Server/Webbapp-baslinjen `1.0.0-dev.5 / r2`. Distributionslagret heter `github-standalone.2` och ändrar inte projektets canonical/frysta artefakt.

## Snabbinstallation

Stödd målmiljö:

- Ubuntu Server **24.04 LTS**
- **amd64 / x86_64**
- fysisk server eller full VM
- vanlig LAN-IPv4-adress
- Internetåtkomst under installationen för Ubuntu/Docker-paket och Node-basimagen

Packa upp releasen och kör:

```bash
cd BergaHallen-KTM-Server-1.0.0-dev.5-Standalone-Quick-Install
sudo ./install.sh
```

Installationen ordnar Docker vid behov, skapar lokal CA och IP-SAN-certifikat, initierar databasen, genererar säkra admin-/sessionshemligheter, startar HTTPS på port 443 och visar en Pairing v2-QR för Android.

Efter installationen används normalt:

```text
https://<SERVERNS-LAN-IP>/
```

`.local`, mDNS och egen DNS krävs inte.

## Vanliga kommandon

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm pairing
sudo bergahallen-ktm logs
sudo bergahallen-ktm restart
sudo bergahallen-ktm ca-path
sudo bergahallen-ktm rebind-ip
```

Om DHCP ändrar serverns IP kör du `sudo bergahallen-ktm rebind-ip`. Leaf-certifikatet skapas då om under **samma CA**, så Androids CA-pin kan behållas.

För fullständig dokumentation, säkerhetsmodell och avinstallation: se [README.md](README.md).


## Avinstallera och installera igen

`sudo bergahallen-ktm uninstall` tar bort programfilerna men bevarar avsiktligt databas, privacy-state, lokal CA och serveridentitet. Från **Standalone Quick Install 2** kan du packa upp releasen igen och köra `sudo ./install.sh`; den bevarade standalone-installationen upptäcks automatiskt och återställs med samma databas, CA och `instance_uid`.

För en destruktiv helt ren borttagning använder du `sudo bergahallen-ktm uninstall --purge-data`. Då tas Docker-volymer och lokal TLS-identitet bort och nästa installation blir helt ny.
