# API overview

The current Server API contract is **v1**.

## Common metadata endpoints

```text
GET /api/v1/health
GET /api/v1/meta
GET /api/v1/compatibility
```

The API also contains route groups for:

- authentication/account state;
- account deletion;
- decks;
- matches and live match mutations;
- history/statistics;
- administration;
- server discovery/provisioning metadata.

The exact route implementation is under `server/routes/`.

## Error handling

API errors use a stable machine-readable envelope while preserving backward-compatible error text where required. Requests receive a correlation/request ID so client-visible failures can be matched to local server logs.

## Compatibility

The current compatibility policy is additive API v1. Technical contract versions are exposed through `/api/v1/meta` and `/api/v1/compatibility`.
