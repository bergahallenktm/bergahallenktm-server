# TLS and pairing

## Trust model

Production Server Mode uses an Installer/Manager-owned local Certificate Authority. The Server validates and serves the Installer-issued leaf certificate; it never needs the CA private key.

The default endpoint model is **Simple LAN / IP**. DNS and mDNS may be convenient additions but are not required for the canonical beginner path.

## TLS state

TLS State schema v2 binds the server instance identity to the selected endpoint and CA fingerprint. In Simple-IP mode, the canonical HTTPS URL must match the selected LAN IP and the leaf certificate must contain that exact address as an X.509 IP SAN.

`/api/v1/meta` exposes non-secret transport identity metadata including:

- TLS contract version;
- TLS state schema;
- canonical HTTPS URL/port;
- endpoint mode;
- installation CA SPKI SHA256 fingerprint;
- stable server instance UID.

## Android pairing

The current pairing architecture binds trust to:

1. server instance UID;
2. installation CA SPKI fingerprint;
3. HTTPS endpoint identity.

A QR or manual pairing flow must validate the expected server identity before credentials are sent. Discovery alone is a convenience signal, not a trust decision.

## Address changes

A LAN IP change can be handled by issuing a new leaf certificate for the new IP under the same installation CA. The stable CA identity and server instance UID allow an already paired client to distinguish an address change from a different server identity.
