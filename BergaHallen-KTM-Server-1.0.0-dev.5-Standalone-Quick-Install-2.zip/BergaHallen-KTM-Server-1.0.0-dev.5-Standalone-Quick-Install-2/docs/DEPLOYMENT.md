# Deployment

## Recommended production path

Use the BergaHallen KTM Installer/Manager. It provisions the host integration, local installation identity and TLS material that this Server expects.

The Server itself does not create the production Certificate Authority.

## Production topology

```text
LAN client
   |
 HTTPS :443
   |
Docker host 443 -> container 8443
   |
Node HTTPS server
```

The production Compose file publishes only HTTPS. Diagnostic HTTP remains loopback-only inside the container.

## Required TLS files

The production container expects read-only mounts for:

```text
/etc/bergahallen-ktm/tls/ca.crt
/etc/bergahallen-ktm/tls/server.crt
/etc/bergahallen-ktm/tls/server.key
/etc/bergahallen-ktm/tls/tls-state.json
```

The server private key must be permission-restricted as required by the TLS runtime contract.

## Environment

Copy `.env.example` to `.env` for local deployment configuration. Do not commit `.env`.

Important variables include:

- `SESSION_SECRET` – optional Installer-provided strong secret; otherwise Server can persist a locally generated secret.
- `ADMIN_USERNAME` / `ADMIN_PASSWORD` – administrative bootstrap.
- backup schedule/retention settings.
- timezone.

## Start production container

After Installer-style TLS state/certificates exist:

```bash
docker compose up -d --build
```

Then use the canonical HTTPS URL selected by the installation, typically:

```text
https://<LAN-IP>/
```

## Development-only HTTP

For local development only:

```bash
docker compose -f docker-compose.dev-http.yml up -d --build
```

This explicitly disables production TLS and exposes port 3010. Do not treat this as the normal production topology.
