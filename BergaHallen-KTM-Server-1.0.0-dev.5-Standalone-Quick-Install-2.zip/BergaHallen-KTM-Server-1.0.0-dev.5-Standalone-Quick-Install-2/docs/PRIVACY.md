# Privacy and account deletion

BergaHallen KTM is self-hosted. In Server Mode, account/gameplay data is stored on the user's configured local Server rather than in a developer-operated BergaHallen cloud service.

## Stored server data

Depending on use, the Server may store:

- account/player identity and password hashes;
- decks and decklists;
- matches, life/poison/commander state and match events;
- history/statistics;
- session state;
- operational logs;
- backups.

Plaintext account passwords are not persisted as normal server account data.

## Ordinary-account deletion

The Server supports authenticated self-service deletion for ordinary Server Mode accounts. The flow requires re-authentication and removes or de-identifies account-linked identity/data while preserving de-identified shared historical match facts when needed for other participants and referential integrity.

Active match participation is resolved using the established concede/elimination behavior before identity removal.

## Restore anti-resurrection

Backups may predate an account deletion. A privacy-preserving deletion-tombstone journal is therefore stored outside the normal database restore payload. Managed restore must reapply those tombstones before normal service becomes available.

The journal is intentionally designed to avoid storing the deleted user's normal identifying values.

## Local deletion resource

The web server exposes a local information/resource page at:

```text
/account-deletion
```
