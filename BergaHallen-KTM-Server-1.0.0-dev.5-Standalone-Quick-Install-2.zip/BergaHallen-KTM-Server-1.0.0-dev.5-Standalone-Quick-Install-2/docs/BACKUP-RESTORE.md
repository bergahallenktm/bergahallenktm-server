# Backup, restore and recovery

The current recovery foundation is Backup / Restore / Repair v2 on DB schema 21.

## Backup

Server-created backups use SQLite-consistent backup behavior and are verified before being treated as valid. Verification includes database integrity/foreign-key checks and a SHA256 identity.

## Restore

Restore is staged and validated before replacing the active database. The Server keeps rollback material until the newly activated database has passed post-swap verification.

A backup from another `instance_uid` is treated as cross-instance data and requires explicit handling because the instance UID is part of the Server realm identity used by clients.

## Safe repair

Safe repair is deliberately conservative and does not attempt heuristic reconstruction of damaged domain data. It performs bounded SQLite maintenance only after a verified safety backup and healthy pre-checks.

Useful commands:

```bash
npm run backup
npm run db:integrity
npm run recovery:diagnose
npm run repair:safe
npm run upgrade:preflight
```
