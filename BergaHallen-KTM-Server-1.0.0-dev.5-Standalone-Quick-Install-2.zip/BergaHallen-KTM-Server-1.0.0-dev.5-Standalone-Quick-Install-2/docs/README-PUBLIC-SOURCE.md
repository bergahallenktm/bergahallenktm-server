# BergaHallen KTM Server & Webapp

Self-hosted local-network server and web interface for **BergaHallen KTM**, a Magic: The Gathering companion/tracker used for players, decks, matches, life totals, multiplayer formats, history and statistics.

This repository snapshot is intended for public source review and development. It is derived from the frozen BergaHallen KTM Suite server baseline **1.0.0-dev.5 / r2**.

> **Important:** this GitHub snapshot is a derivative public-source package. It is **not** the canonical frozen release artifact and does not change the status, checksum or provenance of the frozen project package.

## Current technical baseline

- Node.js 20
- Express 4
- SQLite via `better-sqlite3`
- Server API: v1
- Database schema: 21
- Direct HTTPS termination in the Node server
- TLS Deployment Contract: v2
- TLS State schema: v2
- Default server endpoint mode: Simple LAN / IP
- Production host port: 443 → container port 8443
- Loopback-only diagnostic HTTP: `127.0.0.1:3010`
- Swedish and English web UI
- SQLite-backed sessions
- Account deletion with external deletion-tombstone journal
- Backup / restore / recovery tooling

## Recommended installation path

The normal production installation is performed by the separate **BergaHallen KTM Installer/Manager**. The Installer owns the installation TLS identity and provides the certificate material consumed by this Server.

The Server does **not** generate its own production CA.

Expected production TLS files:

```text
/etc/bergahallen-ktm/tls/ca.crt
/etc/bergahallen-ktm/tls/server.crt
/etc/bergahallen-ktm/tls/server.key
/etc/bergahallen-ktm/tls/tls-state.json
```

After TLS and environment configuration are provisioned, the production container is defined by `docker-compose.yml`.

```bash
cp .env.example .env
# Configure environment values as needed.
docker compose up -d --build
```

Production TLS is fail-closed: missing or invalid certificate material does not silently fall back to LAN HTTP.

For explicit local development without production TLS, see `docker-compose.dev-http.yml`. That configuration is development-only.

## Repository layout

```text
server.js                  Application bootstrap and listeners
server/                    API, database, auth, match logic, TLS, backup/recovery
server/routes/             Express API route modules
public/                    Browser webapp, styles, localization and assets
scripts/                   Operational database/privacy/recovery scripts
Dockerfile                 Production container image
docker-compose.yml         Production HTTPS topology
docker-compose.dev-http.yml Development-only cleartext topology
BERGAHALLEN-SERVER-RELEASE.json Machine-readable server/release contract
package.json / package-lock.json Node package definition and frozen dependencies
docs/                      Public-facing technical documentation
```

## Useful commands

```bash
npm start
npm run backup
npm run db:integrity
npm run recovery:diagnose
npm run repair:safe
npm run privacy:reapply
npm run upgrade:preflight
```

## Network and security model

The intended deployment is a trusted local network. Production Server Mode uses HTTPS and the installation CA identity. Android pairing/trust is based on the installation CA fingerprint and server instance identity, not on DNS/mDNS alone.

This project should not be exposed directly to the public Internet without a separate security/deployment review.

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md), [docs/TLS-AND-PAIRING.md](docs/TLS-AND-PAIRING.md) and [SECURITY.md](SECURITY.md).

## Data and privacy

Server data is stored locally on the self-hosted installation. The server supports self-service ordinary-account deletion and maintains a privacy-preserving deletion journal outside normal database restore payloads so managed restore can reapply deletion.

See [docs/PRIVACY.md](docs/PRIVACY.md).

## Verification

The frozen source baseline from which this public snapshot was derived passed **310/310 runtime tests with 0 failures and 0 skipped tests** in the dev.5 clean-install field verification.

The internal regression corpus, historical test logs, Project Control handoffs and static TLS test fixture key are deliberately excluded from this public-clean package. See [docs/VERIFICATION.md](docs/VERIFICATION.md).

## Provenance

See [PUBLIC-SNAPSHOT.md](PUBLIC-SNAPSHOT.md) and [docs/PROVENANCE.md](docs/PROVENANCE.md).

## License

No open-source license is included in this snapshot. See [LICENSE-NOTICE.md](LICENSE-NOTICE.md).
