# Provenance

This public repository snapshot was derived from the frozen BergaHallen KTM Server/Webapp baseline:

```text
Suite: 1.0.0-dev.5
Server component: r2
Canonical frozen Full ZIP SHA256:
226eddadffe593af4bdba9f7e604691b3c0d33129e71380c575970acfd786633
```

The historical file name included `TEST-CANDIDATE-r2`; Project Control subsequently froze those exact bytes as the dev.5 Server component.

This cleaned GitHub snapshot is not a replacement for that canonical artifact. See the repository-root `PUBLIC-SNAPSHOT.md` for the exact cleanup transformations.
