# Operations

## Health

```text
GET /api/v1/health
```

The production container also exposes a loopback-only diagnostic HTTP health listener on `127.0.0.1:3010` inside the container when enabled. It is not intended to be published to the LAN.

## Logs

The Server uses bounded local operational logging and Docker's configured log rotation. Request correlation IDs help connect client errors with server-side events.

Do not log or publish passwords, session tokens, private keys or database contents.

## Graceful shutdown

The Server handles SIGTERM/SIGINT, stops backup scheduling, closes listeners, checkpoints SQLite WAL and closes session/database stores.

## First administrative account

The Server ensures an administrative account exists. Installer/Manager normally controls bootstrap configuration. If no bootstrap password is provided in the supported environment, the Server can generate a one-time bootstrap credential according to the existing runtime behavior.
