# Architecture

BergaHallen KTM Server & Webapp is a single self-hosted Node.js service with a local SQLite persistence layer and a static browser client.

## Main components

- `server.js` – startup ordering, Express application, sessions, health/meta, network listeners and shutdown.
- `server/db.js` – SQLite database and schema migrations through schema 21.
- `server/routes/` – authentication, account deletion, decks, matches, statistics, administration and discovery.
- `server/tlsRuntime.js` – validation and loading of Installer-owned production TLS identity.
- `server/backup.js`, `server/recovery.js`, `server/restoreBootstrap.js` – backup/restore/recovery boundaries.
- `server/privacyDeletionJournal.js` and `server/accountDeletionService.js` – privacy-preserving deletion journal and account-deletion workflow.
- `public/` – browser webapp and sv/en localization.
- `scripts/` – operational CLI helpers.

## Startup ordering

The Server performs recovery-sensitive work before making normal network service available:

1. apply a pending staged restore if present;
2. prepare upgrade safety state;
3. open/migrate the SQLite database;
4. reapply deletion tombstones after restore;
5. finalize upgrade checks;
6. validate the Installer-owned TLS identity;
7. bootstrap/verify the administrative account;
8. start HTTPS and optional loopback-only diagnostics.

Production TLS validation is fail-closed.

## Persistence

The runtime uses SQLite for application data and a separate SQLite-backed session store. Docker persists application data under `/app/data`.

The deletion journal/key live outside the normal database restore payload so an old database restore cannot silently resurrect a previously deleted account.

## API

Both legacy `/api/...` and versioned `/api/v1/...` paths remain present. `/api/v1` is the stable integration surface for current web/Android development.

Health and capability metadata are exposed at:

```text
/api/v1/health
/api/v1/meta
/api/v1/compatibility
```
