# Verification provenance

The canonical frozen Server source from which this public snapshot was derived was field-verified in the BergaHallen KTM dev.5 clean-install track.

Recorded runtime result:

```text
310 tests
310 pass
0 fail
0 skipped
```

The same field track also verified:

- clean schema-21 initialization;
- production HTTPS startup;
- fail-closed behavior for missing TLS material;
- fail-closed behavior for wrong IP SAN;
- Simple LAN/IP operation without an mDNS/DNS dependency;
- admin/system-status smoke;
- privacy/account-deletion smoke;
- discovery/meta smoke;
- loopback diagnostic HTTP not being LAN-published;
- explicit local CA trust/pinning requirement.

## Why the internal test corpus is not in this public-clean snapshot

The canonical release package accumulated many historical regression files, build logs, handoffs and field evidence across the pre-1.0 development history. It also contained a static private key used only by a TLS test fixture.

Those files are valuable to the internal development archive but are unnecessary in a clean public source repository. They have therefore been deliberately excluded here. The canonical frozen artifact remains the authoritative verification source.
