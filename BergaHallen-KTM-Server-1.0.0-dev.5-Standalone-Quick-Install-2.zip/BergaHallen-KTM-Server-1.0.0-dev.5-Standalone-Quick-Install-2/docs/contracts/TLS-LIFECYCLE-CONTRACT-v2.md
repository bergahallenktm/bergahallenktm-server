# BergaHallen KTM – TLS Lifecycle Contract v2

**Status:** CANONICAL / APPROVED  
**Supersedes:** TLS Lifecycle Contract v1 where conflicting

## Fresh install – Simple LAN default

1. preserve/create instance UID;
2. detect LAN IPv4;
3. preselect sole suitable address or ask simple numbered choice;
4. create local CA;
5. issue leaf with selected IP SAN;
6. write TLS state schema 2;
7. start HTTPS;
8. verify `https://<IP>/api/v1/health`;
9. show:
   - server IP;
   - HTTPS URL;
   - CA fingerprint;
   - terminal pairing QR;
   - next-step instructions.

No DNS/mDNS setup is required.

## Optional mDNS

If Avahi is available/enabled:
- publish convenience name/service;
- optional `.local` SAN may be issued;
- failure does not invalidate IP mode.

## Advanced DNS

User explicitly selects Advanced DNS/FQDN and supplies name.

Installer does not assume a managed DNS environment exists.

## DHCP/IP change

Manager detects selected interface/IP change.

Safe repair:
- preserve CA;
- reissue leaf for new IP;
- update state;
- restart/reload Server;
- verify HTTPS;
- regenerate pairing info.

Existing Android CA trust remains valid.

## Leaf renewal

Same CA, current endpoint SANs, no re-pair.

## CA reset

Explicit action only, re-pair required.

## Restore

Managed restore preserves:
- CA;
- deletion journal/key;
- instance UID;
- endpoint mode.

If restored selected IP is no longer valid:
- preserve CA;
- detect/select current LAN IP;
- reissue leaf;
- do not rotate CA merely because IP changed.

## Diagnostics

Doctor/verify-meta check:
- current endpoint mode;
- selected IP is present/reachable;
- IP SAN match;
- CA fingerprint match;
- HTTPS health;
- no production LAN HTTP exposure.

## Pairing output

Manager CLI must provide a trusted bootstrap independent of browser trust:

- `show-pairing`
- fingerprint text
- pairing payload
- scannable terminal QR where terminal supports it

Equivalent command names are allowed.
