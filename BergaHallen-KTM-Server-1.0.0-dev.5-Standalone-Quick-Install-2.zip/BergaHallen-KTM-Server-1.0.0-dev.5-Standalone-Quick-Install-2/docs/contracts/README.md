# Current integration contracts

This folder contains a deliberately small subset of the current cross-component contracts that are directly relevant to a public Server/Webapp source repository.

Included:

- Account Deletion Contract v1
- Backup/Restore Deletion Contract v1
- API v1 Compatibility Contract
- Server Discovery Contract v1
- Pairing & Trust Contract v2
- TLS Deployment Contract v2
- TLS Lifecycle Contract v2
- Simple LAN Installation UX Contract v1

Historical superseded contract revisions and internal development-gate documents are intentionally not included in this public-clean snapshot.
