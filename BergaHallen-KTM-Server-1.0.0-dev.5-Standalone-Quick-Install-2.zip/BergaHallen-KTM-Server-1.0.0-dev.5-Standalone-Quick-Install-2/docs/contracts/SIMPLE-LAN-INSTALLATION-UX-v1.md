# BergaHallen KTM – Simple LAN Installation UX Contract v1

**Status:** CANONICAL / APPROVED**

## Goal

A user with little Linux/server/network experience should be able to install BergaHallen KTM on a normal LAN without understanding DNS.

## Default flow

Example interaction:

```text
Network setup

BergaHallen KTM found this LAN address:

  192.168.1.50  (ens18)

Use this address for the server?
[Use recommended] [Choose another]
```

If multiple:

```text
Which network should phones/computers use to reach this server?

1. 192.168.1.50  – ens18
2. 10.0.0.25     – enp3s0

Choice [1]:
```

Avoid terms like SAN, CA, mDNS or FQDN in the default beginner flow.

## Advanced options

Separate clearly:

`Advanced network setup`

May expose:
- DNS/FQDN;
- optional mDNS;
- explicit interface;
- explicit IP;
- later custom certificate options if approved.

## Completion screen/document

Must prominently show:

- `Server address: https://192.168.1.50`
- pairing QR
- short fingerprint
- how to connect Android
- where the full fingerprint can be viewed
- how to open Manager
- what to do if the server IP changes

## IP change UX

Plain-language message:

`The server received a new network address. BergaHallen KTM kept the same trusted server identity and renewed its certificate for the new address.`

Then show new URL/QR.

Do not tell a beginner to edit DNS/router configuration as the normal repair.
