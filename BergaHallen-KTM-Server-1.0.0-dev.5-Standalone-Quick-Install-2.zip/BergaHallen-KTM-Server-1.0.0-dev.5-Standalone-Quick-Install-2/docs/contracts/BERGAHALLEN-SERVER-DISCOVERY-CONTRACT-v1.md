# BergaHallen KTM – Discovery / Connection Contract v1
## Server/Webbapp ↔ Android ↔ Installer

**Status:** FROZEN – cross-client field gate approved  
**Frozen server alignment:** 3.9.11.2.1 / runtime 0.9.11.2.1  
**DB schema:** 19

Discovery/Binding v1 är fryst efter gemensam Server + Android + Installer-fältverifiering. Inkompatibla wire/identity-ändringar kräver ett nytt kontraktsnummer.

---

## 1. Identity

```text
server identity = instance_uid
endpoint        = replaceable candidate hint
```

IP, hostname, URL, QR och mDNS-namn är aldrig serveridentitet.

Alla serverlokala numeriska ID:n ska tolkas inom verifierad realm:

```text
(instance_uid, numeric_id)
```

Det gäller exempelvis player/account/deck/match-ID.

---

## 2. Final verify-before-bind

Varje kandidat från QR, mDNS, manuell adress eller remembered endpoint måste slutligt verifieras via:

```http
GET <base_url>/api/v1/meta
```

Verifiera minst:
- kompatibel `api_version` / `min_supported_api_version`;
- icke-tom `instance_uid`;
- advertised/scanned UID matchar exakt när den finns.

`GET /api/v1/discovery` är endast en optional probe/fingerprint och är inte bind/trust authority.

---

## 3. Canonical QR Contract v1

Servergenererad modern QR innehåller compact JSON:

```json
{
  "type": "bergahallen-server",
  "version": 1,
  "instance_uid": "stable-instance-uid",
  "server_name": "Bergahallen KTM",
  "endpoints": [
    { "url": "http://ktm-server.local:3010" },
    { "url": "http://192.168.1.50:3010" }
  ]
}
```

Rules:
- `endpoints[]` är ordnad preference/hints, inte identity;
- inga credentials/secrets;
- server output använder canonical `endpoints[]`;
- klienten får acceptera legacy single `url` som shorthand för ett endpoint-element.

Den tidigare custom URI-formen är inte längre normativ.

---

## 4. Provisioning API

```http
GET /api/v1/discovery/provision
```

Servern bygger endpoint-listan från tillgängliga hints, i preference order:
1. `BERGAHALLEN_PREFERRED_URL` när satt;
2. query `endpoint` (kan förekomma flera gånger);
3. legacy query `url` eller `base_url`;
4. request/browser origin som kandidat.

Svar innehåller bl.a.:

```json
{
  "type": "bergahallen-server",
  "version": 1,
  "instance_uid": "...",
  "endpoints": [{"url":"..."}],
  "url": "first-endpoint-legacy-convenience",
  "verification_path": "/api/v1/meta",
  "endpoint_semantics": "replaceable_hints",
  "numeric_id_scope": "instance_uid"
}
```

`url` i provisioning-svaret är endast backward-compatible convenience och inte canonical QR wire.

---

## 5. Preferred URL config

Ny normativ config-hint:

```text
BERGAHALLEN_PREFERRED_URL
```

Semantik:
- optional;
- advertisement/bootstrap hint;
- får ändras utan identity change;
- används aldrig som authority.

Legacy alias:

```text
BERGAHALLEN_LAN_URL
```

används bara om preferred value saknas.

---

## 6. mDNS / Installer

Normativ nearby service type:

```text
_bergahallen-ktm._tcp.
```

Host-level Avahi/DNS-SD är Installer/management-ansvar och optional convenience.

Servern:
- behåller Docker bridge;
- kräver inte `network_mode: host`;
- kräver inte Avahi för korrekt HTTP/API-funktion;
- gör inga subnet/VLAN/DHCP/single-NIC-antaganden.

---

## 7. Multi-server compatibility

Android får komma ihåg flera oberoende serverrealms. Servern behöver ingen realm registry.

Varje fysisk serverinstans representerar sin egen `instance_uid`.

Samma numeric ID eller sync revision på två serverinstanser betyder inte samma object.

---

## 8. Guest boundary

Guest Match är Android-lokal temporary tracker och använder inga server-API:er.

Servern ska inte implementera:
- Guest player/profile API;
- Guest history/stats;
- LOCAL→SERVER import;
- cross-server transfer.

Login/discovery i sig importerar ingen Guest-data.

---

## 9. Freeze

Cross-client gate result:

```text
Server 3.9.11.2.1 alignment       GREEN / GODKÄND
Android 3.9.11.2 foundation       GREEN / GODKÄND
Installer 0.6.5 discovery         GREEN / GODKÄND
End-to-end field matrix            GREEN
Discovery/Binding Contract v1      FROZEN
3.9.12                              UNBLOCKED
```

Frozen invariants are the identity model, canonical QR wire, `/meta` verification authority, endpoint-hint semantics, optional mDNS and multi-server separation. Compatibility/robustness fixes may continue without changing v1 semantics.
