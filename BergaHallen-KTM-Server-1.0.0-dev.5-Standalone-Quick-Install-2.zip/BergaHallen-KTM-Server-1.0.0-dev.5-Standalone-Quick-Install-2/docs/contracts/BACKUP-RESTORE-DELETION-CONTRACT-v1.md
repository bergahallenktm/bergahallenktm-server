# BergaHallen KTM – Backup/Restore Deletion Contract v1

**Status:** CANONICAL / APPROVED  
**Owners:** Server + Installer/Manager

## Problem

A valid account deletion can be undone accidentally if an older database backup is restored.

That is not acceptable product behavior.

## Canonical solution

Maintain a deletion tombstone journal outside the normal database restore payload.

Recommended persistent path:

`/var/lib/bergahallen-ktm/privacy/deletion-tombstones.jsonl`

Recommended key path:

`/etc/bergahallen-ktm/privacy/deletion-journal.key`

The key file:
- is generated once per server installation;
- mode `0600`;
- owned by the KTM service/root management context as appropriate;
- is not written to logs;
- is preserved across product-managed upgrade/restore.

## Journal content

Do not store username, player display name, password hash, deck names or email-like identifiers in the journal.

Each tombstone should contain the minimum:

```json
{
  "schema_version": 1,
  "account_marker": "HMAC-SHA256(stable-internal-account-id)",
  "deleted_at": "ISO-8601 timestamp",
  "deletion_receipt_id": "opaque-random-id"
}
```

`account_marker` is derived with the server-local deletion-journal key.

If the current account model lacks a stable UID, Server may derive the marker from a stable internal account primary key combined with the server `instance_uid`, using the secret HMAC key.

## Restore rule

For every product-managed restore:

1. preserve the current deletion key and journal;
2. restore the requested database backup;
3. before making the restored service available, scan restored accounts against deletion markers;
4. reapply the canonical Account Deletion Contract to any resurrected matching account;
5. verify no deleted login identity is active;
6. only then complete/start normal service.

## Backup handling

Existing backup archives do not need destructive in-place rewriting during the delete request.

They are disaster-recovery material, not active account storage.

However:
- product-managed restore must reapply deletion;
- the privacy policy must disclose that older backups can temporarily contain pre-deletion state;
- product backup retention policy must be documented;
- manually copied raw backups outside KTM's managed restore flow are the server operator's responsibility.

## Factory reset / server replacement

A true full server factory reset or migration that intentionally discards the deletion journal may remove this protection.

Installer/Manager documentation must make clear that importing historical backups into a new installation without the original deletion journal can reintroduce previously deleted data.

A future cross-server migration feature must explicitly migrate the deletion journal.

## Technical version

Introduce:

`Deletion Tombstone Journal schema = 1`

Do not conflate this with DB schema 21, Backup/Restore/Repair Contract v2, or Installer release-manifest schema 5 unless their actual definitions are changed.

Any required upgrade to those existing technical contracts must be explicit in component handoffs.
