# BergaHallen KTM – Account Deletion Contract v1

**Status:** CANONICAL / APPROVED  
**Owner:** Project Control  
**Applies to:** Server Mode ordinary user accounts created/used through BergaHallen KTM  
**Does not apply to:** Local Mode-only data; server admin/superuser management identities

## 1. Core rule

"Delete account" means the ordinary user's authentication identity and associated identifying/user-generated account data are removed or irreversibly de-identified.

It must not be implemented as:
- disabled account,
- suspended account,
- hidden account,
- login block with the original personal data retained as the active identity.

## 2. Re-authentication

Deletion requires:
- a currently authenticated ordinary Server Mode account;
- the current password to be submitted again;
- an explicit destructive confirmation.

Cached/offline-only authentication is not sufficient.

If the server cannot be reached, Android must not pretend deletion succeeded.

## 3. Atomicity

The server deletion operation must be transactionally safe.

The account must not end in a partially deleted state visible to normal runtime.

The server may perform pre-transaction validation, but identity/auth deletion and database anonymisation should commit atomically where the database permits.

## 4. Active matches

An active match must not prevent account deletion.

Before identity anonymisation:
- each active participation belonging to the deleting user is processed using the existing "concede/eliminate" semantics as closely as possible;
- this consequence must be disclosed in the confirmation UI.

Deletion must not leave an active match seat that requires the deleted login to continue.

## 5. Authentication/account data

Delete:
- password hash / password verifier;
- active sessions;
- refresh/reconnect/session tokens associated with the server account;
- account-to-player authentication binding;
- account username/login identifier where stored separately;
- account-specific recovery/authentication data, if any.

The deleted account must no longer be usable for login.

## 6. Player record

Preferred behavior:
- hard-delete the linked player if no retained match/history/foreign-key requirement exists.

If retained references require the player row:
- convert it to a tombstone;
- remove authentication binding;
- remove original display name and other identifying/profile fields;
- replace display name with a generated non-personal label such as `Deleted player <random-suffix>`;
- mark the row as deleted/tombstoned so it cannot be selected as a new match player, deck owner or account target.

The random suffix must not derive from username, original name, email, password, IP address or another user-facing identifier.

## 7. Decks

For decks owned by the deleted account/player:

If safely unreferenced:
- hard-delete the deck.

If historical foreign keys require the row:
- convert to a tombstone;
- remove decklist/card contents;
- remove custom deck name/notes/description and other user-entered content;
- remove owner/loan relationships;
- retain only the minimum non-identifying fields required for referential integrity;
- label it with a generated non-personal `Deleted deck <random-suffix>` style name if a non-null/unique field is required.

Do not delete or alter other users' independently owned decks merely because they were previously loaned to the deleted user.

## 8. Match history and statistics

Shared historical match facts may be retained when needed to preserve other players' match history/statistics and database integrity.

However:
- original deleted-user display names must be scrubbed from retained snapshots where technically present;
- account/login identifiers must be removed;
- user-visible history must show an anonymised tombstone identity;
- deleted account profile/stats endpoints must no longer resolve the old account identity;
- aggregate statistics may retain anonymous match outcomes.

This is de-identification of shared gameplay facts, not retention of the deleted account.

## 9. Logs

Passwords, session tokens and reconnect secrets must never be written to application logs.

New dev.3 code must avoid persistent logging of deleted account names/identifiers.

Operational/security logs that legitimately predate deletion are not scanned as a primary deletion database; the privacy policy must disclose the operational log policy and the project should use bounded retention.

## 10. Backups and restore

Product-managed backups may contain older database states created before deletion.

The product must therefore maintain a privacy-preserving deletion journal outside the database restore payload and reapply deletion tombstones before a restored server is made available.

See `BACKUP-RESTORE-DELETION-CONTRACT-v1.md`.

## 11. Deletion completion

On success:
- the user is logged out;
- Android clears Server Mode credentials/tokens for that server/account;
- Android must not automatically recreate the account;
- the server returns a deletion receipt/result without returning deleted personal data.

## 12. Local Mode

Local Mode has no Server account and is outside this server account-deletion endpoint.

Android should provide separate wording/control for clearing Local Mode data if/when that feature is exposed.

Do not label Local Mode reset as "Delete server account".

## 13. Admin/superuser

The ordinary self-service endpoint must reject server administration identities that were not created as normal app player accounts.

Admin/superuser lifecycle remains Installer/Manager/server-administration responsibility.

The Android UI should not expose the ordinary player account-deletion action when logged in as a protected management identity.
