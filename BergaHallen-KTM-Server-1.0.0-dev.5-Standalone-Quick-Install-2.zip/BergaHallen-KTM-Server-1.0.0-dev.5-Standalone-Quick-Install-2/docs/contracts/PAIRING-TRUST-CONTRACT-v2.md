# BergaHallen KTM – Pairing & Trust Contract v2

**Status:** CANONICAL / APPROVED  
**Supersedes:** Pairing & Trust Contract v1 where conflicting

## 1. Beginner baseline

Pairing must work using only:
- Server LAN IP;
- installation CA fingerprint;
- Android device on the reachable LAN.

No DNS/mDNS is required.

## 2. Pairing payload v2

Canonical logical structure:

```json
{
  "contract": "bergahallen-ktm-pairing",
  "version": 2,
  "instance_uid": "...",
  "preferred_url": "https://192.168.1.50",
  "endpoint_mode": "simple_ip",
  "endpoints": [
    {
      "type": "ip",
      "url": "https://192.168.1.50",
      "priority": 1
    }
  ],
  "tls_ca_spki_sha256": "...",
  "server_api": 1,
  "tls_contract": 2
}
```

Optional endpoints may include:
- `mdns`;
- `dns`.

IP remains valid independently of them.

## 3. Trusted QR bootstrap

Canonical beginner source:
- Installer/Manager CLI/terminal after installation;
- `pairing-qr` CLI command;
- equivalent trusted console output.

The terminal should render a directly scannable QR where practical and always print the underlying URL/fingerprint text.

A QR displayed by Manager Web is supplementary.

If Manager Web browser TLS is not yet trusted, user documentation must direct the user to CLI/terminal QR or manual fingerprint comparison instead of clicking through warnings.

## 4. QR validation

Before credentials:
- Android obtains presented server chain;
- validates expected CA SPKI fingerprint from QR;
- validates instance UID/endpoint consistency;
- validates leaf endpoint identity (IP SAN for IP URL);
- only then sends login/pairing credentials.

Mismatch = hard failure.

## 5. Manual IP pairing

User may enter:

`192.168.1.50`

Android normalizes to:

`https://192.168.1.50`

Before credentials:
- connect for identity inspection only;
- show CA fingerprint;
- require comparison with fingerprint shown by Installer/Manager;
- require explicit confirmation;
- pin CA.

No "trust any certificate" control.

## 6. Optional discovery

mDNS, broadcast discovery or other discovery may pre-fill address information.

Discovery is not trusted identity.

Trust still comes from:
- QR out-of-band fingerprint;
- or explicit manual fingerprint comparison.

## 7. Address change under same CA

If a bound Simple-IP server moves to a new IP:
- Android may accept a user-entered/discovered new URL only after the new endpoint presents the SAME pinned CA and SAME instance UID;
- leaf must validate for the new IP;
- no new CA trust decision is required.

If CA differs:
- reject;
- explicit re-pair required.

## 8. Pairing v1 compatibility

Android dev.4 may parse v1 payloads for development/backward compatibility.

Final dev.4 canonical pairing emitted by Installer must be v2.

A v1 `.local` payload must never force the user to depend on mDNS when an IP endpoint is available.
