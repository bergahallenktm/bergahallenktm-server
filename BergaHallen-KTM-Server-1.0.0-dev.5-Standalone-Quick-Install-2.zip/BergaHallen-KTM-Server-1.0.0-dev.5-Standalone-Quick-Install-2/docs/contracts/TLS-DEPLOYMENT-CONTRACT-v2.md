# BergaHallen KTM – TLS Deployment Contract v2

**Status:** CANONICAL / APPROVED  
**Supersedes:** TLS Deployment Contract v1 where conflicting

## 1. Baseline requirement

Production Server Mode must work over HTTPS by LAN IP address without DNS or mDNS.

Minimum required baseline:

`https://<selected-LAN-IPv4>/`

mDNS and custom DNS are optional enhancements.

## 2. Trust model

Each installation retains one private local CA.

Installer/Manager owns:
- CA key/certificate;
- Server leaf key/certificate;
- TLS state.

Android pins the installation CA SPKI fingerprint per server.

## 3. Endpoint modes

`simple_ip`
- mandatory;
- default;
- no name-service dependency.

`mdns`
- optional;
- `.local` convenience;
- never the only usable endpoint.

`dns`
- optional advanced mode;
- operator supplies managed FQDN.

## 4. Certificate SAN rules

For IP URL:
- selected LAN IP MUST be encoded as SAN `iPAddress`;
- certificate identity validation uses that exact IP.

For DNS URL:
- FQDN MUST be SAN `dNSName`.

A leaf may contain multiple SAN entries when justified:
- selected IP;
- additional current LAN IPs;
- optional `.local`;
- optional advanced FQDN.

Do not rely on Common Name for endpoint validation.

## 5. Simple IP selection

Installer identifies suitable non-loopback LAN IPv4 addresses.

Reject as automatic default:
- loopback;
- Docker/container bridge-only addresses;
- obvious virtual/internal interfaces not reachable by the intended LAN client where detectable;
- link-local fallback unless no better option and clearly disclosed.

If one suitable address:
- preselect automatically.

If several:
- show plain numbered choices, for example:
  `1. 192.168.1.50 – enp3s0`
  `2. 10.10.20.15 – ens18`

Allow Advanced users to specify an address explicitly.

## 6. Dynamic LAN IP

Simple IP mode stores selected interface/address identity in TLS state.

When the active LAN IP changes:
- Manager detects certificate SAN mismatch/current-address change;
- leaf may be reissued automatically under the same CA;
- CA remains unchanged;
- TLS state updates atomically;
- QR/status information updates.

CA rotation is NOT needed for ordinary DHCP address change.

## 7. Server listener

Server continues direct HTTPS termination.

Canonical internal port:
`8443`

Canonical production host port:
`443`

No normal LAN cleartext listener.

Host-local diagnostics may remain loopback-only.

## 8. TLS state schema v2

Minimum logical fields:

```json
{
  "schema_version": 2,
  "instance_uid": "...",
  "endpoint_mode": "simple_ip",
  "canonical_https_url": "https://192.168.1.50",
  "selected_ip": "192.168.1.50",
  "selected_interface": "ens18",
  "optional_mdns_name": null,
  "optional_dns_name": null,
  "tls_ca_spki_sha256": "...",
  "ca_cert_sha256": "...",
  "leaf_cert_sha256": "..."
}
```

Implementations may add fields but must preserve these semantics.

## 9. Migration from schema v1

Installer migrates v1 -> v2 without rotating CA.

For an existing dev.4 test installation:
- retain CA;
- select/detect LAN IP;
- issue new leaf with IP SAN if needed;
- preserve instance UID;
- preserve deletion journal/key;
- update state atomically.

## 10. Metadata

`/api/v1/meta` remains additive and should expose:

- `tls_contract=2`
- `tls_state_schema=2`
- `https_required=true`
- `canonical_https_url`
- `tls_endpoint_mode`
- `tls_ca_spki_sha256`
- `instance_uid`

Optional endpoint alternatives may also be advertised.

## 11. Browser access

Browser access by IP is supported when:
- the leaf has the IP SAN;
- the user/device trusts the local CA.

Installer provides supported CA export/install guidance.

Bypassing certificate warnings is not the normal supported workflow.

## 12. Fail closed

Production TLS mode must not silently fall back to LAN HTTP if:
- TLS material is invalid;
- SAN does not match canonical endpoint;
- key/certificate mismatch exists.
