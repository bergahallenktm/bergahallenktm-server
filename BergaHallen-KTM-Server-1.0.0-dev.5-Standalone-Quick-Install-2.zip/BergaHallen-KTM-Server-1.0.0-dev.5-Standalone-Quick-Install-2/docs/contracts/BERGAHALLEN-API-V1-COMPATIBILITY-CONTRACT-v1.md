# BergaHallen KTM API v1 Compatibility Contract v1

**Server implementation:** 3.9.13 / runtime 0.9.13  
**DB schema:** 20  
**API:** v1  
**Status:** SERVER-APPROVED CANDIDATE / ANDROID SIGN-OFF PENDING

## 1. Scope

This contract hardens the already deployed API v1 without changing existing domain semantics. It defines compatibility discovery, the error envelope, retry semantics and endpoint replay/idempotency policy needed by Android Offline First.

Breaking changes to API v1 are forbidden. New response fields and capabilities must be additive. A breaking wire-semantic change requires a new API or explicit contract version coordinated with clients.

## 2. Compatibility discovery

`GET /api/v1/meta` remains the mandatory final verify-before-bind endpoint and remains authoritative for `instance_uid`.

3.9.13 adds these stable additive fields:

```text
api_version                         1
min_supported_api_version           1
api_compatibility_contract_version  1
error_envelope_version              1
retry_policy_version                1
idempotency_policy_version          1
api_compatibility_policy            api_v1_additive
api_compatibility_path              /api/v1/compatibility
```

The matching capabilities are advertised under `/meta.capabilities`:

```text
api_v1_compatibility_manifest = true
stable_error_envelope          = true
request_id_correlation         = true
endpoint_retry_policy          = true
endpoint_idempotency_policy    = true
```

`GET /api/v1/compatibility` is an additive descriptive manifest. It does not replace `/meta` for identity verification.

`/api/v1/health`, `/api/v1/meta` and `/api/v1/compatibility` use `Cache-Control: no-store`.

## 3. Old/new-client policy

### Old client -> new server

Supported while the client continues to use API v1 semantics it understands. Unknown additive response fields/capabilities may be ignored. The server must not require an old client to write back fields it cannot know about merely because the server added them.

### New client -> old server

The client must evaluate `/meta`. It may use documented legacy fallbacks for absent additive fields, degrade individual unsupported features, or block operations whose required contract is unavailable. It must not infer support from `app_version` alone.

### Unknown fields/capabilities

- unknown response fields: ignore safely and preserve server authority;
- unknown capability: do not enable unknown behavior;
- absent additive field: only use the fallback defined by that feature contract.

## 4. Stable API error envelope

All API errors are normalized to contain at least:

```json
{
  "success": false,
  "code": "STABLE_MACHINE_CODE",
  "message": "Human readable text",
  "retryable": false,
  "request_id": "correlation-id"
}
```

The legacy `error` field is preserved when a route already supplies it.

Optional fields can include:

```text
details
required_permission
role
authorization_revision
auth_state
authentication_required
reauth_required
```

Clients branch on `code`, HTTP status and explicit metadata, not localized/free-form `message` or `error` text.

`X-Request-Id` is accepted when it matches the safe correlation-id grammar and is returned as both response header and error-envelope `request_id`. Otherwise the server generates a UUID. API responses also expose `X-Bergahallen-Api-Version: 1`.

Malformed JSON is normalized as `400 INVALID_JSON`. Payloads over the configured limit are normalized as `413 PAYLOAD_TOO_LARGE`. Unexpected 5xx responses do not expose raw internal exception text to the client; the full internal error remains server-side with the request ID.

## 5. `retryable` is NOT auto-replay permission

`retryable=true` means the failure condition is transient. It does **not** mean a mutation is safe to execute again.

Stable interpretation:

- 400/401/403/404/409/410/422 => non-retryable without user action/reconciliation;
- 429 => retryable condition;
- known temporary service/database/server conditions and 5xx => retryable condition;
- `SESSION_EXPIRED` / `AUTH_REQUIRED` => reauthenticate, not automatic mutation replay;
- permission denial (403) => authoritative denial, not local fallback.

If a mutation's network response is lost, commit state is unknown. Clients must apply the endpoint policy below rather than using `retryable` alone.

## 6. Endpoint replay policy

The machine-readable source of truth is `GET /api/v1/compatibility` -> `endpoint_policies[]`.

Policy values:

```text
safe        operation is intrinsically idempotent or target-state based
conditional replay only when the documented stable idempotency key is reused
reconcile   refresh/reconcile authoritative state before deciding to resend
never       never blind-auto-replay after uncertain commit state
```

### Safe/inherent

- all GET `/api/v1/*` reads;
- `POST /matches/check-availability` validation;
- login/logout session operations;
- hidden-role reveal (private read semantics);
- Day/Night state-set; same target state is success/no-op;
- timer pause/resume target-state operations;
- card-link preference state-set.

### Conditional idempotency

- `POST /api/v1/decks` requires the same stable `client_uid`;
- `POST /api/v1/matches/offline-sync` requires the same canonical `client_match_uid` and exact target server realm;
- registration can only be retried as the exact same name/password request and is not a generic client mutation key.

### Reconcile / revision guarded

- deck update/archive/restore use `expected_revision` when Deck Contract v2 is advertised;
- locale update uses the locale revision contract;
- CSV deck import must reconcile after uncertain commit rather than assuming name conflict equals a stable replay receipt.

### Never blind-auto-retry

At minimum:

- online match start;
- abort;
- life/poison/commander-tax/commander-damage delta mutations;
- concede;
- undo;
- reorder seats;
- next turn;
- finish;
- hidden-role target/throne mutations;
- admin mutations unless a future endpoint-specific contract explicitly defines stronger idempotency.

For these operations an uncertain response requires authoritative refresh/reconciliation or explicit user action.

## 7. Offline First / multi-server boundary

Existing frozen rules remain unchanged:

- server identity is `instance_uid`;
- numeric IDs are scoped by `instance_uid`;
- endpoint/URL/IP/hostname is a replaceable hint;
- pending work must stay bound to the exact target `instance_uid`;
- no request may be replayed against another realm because it is reachable at a familiar URL;
- Guest Match creates no server-bound replay work.

## 8. Existing contract versions preserved

3.9.13 keeps the existing feature contracts and DB schema unchanged, including Discovery v1, Account v1, Authorization v1, Deck v2, Offline Sync v5, History v6, Stats v5, Locale v1 and Day/Night v1. `account_model` remains `account_player_1to1`.

## 9. Freeze gate

Server-side implementation and tests constitute a **SERVER-APPROVED CANDIDATE**. Cross-client `API v1 Compatibility Contract v1 = FROZEN` requires Android 3.9.13 confirmation/field verification. No later server step may claim a breaking API v1 change while this candidate is awaiting sign-off.
