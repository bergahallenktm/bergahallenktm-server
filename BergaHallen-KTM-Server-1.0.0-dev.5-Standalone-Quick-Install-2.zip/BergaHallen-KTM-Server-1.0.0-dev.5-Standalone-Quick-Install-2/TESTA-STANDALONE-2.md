# Test – Standalone Quick Install 2 reinstall

Run this only on a disposable/test Ubuntu 24.04 LTS amd64 host.

## A. Fresh install

```bash
sudo ./install.sh
sudo bergahallen-ktm status
sudo bergahallen-ktm pairing
```

Record:

```bash
sudo jq -r '.instance_uid, .tls_ca_spki_sha256, .selected_ip' /etc/bergahallen-ktm/tls/tls-state.json
```

Create at least one harmless test object in the Webapp (for example a player/deck) so persistence is visible.

## B. Normal uninstall (preserve data)

```bash
sudo bergahallen-ktm uninstall
```

Expected:
- `/opt/bergahallen-ktm-server` is removed;
- `/etc/bergahallen-ktm` remains;
- the three `bergahallen-ktm-*` Docker volumes remain;
- TCP/443 is free.

## C. Reinstall from the extracted Standalone Quick Install 2 release

```bash
sudo ./install.sh
```

Expected output includes:

```text
Detected a previous standalone uninstall with preserved data; entering safe reinstall mode.
BergaHallen KTM Server reinstalled successfully.
Existing database, CA and instance identity were preserved.
```

Then run:

```bash
sudo bergahallen-ktm status
sudo jq -r '.instance_uid, .tls_ca_spki_sha256, .selected_ip' /etc/bergahallen-ktm/tls/tls-state.json
```

PASS criteria:
- Server is healthy.
- `instance_uid` is identical to before uninstall.
- CA SPKI fingerprint is identical to before uninstall.
- previously created Webapp test data is still present.
- Android pairing still identifies the same server/CA.

If the LAN IP changed while the Server was uninstalled, the new IP may differ, but the CA SPKI must remain identical.

## D. Optional destructive clean-removal test

```bash
sudo bergahallen-ktm uninstall --purge-data
sudo ./install.sh
```

Expected after the new clean install:
- a new `instance_uid`;
- a new CA SPKI fingerprint;
- old application data is absent.
