const express = require('express');
const http = require('http');
const https = require('https');
const path = require('path');
const crypto = require('crypto');
const session = require('express-session');
const SqliteSessionStore = require('./server/sqliteSessionStore');
const { applyPendingRestore } = require('./server/restoreBootstrap');
const { resolveSessionSecret } = require('./server/sessionSecret');
const { reapplyDeletionJournal, ACCOUNT_DELETION_CONTRACT_VERSION, DELETION_TOMBSTONE_JOURNAL_SCHEMA } = require('./server/accountDeletionService');
const { diagnostics: privacyJournalDiagnostics } = require('./server/privacyDeletionJournal');
const { prepareStartupUpgrade, finalizeStartupUpgrade, markStartupUpgradeFailed, publicUpgradeStatus } = require('./server/upgradeSafety');
const { loadTlsRuntime, publicTlsMetadata, setActiveTlsRuntime } = require('./server/tlsRuntime');

// En staged restore appliceras innan SQLite öppnas av db.js.
// Det gör databasbytet säkert även när servern kör med WAL.
const startupRestore = applyPendingRestore();

// Post-v1.0 Upgrade Foundation: inspectera källdatabasen och skapa en verifierad
// pre-upgrade-backup innan db.js får köra framtida startup-migreringar. På nuvarande
// schema 21 är detta en ren no-op, men mekanismen blir aktiv automatiskt när ett
// framtida Serverpaket höjer target schema i release-manifestet.
const startupUpgrade = prepareStartupUpgrade();

let db;
try {
  db = require('./server/db');
} catch (err) {
  markStartupUpgradeFailed(err);
  throw err;
}

// Privacy deletion journal is reapplied after a staged DB restore and before
// normal service becomes available. This prevents managed restore from
// resurrecting accounts that were validly deleted after the backup was made.
let startupDeletionReapply = null;
try {
  startupDeletionReapply = reapplyDeletionJournal({ db });
} catch (err) {
  try { db.close(); } catch (_) {}
  throw err;
}

let completedStartupUpgrade = null;
try {
  completedStartupUpgrade = finalizeStartupUpgrade(db);
} catch (err) {
  markStartupUpgradeFailed(err);
  try { db.close(); } catch (_) {}
  throw err;
}

// dev.4 TLS foundation: validate Installer-owned TLS identity before any
// network listener becomes available. In production, missing/corrupt TLS
// material is fail-closed and never falls back to LAN cleartext.
let tlsRuntime;
try {
  tlsRuntime = loadTlsRuntime({ instanceUid: db.instanceUid });
  setActiveTlsRuntime(tlsRuntime);
} catch (err) {
  try { db.close(); } catch (_) {}
  throw err;
}
const { defaultErrorCode, normalizeErrorBody } = require('./server/apiHelpers');
const { API_VERSION, MIN_SUPPORTED_API_VERSION, compatibilityMeta, compatibilityManifest } = require('./server/apiCompatibility');
const { ENGINE_VERSION, OPTIONS_REVISION, RULES_SCHEMA_VERSION, RULES_VERSION } = require('./server/matchFormatEngine');
const { OFFLINE_SYNC_VERSION, HISTORY_CONTRACT_VERSION, STATS_CONTRACT_VERSION, DECK_CONTRACT_VERSION, DAY_NIGHT_CONTRACT_VERSION, DISCOVERY_CONTRACT_VERSION, CAPABILITIES } = require('./server/apiContract');
const { LOCALE_SETTINGS_VERSION, publicLocalizationMetadata, localeSettingsForPlayer, legacyLocaleForPlayer } = require('./server/localeSettings');
const { ACCOUNT_CONTRACT_VERSION, AUTHORIZATION_CONTRACT_VERSION, ACCOUNT_MODEL, roleForPlayer, authorizationForPlayer, accountIdentityForPlayer } = require('./server/accountPolicy');
const authRoutes = require('./server/routes/auth');
const deckRoutes = require('./server/routes/decks');
const matchRoutes = require('./server/routes/matches');
const statsRoutes = require('./server/routes/stats');
const adminRoutes = require('./server/routes/admin');
const discoveryRoutes = require('./server/routes/discovery');
const { createAccountDeletionRouter } = require('./server/routes/accountDeletion');
const { ensureAdminAccount } = require('./server/adminBootstrap');
const packageInfo = require('./package.json');
const { scheduleDailyBackups } = require('./server/backup');
const localLogger = require('./server/localLogger');
const { BACKUP_RESTORE_REPAIR_VERSION } = require('./server/recovery');

const app = express();
const PORT = Number(process.env.PORT || 3010);
const HTTPS_PORT = Number(tlsRuntime.httpsPort || 8443);
const sessionSecret = resolveSessionSecret();

// Säkerställ att installationen alltid har exakt minst ett nåbart superuser-konto.
// Första lösenordet kommer från ADMIN_PASSWORD eller genereras och skrivs en gång i loggen.
ensureAdminAccount(db);

app.disable('x-powered-by');

// Säkerhetsheaders som inte ändrar API-semantik men minskar onödig browser-yta.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

// Ett request-id gör fel från webb och Android betydligt enklare att matcha mot
// serverloggen. Klienten får tillbaka samma id i X-Request-Id och i API-fel.
app.use((req, res, next) => {
  const suppliedRequestId = String(req.get('X-Request-Id') || '').trim();
  const requestId = /^[A-Za-z0-9._:-]{1,128}$/.test(suppliedRequestId) ? suppliedRequestId : crypto.randomUUID();
  req.requestId = requestId;
  res.setHeader('X-Request-Id', requestId);
  const isApiRequest = req.path === '/api' || req.path.startsWith('/api/');
  if (isApiRequest) res.setHeader('X-Bergahallen-Api-Version', String(API_VERSION));

  // 3.9.8.2.1: alla API-fel får samma maskinläsbara envelope utan att äldre
  // routes behöver skrivas om på en gång. Befintliga `error`-fält bevaras,
  // samtidigt som Android alltid får code/message/retryable/request_id.
  if (isApiRequest) {
    const originalJson = res.json.bind(res);
    res.json = (body) => {
      if (Number(res.statusCode || 200) >= 400 && body && typeof body === 'object' && !Array.isArray(body)) {
        body = normalizeErrorBody(body, res.statusCode, requestId);
      }
      return originalJson(body);
    };
  }
  next();
});

// Body parsing runs after the API correlation/error-envelope middleware so
// malformed JSON and payload-limit failures receive the same v1 error shape.
app.use(express.json({ limit: '10mb' }));

app.get('/account-deletion', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(path.join(__dirname, 'public', 'account-deletion.html'));
});

app.use(express.static(path.join(__dirname, 'public')));

// Persistent sessionslagring i SQLite. sessions.db ligger i samma persistenta
// Docker-volym som appdatabasen, men i en separat fil. Det gör att login för
// webb och Android överlever containeromstarter utan Express MemoryStore.
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;
const sessionStore = new SqliteSessionStore({
  ttlMs: SESSION_TTL_MS,
  dataDir: process.env.BERGAHALLEN_DATA_DIR ? path.resolve(process.env.BERGAHALLEN_DATA_DIR) : undefined
});

// Installer/Manager sätter normalt SESSION_SECRET. Vid manuell lokal start utan
// miljövariabel skapas i stället en slumpmässig hemlighet som sparas i datamappen
// och återanvänds efter omstart. Själva hemligheten loggas aldrig.
if (sessionSecret.source !== 'environment') {
  console.warn(`[session] SESSION_SECRET saknas; använder persistent lokalt genererad hemlighet (${sessionSecret.path}).`);
}
app.use(session({
  store: sessionStore,
  secret: sessionSecret.secret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: SESSION_TTL_MS,
    sameSite: 'lax',
    httpOnly: true,
    // Production Server Mode is HTTPS-only from dev.4. Secure cookies ensure
    // login/deletion re-auth state can never be sent over the diagnostic HTTP path.
    secure: !!tlsRuntime.httpsRequired
  }
}));

// Validera sessionskontot mot databasen på varje request. auth_revision gör att
// ett administrativt lösenordsbyte eller borttagning omedelbart kan ogiltigförklara
// gamla webb-/Androidsessioner utan att vi behöver känna till deras cookie-id:n.
app.use((req, res, next) => {
  if (!req.session?.user?.id) return next();
  const player = db.prepare('SELECT id,entity_uid,name,card_link_preference,preferred_locale,locale_mode,locale_preference,locale_revision,is_admin,archived,auth_revision FROM players WHERE id=?').get(req.session.user.id);
  const sessionRevision = req.session.user.auth_revision;
  const revisionChanged = sessionRevision !== undefined && Number(sessionRevision) !== Number(player?.auth_revision || 0);
  if (!player || player.archived || revisionChanged) {
    // Preserve a request-local reason after destroying the stale session so
    // protected API middleware can return deterministic 401 semantics.
    req.authFailureCode = 'SESSION_EXPIRED';
    return req.session.destroy(() => next());
  }
  req.session.user = {
    id: player.id,
    name: player.name,
    card_link_preference: player.card_link_preference || 'scryfall',
    entity_uid: player.entity_uid || null,
    preferred_locale: legacyLocaleForPlayer(player),
    locale_settings: localeSettingsForPlayer(player),
    is_admin: !!player.is_admin,
    role: roleForPlayer(player),
    authorization: authorizationForPlayer(player),
    account: accountIdentityForPlayer(player),
    auth_revision: Number(player.auth_revision || 0)
  };
  next();
});

app.use(localLogger.requestMiddleware);

function systemInfo() {
  return {
    status: 'ok',
    app: 'Bergahallen KTM',
    app_version: packageInfo.version,
    api_version: API_VERSION,
    min_supported_api_version: MIN_SUPPORTED_API_VERSION,
    ...compatibilityMeta(),
    schema_version: db.schemaVersion,
    instance_uid: db.instanceUid,
    session_store: 'sqlite',
    admin_api: true,
    match_engine_version: ENGINE_VERSION,
    rules_schema_version: RULES_SCHEMA_VERSION,
    match_rules_version: RULES_VERSION,
    match_options_revision: OPTIONS_REVISION,
    offline_sync_version: OFFLINE_SYNC_VERSION,
    history_contract_version: HISTORY_CONTRACT_VERSION,
    stats_contract_version: STATS_CONTRACT_VERSION,
    locale_settings_version: LOCALE_SETTINGS_VERSION,
    deck_contract_version: DECK_CONTRACT_VERSION,
    day_night_contract_version: DAY_NIGHT_CONTRACT_VERSION,
    discovery_contract_version: DISCOVERY_CONTRACT_VERSION,
    account_contract_version: ACCOUNT_CONTRACT_VERSION,
    authorization_contract_version: AUTHORIZATION_CONTRACT_VERSION,
    account_model: ACCOUNT_MODEL,
    account_deletion_contract: ACCOUNT_DELETION_CONTRACT_VERSION,
    deletion_tombstone_journal_schema: DELETION_TOMBSTONE_JOURNAL_SCHEMA,
    privacy_journal_status: privacyJournalDiagnostics().status,
    ...publicTlsMetadata(tlsRuntime),
    localization: publicLocalizationMetadata(),
    capabilities: {
      ...CAPABILITIES,
      match_engine: ENGINE_VERSION,
      offline_sync: OFFLINE_SYNC_VERSION
    },
    upgrade_safety_version: 1,
    backup_restore_repair_version: BACKUP_RESTORE_REPAIR_VERSION,
    upgrade_status: publicUpgradeStatus(),
    server_time: new Date().toISOString()
  };
}

// Både legacy-/api och versionslåst /api/v1 hålls igång. Utvecklingswebben
// använder /api/v1 och fortsatt Androidutveckling ska använda samma kontrakt.
app.get(['/api/health', '/api/v1/health'], (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    db.prepare('SELECT 1 AS ok').get();
    sessionStore.ping();
    res.json(systemInfo());
  } catch (err) {
    res.status(503).json({ error: 'Serverns datalagring svarar inte.', code: 'DATABASE_UNAVAILABLE' });
  }
});

app.get(['/api/meta', '/api/v1/meta'], (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(systemInfo());
});

// API v1 compatibility manifest. This endpoint is descriptive and additive;
// /api/v1/meta remains the final verify-before-bind source for server identity.
app.get(['/api/compatibility', '/api/v1/compatibility'], (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    ...compatibilityManifest(),
    app_version: packageInfo.version,
    schema_version: db.schemaVersion,
    instance_uid: db.instanceUid,
    upgrade_safety_version: 1,
    backup_restore_repair_version: BACKUP_RESTORE_REPAIR_VERSION,
    upgrade_status: publicUpgradeStatus(),
    server_time: new Date().toISOString()
  });
});

const accountDeletionRoutes = createAccountDeletionRouter({ sessionStore });

// Legacy API – nuvarande Androidkod och äldre klienter fortsätter fungera.
app.use('/api/auth', authRoutes);
app.use('/api', deckRoutes);
app.use('/api', matchRoutes);
app.use('/api', statsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', discoveryRoutes);

// Stabilt versionsprefix för fortsatt Androidutveckling.
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/account', accountDeletionRoutes);
app.use('/api/v1', deckRoutes);
app.use('/api/v1', matchRoutes);
app.use('/api/v1', statsRoutes);
app.use('/api/v1/admin', adminRoutes);
app.use('/api/v1', discoveryRoutes);

app.use('/api', (req, res) => {
  console.warn(`⚠️ [${req.requestId}] Okänd endpoint: ${req.method} ${req.originalUrl}`);
  res.status(404).json({ error: 'Endpoint hittades inte.', code: 'ENDPOINT_NOT_FOUND' });
});

app.use((err, req, res, next) => {
  const requestId = req.requestId || 'saknas';
  const status = Number(err?.status || err?.statusCode || 500);
  const safeStatus = Number.isInteger(status) && status >= 400 && status <= 599 ? status : 500;
  const parserCode = err?.type === 'entity.parse.failed'
    ? 'INVALID_JSON'
    : (err?.type === 'entity.too.large' ? 'PAYLOAD_TOO_LARGE' : null);
  const exposeMessage = safeStatus < 500 || err?.expose === true;
  const publicMessage = parserCode === 'INVALID_JSON'
    ? 'JSON-payloaden kunde inte tolkas.'
    : (parserCode === 'PAYLOAD_TOO_LARGE'
      ? 'API-payloaden är för stor.'
      : (exposeMessage ? (err?.message || 'API-anropet kunde inte genomföras.') : 'Ett internt serverfel uppstod.'));

  console.error(`\n❌ [${new Date().toISOString()}] [${requestId}] Fel vid ${req.method} ${req.originalUrl}`);
  console.error(err);
  localLogger.error('system', 'Unhandled request error', { request_id: requestId, method: req.method, path: req.originalUrl, error: err?.message || String(err) });
  if (res.headersSent) return next(err);
  res.status(safeStatus).json({
    error: publicMessage,
    code: parserCode || err?.code || defaultErrorCode(safeStatus),
    request_id: requestId
  });
});

// Public v1.0 har en etablerad API-/integrationssvit som täcker auth, decks,
// match/replay, historik/statistik och centrala migreringar. /api/v1 är fortsatt
// det frysta kontraktet för webb och Android; nya regressionsfall ska läggas till
// när ett konkret fel eller en ny stödd publik uppgraderingsväg introduceras.

const networkServers = [];

function storageHealthy() {
  db.prepare('SELECT 1 AS ok').get();
  sessionStore.ping();
}

function diagnosticHandler(req, res) {
  const requestPath = String(req.url || '').split('?')[0];
  if (!['/api/health', '/api/v1/health', '/healthz'].includes(requestPath)) {
    res.statusCode = 404;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.end(JSON.stringify({ status:'not_found' }));
    return;
  }
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  try {
    storageHealthy();
    res.statusCode = 200;
    res.end(JSON.stringify(systemInfo()));
  } catch (_) {
    res.statusCode = 503;
    res.end(JSON.stringify({ status:'error', code:'DATABASE_UNAVAILABLE' }));
  }
}

if (tlsRuntime.httpsRequired) {
  const httpsServer = https.createServer(tlsRuntime.tlsOptions, app);
  httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
    console.log(`🔒 Bergahallen KTM HTTPS körs på intern port ${HTTPS_PORT} | ${tlsRuntime.canonicalHostname} | API v${API_VERSION} | DB schema v${db.schemaVersion}`);
    localLogger.info('system', 'HTTPS server started', {
      port: HTTPS_PORT,
      canonical_https_port: tlsRuntime.canonicalHttpsPort,
      canonical_hostname: tlsRuntime.canonicalHostname,
      tls_contract: tlsRuntime.tlsContract,
      tls_ca_spki_sha256: tlsRuntime.caSpkiSha256,
      api_version: API_VERSION,
      schema_version: db.schemaVersion,
      app_version: packageInfo.version
    });
  });
  networkServers.push(httpsServer);

  if (tlsRuntime.diagnosticHttpEnabled) {
    const diagnosticServer = http.createServer(diagnosticHandler);
    diagnosticServer.listen(tlsRuntime.diagnosticHttpPort, tlsRuntime.diagnosticHttpHost, () => {
      console.log(`🩺 Lokal HTTP-diagnostik: ${tlsRuntime.diagnosticHttpHost}:${tlsRuntime.diagnosticHttpPort}`);
      localLogger.info('system', 'Loopback diagnostic HTTP started', {
        host: tlsRuntime.diagnosticHttpHost,
        port: tlsRuntime.diagnosticHttpPort
      });
    });
    networkServers.push(diagnosticServer);
  }
} else {
  const httpServer = http.createServer(app);
  httpServer.listen(PORT, tlsRuntime.diagnosticHttpHost, () => {
    console.log(`⚔️ Bergahallen KTM utvecklings-HTTP körs på ${tlsRuntime.diagnosticHttpHost}:${PORT} | API v${API_VERSION} | DB schema v${db.schemaVersion}`);
    localLogger.info('system', 'Development HTTP server started', { port: PORT, host: tlsRuntime.diagnosticHttpHost, api_version: API_VERSION, schema_version: db.schemaVersion, app_version: packageInfo.version });
  });
  networkServers.push(httpServer);
}

const backupScheduler = scheduleDailyBackups(db);
if (startupUpgrade?.required) {
  localLogger.warn('database', completedStartupUpgrade?.completed ? 'Server upgrade completed during startup' : 'Server upgrade prepared during startup', {
    source_schema: startupUpgrade?.state?.source_schema ?? startupUpgrade?.database?.schema_version ?? null,
    target_schema: startupUpgrade?.state?.target_schema ?? startupUpgrade?.target_schema ?? db.schemaVersion,
    support_level: startupUpgrade?.state?.support_level ?? startupUpgrade?.support_level ?? null,
    backup_name: startupUpgrade?.state?.backup_name ?? null,
    completed: !!completedStartupUpgrade?.completed
  });
}
if (startupDeletionReapply?.reapplied) {
  localLogger.warn('database', 'Privacy deletion tombstones reapplied during startup', {
    reapplied: startupDeletionReapply.reapplied,
    journal_schema_version: startupDeletionReapply.journal_schema_version
  });
}
if (startupRestore?.applied) {
  localLogger.warn('database', 'Database restore applied during startup', startupRestore);
} else if (startupRestore?.failed) {
  localLogger.error('database', 'Staged database restore was rejected during startup', startupRestore);
}

let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n🛑 ${signal}: stänger Bergahallen KTM kontrollerat...`);
  localLogger.info('system', 'Server shutdown requested', { signal });

  try { backupScheduler?.stop?.(); } catch (_) {}

  const forceTimer = setTimeout(() => {
    console.error('❌ Tvingad avstängning efter timeout.');
    localLogger.error('system', 'Forced shutdown after timeout', { signal });
    process.exit(1);
  }, 10000);
  forceTimer.unref();

  let remaining = networkServers.length;
  const finish = () => {
    remaining -= 1;
    if (remaining > 0) return;
    try {
      db.pragma('wal_checkpoint(TRUNCATE)');
    } catch (err) {
      console.warn('⚠️ Kunde inte checkpointa WAL vid avstängning:', err.message);
    }
    try {
      sessionStore.close();
    } catch (err) {
      console.warn('⚠️ Kunde inte stänga sessionsdatabasen rent:', err.message);
    }
    try {
      db.close();
    } catch (err) {
      console.warn('⚠️ Kunde inte stänga databasen rent:', err.message);
    }
    clearTimeout(forceTimer);
    console.log('✅ Server och databas stängda.');
    process.exit(0);
  };

  if (remaining === 0) {
    remaining = 1;
    return finish();
  }
  for (const networkServer of networkServers) {
    try { networkServer.close(finish); }
    catch (_) { finish(); }
  }
}

process.once('SIGTERM', () => shutdown('SIGTERM'));
process.once('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled Promise Rejection:', reason);
  localLogger.error('system', 'Unhandled Promise Rejection', { error: String(reason?.message || reason) });
});
