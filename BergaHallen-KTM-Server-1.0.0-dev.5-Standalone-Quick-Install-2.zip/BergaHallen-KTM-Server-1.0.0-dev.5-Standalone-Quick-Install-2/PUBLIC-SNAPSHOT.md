# Public source snapshot notice

This directory is a **derived GitHub/public source snapshot** of the BergaHallen KTM Server/Webapp frozen baseline.

## Canonical source baseline

- Suite: `1.0.0-dev.5`
- Server component: frozen `r2` bytes (historical package name retained `TEST-CANDIDATE-r2`)
- Canonical frozen Full ZIP SHA256:
  `226eddadffe593af4bdba9f7e604691b3c0d33129e71380c575970acfd786633`
- API: 1
- DB schema: 21
- TLS Contract: 2
- TLS State schema: 2

## Relationship to the active project

This public snapshot is a publication side-track only.

It does **not**:

- replace the frozen source artifact;
- change the frozen component status;
- establish a new Suite baseline;
- create a dev.6 Server component;
- change future Server/Webapp development history.

Future active development must continue from the Project Control canonical baseline, not from this cleaned GitHub package.

## Public-clean transformations

The public snapshot intentionally:

- removes historical implementation-step documentation;
- removes internal handoffs, build logs, field logs and test result files;
- removes the internal regression corpus and its static TLS test private key;
- removes test-only npm script entries that would reference the excluded internal corpus;
- replaces one user-specific name used only in a source-code comment with a neutral example;
- replaces the release-package `.gitignore` with a GitHub-appropriate version;
- adds `.dockerignore` and concise public documentation.

No application/runtime logic was intentionally changed by this cleanup.
