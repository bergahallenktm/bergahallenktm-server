# Standalone Quick Install – verification record

Distribution: `github-standalone.2`  
Runtime basis: frozen Server/Webapp `1.0.0-dev.5 / r2`

## Verified while packaging

- 73 runtime/operational files compared against the cleaned public dev.5/r2 snapshot: **0 differences**.
- Bash syntax check: `install.sh`, `standalone/lib.sh`, management command and uninstall script: **PASS**.
- JavaScript syntax check across Server/Webapp/scripts: **PASS**.
- JSON parsing for all packaged JSON files: **PASS**.
- Secret hygiene scan: no packaged PEM private key: **PASS**.
- Local-environment hygiene scan for known development home paths/IP: **PASS**.
- TLS bootstrap unit smoke using generated ECDSA P-256 CA + IP leaf: Server `tlsRuntime` accepted generated TLS State schema v2 and exact IP SAN: **PASS**.
- Pairing Contract v2 payload generation smoke: **PASS**.

## Not claimed by this packaging verification

The complete `sudo ./install.sh` flow was not executed against a disposable clean Ubuntu 24.04 VM in this packaging environment. The package therefore remains a **pre-release standalone distribution** until such a fresh-machine field test is completed.

The underlying frozen Server runtime itself was previously field verified separately; this statement concerns only the new standalone bootstrap wrapper.

## Standalone.2 reinstall correction

The wrapper was changed so a normal standalone uninstall that preserves data can be installed again safely. Packaging verification checks that:

- preserved state is accepted only when `standalone-install.json` identifies `github_public_standalone`;
- all three expected Docker volumes must still exist;
- the preserved database `instance_uid` must equal the preserved TLS/install identity before startup;
- the existing local CA and secrets are reused, not regenerated;
- an IP change causes only the leaf certificate to be reissued under the same CA;
- unknown or partial residual state still fails closed;
- `uninstall --purge-data` remains the explicit destructive clean-removal path.

A full host-level uninstall -> reinstall cycle still requires field verification on Ubuntu 24.04 and is not claimed by this packaging-only verification.
