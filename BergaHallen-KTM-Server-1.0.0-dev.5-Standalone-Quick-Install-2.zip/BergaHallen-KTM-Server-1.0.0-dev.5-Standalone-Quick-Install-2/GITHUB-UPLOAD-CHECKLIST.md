# GitHub public upload checklist

This package is prepared to be the root of a public Git repository.

## Before first push

1. Create an empty GitHub repository.
2. Extract this package and use the `bergahallen-ktm-server-public` directory as the repository root.
3. Decide whether you want to add an explicit open-source `LICENSE`. This snapshot deliberately does not choose one for you.
4. Do **not** copy runtime data, `.env`, TLS keys, databases or backups into the repository.
5. Review the staged file list before committing.

Suggested local commands:

```bash
git init
git add .
git status
```

Before committing, confirm that `git status` does **not** show files such as:

```text
.env
*.key
*.pem
*.db
*.db-wal
*.db-shm
data/
tls-state.json
```

Then commit and add your GitHub remote using the repository URL GitHub gives you.

## What should be public

Expected top-level source includes:

```text
server.js
server/
public/
scripts/
Dockerfile
docker-compose.yml
docker-compose.dev-http.yml
.env.example
package.json
package-lock.json
BERGAHALLEN-SERVER-RELEASE.json
docs/
```

## What is intentionally absent

Do not re-add the internal archive of:

- `TESTRESULTAT-*`
- `BUILD-*.log`
- `HANDOFF-*`
- `OVERLAMNING-*`
- `VERIFIERA-*`
- `UPPDATERA-*`
- historical `STEG*` development notes
- internal TLS test fixture private keys/certificates

Those belong to the private/canonical development history, not the public source repository.
