# Security

## Deployment scope

BergaHallen KTM Server is designed for self-hosted use on a trusted local network. The public snapshot does not claim support for direct Internet exposure.

Production Server Mode is HTTPS-only and fail-closed. The Installer/Manager owns the local installation CA and certificate lifecycle; the Server consumes the resulting certificate files.

## Secrets

Do not commit:

- `.env` files;
- production TLS private keys;
- CA private keys;
- deletion-journal keys;
- database files or backups;
- generated session secrets;
- credentials or authentication tokens.

The provided `.gitignore` excludes common local secret/data paths. Always review staged changes before pushing.

## Reporting a security issue

Do not post passwords, private keys, database contents or other sensitive data in a public issue. Use a private repository security-reporting channel if one has been configured by the repository owner.
